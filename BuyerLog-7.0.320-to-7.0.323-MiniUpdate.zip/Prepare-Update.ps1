﻿param([string]$InstallPath = '', [switch]$Check)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$temporary = $null

function Read-Json([string]$File) { return Get-Content -LiteralPath $File -Raw -Encoding UTF8 | ConvertFrom-Json }
function Inside([string]$File, [string]$Root) {
    $prefix = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return [IO.Path]::GetFullPath($File).StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)
}
function Safe-Directory([string]$Directory) {
    $current = [IO.Path]::GetFullPath($Directory)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            if (([IO.File]::GetAttributes($current) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Baglanti/junction klasoru kabul edilmez / Linked installation directories are not supported.' }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ($parent -eq $current) { break }
        $current = $parent
    }
}
function Assert-Idle([string]$StateFile, [datetime]$SessionStartedAt) {
    if (-not (Test-Path -LiteralPath $StateFile)) { throw 'Buyer Log acilisinin bitmesini bekleyin / Wait for Buyer Log startup to finish.' }
    $state = Read-Json $StateFile
    if ($state.state -notin @('IDLE','FAILED') -or ($state.pending -and $state.pending.ready) -or ($state.activation -and $state.activation.status -eq 'trial')) {
        throw 'Buyer Log bos durumda olmali; devam eden kontrol/kurulumu once tamamlayin / Buyer Log must be idle; finish the current check or installation first.'
    }
    $checkedAt = [DateTime]::MinValue
    if ($state.lastCheck -is [DateTime]) { $checkedAt = $state.lastCheck.ToUniversalTime() }
    elseif ($state.lastCheck -is [DateTimeOffset]) { $checkedAt = $state.lastCheck.UtcDateTime }
    elseif ($state.lastCheck) { $checkedAt = [DateTimeOffset]::Parse([string]$state.lastCheck).UtcDateTime }
    if ($checkedAt -lt $SessionStartedAt) {
        throw 'Bu oturumdaki otomatik guncelleme kontrolunun bitmesini bekleyin. Gerekirse STABLE kanalinda bir kez kontrol edip yeniden deneyin / Wait for this session''s automatic update check. If needed, check STABLE once, then try again.'
    }
}
try {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if (-not ('BuyerLogCacheAssembler' -as [type])) {
        # PowerShell 5 uses .NET Framework reference assemblies; newer hosts resolve them automatically.
        if ($PSVersionTable.PSVersion.Major -le 5) {
            Add-Type -Path (Join-Path $PSScriptRoot 'CacheAssembler.cs') -ReferencedAssemblies System.IO.Compression.dll,System.IO.Compression.FileSystem.dll
        } else { Add-Type -Path (Join-Path $PSScriptRoot 'CacheAssembler.cs') }
    }
    $manifest = Read-Json (Join-Path $PSScriptRoot 'delta.json')
    if ($manifest.schema -ne 'buyerlog-update-cache-delta/v1' -or $manifest.baseVersion -ne '7.0.320' -or $manifest.targetVersion -ne '7.0.323') { throw 'Uyumsuz mini paket / Incompatible delta package.' }
    foreach ($hash in @($manifest.baseSha256,$manifest.targetSha256,$manifest.payloadSha256,$manifest.tailSha256)) {
        if ([string]$hash -cnotmatch '^[a-f0-9]{64}$') { throw 'Gecersiz SHA256 / Invalid SHA256.' }
    }
    if ([long]$manifest.targetSize -le 0 -or [long]$manifest.targetSize -gt 104857600 -or $manifest.entries.Count -lt 1 -or $manifest.entries.Count -gt 30000) { throw 'Gecersiz paket boyutu / Invalid package size.' }
    $cacheName = [string]$manifest.targetVersion + '-' + ([string]$manifest.targetSha256).Substring(0,12) + '.zip'
    $baseCacheName = [string]$manifest.baseVersion + '-' + ([string]$manifest.baseSha256).Substring(0,12) + '.zip'
    $releaseManifestName = 'BuyerLog-' + [string]$manifest.targetVersion + '.json'
    if ($manifest.cacheName -cne $cacheName -or $manifest.baseCacheName -cne $baseCacheName -or $manifest.releaseManifest -cne $releaseManifestName) { throw 'Guvenli dosya adi eslesmiyor / Unsafe package filename.' }
    $signed = Read-Json (Join-Path $PSScriptRoot $manifest.releaseManifest)
    if ($signed.version -ne $manifest.targetVersion -or $signed.size -ne $manifest.targetSize -or $signed.sha256 -ne $manifest.targetSha256 -or -not $signed.signature) { throw 'Resmi paket kimligi eslesmiyor / Official package identity mismatch.' }
    $payload = Join-Path $PSScriptRoot 'delta-payload.zip'
    if ([BuyerLogCacheAssembler]::FileHash($payload) -ne $manifest.payloadSha256) { throw 'Mini ZIP bozuk / Delta payload is corrupt.' }
    if ([string]::IsNullOrWhiteSpace($InstallPath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'BuyerLog.exe bulunan kurulum klasorunu secin / Select the folder containing BuyerLog.exe'
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $InstallPath = $dialog.SelectedPath
    }
    $root = [IO.Path]::GetFullPath($InstallPath.Trim().Trim('"'))
    Safe-Directory $root
    if (-not (Test-Path -LiteralPath (Join-Path $root 'BuyerLog.exe') -PathType Leaf)) { throw 'BuyerLog.exe bulunamadi / BuyerLog.exe was not found.' }
    $exe = [IO.Path]::GetFullPath((Join-Path $root 'BuyerLog.exe'))
    $app = Get-Process -Name BuyerLog,BuyerLog.exe -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe } | Sort-Object StartTime | Select-Object -First 1
    if (-not $app) { throw 'Buyer Log acik olmali. Acilisin ve otomatik kontrolun bitmesini bekleyin / Keep Buyer Log open and wait for startup and its automatic check to finish.' }
    $core = Join-Path $root 'resources/app'
    $pointerFile = Join-Path $root 'data/local/updater/current.json'
    if (Test-Path -LiteralPath $pointerFile) {
        $pointer = Read-Json $pointerFile
        if ($pointer.version -ne $manifest.baseVersion) { throw 'Etkin surum 7.0.320 degil / The active version is not 7.0.320.' }
        if ($pointer.appCoreRoot -and (Inside $pointer.appCoreRoot $root) -and (Test-Path -LiteralPath (Join-Path $pointer.appCoreRoot 'package.json'))) {
            $core = [string]$pointer.appCoreRoot
        } else {
            $candidate = Join-Path $root '.buyerlog-versions/7.0.320/app'
            if (Test-Path -LiteralPath (Join-Path $candidate 'package.json')) { $core = $candidate }
            else { throw 'Etkin uygulama klasoru dogrulanamadi / The active application folder could not be verified.' }
        }
    }
    Safe-Directory $core
    $pkg = Read-Json (Join-Path $core 'package.json')
    if ($pkg.version -ne $manifest.baseVersion) { throw 'Bu paket yalniz 7.0.320 icindir / This package is only for 7.0.320.' }
    $stateFile = Join-Path $root 'data/local/updater/state.json'
    Assert-Idle $stateFile ($app.StartTime.ToUniversalTime())
    $cache = Join-Path $root '.buyerlog-updater/cache'
    Safe-Directory $cache
    $target = Join-Path $cache $cacheName
    if (-not (Inside $target $cache)) { throw 'Guvenli onbellek hedefi gerekli / A safe cache destination is required.' }
    if (Test-Path -LiteralPath $target) {
        if ([BuyerLogCacheAssembler]::FileHash($target) -eq $manifest.targetSha256) { Write-Host 'Dogrulanmis paket zaten hazir / The verified update is already cached.'; exit 0 }
        throw 'Ayni adli onbellek dosyasi bozuk; otomatik uzerine yazilmadi / An invalid cache file already exists; it was not overwritten.'
    }
    $baseZip = $null
    $cachedBase = Join-Path $cache $baseCacheName
    if ((Test-Path -LiteralPath $cachedBase) -and [BuyerLogCacheAssembler]::FileHash($cachedBase) -eq $manifest.baseSha256) { $baseZip = $cachedBase }
    $entries = New-Object 'System.Collections.Generic.List[BuyerLogDeltaEntry]'
    foreach ($record in $manifest.entries) {
        $entry = New-Object BuyerLogDeltaEntry
        $entry.Path = [string]$record.path; $entry.Header = [string]$record.header
        $entry.Sha256 = [string]$record.sha256; $entry.Size = [long]$record.size
        $entry.Payload = [string]$record.payload; $entry.BaseOffset = [long]$record.baseOffset
        $entries.Add($entry)
    }
    Write-Host ('7.0.320 -> ' + $manifest.targetVersion + ' / ' + $entries.Count + ' dosya kontrol ediliyor / verifying files...')
    if ($Check) { $outputFile = $null }
    else {
        [IO.Directory]::CreateDirectory($cache) | Out-Null
        $temporary = $target + '.assemble-' + [Guid]::NewGuid().ToString('N') + '.tmp'
        $outputFile = $temporary
    }
    [BuyerLogCacheAssembler]::Assemble($core, $baseZip, $payload, $entries.ToArray(), 'target-tail.bin', [string]$manifest.tailSha256, [long]$manifest.targetSize, [string]$manifest.targetSha256, $outputFile)
    $app.Refresh()
    if ($app.HasExited) { throw 'Buyer Log kapandi; uygulamayi yeniden acip tekrar hazirlayin / Buyer Log closed; reopen it and prepare the package again.' }
    Assert-Idle $stateFile ($app.StartTime.ToUniversalTime())
    if ($Check) { Write-Host 'KONTROL BASARILI. Uygulama, veri ve onbellek degistirilmedi / CHECK PASSED. Application, data and cache were not changed.'; exit 0 }
    [IO.File]::Move($temporary, $target); $temporary = $null
    Write-Host 'HAZIR. Buyer Log KAPATMADAN > Guncellemeleri Kontrol Et > TEST > Kontrol Et. Sonra uygulamanin normal Yeniden Baslat adimini kullanin.'
    Write-Host 'READY. WITHOUT CLOSING Buyer Log > Check for Updates > TEST > Check. Then use the app''s normal Restart action.'
    Write-Host 'Uygulama dosyalari, kullanici verileri ve guncelleme ayarlari degistirilmedi / Application files, user data and update settings were not changed.'
} catch {
    Write-Host ('HATA / ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($temporary -and (Test-Path -LiteralPath $temporary)) { Remove-Item -LiteralPath $temporary -Force }
}
