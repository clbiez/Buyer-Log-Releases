using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

public sealed class BuyerLogDeltaEntry {
    public string Path;
    public string Header;
    public string Sha256;
    public string Payload;
    public long Size;
    public long BaseOffset;
}

public static class BuyerLogCacheAssembler {
    private static string Hex(byte[] value) {
        return BitConverter.ToString(value).Replace("-", "").ToLowerInvariant();
    }
    public static string FileHash(string file) {
        using (FileStream stream = File.OpenRead(file))
        using (SHA256 hash = SHA256.Create()) { return Hex(hash.ComputeHash(stream)); }
    }
    private static string SafeSource(string root, string relative) {
        if (String.IsNullOrEmpty(relative) || relative.Contains("\\") || relative.Contains(":"))
            throw new InvalidDataException("Unsafe source path");
        foreach (string part in relative.Split('/'))
            if (part == "" || part == "." || part == "..") throw new InvalidDataException("Unsafe source path");
        string fullRoot = System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar;
        string file = System.IO.Path.GetFullPath(System.IO.Path.Combine(fullRoot, relative.Replace('/', System.IO.Path.DirectorySeparatorChar)));
        if (!file.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Source path escaped installation");
        return file;
    }
    public static void Assemble(string core, string baseZip, string payloadZip, BuyerLogDeltaEntry[] entries,
        string tailName, string tailSha256, long expectedSize, string expectedSha256, string output) {
        long totalSize = 0;
        using (FileStream payloadFile = File.OpenRead(payloadZip))
        using (ZipArchive payload = new ZipArchive(payloadFile, ZipArchiveMode.Read))
        using (FileStream original = String.IsNullOrEmpty(baseZip) ? null : File.OpenRead(baseZip))
        using (Stream target = String.IsNullOrEmpty(output) ? Stream.Null : new FileStream(output, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        using (SHA256 totalHash = SHA256.Create())
        using (CryptoStream writer = new CryptoStream(target, totalHash, CryptoStreamMode.Write)) {
            byte[] buffer = new byte[1024 * 1024];
            foreach (BuyerLogDeltaEntry entry in entries) {
                if (entry.Size < 0 || entry.Size > 128L * 1024 * 1024) throw new InvalidDataException("Invalid entry size");
                byte[] header = Convert.FromBase64String(entry.Header);
                if (header.Length < 30 || header.Length > 131100 || BitConverter.ToUInt32(header, 0) != 0x04034b50 || BitConverter.ToUInt16(header, 8) != 0)
                    throw new InvalidDataException("Expected a native STORE ZIP header");
                if (totalSize > expectedSize - header.Length - entry.Size) throw new InvalidDataException("Package size limit exceeded");
                writer.Write(header, 0, header.Length); totalSize += header.Length;
                Stream input = null;
                bool ownsInput = true;
                try {
                    if (!String.IsNullOrEmpty(entry.Payload)) {
                        ZipArchiveEntry item = payload.GetEntry(entry.Payload);
                        if (item == null || item.Length != entry.Size) throw new InvalidDataException("Missing delta payload: " + entry.Path);
                        input = item.Open();
                    } else if (original != null) {
                        if (entry.BaseOffset < 0 || entry.BaseOffset > original.Length - entry.Size) throw new InvalidDataException("Invalid base ZIP offset");
                        original.Position = entry.BaseOffset; input = original; ownsInput = false;
                    } else input = File.OpenRead(SafeSource(core, entry.Path));
                    using (SHA256 hash = SHA256.Create()) {
                        long remaining = entry.Size;
                        while (remaining > 0) {
                            int count = input.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));
                            if (count == 0) throw new EndOfStreamException("Incomplete source: " + entry.Path);
                            hash.TransformBlock(buffer, 0, count, null, 0);
                            writer.Write(buffer, 0, count); remaining -= count; totalSize += count;
                        }
                        if (ownsInput && input.ReadByte() != -1) throw new InvalidDataException("Source size changed: " + entry.Path);
                        hash.TransformFinalBlock(new byte[0], 0, 0);
                        if (!String.Equals(Hex(hash.Hash), entry.Sha256, StringComparison.Ordinal))
                            throw new InvalidDataException("Source SHA256 mismatch: " + entry.Path + ". No installed application file was changed.");
                    }
                } finally { if (ownsInput && input != null) input.Dispose(); }
            }
            ZipArchiveEntry tail = payload.GetEntry(tailName);
            if (tail == null || tail.Length > 16 * 1024 * 1024) throw new InvalidDataException("Missing ZIP directory");
            using (Stream input = tail.Open())
            using (SHA256 hash = SHA256.Create()) {
                int count;
                while ((count = input.Read(buffer, 0, buffer.Length)) > 0) {
                    if (totalSize > expectedSize - count) throw new InvalidDataException("Package size limit exceeded");
                    hash.TransformBlock(buffer, 0, count, null, 0); writer.Write(buffer, 0, count); totalSize += count;
                }
                hash.TransformFinalBlock(new byte[0], 0, 0);
                if (Hex(hash.Hash) != tailSha256) throw new InvalidDataException("ZIP directory SHA256 mismatch");
            }
            writer.FlushFinalBlock();
            if (totalSize != expectedSize || Hex(totalHash.Hash) != expectedSha256)
                throw new InvalidDataException("Official update ZIP identity mismatch. No installed application file was changed.");
        }
    }
}
