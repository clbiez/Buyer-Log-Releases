@echo off
chcp 65001 >nul
powershell.exe -NoProfile -File "%~dp0Prepare-Update.ps1"
if errorlevel 1 echo Hazirlama basarisiz / Preparation failed.
pause
