'use strict';

/* Model Sınıflandırma API'si. Sonuç türetilmiş veridir (server/lib/model-class-store.js);
 * Koleksiyon satırına yazılmaz. Okuma/yazma Koleksiyon alanı yetkisiyle korunur. */
const modelClassStore = require('../lib/model-class-store');
const plmBomStore = require('../lib/plm-bom-store');

module.exports = function registerModelClassRoutes(app, deps) {
  const {
    apiError,
    express,
    userAccess,
  } = deps;
  // Testler kendi depolarını verebilir; üretimde varsayılan modül depoları kullanılır.
  const store = deps.store || modelClassStore.defaultStore;
  const bomStore = deps.bomStore || plmBomStore;
  const guard = userAccess.requireAnyArea('koleksiyon');
  const bomEntryFor = () => {
    let source = null;
    try { source = bomStore.load(); } catch (_) { source = null; }
    return plmId => (source ? bomStore.entry(plmId, source) : null);
  };
  app.get('/api/model-classes', guard, (req, res) => {
    try {
      // Koşullu okuma: istemcinin revizyonu güncelse kayıtlar yeniden hesaplanıp gönderilmez.
      const since = Number(req.query.since);
      if (Number.isFinite(since) && since > 0 && since === store.revision()) return res.set('Cache-Control', 'no-store').json({ unchanged: true, revision: since });
      const ids = String(req.query.ids || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 5000);
      res.set('Cache-Control', 'no-store').json(store.publicPayload(bomEntryFor(), ids.length ? ids : null));
    } catch (error) { apiError(res, error, 'Model sınıfları okunamadı. / Model classes could not be read.'); }
  });
  app.post('/api/model-classes/results', guard, express.json({ limit: '512kb' }), (req, res) => {
    try {
      res.json({ ok: true, ...modelClassStore.acceptAnswer(store, req.body || {}, { bomEntryFor: bomEntryFor() }) });
    } catch (error) {
      if (error && error.code === 'VISION_NOT_CONFIRMED') return res.status(422).json({ error: error.message, code: error.code, failedSheets: error.failedSheets || [] });
      apiError(res, error, 'Model sınıfları kaydedilemedi. / Model classes could not be saved.');
    }
  });
};
