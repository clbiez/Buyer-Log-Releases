(function(root,factory){const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;else root.BLPriceLineage=api;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  'use strict';
  // Presentation snapshots only. Amounts and selected sources come from the
  // existing pricing/FX engines; this module never selects or calculates a price.
  function binding(row,{module,owner,user,fields}){
    return {module,workspace:String(owner||''),owner:String(row?._collectionOwnerId||owner||''),user:String(user||''),id:String(row?._collectionSourceId??row?.id??row?._id??''),identity:['orderCode','plmId','modelName','colourCode'].map(id=>fields.canonicalValue(row,module,id))};
  }
  function sameBinding(a,b){return Boolean(a&&b&&JSON.stringify(a)===JSON.stringify(b));}
  function offerProvenance(lines,{engine,amount,manufacturer}){
    if(!engine?.effectiveHistory||!engine?.price||!engine?.keyOf)return {origin:'',at:null};
    const offers=[];let unconfirmed=false;
    for(const {line,req}of lines||[]){
      if(engine.keyOf(line.manufacturer)!==engine.keyOf(manufacturer)||engine.price(line.price)!==amount)continue;
      const event=engine.effectiveHistory(line,req).filter(item=>item.type==='offer').at(-1);
      if(event&&engine.price(event.price)===amount&&Number.isFinite(Date.parse(event.at)))offers.push({event,line,req});else unconfirmed=true;
    }
    if(unconfirmed)return {origin:'unconfirmed',at:null};
    const latest=offers.sort((a,b)=>String(b.event.at).localeCompare(String(a.event.at))||String(b.event.id).localeCompare(String(a.event.id)))[0];
    return latest?{origin:latest.event.source||'',at:latest.event.at,requestId:latest.req.id,lineId:latest.line.id}:{origin:'',at:null};
  }
  function snapshot(input){
    const capturedAt=new Date(input.now||Date.now()).toISOString(),now=Date.parse(capturedAt);
    const age=at=>{const stamp=Date.parse(at||'');return Number.isFinite(stamp)&&stamp<=now?Math.floor((now-stamp)/86400000):null;};
    const source={...(input.source||{}),ageDays:age(input.source?.at)},manual=input.fx?.manual===true;
    const fx={...(input.fx||{}),manual,requestedMonth:manual?null:input.fx?.requestedMonth||null,resolvedMonth:manual?null:input.fx?.resolvedMonth||null,revision:manual?null:input.fx?.revision??null,ageDays:manual?null:age(input.fx?.sourceModifiedAt||input.fx?.updatedAt)};
    fx.fallback=Boolean(!manual&&fx.requestedMonth&&fx.resolvedMonth&&fx.requestedMonth!==fx.resolvedMonth);
    return {schemaVersion:1,module:input.module,record:input.record||'',capturedAt,source,values:{...(input.values||{})},rule:input.rule?{...input.rule}:null,trRule:input.trRule?{...input.trRule}:null,fx,revisions:{...(input.revisions||{})},blockers:(input.blockers||[]).slice(),precedence:input.precedence||''};
  }
  function number(value){
    if(value==null||String(value).trim()==='')return null;
    const n=Number(value);
    return Number.isFinite(n)?n:null;
  }
  const formatters=new Map();
  function localized(value,language,precision,min=0){
    const key=language+':'+precision+':'+min;
    if(!formatters.has(key))formatters.set(key,new Intl.NumberFormat(language==='en'?'en-GB':'tr-TR',{maximumFractionDigits:precision,minimumFractionDigits:min}));
    return formatters.get(key).format(value);
  }
  function hoverLines(facts,field,language){
    const fob=number(facts?.fob),supp=number(facts?.suppFob);
    if(!facts||fob==null||supp==null||(field==='fob'&&!facts.nonDtr))return [];
    const en=language==='en',prefix=facts.currency==='TRY'?'₺':facts.currency==='USD'?'$':(facts.currency?facts.currency+' ':'');
    const money=(value,precision=2)=>prefix+localized(value,language,precision,2);
    const percent=value=>localized(value,language,6)+'%';
    const prices=[['FOB',fob],['Supp. FOB',supp]];
    if((facts.displayField||field)==='supplierFob')prices.reverse();
    const lines=prices.map(([label,value])=>label+': '+money(value));
    const royalty=number(facts.effectiveRoyalty),hologram=number(facts.hologramCost);
    if(facts.direction&&royalty!=null&&hologram!=null){
      const base=number(facts.royalty),commission=number(facts.commission);
      const rate=percent(royalty),fee=money(hologram,6);
      const breakdown=base!=null&&commission!=null&&commission!==0
        ? percent(base)+' + '+percent(commission)+' = '+rate
        : rate;
      lines.push('Royalty: '+breakdown+' · Hologram: '+fee);
      lines.push(facts.direction==='final'
        ? 'FOB = '+money(supp)+' ÷ (1 − '+rate+') + '+fee+' = '+money(fob)
        : 'Supp. FOB = ('+money(fob)+' − '+fee+') × (1 − '+rate+') = '+money(supp));
    }else if(facts.nonDtr){
      lines.push(({manual:en?'Supp. FOB entered manually':'Supp. FOB elle girildi',cpupdate:en?'Supp. FOB imported from CP update':'Supp. FOB CP güncellemesinden aktarıldı',source:en?'Supp. FOB supplied by the source':'Supp. FOB kaynak veriden alındı'})[facts.origin]||
        (en?'Calculation details are unavailable':'Hesaplama ayrıntısı bulunamadı'));
    }
    return lines;
  }
  const escape=value=>String(value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch]);
  const titleAttribute=text=>text?' title="'+escape(text)+'"':'';
  function hoverField(moduleId,column,row){
    const field=typeof column==='string'?column:column?.priceField?.(row)||column?.canonicalId||column?.key;
    const id=field==='fob'||field==='supplierFob'?field:root.BLCanonicalFields?.canonicalId(moduleId,field);
    return id==='fob'||id==='supplierFob'?id:'';
  }
  function hoverDetails(row,moduleId,field){
    return hoverLines(root.BLPriceHoverFacts?.(row,moduleId),field,root.document?.documentElement.lang||'tr');
  }
  function hoverAttributes(row,moduleId,column,fallback=''){
    const field=hoverField(moduleId,column,row);
    const lines=field?hoverDetails(row,moduleId,field):[];
    if(!lines.length)return titleAttribute(fallback);
    return ' data-tip="'+escape(lines[0])+'"'+titleAttribute(lines.join('\n'));
  }
  return Object.freeze({binding,sameBinding,snapshot,offerProvenance,hoverLines,hoverField,hoverDetails,hoverAttributes});
});
