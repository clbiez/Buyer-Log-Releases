(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./date-dimension'), require('./business-rules'));
  } else {
    root.BLMBExFactoryEngine = factory(root.BLDateDimension, root.BLBusinessRules);
  }
})(globalThis, function (calendar, transit) {
  'use strict';

  const DAY_MS = 86400000;
  const ordinal = transit.defaultDateOrdinal;
  const iso = day => new Date(day * DAY_MS).toISOString().slice(0, 10);

  function targetDates(mode, value) {
    let mb;
    if (mode === 'month') {
      const parts = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(value);
      if (!parts) return null;
      mb = calendar.businessMonthRange(Number(parts[1]), Number(parts[2]))?.end;
    } else {
      mb = calendar.toISO(value);
    }
    return mb ? { mb, retail: iso(ordinal(mb) - transit.RETAIL_TO_MB_DAYS) } : null;
  }

  function latestExFactory({ retail, country, delType, season, rules }) {
    const deadline = ordinal(calendar.toISO(retail));
    const type = transit.transitDelTypeKey(delType);
    if (deadline == null || !type) return null;

    const matchingRules = (rules || []).filter(rule => transit.transitDelTypeKey(rule.delType) === type
      && transit.transitRuleCountryMatches(rule, country)
      && transit.transitRuleSeasonMatches(rule, season));
    const starts = new Set([-Infinity]);
    for (const rule of matchingRules) {
      const start = ordinal(rule.exfStart);
      const end = ordinal(rule.exfEnd);
      if (start != null && start <= deadline) starts.add(start);
      if (end != null && end < deadline) starts.add(end + 1);
    }

    // Within each window the same rules apply. Search newest first, since a
    // shorter route in a later window can beat subtracting today's transit days.
    let end = deadline;
    for (const start of [...starts].sort((a, b) => b - a)) {
      const resolved = transit.resolveTransitDays({
        exFactory: iso(end), rules: matchingRules, season, country, delType, forceRules: true,
      });
      if (resolved.days != null) {
        const candidate = Math.min(end, deadline - Math.ceil(resolved.days));
        if (candidate >= start) {
          const source = resolved.rule ? (resolved.rule.countries?.length ? 'country' : 'general') : 'default';
          return { date: iso(candidate), days: resolved.days, source };
        }
      }
      end = start - 1;
    }
    return null;
  }

  function availableDays(retail, exFactory) {
    const end = ordinal(calendar.toISO(retail));
    const start = ordinal(calendar.toISO(exFactory));
    return start == null || end == null ? null : end - start;
  }

  return { targetDates, latestExFactory, availableDays };
});
