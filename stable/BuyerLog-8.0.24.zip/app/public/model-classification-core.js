'use strict';
/* ===================================================================
   MODEL SINIFLANDIRMA — saf çekirdek (DOM/ağ yok; sunucu ve tarayıcı ortak)

   Amaç: aynı ürün tanımı altındaki modelleri yapı (görselden), kumaş
   (PLM metni / kumaş kartı) ve baskı (PLM BOM) özellikleriyle otomatik
   ayırmak; tek bir özet ve sınıf anahtarı üretmek.

   Kaynak düzeni (her özelliğin tek kaynağı vardır — mimari ilke 06):
   - Kumaş tipi, şardon, gramaj, karışım → kural (plm-fabric-info / kumaş
     kartı). Gramaj ve karışım AI'dan ASLA alınmaz; kumaş tipi yalnız kural
     bulamadığında AI'dan, sabit listeden alınır ve "ai" kaynağıyla işaretlenir.
   - Baskı yeri / tekniği → kural (PLM BOM yerleşimleri).
   - Ürün ailesi → kural (ürün tanımı sözlüğü); bulunamazsa AI.
   - Yaka, kapama, kol, etek ucu, gövde kurgusu, detaylar… → LCW AI görsel
     okuması, yalnız bu dosyadaki sabit sözlükten. Kanıt yoksa "?".

   Görsel makbuzu: her paftaya rastgele bir kontrol kodu basılır. Kod
   bağlamda GÖNDERİLMEZ; LCW AI ancak görseli gerçekten görürse geri
   yazabilir. Kod tutmazsa paketin hiçbir sonucu kaydedilmez — görseli
   görmeden metinden yapılmış sınıflandırma sessizce kabul edilmez.

   Saklanan değer kodlardır; etiketler çizim anında aktif dilde üretilir.
   =================================================================== */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BLModelClassCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const TAXONOMY_VERSION = 1;
  const SOURCE = 'model-classification';
  const UNSURE = '?';
  const NA = '-';

  const FAMILIES = Object.freeze([
    ['top', { tr: 'Üst giyim', en: 'Top' }], ['bottom', { tr: 'Alt giyim', en: 'Bottom' }], ['dress', { tr: 'Elbise', en: 'Dress' }],
    ['skirt', { tr: 'Etek', en: 'Skirt' }], ['outerwear', { tr: 'Dış giyim', en: 'Outerwear' }], ['onepiece', { tr: 'Tulum / tek parça', en: 'One-piece' }],
    ['set', { tr: 'Takım', en: 'Set' }], ['other', { tr: 'Diğer', en: 'Other' }],
  ]);
  const FAMILY_KEYS = FAMILIES.map(f => f[0]);
  const familyText = (f, en) => { const r = FAMILIES.find(x => x[0] === f); return r ? r[1][en ? 'en' : 'tr'] : f; };

  /* Ürün tanımı → aile. En uzun ifade önce denenir ("ESOFMAN ALTI" > "ESOFMAN"). */
  const FAMILY_HINTS = Object.freeze([
    ['top', ['SWEAT', 'SWEATSHIRT', 'HOODIE', 'T-SHIRT', 'TSHIRT', 'TISORT', 'POLO', 'GOMLEK', 'SHIRT', 'BLUZ', 'BLOUSE', 'KAZAK', 'SWEATER', 'HIRKA', 'CARDIGAN', 'ATLET', 'TANK TOP', 'CROP TOP', 'TOP', 'BADI', 'ESOFMAN UST', 'TUNIK', 'TUNIC']], // i18n-ignore
    ['bottom', ['PANTOLON', 'PANTS', 'TROUSERS', 'JEAN', 'JEANS', 'ESOFMAN ALTI', 'JOGGER', 'TAYT', 'LEGGING', 'LEGGINGS', 'SORT', 'SHORTS', 'SHORT', 'BERMUDA', 'KAPRI', 'CAPRI']], // i18n-ignore
    ['dress', ['ELBISE', 'DRESS']], // i18n-ignore
    ['skirt', ['ETEK', 'SKIRT']], // i18n-ignore
    ['outerwear', ['MONT', 'CEKET', 'JACKET', 'KABAN', 'COAT', 'YELEK', 'VEST', 'GILET', 'YAGMURLUK', 'PARKA', 'SISME', 'PUFFER', 'TRENCKOT', 'BOMBER']], // i18n-ignore
    ['onepiece', ['TULUM', 'JUMPSUIT', 'SALOPET', 'ROMPER', 'ZIBIN', 'BODY']], // i18n-ignore
    ['set', ['TAKIM', 'SET', 'PIJAMA TAKIMI', 'ESOFMAN TAKIMI', 'ALT UST TAKIM']], // i18n-ignore
  ]);

  const UPPER = ['top', 'dress', 'outerwear', 'onepiece', 'set'];
  const LOWER = ['bottom', 'onepiece', 'set'];
  const ALL = FAMILY_KEYS;
  /* Özellikler. code: cevap satırındaki kısa ad. key: sınıf anahtarına girer mi
     (false = yalnız özette görünür; görselden güvenilir okunamayanlar için). */
  const v = (code, text) => Object.freeze([code, text.tr, text.en]);
  const ATTRIBUTES = Object.freeze([
    { id: 'neckline', code: 'neck', families: UPPER, key: true, tr: 'Yaka', en: 'Neckline', values: [
      v('crew', { tr: 'Bisiklet yaka', en: 'Crew neck' }), v('v_neck', { tr: 'V yaka', en: 'V-neck' }), v('polo', { tr: 'Polo yaka', en: 'Polo collar' }),
      v('shirt_collar', { tr: 'Gömlek yaka', en: 'Shirt collar' }), v('stand', { tr: 'Dik yaka', en: 'Stand / mock neck' }), v('turtle', { tr: 'Balıkçı yaka', en: 'Turtleneck' }),
      v('hood', { tr: 'Kapüşonlu', en: 'Hooded' }), v('boat', { tr: 'Kayık yaka', en: 'Boat neck' }), v('square', { tr: 'Kare yaka', en: 'Square neck' }),
      v('henley', { tr: 'Patlı yaka', en: 'Henley' }), v('lapel', { tr: 'Klasik/ceket yaka', en: 'Lapel collar' }), v('none', { tr: 'Yakasız', en: 'Collarless' })] },
    { id: 'closure', code: 'clo', families: ALL, key: true, tr: 'Kapama', en: 'Closure', values: [
      v('none', { tr: 'Kapamasız', en: 'No closure' }), v('half_zip', { tr: 'Yarım fermuar', en: 'Half zip' }), v('full_zip', { tr: 'Boydan fermuar', en: 'Full zip' }),
      v('buttons_full', { tr: 'Boydan düğme', en: 'Full button-through' }), v('placket', { tr: 'Düğmeli pat', en: 'Button placket' }), v('snaps', { tr: 'Çıtçıt', en: 'Snaps' }),
      v('fly', { tr: 'Ön fermuar/düğme (alt)', en: 'Fly' }), v('tie', { tr: 'Bağlamalı', en: 'Tie' })] },
    { id: 'sleeveType', code: 'slv', families: UPPER, key: true, tr: 'Kol tipi', en: 'Sleeve type', values: [
      v('set_in', { tr: 'Takma kol', en: 'Set-in' }), v('raglan', { tr: 'Reglan', en: 'Raglan' }), v('drop_shoulder', { tr: 'Düşük omuz', en: 'Drop shoulder' }),
      v('dolman', { tr: 'Yarasa kol', en: 'Dolman' }), v('sleeveless', { tr: 'Kolsuz', en: 'Sleeveless' })] },
    { id: 'sleeveLength', code: 'sll', families: UPPER, key: true, tr: 'Kol boyu', en: 'Sleeve length', values: [
      v('long', { tr: 'Uzun kol', en: 'Long sleeve' }), v('three_quarter', { tr: 'Truvakar kol', en: '3/4 sleeve' }), v('short', { tr: 'Kısa kol', en: 'Short sleeve' }), v('none', { tr: 'Kolsuz', en: 'No sleeve' })] },
    { id: 'cuff', code: 'cuf', families: UPPER, key: false, tr: 'Kol ucu', en: 'Cuff', values: [
      v('rib', { tr: 'Ribanalı', en: 'Rib cuff' }), v('plain', { tr: 'Düz', en: 'Plain' }), v('elastic', { tr: 'Lastikli', en: 'Elastic' }), v('button', { tr: 'Düğmeli manşet', en: 'Button cuff' })] },
    { id: 'hem', code: 'hem', families: ['top', 'dress', 'outerwear', 'set'], key: false, tr: 'Etek ucu', en: 'Hem', values: [
      v('rib', { tr: 'Ribanalı', en: 'Rib hem' }), v('straight', { tr: 'Düz', en: 'Straight' }), v('curved', { tr: 'Oval', en: 'Curved' }), v('drawcord', { tr: 'Büzgülü', en: 'Drawcord' }), v('split', { tr: 'Yırtmaçlı', en: 'Split' })] },
    { id: 'waist', code: 'wst', families: LOWER.concat(['skirt']), key: true, tr: 'Bel', en: 'Waist', values: [
      v('elastic', { tr: 'Lastikli', en: 'Elastic' }), v('elastic_drawcord', { tr: 'Lastikli + bağcıklı', en: 'Elastic + drawcord' }), v('waistband', { tr: 'Kemerli (düğmeli)', en: 'Waistband' }),
      v('rib', { tr: 'Ribanalı', en: 'Rib' }), v('paperbag', { tr: 'Paperbag', en: 'Paperbag' })] },
    { id: 'legShape', code: 'leg', families: LOWER, key: true, tr: 'Paça', en: 'Leg shape', values: [
      v('jogger', { tr: 'Jogger (lastikli paça)', en: 'Jogger' }), v('straight', { tr: 'Düz paça', en: 'Straight' }), v('wide', { tr: 'Bol paça', en: 'Wide' }),
      v('slim', { tr: 'Dar paça', en: 'Slim' }), v('flare', { tr: 'İspanyol paça', en: 'Flare' })] },
    { id: 'legLength', code: 'lgl', families: LOWER, key: true, tr: 'Boy', en: 'Length', values: [
      v('shorts', { tr: 'Şort', en: 'Shorts' }), v('bermuda', { tr: 'Bermuda', en: 'Bermuda' }), v('capri', { tr: 'Kapri', en: 'Capri' }), v('seven_eighths', { tr: '7/8', en: '7/8' }), v('full', { tr: 'Tam boy', en: 'Full length' })] },
    { id: 'dressLength', code: 'dln', families: ['dress', 'skirt'], key: true, tr: 'Boy', en: 'Length', values: [
      v('mini', { tr: 'Mini', en: 'Mini' }), v('midi', { tr: 'Midi', en: 'Midi' }), v('maxi', { tr: 'Maksi', en: 'Maxi' })] },
    { id: 'silhouette', code: 'sil', families: ['dress', 'skirt'], key: true, tr: 'Kesim', en: 'Silhouette', values: [
      v('a_line', { tr: 'A kesim', en: 'A-line' }), v('straight', { tr: 'Düz', en: 'Straight' }), v('bodycon', { tr: 'Vücuda oturan', en: 'Bodycon' }),
      v('tiered', { tr: 'Kat kat', en: 'Tiered' }), v('wrap', { tr: 'Kruvaze', en: 'Wrap' }), v('pleated', { tr: 'Pliseli', en: 'Pleated' })] },
    { id: 'filling', code: 'fil', families: ['outerwear'], key: true, tr: 'Dolgu', en: 'Filling', values: [
      v('none', { tr: 'Dolgusuz', en: 'Unpadded' }), v('puffer', { tr: 'Şişme', en: 'Puffer' }), v('quilted', { tr: 'Kapitone', en: 'Quilted' })] },
    { id: 'construction', code: 'con', families: ALL, key: true, tr: 'Gövde kurgusu', en: 'Construction', values: [
      v('plain', { tr: 'Düz gövde', en: 'Plain body' }), v('panelled', { tr: 'Ara panelli', en: 'Panelled' }), v('colour_block', { tr: 'Renk bloklu', en: 'Colour-blocked' }),
      v('layered', { tr: 'Katmanlı (2\'si 1 arada)', en: 'Layered (2-in-1)' })] },
    { id: 'fit', code: 'fit', families: ALL, key: false, tr: 'Kalıp', en: 'Fit', values: [
      v('regular', { tr: 'Regular', en: 'Regular' }), v('oversize', { tr: 'Oversize', en: 'Oversize' }), v('relaxed', { tr: 'Rahat', en: 'Relaxed' }), v('slim', { tr: 'Slim', en: 'Slim' }), v('crop', { tr: 'Crop', en: 'Crop' })] },
    { id: 'details', code: 'det', families: ALL, key: true, multi: true, tr: 'Detaylar', en: 'Details', values: [
      v('kangaroo_pocket', { tr: 'Kanguru cep', en: 'Kangaroo pocket' }), v('patch_pocket', { tr: 'Aplike cep', en: 'Patch pocket' }), v('side_pockets', { tr: 'Yan cep', en: 'Side pockets' }),
      v('zip_pocket', { tr: 'Fermuarlı cep', en: 'Zip pocket' }), v('cargo_pocket', { tr: 'Kargo cep', en: 'Cargo pocket' }), v('chest_pocket', { tr: 'Göğüs cebi', en: 'Chest pocket' }),
      v('drawcord', { tr: 'Bağcık', en: 'Drawcord' }), v('contrast_tape', { tr: 'Şerit', en: 'Contrast tape' }), v('piping', { tr: 'Biye', en: 'Piping' }),
      v('layered_sleeve', { tr: 'Çıkma kol', en: 'Layered sleeve' }), v('contrast_sleeve', { tr: 'Kontrast kol', en: 'Contrast sleeve' }), v('contrast_rib', { tr: 'Kontrast ribana', en: 'Contrast rib' }),
      v('thumbhole', { tr: 'Başparmak deliği', en: 'Thumbhole' }), v('side_slit', { tr: 'Yan yırtmaç', en: 'Side slit' }), v('ruffle', { tr: 'Fırfır', en: 'Ruffle' }),
      v('pleats', { tr: 'Pile', en: 'Pleats' }), v('belt', { tr: 'Kemer', en: 'Belt' }), v('deco_buttons', { tr: 'Süs düğme', en: 'Decorative buttons' }),
      v('embroidery', { tr: 'Nakış', en: 'Embroidery' }), v('applique', { tr: 'Aplike', en: 'Appliqué' }), v('badge', { tr: 'Arma / patch', en: 'Badge / patch' }),
      v('sequins', { tr: 'Pul / payet', en: 'Sequins' }), v('raw_edge', { tr: 'Kesik kenar', en: 'Raw edge' }), v('distressed', { tr: 'Yıpratma', en: 'Distressed' }), v('lining_contrast', { tr: 'Kontrast astar', en: 'Contrast lining' })] },
    { id: 'fabricType', code: 'fab', families: ALL, key: true, aiFallback: true, tr: 'Kumaş tipi', en: 'Fabric type', values: [
      v('THREE_THREAD', { tr: '3 İplik', en: '3-thread' }), v('TWO_THREAD', { tr: '2 İplik', en: '2-thread' }), v('SINGLE_JERSEY', { tr: 'Süprem', en: 'Single jersey' }),
      v('RIB', { tr: 'Ribana', en: 'Rib' }), v('INTERLOCK', { tr: 'İnterlok', en: 'Interlock' }), v('PIQUE', { tr: 'Pike', en: 'Piqué' }), v('FLEECE', { tr: 'Polar', en: 'Fleece' }),
      v('FRENCH_TERRY', { tr: 'Havlu', en: 'French terry' }), v('WAFFLE', { tr: 'Petek', en: 'Waffle' }), v('SCUBA', { tr: 'Dalgıç', en: 'Scuba' }), v('MESH', { tr: 'File', en: 'Mesh' }),
      v('VELVET', { tr: 'Kadife', en: 'Velvet' }), v('DENIM', { tr: 'Denim', en: 'Denim' }), v('WOVEN', { tr: 'Dokuma', en: 'Woven' }), v('SWEATER_KNIT', { tr: 'Triko', en: 'Sweater knit' })] },
  ].map(a => Object.freeze({ ...a, values: Object.freeze(a.values) })));
  const ATTR = new Map(ATTRIBUTES.map(a => [a.id, a]));
  const BY_CODE = new Map(ATTRIBUTES.map(a => [a.code, a]));
  /* Görselden okunanlar (kumaş tipi yalnız kural boşsa AI'dan gelir). */
  const AI_ATTRS = ATTRIBUTES.filter(a => a.id !== 'fabricType').map(a => a.id);

  const BRUSHING = Object.freeze({ BRUSHED: { tr: 'Şardonlu', en: 'brushed' }, UNBRUSHED: { tr: 'Şardonsuz', en: 'unbrushed' } });
  const PLACEMENT_LABELS = Object.freeze({ front_body: { tr: 'Ön', en: 'Front' }, back_body: { tr: 'Arka', en: 'Back' }, left_sleeve: { tr: 'Sol kol', en: 'Left sleeve' }, right_sleeve: { tr: 'Sağ kol', en: 'Right sleeve' }, both_sleeves: { tr: 'Kollar', en: 'Sleeves' }, sleeve: { tr: 'Kol', en: 'Sleeve' }, chest: { tr: 'Göğüs', en: 'Chest' }, pocket: { tr: 'Cep', en: 'Pocket' }, hood: { tr: 'Kapüşon', en: 'Hood' }, left_leg: { tr: 'Sol bacak', en: 'Left leg' }, right_leg: { tr: 'Sağ bacak', en: 'Right leg' }, both_legs: { tr: 'Bacaklar', en: 'Legs' }, leg: { tr: 'Bacak', en: 'Leg' }, all_over: { tr: 'All over', en: 'All over' }, other: { tr: 'Diğer', en: 'Other' } });
  const PLACEMENT_ORDER = Object.keys(PLACEMENT_LABELS);

  const clean = x => String(x == null ? '' : x).replace(/\s+/g, ' ').trim();
  const TR_FOLD = { 'ı': 'I', 'İ': 'I', 'ş': 'S', 'Ş': 'S', 'ğ': 'G', 'Ğ': 'G', 'ü': 'U', 'Ü': 'U', 'ö': 'O', 'Ö': 'O', 'ç': 'C', 'Ç': 'C' };
  const fold = x => clean(x).replace(/[ıİşŞğĞüÜöÖçÇ]/g, c => TR_FOLD[c]).normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase();
  const isEn = lang => String(lang || '').toLowerCase() === 'en';

  /* ---------- Ürün ailesi (kural) ---------- */
  const HINTS = FAMILY_HINTS.flatMap(([family, words]) => words.map(w => [fold(w), family])).sort((a, b) => b[0].length - a[0].length);
  function familyFromProduct(text) {
    const t = ' ' + fold(text).replace(/[^A-Z0-9]+/g, ' ') + ' ';
    if (!t.trim()) return '';
    for (const [w, family] of HINTS) if (t.includes(' ' + w.replace(/[^A-Z0-9]+/g, ' ') + ' ')) return family;
    return '';
  }
  const applies = (attr, family) => !family || family === 'other' || attr.families.includes(family);
  const attributesFor = family => ATTRIBUTES.filter(a => applies(a, family));

  /* ---------- Etiketler ---------- */
  function label(attrId, value, lang) {
    if (value === UNSURE) return isEn(lang) ? 'unknown' : 'bilinmiyor';
    const a = ATTR.get(attrId); if (!a) return String(value);
    const r = a.values.find(x => x[0] === value);
    return r ? (isEn(lang) ? r[2] : r[1]) : String(value);
  }
  const familyLabel = (f, lang) => familyText(f, isEn(lang));
  const attrName = (attrId, lang) => { const a = ATTR.get(attrId); return a ? (isEn(lang) ? a.en : a.tr) : attrId; };

  /* ---------- LCW AI istem sözlüğü ---------- */
  function promptVocabulary(lang) {
    const en = isEn(lang);
    const lines = [(en ? 'family (product family): ' : 'family (ürün ailesi): ') + FAMILY_KEYS.join(', ')];
    for (const a of ATTRIBUTES) {
      const scope = a.families.length === FAMILY_KEYS.length ? (en ? 'all' : 'hepsi') : a.families.join('/');
      const vals = a.values.map(x => `${x[0]} (${en ? x[2] : x[1]})`).join(', ');
      const extra = a.multi ? (en ? '; several allowed, joined with +' : '; birden çok olabilir, + ile birleştir') : '';
      const fb = a.aiFallback ? (en ? '; read from the fabric field text only, never from the image; Buyer Log\'s own fabric parser wins when it knows the type' : '; yalnız kumaş alanı metninden oku, görselden değil; Buyer Log kumaş tipini kendisi okuyabildiyse onunki geçerlidir') : '';
      lines.push(`${a.code} — ${en ? a.en : a.tr} [${scope}${extra}${fb}]: ${vals}`);
    }
    return lines.join('\n');
  }

  /* ---------- Görsel makbuzu ---------- */
  const CODE_CHARS = 'ACDEFHJKLMNPRTUVWXY3479';
  function sheetCode(rand = Math.random) {
    let s = '';
    for (let i = 0; i < 4; i++) s += CODE_CHARS[Math.floor(rand() * CODE_CHARS.length) % CODE_CHARS.length];
    return s;
  }
  /* sheets: [{ name, code }]; reported: cevaptaki "ad=kod" satırları. Tüm paftalar birebir
     doğrulanmalı; eksik/yanlış tek pafta paketin tamamını geçersiz kılar. */
  function verifyReceipt(sheets, reported) {
    const got = new Map();
    for (const line of Array.isArray(reported) ? reported : []) {
      const m = /^\s*([^=\s]+)\s*=\s*([A-Z0-9]{4})\s*$/i.exec(String(line));
      if (m) got.set(m[1].trim(), m[2].toUpperCase());
    }
    const failed = (sheets || []).filter(sh => got.get(sh.name) !== String(sh.code).toUpperCase()).map(sh => sh.name);
    return { ok: failed.length === 0, failed };
  }

  /* ---------- Cevap satırı ---------- */
  function parseLine(line) {
    const out = {};
    for (const part of String(line == null ? '' : line).split('|')) {
      const i = part.indexOf('='); if (i < 0) continue;
      const k = clean(part.slice(0, i)).toLowerCase(), val = clean(part.slice(i + 1));
      if (k && !(k in out)) out[k] = val;
    }
    return out;
  }
  /* Tek modelin AI değerlerini sözlüğe göre doğrular. Bilinmeyen/izinsiz değer "?" olur ve
     notes'a yazılır (uydurma kod saklanmaz). Ailesi uygun olmayan özellik atlanır. */
  function normalizeAi(raw, { family: ruleFamily = '', fabricKnown = true } = {}) {
    const notes = [];
    let family = ruleFamily;
    const aiFamily = clean(raw.fam || raw.family).toLowerCase();
    if (!family) family = FAMILY_KEYS.includes(aiFamily) ? aiFamily : '';
    const values = {};
    for (const a of ATTRIBUTES) {
      if (a.id === 'fabricType' && fabricKnown) continue;
      if (family && !applies(a, family)) continue;
      const rawVal = clean(raw[a.code]);
      if (!rawVal || rawVal === UNSURE) { values[a.id] = a.multi ? [] : UNSURE; if (!rawVal) notes.push('missing:' + a.code); continue; }
      if (rawVal === NA) { values[a.id] = a.multi ? [] : UNSURE; continue; }
      const allowed = new Set(a.values.map(x => x[0]));
      if (a.multi) {
        const list = [...new Set(rawVal.split(/[+,;]/).map(x => clean(x)).filter(Boolean))];
        const ok = list.filter(x => allowed.has(x)).sort();
        for (const bad of list.filter(x => !allowed.has(x) && x !== 'none')) notes.push('invalid:' + a.code + ':' + bad.slice(0, 40));
        values[a.id] = ok;
      } else if (allowed.has(rawVal)) values[a.id] = rawVal;
      else { values[a.id] = UNSURE; notes.push('invalid:' + a.code + ':' + rawVal.slice(0, 40)); }
    }
    const suggestions = clean(raw.new).split(/[+;]/).map(clean).filter(Boolean).slice(0, 3).map(x => x.slice(0, 60));
    return { family: family || UNSURE, values, reason: clean(raw.r).slice(0, 200), suggestions, notes };
  }
  /* Paket cevabı: her anahtar tam bir kez. Döner: byKey (anahtar → ham satır), missing, duplicate, unknown. */
  function parseAnswer(lines, keys) {
    const want = new Set(keys), seen = new Map(), dup = new Set(), unknown = [];
    for (const line of Array.isArray(lines) ? lines : []) {
      const p = parseLine(line); const k = p.k || p.key;
      if (!k) continue;
      if (!want.has(k)) { unknown.push(k); continue; }
      if (seen.has(k)) { dup.add(k); continue; }
      seen.set(k, p);
    }
    for (const k of dup) seen.delete(k);
    return { byKey: seen, missing: keys.filter(k => !seen.has(k)), duplicate: [...dup], unknown };
  }

  /* ---------- Kumaş (kural) ---------- */
  /* parsed: plm-fabric-info.parseMainFabricInfo çıktısı (ya da kumaş kartından aynı biçim). */
  function fabricFacets(parsed) {
    const p = parsed || {};
    const gsm = (() => { const m = /(\d{2,4}(?:\.\d+)?)/.exec(String(p.fabricWeight && p.fabricWeight.value || '')); return m ? Number(m[1]) : null; })();
    const type = p.kumasTipi && p.kumasTipi.canonical || '';
    const category = p.fabricCategory && p.fabricCategory.canonical || '';
    const typeOrCategory = type || (['DENIM', 'WOVEN'].includes(category) ? category : category === 'SWEATER' ? 'SWEATER_KNIT' : '');
    return {
      type: typeOrCategory,
      typeSource: typeOrCategory ? 'rule' : '',
      brushing: p.brushing && p.brushing.canonical || '',
      gsm,
      gsmExact: Boolean(p.fabricWeight && p.fabricWeight.confidence === 'EXACT'),
      compositionKey: p.karisim && p.karisim.key || '',
      composition: p.karisim && p.karisim.value || '',
    };
  }
  const MAT_SHORT = { COTTON: 'CO', POLYESTER: 'PES', ELASTANE: 'EL', VISCOSE: 'CV', MODAL: 'MD', LYOCELL: 'CLY', POLYAMIDE: 'PA', WOOL: 'WO', ACRYLIC: 'PAN', LINEN: 'LI', CASHMERE: 'WS', SILK: 'SE', OTHER: 'OT' };
  const compositionShort = key => String(key || '').split('|').filter(Boolean).map(x => { const [m, p] = x.split(':'); return `${p}% ${MAT_SHORT[m] || m}`; }).sort((a, b) => parseFloat(b) - parseFloat(a)).join(' ');

  /* ---------- Baskı (kural) ---------- */
  function printFacets(bomEntry) {
    const list = bomEntry && Array.isArray(bomEntry.placements) ? bomEntry.placements : [];
    const places = [...new Set(list.map(x => x.placement).filter(Boolean))].sort((a, b) => PLACEMENT_ORDER.indexOf(a) - PLACEMENT_ORDER.indexOf(b));
    const techniques = [...new Set(list.map(x => clean(x.printType)).filter(Boolean))].sort();
    return { known: Boolean(bomEntry), places, techniques };
  }

  /* ---------- Çapraz kontrol (kural ↔ AI) ---------- */
  /* AI değeri kural kanıtıyla çelişirse değer "?" yapılır ve çelişki kaydedilir: yanlış ama
     emin bir cevap sınıfa girmez. */
  function crossCheck(rec) {
    const conflicts = [];
    const val = rec.values || {}, places = rec.print && rec.print.places || [];
    const flag = (attr, rule) => { conflicts.push({ attr, ai: val[attr], rule }); val[attr] = UNSURE; };
    if (places.includes('hood') && val.neckline && val.neckline !== UNSURE && val.neckline !== 'hood') flag('neckline', 'bom-hood-print');
    if (places.some(p => /sleeve/.test(p)) && (val.sleeveLength === 'none' || val.sleeveType === 'sleeveless')) {
      if (val.sleeveLength === 'none') flag('sleeveLength', 'bom-sleeve-print');
      if (val.sleeveType === 'sleeveless') flag('sleeveType', 'bom-sleeve-print');
    }
    if (val.sleeveType === 'sleeveless' && val.sleeveLength && ![UNSURE, 'none'].includes(val.sleeveLength)) { flag('sleeveType', 'self-sleeve'); }
    if (rec.family === 'top' && places.some(p => /leg/.test(p))) conflicts.push({ attr: 'family', ai: rec.family, rule: 'bom-leg-print' });
    return conflicts;
  }

  /* ---------- Sınıf anahtarı ve özet ---------- */
  /* Kayıt: { family, productType, values, fabric, print }. Anahtar yalnız key=true özelliklerden;
     "?" kendi başına bir değerdir (bilinmeyen başka sınıfla birleşmez). */
  function classParts(rec) {
    const parts = [];
    const val = rec.values || {};
    parts.push(['family', rec.family || UNSURE]);
    for (const a of ATTRIBUTES) {
      if (!a.key || a.id === 'fabricType' || !applies(a, rec.family)) continue;
      const x = val[a.id];
      if (a.multi) parts.push([a.id, (Array.isArray(x) ? x : []).join('+') || 'none']);
      else parts.push([a.id, x || UNSURE]);
    }
    const f = rec.fabric || {};
    parts.push(['fabricType', f.type || UNSURE], ['brushing', f.brushing || '-'], ['gsm', f.gsm == null ? UNSURE : String(f.gsm)], ['composition', (f.compositionKey || UNSURE).replace(/\|/g, ',')]);
    const pr = rec.print || {};
    parts.push(['print', pr.known ? (pr.places || []).join('+') || 'none' : UNSURE], ['technique', pr.known ? (pr.techniques || []).join('+') || 'none' : UNSURE]);
    return parts;
  }
  const classKey = rec => classParts(rec).map(([k, x]) => k + '=' + x).join('|');
  function hash(s) { let h = 2166136261; for (const ch of String(s)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
  const classId = rec => 'MC-' + hash(classKey(rec)).toUpperCase().slice(0, 6);

  /* Kullanıcıya görünen tek satır. Varsayılan/boş değerler (kapamasız, düz gövde, detay yok)
     özette yazılmaz; anahtar yine ayırır. */
  function summary(rec, lang) { const p = summaryParts(rec, lang); return [p.construction, p.material].filter(Boolean).join(' · '); }
  /* İki parça: yapı (görselden) ve malzeme/baskı (kuraldan). Hücre iki satırda çizer. */
  function summaryParts(rec, lang) {
    const en = isEn(lang), val = rec.values || {}, out = [];
    const unk = en ? '?' : '?';
    out.push(clean(rec.productType) || familyLabel(rec.family, lang));
    const pick = (id, skip = []) => { const x = val[id]; if (x == null || skip.includes(x)) return; out.push(x === UNSURE ? `${attrName(id, lang)} ${unk}` : label(id, x, lang)); };
    if (applies(ATTR.get('neckline'), rec.family)) pick('neckline');
    if (applies(ATTR.get('closure'), rec.family)) pick('closure', ['none']);
    if (applies(ATTR.get('sleeveType'), rec.family)) pick('sleeveType', ['set_in']);
    if (applies(ATTR.get('sleeveLength'), rec.family)) pick('sleeveLength');
    for (const id of ['waist', 'legShape', 'legLength', 'dressLength', 'silhouette', 'filling']) if (applies(ATTR.get(id), rec.family)) pick(id, ['none']);
    pick('construction', ['plain']);
    const det = Array.isArray(val.details) ? val.details : [];
    for (const d of det) out.push(label('details', d, lang));
    const construction = out.filter(Boolean).join(' · ');
    out.length = 0;
    const f = rec.fabric || {};
    const fab = [f.type ? label('fabricType', f.type, lang) + (f.typeSource === 'ai' ? '*' : '') : (en ? 'Fabric ?' : 'Kumaş ?')];
    if (f.brushing && BRUSHING[f.brushing]) fab.push(BRUSHING[f.brushing][en ? 'en' : 'tr']);
    if (f.gsm != null) fab.push(f.gsm + ' gsm');
    out.push(fab.join(' '));
    if (f.compositionKey) out.push(compositionShort(f.compositionKey));
    const pr = rec.print || {};
    if (pr.known && pr.places && pr.places.length) out.push(pr.places.map(p => (PLACEMENT_LABELS[p] || { tr: p, en: p })[en ? 'en' : 'tr']).join('+') + (pr.techniques && pr.techniques.length ? ' ' + pr.techniques.join('/') : ''));
    else if (pr.known) out.push(en ? 'No print' : 'Baskısız');
    return { construction, material: out.filter(Boolean).join(' · ') };
  }

  /* ---------- Parmak izi: girdi değişmedikçe yeniden sorulmaz ---------- */
  function fingerprint(input) {
    const i = input || {};
    return 'v' + TAXONOMY_VERSION + '-' + hash([clean(i.imageRef), clean(i.productType), clean(i.fabricText), clean(i.modelName), clean(i.extra)].join('\u0001'));
  }

  /* ---------- Bir modelin tam kaydı (sunucu çağırır) ---------- */
  function buildRecord({ id, input = {}, ai = null, parsedFabric = null, bomEntry = null, model = '', at = '' }) {
    const ruleFamily = familyFromProduct(input.productType) || familyFromProduct(input.extra);
    const fabric = fabricFacets(parsedFabric);
    const norm = ai ? normalizeAi(ai, { family: ruleFamily, fabricKnown: Boolean(fabric.type) }) : { family: ruleFamily || UNSURE, values: {}, reason: '', suggestions: [], notes: ['no-ai'] };
    if (!fabric.type && norm.values.fabricType && norm.values.fabricType !== UNSURE) { fabric.type = norm.values.fabricType; fabric.typeSource = 'ai'; }
    delete norm.values.fabricType;
    const rec = {
      id: clean(id), fp: fingerprint(input), taxonomy: TAXONOMY_VERSION,
      productType: clean(input.productType).slice(0, 80),
      family: norm.family, familySource: ruleFamily ? 'rule' : 'ai',
      values: norm.values, fabric, print: printFacets(bomEntry),
      image: Boolean(input.hasImage), reason: norm.reason, suggestions: norm.suggestions, notes: norm.notes,
      model: clean(model).slice(0, 60), at: clean(at).slice(0, 40),
    };
    rec.conflicts = crossCheck(rec);
    const unknown = AI_ATTRS.filter(id => applies(ATTR.get(id), rec.family) && ATTR.get(id).key && rec.values[id] === UNSURE);
    rec.unknown = unknown;
    rec.status = rec.family === UNSURE ? 'partial' : unknown.length || !fabric.type ? 'partial' : 'complete';
    rec.classKey = classKey(rec);
    rec.classId = classId(rec);
    return rec;
  }

  return Object.freeze({
    TAXONOMY_VERSION, SOURCE, UNSURE, NA, FAMILIES, FAMILY_KEYS, ATTRIBUTES, AI_ATTRS, BRUSHING, PLACEMENT_LABELS,
    familyFromProduct, attributesFor, label, familyLabel, attrName, promptVocabulary,
    sheetCode, verifyReceipt, parseLine, parseAnswer, normalizeAi,
    fabricFacets, compositionShort, printFacets, crossCheck, classParts, classKey, classId, summary, summaryParts, fingerprint, buildRecord, fold,
  });
});
