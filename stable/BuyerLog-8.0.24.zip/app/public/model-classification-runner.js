'use strict';
/* ===================================================================
   MODEL SINIFLANDIRMA — otonom çalıştırıcı (G/Ç dışarıdan verilir; Node testinde çalışır)

   - Yalnız girdisi değişen ya da hiç sınıflanmamış modeller gönderilir
     (parmak izi: görsel, ürün tanımı, kumaş metni, model adı).
   - Görseller tek tek ek olarak değil, etiketli PAFTALAR hâlinde gider (ek sayısı
     sınırı ve dosya kotası). Her paftaya bağlamda olmayan bir kontrol kodu basılır;
     sunucu kodu doğrulamadan hiçbir sonucu kaydetmez (görsel makbuzu).
   - Tek seferde tek LCW AI isteği: kullanıcının sohbetine ve BOM analizine slot kalır.
     Meşgul/geçici hatada bekler; giriş gerekirse, kota dolarsa ya da görsel iki kez
     doğrulanamazsa durur ve nedenini bildirir (döngüye girmez, kullanıcıyı darlamaz).
   - Bağlam sığmazsa paket ikiye bölünür; cevapta eksik kalan model bir kez yeniden sorulur.
   =================================================================== */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BLModelClassRunner = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const SOURCE = 'model-classification';
  const DEFAULTS = Object.freeze({
    modelsPerSheet: 9,        // 3 × 3 kare; pafta ~2000 px → model başına ~650 px
    sheetsPerRequest: 2,      // istek başına en çok 18 model: ince detay için küçük paket
    maxRequestsPerRun: 400,
    busyWaitMs: 30000,
    transientWaitMs: 15000,
    maxTransientRetries: 4,
    fieldChars: 1800,
    fieldItems: 120,
  });
  const STOP_CODES = new Set(['LCWAI_AUTH_REQUIRED', 'LCWAI_SESSION_EXPIRED', 'LCWAI_BROWSER_UNAVAILABLE', 'LCWAI_LOGIN_IN_PROGRESS', 'LCWAI_LOGIN_TIMEOUT', 'LCWAI_FORBIDDEN', 'LCWAI_QUOTA_EXCEEDED', 'LCWAI_CANCELLED']);
  const clean = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();

  /* Modelin tüm dolu alanları "Etiket: değer"; uzun değer kayıpsız parçalara bölünür. */
  function fieldLines(entries, { fieldChars = DEFAULTS.fieldChars, fieldItems = DEFAULTS.fieldItems } = {}) {
    const out = [];
    for (const e of entries || []) {
      const label = clean(e && e.label), value = clean(e && e.value);
      if (!value) continue;
      let rest = value, first = true;
      while (rest.length && out.length < fieldItems) {
        const prefix = label ? (first ? `${label}: ` : `${label} (+): `) : '';
        const room = Math.max(200, fieldChars - prefix.length);
        out.push(prefix + rest.slice(0, room)); rest = rest.slice(room); first = false;
      }
    }
    return out;
  }

  /* Bekleyenler: depoda olmayan ya da parmak izi değişen modeller (sıra korunur). */
  function pending(models, stored, fingerprint) {
    const have = stored || {};
    return (models || []).filter(m => { const s = have[m.id]; return !s || s.fp !== fingerprint(m.input); });
  }

  function chunk(list, n) { const out = []; for (let i = 0; i < list.length; i += n) out.push(list.slice(i, i + n)); return out; }

  /* deps: listModels() → [{ id, plmId, imageSrc, input:{productType, fabricText, imageRef, modelName, extra}, fields:[{label,value}] }]
           fetchStored() → { id: { fp } } · fingerprint(input) · drawSheets(items[{id,key,src}], {perSheet, codeOf}) → [{ name, blob, ids, code }]
           upload(blob, name) → ek · ask({ source, task, context, attachments }) → { data, truncated, model }
           post(payload) → { saved, missing } · sheetCode() · sleep(ms) · onStatus(status) · signal */
  async function run(deps, options = {}) {
    const o = { ...DEFAULTS, ...options };
    const status = { state: 'running', total: 0, done: 0, failed: 0, requests: 0, noImage: 0, imageFailed: 0, stopCode: '', visionFailures: 0, startedAt: Date.now() };
    const emit = () => { try { deps.onStatus && deps.onStatus({ ...status }); } catch (_) {} };
    const aborted = () => Boolean(deps.signal && deps.signal.aborted);
    const sleep = ms => (deps.sleep ? deps.sleep(ms) : new Promise(r => setTimeout(r, ms)));
    const models = await deps.listModels();
    const byId = new Map(models.map(m => [m.id, m]));
    const todo = pending(models, await deps.fetchStored(), deps.fingerprint);
    status.total = todo.length; emit();
    const perRequest = Math.max(1, o.modelsPerSheet * o.sheetsPerRequest);
    // Görselliler önce: görselsiz modeller kendi paketlerinde (pafta gerekmez) gider.
    const withImg = todo.filter(m => m.imageSrc), without = todo.filter(m => !m.imageSrc);
    status.noImage = without.length;
    const queue = [...chunk(withImg, perRequest), ...chunk(without, perRequest)].map(ids => ({ ids: ids.map(m => m.id), retry: false, vision: 0, transient: 0 }));
    let visionStrikes = 0;

    async function once(job) {
      const wanted = job.ids.map(id => byId.get(id));
      const draft = wanted.filter(m => m.imageSrc).map((m, i) => ({ id: m.id, key: 'M' + (i + 1), src: m.imageSrc }));
      const sheets = draft.length ? await deps.drawSheets(draft, { perSheet: o.modelsPerSheet, codeOf: () => deps.sheetCode() }) : [];
      const sheetOf = new Map();
      for (const sh of sheets) for (const id of sh.ids) sheetOf.set(id, sh.name);
      // Görseli olup paftaya çizilemeyen model (yüklenemedi/bozuk) bu turda atlanır: metinden
      // yapılmış bir okuma görselli modelin yerine geçmez. Görsel düzelince parmak izi değişir.
      const batch = wanted.filter(m => !m.imageSrc || sheetOf.has(m.id));
      status.imageFailed += wanted.length - batch.length;
      if (!batch.length) return { saved: [], missing: [] };
      // Paftadaki etiket ile bağlamdaki anahtar aynı olmalı: anahtarlar çizim sırasından gelir.
      const keyOf = new Map(draft.map(x => [x.id, x.key]));
      let extra = draft.length;
      const keys = batch.map(m => keyOf.get(m.id) || 'M' + (++extra));
      const attachments = [];
      for (const sh of sheets) { if (aborted()) throw Object.assign(new Error('cancelled'), { code: 'LCWAI_CANCELLED' }); attachments.push(await deps.upload(sh.blob, sh.name)); }
      const context = { models: batch.map((m, i) => ({ k: keys[i], image: sheetOf.get(m.id) || 'none', fields: fieldLines(m.fields, o) })) };
      status.requests += 1; emit();
      let res;
      try { res = await deps.ask({ source: SOURCE, task: 'Sınıflandır / Classify', context, attachments }); }
      catch (e) { if (e && e.code === 'LCWAI_CONTEXT_TOO_LARGE') return { split: true }; throw e; }
      if (!res || res.truncated) return { split: true };
      if (!res.data) return { bad: true };
      const payload = {
        items: batch.map((m, i) => ({ id: m.id, plmId: m.plmId || '', key: keys[i], input: { ...m.input, hasImage: sheetOf.has(m.id) } })),
        answer: { sheetCodes: res.data.sheetCodes, assignments: res.data.assignments },
        sheets: sheets.map(sh => ({ name: sh.name, code: sh.code })),
        model: res.model && (res.model.label || res.model.key) || '',
      };
      const out = await deps.post(payload);
      const idOf = new Map(keys.map((k, i) => [k, batch[i].id]));
      return { saved: out.saved || [], missing: (out.missing || []).map(k => idOf.get(k)).filter(Boolean) };
    }

    try {
      while (queue.length) {
        if (aborted()) throw Object.assign(new Error('cancelled'), { code: 'LCWAI_CANCELLED' });
        if (status.requests >= o.maxRequestsPerRun) { status.stopCode = 'RUN_LIMIT'; break; }
        const job = queue.shift();
        let r;
        try { r = await once(job); }
        catch (e) {
          const code = e && e.code || '';
          if (code === 'VISION_NOT_CONFIRMED') {
            status.visionFailures += 1; visionStrikes += 1;
            // Bir kez daha (yeni kodlarla); ikinci kez de görülmezse çalıştırma durur: görme kapalı olabilir.
            if (!job.vision && visionStrikes < 2) { queue.unshift({ ...job, vision: 1 }); continue; }
            status.stopCode = 'VISION_NOT_CONFIRMED'; queue.unshift(job); break;
          }
          if (STOP_CODES.has(code)) { status.stopCode = code; queue.unshift(job); break; }
          if (code === 'LCWAI_BUSY' || code === 'LCWAI_RATE_LIMITED' || (e && e.retryable)) {
            if (job.transient >= o.maxTransientRetries) { status.stopCode = code || 'TRANSIENT'; queue.unshift(job); break; }
            queue.unshift({ ...job, transient: job.transient + 1 });
            await sleep(code === 'LCWAI_BUSY' ? o.busyWaitMs : o.transientWaitMs);
            continue;
          }
          status.stopCode = code || 'LCWAI_INTERNAL'; queue.unshift(job); break;
        }
        if (r.split) {
          if (job.ids.length > 1) { const h = Math.ceil(job.ids.length / 2); queue.unshift({ ...job, ids: job.ids.slice(0, h) }, { ...job, ids: job.ids.slice(h) }); }
          else status.failed += 1;
          continue;
        }
        if (r.bad) { if (!job.retry) queue.unshift({ ...job, retry: true }); else status.failed += job.ids.length; continue; }
        visionStrikes = 0;
        status.done += r.saved.length;
        if (r.missing.length) { if (!job.retry) queue.push({ ids: r.missing, retry: true, vision: 0, transient: 0 }); else status.failed += r.missing.length; }
        emit();
      }
    } finally {
      status.remaining = queue.reduce((n, j) => n + j.ids.length, 0);
      status.state = status.stopCode && status.stopCode !== 'RUN_LIMIT' ? 'stopped' : status.remaining ? 'paused' : 'done';
      status.finishedAt = Date.now();
      emit();
    }
    return status;
  }

  return Object.freeze({ SOURCE, DEFAULTS, STOP_CODES, fieldLines, pending, run });
});
