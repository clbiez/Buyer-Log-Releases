/* Buyer Log — Koleksiyon "Model Sınıfı" sütunu ve otonom sınıflandırma köprüsü
 *
 * Sütun sentetik ve salt okunurdur (KOL_SYNTHETIC_COL_META.__modelClass__); LFL ile
 * aynı kalıp: ensure() veriyi okur, text()/cell() çizer. Değer Koleksiyon satırına
 * yazılmaz; kaynak /api/model-classes (türetilmiş depo).
 *
 * Otonom çalışma: Koleksiyon görünürken ve sütun açıkken, LCW AI oturumu zaten
 * bağlıysa, sınıflanmamış/değişmiş modeller arka planda tek tek paketlerle
 * gönderilir. Giriş penceresi açılmaz, uyarı penceresi çıkmaz; durum başlıktaki
 * ipucunda görünür. Model başına onay istenmez.
 */
(function (global) {
  'use strict';
  if (global.BLModelClassUI) return;
  const Core = global.BLModelClassCore, Runner = global.BLModelClassRunner;
  // appLang app-main'de üst düzey `let`: window özelliği değildir, adıyla okunur (collection-lfl.js ile aynı).
  const isEn = () => (typeof appLang !== 'undefined' ? appLang === 'en' : String(document.documentElement.lang || '').startsWith('en')); // eslint-disable-line no-undef
  const T = (tr, en) => (isEn() ? en : tr);
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const FRESH_MS = 60000, AUTO_DELAY_MS = 8000, RECHECK_MS = 30 * 60 * 1000;
  // Pafta: 3 × 3 kare (Koleksiyon görselleri ön+arka yan yana, geniş). Üst bant kontrol kodunu taşır.
  const SHEET = Object.freeze({ cols: 3, tileW: 680, tileH: 420, label: 44, band: 72, maxBytes: 9.5 * 1024 * 1024 });
  const ALLOWED_FIELDS = new Set(['productMainDefinition', 'urunTipi', 'plmId', 'modelKod', 'colour', 'line', 'artworkDetail', 'fabric', 'fit', 'licensor', 'lisans', 'mag', 'mmyg', 'buyingGroup', 'season', 'not']);
  const S = { records: new Map(), version: 0, revision: 0, loadedAt: 0, pending: null, status: 'idle', run: null, runStatus: null, lastAutoAt: 0, autoTimer: 0, controller: null };

  function screen() { return global.BLAIScreenData || null; }
  /* Model kimliği: PLM ID (renkten bağımsız); yoksa model adı. Sınıf modele aittir, renge değil. */
  function keyOf(row) {
    const plm = String(row && row.plmId || '').trim().replace(/\.0+$/, '');
    if (plm) return plm;
    const model = String(row && row.modelKod || '').trim().toLocaleUpperCase('tr-TR');
    return model ? 'MODEL:' + model : '';
  }
  function repaint() { if (document.body.dataset.activeTab === 'koleksiyon' && typeof renderKol === 'function') renderKol(); } // eslint-disable-line no-undef

  function ensure() {
    if (S.pending) return S.pending;
    if (S.loadedAt && Date.now() - S.loadedAt < FRESH_MS) { scheduleAuto(); return Promise.resolve(); }
    S.pending = (async () => {
      try {
        // Koşullu okuma: depo revizyonu değişmediyse sunucu kayıtları yeniden göndermez ve hiç çizim yapılmaz.
        const res = await fetch('/api/model-classes' + (S.revision ? `?since=${encodeURIComponent(S.revision)}` : ''), { cache: 'no-store', credentials: 'same-origin' });
        if (!res.ok) { S.status = res.status === 403 ? 'forbidden' : 'error'; return; }
        const data = await res.json();
        S.status = 'ready'; S.loadedAt = Date.now();
        if (data.unchanged) return;
        S.records = new Map(Object.entries(data.models || {})); S.version += 1; S.revision = Number(data.revision) || 0;
        refreshView();
      } catch (_) { S.status = 'error'; }
      finally { S.pending = null; scheduleAuto(); }
    })();
    return S.pending;
  }
  function recordFor(row) { const key = keyOf(row); return key ? S.records.get(key) || null : null; }
  /* Filtre: değer sınıf kodu (dilden bağımsız, kayıtlı filtrede kalıcı); etiket aktif dilde kod + özet.
     Sınıflanmamış satır '' (filtre panelinde "(boş)"). */
  function filterValue(row) { const rec = recordFor(row); return rec ? rec.classId : ''; }
  let labelCache = null;
  function filterLabel(classId) {
    if (!classId || !Core) return '';
    const lang = isEn() ? 'en' : 'tr';
    if (!labelCache || labelCache.version !== S.version || labelCache.lang !== lang) {
      const map = new Map();
      for (const rec of S.records.values()) if (!map.has(rec.classId)) map.set(rec.classId, `${rec.classId} · ${Core.summary(rec, lang)}`);
      labelCache = { version: S.version, lang, map };
    }
    return labelCache.map.get(classId) || classId;
  }
  function text(row) {
    const rec = recordFor(row);
    if (!rec || !Core) return '';
    return Core.summary(rec, isEn() ? 'en' : 'tr');
  }
  function detail(rec) {
    if (!rec) return S.run ? T('Sınıflandırma sürüyor; bu model henüz işlenmedi.', 'Classification is running; this model has not been processed yet.') : T('Henüz sınıflanmadı.', 'Not classified yet.');
    const lines = [rec.classId];
    if (rec.status === 'partial') lines.push(T(`Eksik: ${rec.unknown.map(id => Core.attrName(id, 'tr')).join(', ') || 'kumaş'}`, `Missing: ${rec.unknown.map(id => Core.attrName(id, 'en')).join(', ') || 'fabric'}`));
    for (const c of rec.conflicts || []) lines.push(T(`Çelişki: ${Core.attrName(c.attr, 'tr')} (LCW AI: ${c.ai}) PLM BOM ile uyuşmuyor; değer kullanılmadı.`, `Conflict: ${Core.attrName(c.attr, 'en')} (LCW AI: ${c.ai}) disagrees with the PLM BOM; value not used.`));
    if (rec.fabric && rec.fabric.typeSource === 'ai') lines.push(T('* Kumaş tipi PLM metninden kuralla okunamadı; LCW AI okuması.', '* Fabric type could not be read by rule from the PLM text; LCW AI reading.'));
    if (!rec.image) lines.push(T('Görsel yoktu; yalnız alanlardan okundu.', 'No image; read from the fields only.'));
    if (rec.reason) lines.push(rec.reason);
    return lines.join('\n');
  }
  /* Kumaş hücresinin iki satırlı ortak sınıflarıyla (collection-spreadsheet.css): 1. satır sınıf kodu
     ve yapı (görselden), 2. satır kumaş ve baskı (kuraldan). Ayrı görünüm/CSS eklenmez. */
  /* Hücrenin içeriği yalnız model anahtarına bağlıdır; bu yüzden veri gelince tablo yeniden
     çizilmeden hücreler yerinde güncellenebilir (data-mc). */
  /* Hücre her zaman AYNI yapıyı taşır: sabit boyutlu, yerleşimi kapalı kutu (.kolMcBox, contain:strict)
     içinde kod etiketi + iki satır. Veri gelince yalnız metin düğümlerinin içeriği ve title değişir.
     Ölçüm (3.000 satır, Chromium): tabloda öğe ekleyip çıkarmak sayfanın tamamında ~100 ms stil
     hesabı tetikliyor; yalnız metin düğümü güncellemesi stil hesabı gerektirmez (~4 ms). */
  const TD_CLASS = 'kolBestCell kolFabricTd kolMcTd';
  const EMPTY = '\u200b'; // boş metin düğümü yerine: düğüm her zaman var olur, sonradan yalnız içeriği değişir
  function cellParts(key) {
    const rec = key ? S.records.get(key) || null : null;
    const title = [rec && Core ? Core.summary(rec, isEn() ? 'en' : 'tr') : '', detail(rec)].filter(Boolean).join('\n');
    if (!rec || !Core) return { title, code: '—', line1: S.run ? T('Sınıflanıyor…', 'Classifying…') : EMPTY, line2: EMPTY };
    const p = Core.summaryParts(rec, isEn() ? 'en' : 'tr');
    return { title, code: rec.classId, line1: p.construction || EMPTY, line2: p.material || EMPTY };
  }
  /* td > kutu (.kolMcBox.kolFabricLine) > [kod etiketi] satır1 <br> satır2 — hücre başına 4 öğe.
     Ölçüm: açılışta stil ~60 kez yeniden hesaplanır ve maliyet öğe sayısıyla büyür; iç içe satır
     kapsayıcıları (8 öğe) yerine düz metin düğümleri kullanılır. Kod etiketi Kumaş hücresinin ortak
     görünümünü (.kolFabricLine .kolFabricCode) korur. */
  function cell(row, attributes) {
    const key = keyOf(row), c = cellParts(key);
    return `<td class="${TD_CLASS}"${attributes || ''} data-mc="${esc(key)}" title="${esc(c.title)}"><div class="kolMcBox kolFabricLine"><span class="kolFabricCode">${esc(c.code)}</span>${esc(c.line1)}<br>${esc(c.line2)}</div></td>`;
  }
  /* Yerinde güncelleme: öğe eklenmez/çıkarılmaz; yalnız metin düğümü içeriği ve title. */
  function patchCell(td) {
    const c = cellParts(td.getAttribute('data-mc')), box = td.firstElementChild;
    const nodes = box ? box.childNodes : [];
    if (!box || nodes.length !== 4 || nodes[1].nodeType !== 3 || nodes[3].nodeType !== 3 || !nodes[0].firstChild) { td.outerHTML = cell({ plmId: td.getAttribute('data-mc') }, ''); return; }
    const set = (node, value) => { if (node.data !== value) node.data = value; };
    set(nodes[0].firstChild, c.code); set(nodes[1], c.line1); set(nodes[3], c.line2);
    if (td.title !== c.title) td.title = c.title;
  }
  /* Veri gelince: bu sütunda filtre/sıralama açıksa satır kümesi değişebilir → tam çizim; değilse
     yalnız görünür sınıf hücreleri yerinde güncellenir (ölçüm: tam çizim ~500 ms/3.000 satır). */
  function refreshView() {
    if (document.body.dataset.activeTab !== 'koleksiyon') return;
    let structural = false;
    try { structural = Boolean((kolColFilters.__modelClass__ && kolColFilters.__modelClass__.size) || (kolSort && kolSort.key === '__modelClass__')); } catch (_) { structural = false; } // eslint-disable-line no-undef
    if (structural) { repaint(); return; }
    for (const td of document.querySelectorAll('#kolTable td[data-mc]')) patchCell(td);
  }
  function headerTitle() {
    const st = S.runStatus;
    const base = T('Görselden (LCW AI) ve PLM kumaş/BOM verisinden otomatik model sınıfı. Kumaş ve baskı kuralla okunur.', 'Automatic model class from the image (LCW AI) and PLM fabric/BOM data. Fabric and print are read by rule.');
    if (!st) return base;
    if (st.state === 'running') return `${base}\n${T(`Sınıflanıyor: ${st.done} / ${st.total}`, `Classifying: ${st.done} / ${st.total}`)}`;
    return `${base}\n${stopText(st)}`;
  }
  function stopText(st) {
    const code = st.stopCode;
    if (!code) return T(`Son çalışma tamamlandı: ${st.done} model.`, `Last run finished: ${st.done} models.`);
    if (code === 'VISION_NOT_CONFIRMED') return T('Durdu: LCW AI paftalardaki kontrol kodunu okuyamadı (görsel görülmedi). Hiçbir sonuç görselsiz kaydedilmedi.', 'Stopped: LCW AI could not read the sheet check codes (image not seen). No result was saved without the image.');
    if (code === 'LCWAI_QUOTA_EXCEEDED') return T('Durdu: LCW AI dosya kotası doldu.', 'Stopped: the LCW AI file quota is full.');
    if (/AUTH|SESSION|LOGIN|BROWSER/.test(code)) return T('Bekliyor: LCW AI oturumu açık değil.', 'Waiting: LCW AI is not signed in.');
    if (code === 'RUN_LIMIT') return T(`Bu çalışmanın sınırına gelindi; kalanlar sonraki çalışmada (${st.remaining}).`, `Run limit reached; the rest continue next run (${st.remaining}).`);
    return T(`Durdu (${code}); sonraki çalışmada kaldığı yerden sürer.`, `Stopped (${code}); it resumes from where it left off next run.`);
  }

  /* ---------- Otonom çalışma ---------- */
  function scheduleAuto() {
    if (S.run || S.autoTimer || document.body.dataset.activeTab !== 'koleksiyon') return;
    if (Date.now() - S.lastAutoAt < RECHECK_MS) return;
    S.autoTimer = global.setTimeout(() => { S.autoTimer = 0; void runAuto(); }, AUTO_DELAY_MS);
  }
  async function aiReady() {
    const ai = global.BuyerLogAI;
    if (!ai || typeof ai.ask !== 'function' || typeof ai.uploadFile !== 'function') return false;
    try { const st = await ai.getStatus({ refresh: false }); return Boolean(st && st.connected); } catch (_) { return false; }
  }
  function listModels() {
    const sd = screen();
    const info = sd && sd.table ? sd.table('koleksiyon', { all: true }) : null;
    const rows = info && Array.isArray(info.rows) ? info.rows : [];
    const columns = (info && info.columns || []).filter(c => ALLOWED_FIELDS.has(c.key));
    const read = (row, key) => { const c = columns.find(x => x.key === key); try { return c ? String(c.readValue(row) || '') : ''; } catch (_) { return ''; } };
    const byKey = new Map();
    for (const row of rows) {
      const key = keyOf(row);
      if (!key) continue;
      const image = (() => { try { return sd.rowImage('koleksiyon', row); } catch (_) { return null; } })();
      const cur = byKey.get(key);
      if (cur && (cur.imageSrc || !image)) continue;
      byKey.set(key, {
        id: key, plmId: /^\d+$/.test(key) ? key : '', imageSrc: image && image.source || '',
        input: { productType: read(row, 'urunTipi') || read(row, 'productMainDefinition'), extra: read(row, 'productMainDefinition'), fabricText: read(row, 'fabric'), imageRef: image && image.source || '', modelName: read(row, 'modelKod') },
        fields: columns.map(c => ({ label: c.label, value: read(row, c.key) })),
      });
    }
    return [...byKey.values()];
  }
  const loadImage = src => new Promise((resolve, reject) => { const img = new Image(); img.decoding = 'async'; img.onload = () => resolve(img); img.onerror = reject; img.src = src; });
  async function encode(canvas) {
    for (const q of [0.88, 0.75, 0.6]) {
      let blob = null;
      try { blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', q)); } catch (_) { return null; }
      if (blob && blob.size <= SHEET.maxBytes) return blob;
    }
    return null;
  }
  /* Etiketli pafta: üst bantta bağlamda olmayan kontrol kodu; her karenin altında anahtar (M1…).
     Okunamayan görsel paftaya girmez (çalıştırıcı o modeli bu turda atlar). */
  async function drawSheets(list, { perSheet, codeOf }) {
    const loaded = await Promise.all(list.map(x => loadImage(x.src).then(img => ({ ...x, img }), () => null)));
    const ok = loaded.filter(x => x && x.img && x.img.naturalWidth);
    const out = [];
    for (let i = 0; i < ok.length; i += perSheet) {
      const part = ok.slice(i, i + perSheet), code = codeOf();
      const rows = Math.ceil(part.length / SHEET.cols), c = document.createElement('canvas');
      c.width = SHEET.cols * SHEET.tileW; c.height = SHEET.band + rows * (SHEET.tileH + SHEET.label);
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = '#111111'; ctx.font = 'bold 40px Arial'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(`CHECK CODE: ${code}`, 24, SHEET.band / 2);
      part.forEach((x, j) => {
        const cx = (j % SHEET.cols) * SHEET.tileW, cy = SHEET.band + Math.floor(j / SHEET.cols) * (SHEET.tileH + SHEET.label);
        const k = Math.min((SHEET.tileW - 16) / x.img.naturalWidth, (SHEET.tileH - 16) / x.img.naturalHeight), w = x.img.naturalWidth * k, h = x.img.naturalHeight * k;
        try { ctx.drawImage(x.img, cx + (SHEET.tileW - w) / 2, cy + (SHEET.tileH - h) / 2, w, h); } catch (_) { /* bozuk görsel: kare boş kalır */ }
        ctx.fillStyle = '#111111'; ctx.font = 'bold 30px Arial'; ctx.textAlign = 'center';
        ctx.fillText(x.key, cx + SHEET.tileW / 2, cy + SHEET.tileH + SHEET.label / 2);
        ctx.strokeStyle = '#999999'; ctx.lineWidth = 1; ctx.strokeRect(cx + 0.5, cy + 0.5, SHEET.tileW - 1, SHEET.tileH + SHEET.label - 1);
      });
      const blob = await encode(c);
      if (blob) out.push({ name: `BuyerLog-class-${Date.now().toString(36)}-${out.length + 1}.jpg`, blob, ids: part.map(x => x.id), code });
    }
    return out;
  }
  async function post(payload) {
    const res = await fetch('/api/model-classes/results', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'HTTP ' + res.status), { code: data.code || 'HTTP_' + res.status });
    for (const [id, rec] of Object.entries(data.records || {})) S.records.set(id, rec);
    S.version += 1;
    refreshView();
    return data;
  }
  async function runAuto() {
    if (S.run || !Core || !Runner || !(await aiReady())) return null;
    S.lastAutoAt = Date.now();
    const controller = new AbortController(); S.controller = controller;
    const ai = global.BuyerLogAI;
    S.run = Runner.run({
      listModels: async () => listModels(),
      fetchStored: async () => Object.fromEntries([...S.records].map(([id, rec]) => [id, { fp: rec.fp }])),
      fingerprint: Core.fingerprint,
      sheetCode: () => Core.sheetCode(),
      drawSheets,
      upload: (blob, name) => ai.uploadFile(new File([blob], name, { type: 'image/jpeg' }), { signal: controller.signal }),
      ask: payload => ai.ask({ ...payload, lang: isEn() ? 'en' : 'tr', signal: controller.signal }),
      post,
      onStatus: st => { S.runStatus = st; },
      signal: controller.signal,
    }).catch(err => ({ state: 'stopped', stopCode: err && err.code || 'ERROR', done: 0, total: 0 })).then(st => { S.runStatus = st; S.run = null; S.controller = null; repaint(); return st; });
    return S.run;
  }
  function cancel() { if (S.controller) S.controller.abort(); }

  global.BLModelClassUI = Object.freeze({ ensure, text, cell, detail, headerTitle, filterValue, filterLabel, runNow: () => { S.lastAutoAt = 0; return runAuto(); }, cancel, status: () => ({ loaded: S.status, run: S.runStatus ? { ...S.runStatus } : null, count: S.records.size }) });
})(typeof window !== 'undefined' ? window : globalThis);
