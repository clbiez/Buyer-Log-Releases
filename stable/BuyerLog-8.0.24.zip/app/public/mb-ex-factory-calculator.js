(() => {
  'use strict';

  const engine = window.BLMBExFactoryEngine;
  const labels = {
    title: ['MB Termin Hesaplayıcı', 'MB Date Calculator'],
    mode: ['MB girişi', 'MB input'],
    month: ['MB ayı', 'MB month'],
    date: ['MB tarihi', 'MB date'],
    monthChoice: ['Ay', 'Month'],
    dateChoice: ['Tarih', 'Date'],
    delivery: ['Nakliye tipi', 'Shipping type'],
    season: ['Sezon', 'Season'],
    genericSeason: ['Sezon bağımsız', 'Season-independent'],
    ex: ['Ex-Factory', 'Ex-Factory'],
    retail: ['Retail', 'Retail'],
    available: ['Kalan Ex→Retail', 'Available Ex→Retail'],
    country: ['Ülke', 'Country'],
    latest: ['En geç Ex-Factory', 'Latest Ex-Factory'],
    transit: ['Yol süresi', 'Transit time'],
    general: ['Genel kural', 'General rule'],
    default: ['Varsayılan', 'Default'],
    noRule: ['Kural yok', 'No rule'],
    close: ['Kapat', 'Close'],
    minimize: ['Küçült', 'Minimize'],
    restore: ['Genişlet', 'Expand'],
    move: ['Pencereyi sürükleyin veya ok tuşlarıyla taşıyın', 'Drag the window or move it with the arrow keys'],
  };
  const en = () => document.documentElement.lang === 'en';
  const T = (tr, english) => en() ? english : tr;
  const label = key => T(...labels[key]);
  let active;

  function open({ readContext, deliveryTypes, deliveryLabel, opener }) {
    if (active) {
      active.restore(opener);
      return;
    }

    const panel = document.createElement('section');
    panel.id = 'mbExFactoryCalculator';
    panel.className = 'mbCalc';
    panel.dataset.uiMigrated = 'mb-calculator';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'false');
    panel.setAttribute('aria-labelledby', 'mbCalcTitle');
    panel.innerHTML = `
      <header class="mbCalcHead">
        <h2 id="mbCalcTitle" class="mbCalcGrip" tabindex="0" data-label="title"></h2>
        <button type="button" class="tbtn mbCalcIcon" data-action="minimize" aria-controls="mbCalcBody" aria-expanded="true"><svg class="ic" aria-hidden="true"><use href="#i-chevron-down"/></svg></button>
        <button type="button" class="tbtn mbCalcIcon" data-action="close"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg></button>
      </header>
      <div id="mbCalcBody" class="mbCalcBody">
        <div class="mbCalcTarget">
          <label data-mode="month"><span data-label="month"></span><input type="month" data-field="month" min="1900-01" max="9999-12"></label>
          <label data-mode="date" hidden><span data-label="date"></span><input type="date" data-date-native data-field="date" min="1900-01-01" max="9999-12-31"></label>
          <select class="mbCalcMode" data-field="mode">
            <option value="month" data-label="monthChoice"></option><option value="date" data-label="dateChoice"></option>
          </select>
        </div>
        <div class="mbCalcFields">
          <label><span data-label="delivery"></span><select data-field="delivery"></select></label>
          <label><span data-label="season"></span><select data-field="season"></select></label>
          <label><span data-label="ex"></span><input type="date" data-date-native data-field="ex" min="1800-01-01" max="9999-12-31"></label>
        </div>
        <div class="mbCalcMetrics" aria-live="polite" aria-atomic="true">
          <div><span data-label="retail"></span> <strong data-result="retail"></strong></div>
          <div><span data-label="available"></span> <strong data-result="days"></strong></div>
        </div>
        <p class="mbCalcHint" data-result="hint"></p>
        <p class="mbCalcHint" data-result="status" role="status"></p>
        <div class="mbCalcResults" hidden>
          <table class="miniTable">
            <thead><tr><th scope="col" data-label="country"></th><th scope="col" data-label="latest"></th><th scope="col" data-label="transit"></th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
      </div>`;

    const $ = selector => panel.querySelector(selector);
    const field = name => $(`[data-field="${name}"]`);
    const result = name => $(`[data-result="${name}"]`);
    const body = $('#mbCalcBody');
    const grip = $('.mbCalcGrip');
    const minimize = $('[data-action="minimize"]');
    const closeButton = $('[data-action="close"]');
    const table = $('.mbCalcResults');
    const dateField = () => field(field('mode').value);
    const controller = new AbortController();
    const { signal } = controller;
    let position, drag, target;
    let context = readContext();

    function setPosition(x, y) {
      const bounds = panel.getBoundingClientRect();
      const margin = 8;
      position = {
        x: Math.max(margin, Math.min(x, window.innerWidth - bounds.width - margin)),
        y: Math.max(margin, Math.min(y, window.innerHeight - bounds.height - margin)),
      };
      panel.style.left = position.x + 'px';
      panel.style.top = position.y + 'px';
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
    }

    function keepInView() {
      const bounds = position ?? panel.getBoundingClientRect();
      setPosition(bounds.x, bounds.y);
    }

    function setMinimized(value) {
      body.hidden = value;
      minimize.querySelector('use').setAttribute('href', value ? '#i-chevron-up' : '#i-chevron-down');
      const action = value ? 'restore' : 'minimize';
      minimize.title = label(action);
      minimize.setAttribute('aria-label', label(action));
      minimize.setAttribute('aria-expanded', String(!value));
      keepInView();
    }

    function selectOptions(select, options) {
      const current = select.value;
      select.replaceChildren(...options.map(([value, text]) => new Option(text, value)));
      if (options.some(([value]) => value === current)) select.value = current;
    }

    function localize() {
      for (const node of panel.querySelectorAll('[data-label]')) node.textContent = label(node.dataset.label);
      grip.title = label('move');
      grip.setAttribute('aria-description', label('move'));
      field('mode').setAttribute('aria-label', label('mode'));
      closeButton.title = label('close');
      closeButton.setAttribute('aria-label', label('close'));
      setMinimized(body.hidden);
      if (body.hidden) return;
      setFormats();
      const types = new Map();
      for (const value of [...deliveryTypes, ...context.deliveryTypes]) {
        const key = window.BLBusinessRules.transitDelTypeKey(value);
        if (!types.has(key)) types.set(key, value);
      }
      selectOptions(field('delivery'), [...types.values()].map(value => [value, deliveryLabel(value)]));
      selectOptions(field('season'), [['', label('genericSeason')], ...context.seasons.map(value => [value, value])]);
      renderPlan();
    }

    let dateFormat, numberFormat;
    function setFormats() {
      const locale = T('tr-TR', 'en-GB');
      dateFormat = new Intl.DateTimeFormat(locale, { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC' });
      numberFormat = new Intl.NumberFormat(locale);
    }

    function displayDate(value) {
      if (!value) return '—';
      const date = new Date(value + 'T00:00:00Z');
      return dateFormat.format(date);
    }

    function displayDays(days) {
      if (days == null) return '—';
      const number = numberFormat.format(days);
      return T(`${number} gün`, `${number} ${Math.abs(days) === 1 ? 'day' : 'days'}`);
    }

    function renderAvailable() {
      const days = target ? engine.availableDays(target.retail, field('ex').value) : null;
      const output = result('days');
      output.textContent = displayDays(days);
      output.classList.toggle('isLate', days != null && days < 0);
    }

    function renderPlan() {
      if (body.hidden) return;
      const mode = field('mode').value;
      for (const node of panel.querySelectorAll('[data-mode]')) node.hidden = node.dataset.mode !== mode;
      target = engine.targetDates(mode, dateField().validity.valid ? dateField().value : '');
      result('retail').textContent = displayDate(target?.retail);
      renderAvailable();

      const offset = window.BLBusinessRules.RETAIL_TO_MB_DAYS;
      const monthEnd = window.BLDateDimension.hasMerchCalendar() ? T('Merch Calendar ay sonu', 'Merch Calendar month end') : T('Takvim ayı sonu', 'Calendar month end');
      result('hint').textContent = mode === 'month'
        ? T(`${monthEnd}${target ? ' · ' + displayDate(target.mb) : ''} · Retail ${offset} gün önce`, `${monthEnd}${target ? ' · ' + displayDate(target.mb) : ''} · Retail ${offset} days earlier`)
        : T(`Retail, MB tarihinden ${offset} gün önce`, `Retail is ${offset} days before the MB date`);

      const { countries, rules } = context;
      const delType = field('delivery').value;
      const season = field('season').value;
      const rows = [];
      if (target) {
        for (const country of countries) {
          const plan = engine.latestExFactory({ retail: target.retail, country, delType, season, rules });
          const row = document.createElement('tr');
          const name = document.createElement('th');
          name.scope = 'row';
          name.textContent = country;
          const date = document.createElement('td');
          if (plan) {
            const useDate = document.createElement('button');
            useDate.type = 'button';
            useDate.className = 'mbCalcDate';
            useDate.textContent = displayDate(plan.date);
            useDate.title = T('Deneme tarihi olarak kullan', 'Use as trial date');
            useDate.addEventListener('click', () => {
              field('ex').value = plan.date;
              renderAvailable();
              field('ex').focus();
            });
            date.append(useDate);
          } else {
            date.textContent = '—';
          }
          const route = document.createElement('td');
          route.textContent = plan ? displayDays(plan.days) : label('noRule');
          if (plan && plan.source !== 'country') {
            const source = document.createElement('small');
            source.textContent = label(plan.source);
            route.append(source);
          }
          row.append(name, date, route);
          rows.push(row);
        }
      }
      $('tbody').replaceChildren(...rows);
      table.hidden = !rows.length;
      const status = result('status');
      status.textContent = rows.length ? '' : target
        ? T('Ülke bilgisi bulunamadı.', 'No countries found.')
        : dateField().value
          ? T('Bu dönem için geçerli bir MB tarihi bulunamadı.', 'No valid MB date was found for this period.')
          : T('Hesaplamak için MB ayı veya tarihi girin.', 'Enter an MB month or date to calculate.');
      status.hidden = !status.textContent;
      keepInView();
    }

    function close() {
      controller.abort();
      panel.remove();
      active = null;
      if (opener?.getClientRects().length) opener.focus({ preventScroll: true });
    }

    grip.addEventListener('pointerdown', event => {
      if (!event.isPrimary || event.button !== 0) return;
      const bounds = panel.getBoundingClientRect();
      drag = { id: event.pointerId, x: event.clientX - bounds.left, y: event.clientY - bounds.top };
      grip.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    grip.addEventListener('pointermove', event => {
      if (drag?.id === event.pointerId) setPosition(event.clientX - drag.x, event.clientY - drag.y);
    });
    grip.addEventListener('lostpointercapture', () => { drag = null; });
    grip.addEventListener('keydown', event => {
      const moves = { ArrowLeft: [-12, 0], ArrowRight: [12, 0], ArrowUp: [0, -12], ArrowDown: [0, 12] };
      if (!moves[event.key]) return;
      event.preventDefault();
      event.stopPropagation();
      const [x, y] = moves[event.key];
      setPosition(position.x + x, position.y + y);
    });
    minimize.addEventListener('click', () => {
      setMinimized(!body.hidden);
      if (!body.hidden) active.refresh();
    });
    closeButton.addEventListener('click', close);
    panel.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !event.defaultPrevented) {
        event.preventDefault();
        event.stopPropagation();
        close();
      }
    });
    body.addEventListener('input', event => {
      if (event.target === field('ex')) renderAvailable();
      else if (event.target.matches('[data-field]')) renderPlan();
    });
    window.addEventListener('resize', keepInView, { signal });
    window.addEventListener('bl:merch-calendar-change', renderPlan, { signal });
    window.addEventListener('bl-refresh-finished', () => active?.refresh(), { signal });

    active = {
      localize,
      restore(nextOpener) {
        opener = nextOpener;
        setMinimized(false);
        active.refresh();
        dateField().focus({ preventScroll: true });
      },
      refresh() {
        if (!body.hidden) {
          context = readContext();
          localize();
        }
      },
    };
    document.body.append(panel);
    localize();
    window.BLMotionPlus?.play('overlay', panel);
    dateField().focus({ preventScroll: true });
  }

  window.BLMBExFactoryCalculator = { open, refresh: () => active?.refresh(), refreshLanguage: () => active?.localize() };
})();
