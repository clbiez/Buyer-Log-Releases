(function(global){
  'use strict';
  const Engine=global.BLCollectionLflEngine;
  let current=null;
  const en=()=>typeof appLang!=='undefined'&&appLang==='en';
  const T=(tr,english)=>en()?english:tr;
  const esc=value=>escapeHtml(String(value??''));
  const identity=()=>{const user=typeof state!=='undefined'?state.currentUser:global.BL_USER_CONTEXT;return JSON.stringify([user?.id,user?.iamRevision,user?.dataScope,user?.scopes]);};
  function session(){const id=identity();if(current?.id!==id){current={id,status:'idle',index:new Map(),detailRows:new Map(),pending:null,countries:[]};}return current;}
  /* BUYER ÜLKE KURALI: her buyer kendi çalışmadığı üretim ülkelerini Previous Season, LFL ve
     Sezon Etkisi referanslarından çıkarır. Kural satırın sahibinin (buyer) Koleksiyon verisidir:
     başka bir buyer bu modellere bakarken de sahibin kuralı uygulanır. Kaynak veri ve kalıcı
     referans özetleri değişmez; hariç tutma ülke kırılımı üzerinden hesaplanır. */
  const NO_RULE=Object.freeze({ownerId:'',ownerName:'',countries:[],canEdit:false});
  function ruleFor(row){
    const rule=typeof global.kolLflCountryRuleFor==='function'?global.kolLflCountryRuleFor(row):null;
    return rule?{...NO_RULE,...rule,countries:Engine.countryList(rule.countries)}:NO_RULE;
  }
  function setOwnerCountries(countries){
    if(typeof global.kolSetLflCountryExclusions!=='function'||global.kolSetLflCountryExclusions(Engine.countryList(countries))===false)return false;
    session().detailRows=new Map();
    repaint();
    return true;
  }
  // Saved pre-country summaries cannot be filtered; they are shown unchanged until references are refreshed.
  const excludedFor=row=>session().countryAware?ruleFor(row).countries:[];
  const countryNames=new Map();
  function countryName(code){
    if(!code)return T('Bilinmiyor','Unknown');
    const lang=en()?'en':'tr',id=lang+':'+code;
    if(countryNames.has(id))return countryNames.get(id);
    let label=code;
    try{const name=new Intl.DisplayNames([lang],{type:'region'}).of(code);if(name&&name!==code)label=`${name} (${code})`;}catch(_){}
    countryNames.set(id,label);return label;
  }
  const exclusionText=codes=>codes.length?T(`Hariç ülkeler: ${codes.map(countryName).join(', ')}`,`Excluded countries: ${codes.map(countryName).join(', ')}`):'';
  function repaint(){
    if(document.body.dataset.activeTab==='koleksiyon'&&typeof renderKol==='function')renderKol();
    global.BLCollectionPriceDrawer?.refresh?.();
  }
  function ensure({rebuild=false}={}){
    const active=session();
    if(active.pending)return active.pending;
    if(!rebuild&&!active.invalidated&&active.status!=='idle')return Promise.resolve();
    active.invalidated=false;
    const hadReference=active.status==='ready';
    if(!hadReference)active.status='loading';
    active.refreshError='';active.refreshNotice=null;
    active.detailRows=new Map();
    active.pending=(async()=>{
      try{
        const response=await fetch('/api/collection-lfl-reference'+(rebuild?'?rebuild=1':''),{cache:'no-store'});
        const data=await response.json();
        if(!response.ok){
          if(response.status===403){active.status='forbidden';active.index=new Map();active.timelines=null;}
          else if(hadReference){active.status='ready';active.refreshError=data.code||'LOAD_ERROR';}
          else active.status=data.code==='SOURCE_FILTER_REQUIRED'?'filter':'error';
          return;
        }
        active.index=new Map((data.references||[]).map(item=>[item.key,item]));active.countryAware=(data.references||[]).some(item=>Array.isArray(item.byCountry));active.countries=[...new Set((data.references||[]).filter(item=>item.currency==='USD').flatMap(item=>(item.byCountry||[]).map(part=>part.country)))].filter(Boolean).sort();active.timelines=Engine.createSeasonTimelines(data.references);active.version=String(data.version||'');active.calculatedAt=data.calculatedAt;active.status='ready';
        if(rebuild)active.refreshNotice={removed:Math.max(0,Number(data.removedCount)||0)};
      }catch(_){active.status=hadReference?'ready':'error';active.refreshError='LOAD_ERROR';}
      finally{
        active.pending=null;
        if(current===active){
          repaint();
          // Explicit refresh outcome is announced; the drawer note keeps the same text.
          if(rebuild&&(active.refreshError||active.refreshNotice))global.showToast?.(active.refreshError?refreshErrorMessage(active.refreshError):refreshNoticeMessage(active.refreshNotice));
        }
      }
    })();
    return active.pending;
  }
  function invalidate(){
    // Source refreshes may clear their own runtime; retain displayed references
    // until a new durable response has successfully replaced them.
    const active=session();active.detailRows=new Map();active.invalidated=true;
    if(document.body.dataset.activeTab==='koleksiyon')void ensure({rebuild:false});
  }
  /* LFL / Previous Season / Sezon Etkisi kıyası FOB sütunundaki Final FOB ile yapılır:
     Supp. FOB (Confirmed → Best → Target) + License Royalty + Hologram. ASAS referans
     FOB'u da Final FOB olduğundan ham Supp. FOB lisanslı modelleri sistematik düşük
     gösterirdi. Değer FOB sütununun kendisidir (row.fob): renderKol çizimden önce
     kolSyncRulePricing ile tüm satırlarda yeniler; kural eksik/belirsizse FOB boştur
     ve kıyas da yapılmaz (price=null). Kural burada yeniden çözülmez. */
  function finalFobValue(row){
    const value=global.kolParseMoneyNum(row?.fob);
    return Number.isFinite(value)&&value>0?value:null;
  }
  function finalFob(row,supp){
    if(!supp||!Number.isFinite(supp.price)||supp.price<=0)return null;
    return {...supp,suppPrice:supp.price,price:finalFobValue(row)};
  }
  const sourceName=price=>price?({confirmed:'Confirmed Price',best:'Best Price',target:'Target Price'}[price.source]||''):'';
  const sourceLabel=price=>price?.price!=null?`Final FOB · ${sourceName(price)}`:'';
  const finalFobBreakdown=price=>price?.price!=null?`Final FOB $${kolFormatMoneyDisplay(String(price.price))} = ${sourceName(price)} $${kolFormatMoneyDisplay(String(price.suppPrice))} + Royalty + Hologram`:'';
  const ruleMissingText=()=>T('Final FOB hesaplanamadı: eşleşen License Royalty / Hologram kuralı yok veya Licensor belirsiz.','Final FOB could not be calculated: no matching License Royalty / Hologram rule or the Licensor is unresolved.');
  function projectRow(row,read=kolEffectiveValue){
    const projected={...row};
    for(const key of ['season','mag','urunTipi','inStoreMonth','quantity','targetPrice','confirmedManufacturer'])projected[key]=read(row,key);
    return projected;
  }
  function sampleWarning(reference){
    const unknownSample=Boolean(reference&&(reference.unidentifiedCount>0||!Number.isInteger(reference.orderCount)||reference.orderCount<1));
    const lowSample=Boolean(reference&&!unknownSample&&reference.orderCount<=3);
    const warning=unknownSample?T('Referanstaki farklı sipariş sayısı doğrulanamıyor; kıyaslamayı kontrol edin.','The number of distinct reference orders cannot be verified; review the comparison.'):lowSample?T(`Referans yalnız ${reference.orderCount} farklı siparişe dayanıyor. Model farkları sonucu etkileyebilir; kıyaslamayı kontrol edin.`,`The reference is based on only ${reference.orderCount} distinct order(s). Model differences may affect the result; review the comparison.`):'';
    const warningShort=unknownSample?T('⚠ Sipariş sayısı belirsiz','⚠ Order count unknown'):lowSample?T(`⚠ Yalnız ${reference.orderCount} sipariş`,`⚠ Only ${reference.orderCount} order(s)`):'';
    const compactWarning=unknownSample?T('⚠ Sayı belirsiz','⚠ Count unknown'):lowSample?T(`⚠ ${reference.orderCount} sipariş`,`⚠ ${reference.orderCount} orders`):'';
    const orderInfo=reference&&!unknownSample?T(`${reference.orderCount} farklı sipariş`,`${reference.orderCount} distinct order(s)`):'';
    return {lowSample,warning,warningShort,compactWarning,orderInfo};
  }
  function impactModel(row){
    const active=session(),projected=projectRow(row);
    const excluded=excludedFor(row),price=finalFob(row,kolSuppFob(projected)),result=active.status==='ready'?Engine.seasonImpact(active.timelines,projected,price?.price,excluded):{status:active.status};
    const reference=result.status==='ready'?result.reference:null,quality=sampleWarning(reference),month=Engine.budgetMonth(projected,'collection'),season=String(projected.season||''),period=[season,month].filter(Boolean).join(' · ');
    const messages={
      dimensions:T('Sezon, MAG ve Klasman gerekli.','Season, MAG and Classification are required.'),
      month:T('Sezon etkisi için Model Bütçe Ayı gerekli.','Model Budget Month is required for season impact.'),
      'no-prior':T('Sezonun ilk ayında veya önceki MB aylarında eşleşen USD siparişi yoksa sezon etkisi hesaplanmaz.','Season impact is unavailable in the first season month or when earlier MB months have no matching USD orders.'),
      'linked-order':T('Satır bir siparişe bağlı; sezona ikinci kez eklenmez.','This row is linked to an order and is not added to the season twice.'),
      quantity:T('Sezon etkisi için sıfırdan büyük adet gerekli.','A positive quantity is required for season impact.'),
      price:price&&price.price==null?ruleMissingText():T('Sezon etkisi için Final FOB gerekli: geçerli Onaylı, Best veya Target fiyatı.','Season impact requires a Final FOB: a valid Confirmed, Best or Target price.'),
      forbidden:T('LFL verisi için erişim yetkisi gerekli.','Access to LFL data is required.'),
      filter:T('Kaynak Veride LFL filtresini tamamlayın.','Complete the LFL filter in Source Data.'),
      error:T('Sezon referansı yüklenemedi.','Could not load the season reference.'),
    };
    const noData=result.status==='no-prior',message=reference?'':messages[result.status]||T('Sezon referansı yükleniyor…','Loading season reference…');
    const emptyText=({'no-prior':T('Önceki ay verisi yok','No earlier-month data'),quantity:T('Adet gerekli','Quantity required'),price:T('Fiyat gerekli','Price required'),'linked-order':T('Siparişe bağlı','Linked to an order'),month:T('MB ayı gerekli','MB month required')})[result.status]||'—';
    const money=value=>`$${kolFormatMoneyDisplay(String(value))}`,rounded=reference?(Math.abs(result.percent)<0.005?0:result.percent):null;
    const percentText=rounded==null?'':`${rounded>0?'+':''}${rounded.toLocaleString(en()?'en-GB':'tr-TR',{maximumFractionDigits:2})}%`;
    const averageText=reference?`${money(result.before)} → ${money(result.after)}`:'',source=sourceLabel(price);
    const undated=reference?.undatedCount?T(`${reference.undatedCount} kaynak satırının MB ayı eksik; kapsama alınmadı.`,`${reference.undatedCount} source row(s) have no MB month and were excluded.`):'';
    const scope=reference?T(`${reference.firstMonth}–${reference.throughMonth} · ${reference.quantity} adet`,`${reference.firstMonth}–${reference.throughMonth} · ${reference.quantity} units`):'';
    const addition=reference?T(`Model: ${result.quantity} adet × ${money(result.price)} · ${source}`,`Model: ${result.quantity} units × ${money(result.price)} · ${source}`):'';
    const formula=T('Yeni ortalama = (mevcut tutar + model Final FOB × model adedi) / (mevcut adet + model adedi). Etki = (yeni ortalama / mevcut ortalama − 1) × 100. Aynı sezon, MAG, Klasman ve USD; yalnız modelin MB ayından önceki aylar. Her satır tek başına simüle edilir.','New average = (existing value + model Final FOB × model quantity) / (existing quantity + model quantity). Impact = (new average / existing average − 1) × 100. Same season, MAG, Classification and USD; only months before the model MB month. Each row is simulated independently.');
    const countries=exclusionText(excluded);
    const detail=reference?[period,`${projected.mag} · ${projected.urunTipi}`,scope,addition,`${averageText} · ${percentText}`,quality.orderInfo,quality.warning,undated,countries,formula].filter(Boolean).join('\n'):[message,countries].filter(Boolean).join('\n');
    return {reference,season,month,period,percent:result.percent,percentText,averageText,source,message,detail,noData,emptyText,excluded,...quality,text:reference?[period,averageText,percentText,addition,quality.warning,undated,countries].filter(Boolean).join(' · '):message,impact:result};
  }
  function model(row,mode='month'){
    if(mode==='impact')return impactModel(row);
    const active=session(),projected=projectRow(row);
    const season=Engine.previousSeason(projected.season),valid=Boolean(season&&String(projected.mag||'').trim()&&String(projected.urunTipi||'').trim());
    const month=mode==='month'?Engine.previousMonth(Engine.budgetMonth(projected,'collection')):'',period=[season,month].filter(Boolean).join(' · ');
    const excluded=excludedFor(row),reference=valid&&active.status==='ready'?Engine.reference(active.index,projected,mode,excluded):null;
    const price=finalFob(row,kolSuppFob(projected)),percent=reference?Engine.changePercent(price?.price,reference.average):null;
    const source=sourceLabel(price);
    const rounded=percent==null?null:Math.abs(percent)<0.05?0:percent;
    const percentText=rounded==null?'':`${rounded>0?'+':''}${rounded.toLocaleString(en()?'en-GB':'tr-TR',{maximumFractionDigits:1})}%`;
    const averageText=reference?`$${kolFormatMoneyDisplay(String(reference.average))}`:'';
    const noData=Boolean(valid&&(mode!=='month'||month)&&active.status==='ready'&&!reference);
    const {lowSample,warning,warningShort,compactWarning,orderInfo}=sampleWarning(reference);
    const emptyText=noData?T('Kıyaslanacak veri yok','No comparison data'):'—';
    let message='';
    if(!valid)message=T('Sezon, MAG ve Klasman gerekli.','Season, MAG and Classification are required.');
    else if(mode==='month'&&!month)message=T('LFL için geçerli bir Model Bütçe Ayı gerekli.','A valid Model Budget Month is required for LFL.');
    else if(active.status==='forbidden')message=T('LFL verisi için erişim yetkisi gerekli.','Access to LFL data is required.');
    else if(active.status==='filter')message=T('Kaynak Veride LFL filtresini tamamlayın.','Complete the LFL filter in Source Data.');
    else if(active.status==='error')message=T('LFL referansı yüklenemedi.','Could not load the LFL reference.');
    else if(active.status!=='ready')message=T('LFL referansı yükleniyor…','Loading LFL reference…');
    else if(!reference)message=T(`Kıyaslanacak veri yok. ${period} için MAG + Klasman ile eşleşen USD siparişi bulunamadı.`,`No comparison data. No USD orders matching MAG + Classification were found for ${period}.`);
    const explanation=(mode==='month'?T('Önceki yılın aynı MB ayı + MAG + Klasman için adet ağırlıklı FOB ortalaması.','Quantity-weighted FOB average for the same MB month last year + MAG + Classification.'):T('Önceki sezonun tüm ayları + MAG + Klasman için adet ağırlıklı FOB ortalaması.','Quantity-weighted FOB average for all months of the previous season + MAG + Classification.'))+' '+T('Yalnız USD siparişleri. Fark = (Final FOB / ortalama − 1) × 100; Final FOB = Supp. FOB + Royalty + Hologram (FOB sütunu).','USD orders only. Change = (Final FOB / average − 1) × 100; Final FOB = Supp. FOB + Royalty + Hologram (FOB column).');
    const countries=exclusionText(excluded);
    const detail=reference?[`${period} · ${projected.mag} · ${projected.urunTipi}`,`${orderInfo?orderInfo+' · ':''}${reference.count} ${T('kayıt','records')} · ${reference.quantity.toLocaleString(en()?'en-GB':'tr-TR')} ${T('adet','units')}`,finalFobBreakdown(price)||(price?ruleMissingText():''),warning,countries,explanation].filter(Boolean).join('\n'):[message,countries].filter(Boolean).join('\n');
    const text=reference?[period,averageText,percentText,source,orderInfo,warning,countries].filter(Boolean).join(' · '):noData?`${period} · ${emptyText}`:'';
    return {reference,season,month,period,percent,percentText,averageText,source,message,detail,text,noData,emptyText,excluded,lowSample,warning,warningShort,compactWarning};
  }
  function content(row,m=model(row)){
    if(!m.reference)return `<span class="kolPsEmpty" title="${esc(m.message)}">${esc(m.emptyText)}</span>`;
    const delta=m.percent==null?'':`<span class="kolBestDelta ${m.percent<=0?'isAtOrBelowTarget':'isAboveTarget'}">${esc(m.percentText)}</span>`;
    return `<div class="kolPs"><div class="kolPsLine"><b class="kolPsPrice">${esc(m.averageText)}</b>${delta}</div><div class="kolPsLine kolPsSub"><span class="kolPsMeta">${esc(m.period)}${m.source?` · ${esc(m.source)}`:''}</span></div>${m.warningShort?`<div class="kolPsLine"><span class="kolPsMeta kolPsWaiting" title="${esc(m.warning)}">${esc(m.warningShort)}</span></div>`:''}</div>`;
  }
  const modeForKey=key=>key==='__seasonImpact__'?'impact':key==='__previousSeason__'?'season':'month';
  const labelFor=key=>key==='__seasonImpact__'?T('Sezon Etkisi','Season Impact'):key==='__previousSeason__'?'Previous Season':'LFL';
  const footerKinds=new Set(['previousSeason','lfl','seasonImpact','priceReferences']);
  function footerSummaries(rows,modes){
    const active=session(),result=new Map(),groups=global.BLCollectionModelGroups;
    // Index all model parents once, including parents outside the active filter.
    const read=groups?.createValueReader?groups.createValueReader(typeof kolRows!=='undefined'?kolRows:rows):kolEffectiveValue;
    const items=(rows||[]).map(row=>{
      // Final FOB (row.fob) zaten Confirmed → Best → Target fiyatından türetilmiştir.
      const projected=projectRow(row,read);
      return {row:projected,price:finalFobValue(row),quantity:projected.quantity,excluded:excludedFor(row)};
    });
    for(const mode of new Set(modes)){
      const observations=items.map(item=>{
        if(active.status!=='ready')return {quantity:item.quantity,reference:null,price:null};
        if(mode==='impact'){const impact=Engine.seasonImpact(active.timelines,item.row,item.price,item.excluded);return {quantity:item.quantity,reference:impact.status==='ready'?impact.before:null,price:impact.status==='ready'?impact.after:null};}
        return {quantity:item.quantity,reference:Engine.reference(active.index,item.row,mode,item.excluded)?.average,price:item.price};
      });
      result.set(mode,Engine.summarizeComparisons(observations));
    }
    return result;
  }
  function footerCells(rows,descriptors){
    const columns=(descriptors||[]).filter(d=>footerKinds.has(d.kind));if(!columns.length)return new Map();
    const keys=d=>d.kind==='priceReferences'?d.folds||[]:[d.k],summaries=footerSummaries(rows,columns.flatMap(d=>keys(d).map(modeForKey))),cells=new Map();
    const money=value=>Number.isFinite(value)?`$${esc(kolFormatMoneyDisplay(String(value)))}`:'—';
    const delta=percent=>{const rounded=Math.abs(percent)<0.005?0:percent,text=`${rounded>0?'+':''}${rounded.toLocaleString(en()?'en-GB':'tr-TR',{maximumFractionDigits:2})}%`;return `<span class="kolBestDelta ${rounded<=0?'isAtOrBelowTarget':'isAboveTarget'}">${esc(text)}</span>`;};
    const line=(caption,value)=>`<span class="collectionAverageLine"><span class="collectionFooterCaption">${esc(caption)}</span><strong>${value}</strong></span>`;
    const value=(s,mode,arithmetic=false)=>{const before=arithmetic?s.arithmeticBefore:s.weightedBefore,after=arithmetic?s.arithmeticAfter:s.weightedAfter;return mode==='impact'&&Number.isFinite(before)&&Number.isFinite(after)?`${money(before)} → ${money(after)}`:money(before);};
    const title=(s,mode)=>T(`Filtrelenmiş satırların model/renk adediyle ağırlıklı ortalaması. Ağırlıklı hesaba dahil: ${s.usedRows}/${s.totalRows} satır · ${s.quantity} adet. Eksik referans veya sıfır/eksik adet ağırlıklı hesaba katılmaz.`,`Quantity-weighted average of filtered model/colour rows. Included in weighted average: ${s.usedRows}/${s.totalRows} rows · ${s.quantity} units. Missing references and zero/missing quantities are excluded.`)+' '+(mode==='impact'?T('Satırların bağımsız sezon simülasyonlarının önce → sonra özeti.','Before → after summary of independent row-level season simulations.'):T(`Yüzde değişimi, fiyat ve referansı birlikte olan ${s.pairedRows} satırda ağırlıklı güncel fiyat / ağırlıklı referans − 1 ile hesaplanır.`,`Percentage change uses weighted current price / weighted reference − 1 across ${s.pairedRows} rows with both a price and a reference.`));
    for(const d of columns){
      let content='',titles=[];
      for(const key of keys(d)){
        const mode=modeForKey(key),s=summaries.get(mode);if(!s)continue;
        titles.push(`${labelFor(key)}: ${title(s,mode)}`);
        // Kompakt sütunda her kıyas kendi ağırlıklı % değişimini aynı satırda gösterir.
        if(d.kind==='priceReferences'){content+=line(`${labelFor(key)} · ${T('Ağ.Ort.','W.Avg')}`,value(s,mode)+(Number.isFinite(s.percent)?' '+delta(s.percent):''));continue;}
        content+=line(T('Ağ.Ort.','W.Avg'),value(s,mode))+line(T('Ort.','Avg'),value(s,mode,true));
        if(Number.isFinite(s.percent))content+=line(T('Ağ.% Δ','W.% Δ'),delta(s.percent));
      }
      cells.set(d.k,`<td class="collectionWeightedAverage" data-kol-footer-key="${esc(d.k)}" title="${esc(titles.join('\n'))}">${content}</td>`);
    }
    return cells;
  }
  const combinedText=(row,keys)=>keys.map(key=>`${labelFor(key)}: ${model(row,modeForKey(key)).text||'—'}`).join(' | ');
  function cell(row,attributes,mode='month'){const m=model(row,mode);return `<td class="kolBestCell kolPriceStripTd" data-kol-drawer="${esc(row.id)}"${attributes} title="${esc(m.detail)}">${content(row,m)}</td>`;}
  function combinedCell(row,attributes,keys){
    /* Ortak kart dili: etiketli satırlar; her referansın kendi fiyatı ve kendi % etkisi. */
    const rows=keys.map(key=>{const m=model(row,modeForKey(key));const tag=m.percentText?`<span class="blCellTag" data-tone="${m.percent<=0?'good':'bad'}">${esc(m.percentText)}</span>`:'';const warn=m.compactWarning?`<span class="blCellNone kolPsWaiting" title="${esc(m.warning)}">${esc(m.compactWarning)}</span>`:'';return `<span class="blCellStackRow" title="${esc(m.detail)}"><span class="blCellStackLabel">${esc(labelFor(key))}</span><b class="blCellValue${m.reference?'':' isEmpty'}">${esc(m.averageText||m.emptyText)}</b><span class="blCellStackTail">${tag}${warn}</span></span>`;}).join('');
    return `<td class="kolBestCell kolPriceStripTd" data-kol-drawer="${esc(row.id)}"${attributes}><div class="kolPs blCellStack">${rows}</div></td>`;
  }
  function detailError(code){
    const messages={
      SOURCE_FILTER_REQUIRED:T('Kaynak Veride LFL filtresini tamamlayın.','Complete the LFL filter in Source Data.'),
      LFL_REFERENCE_STALE:T('LFL kaynağı değişti. Kayıtlı referanslar korunuyor; güncel detay için Referansları yenile düğmesini kullanın.','The LFL source changed. Saved references are preserved; use Refresh references for current details.'),
      LFL_REFERENCE_NOT_FOUND:T('Bu referans için erişilebilir sipariş bulunamadı.','No accessible orders were found for this reference.'),
      FORBIDDEN:T('Sipariş detayları için Koleksiyon ve LFL erişimi gerekli.','Collection and LFL access are required for order details.'),
    };
    return Object.assign(new Error(messages[code]||T('Sipariş detayları yüklenemedi. Tekrar deneyin.','Could not load order details. Please try again.')),{code});
  }
  async function detailData(row,mode){
    if(!['season','month','impact'].includes(mode))throw detailError('INVALID_MODE');
    await ensure();
    const active=session(),m=model(row,mode),reference=m.reference;
    if(!reference)throw new Error(m.message);
    const cache=active.detailRows,key=reference.key,excluded=m.excluded||[],cacheKey=key+'|'+excluded.join(',');
    let task=cache.get(cacheKey);
    if(!task){
      task=(async()=>{
        const response=await fetch('/api/collection-lfl-detail',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,version:active.version,excludedCountries:excluded})});
        const data=await response.json();
        if(!response.ok)throw detailError(response.status===403?'FORBIDDEN':data.code);
        if(session()!==active||active.detailRows!==cache)throw detailError('LFL_DETAIL_CANCELLED');
        if(data.version!==active.version||data.reference?.key!==key||!Array.isArray(data.rows))throw detailError('LFL_REFERENCE_STALE');
        return data;
      })();
      // Details stay in memory only, bounded by the number of explicitly opened groups.
      if(cache.size>=12)cache.delete(cache.keys().next().value);
      cache.set(cacheKey,task);
      task.catch(()=>{if(cache.get(cacheKey)===task)cache.delete(cacheKey);});
    }
    try{return await task;}
    catch(error){
      throw error.code?error:detailError('LOAD_ERROR');
    }
  }
  async function detailReport(row,mode){
    const data=await detailData(row,mode),m=model(row,mode),projected=projectRow(row),reference=data.reference;
    if(m.reference?.key!==reference.key||session().version!==data.version)throw detailError('LFL_DETAIL_CANCELLED');
    const key=mode==='impact'?'__seasonImpact__':mode==='season'?'__previousSeason__':'__lfl__',label=labelFor(key);
    const fields=global.BLCanonicalFields,number=value=>Number(value).toLocaleString(en()?'en-GB':'tr-TR',{maximumFractionDigits:2});
    const field=(id,key=id)=>({key,canonicalId:id,label:fields.label(id,en()?'en':'tr'),type:fields.field(id).type,value:source=>fields.value(source,'lfl',id)});
    const columns=[field('orderCode'),field('modelName'),field('colour'),field('manufacturer'),field('season'),field('mag'),field('category','classification'),
      {key:'_referenceMonth',label:T('Model Bütçe Ayı','Model Budget Month')},
      {key:'_referenceQuantity',canonicalId:'orderQuantity',label:T('Sipariş Adedi','Order Quantity'),type:'number',format:number},
      {key:'_referenceFob',canonicalId:'fob',label:'FOB (USD)',type:'number',format:value=>`$${number(value)}`},
      {key:'_referenceValue',label:T('Tutar (USD)','Value (USD)'),type:'number',format:value=>`$${number(value)}`},
      {key:'_referenceWeight',label:T('Ağırlık Payı (%)','Weight Share (%)'),type:'number',format:value=>`${number(value)}%`},
      field('country'),field('buyer'),field('buyingGroup'),field('colourCode'),field('plmId'),field('inStore'),field('orderPlacementDate','opd'),field('license')];
    const title=`${label} · ${T('Sipariş detayları','Order details')}`;
    return {storageKey:'collection.price-reference.'+mode,source:'lfl',moduleId:'lfl',pageScope:'koleksiyon',title,
      subtitle:[projected.modelKod,m.period,projected.mag,projected.urunTipi,sampleWarning(reference).orderInfo,`${number(reference.quantity)} ${T('adet','units')}`,`${T('Ağ.Ort.','W.Avg')} $${number(reference.average)}`].filter(Boolean).join(' · '),
      note:m.detail+(mode==='impact'?' '+T('Tablo yerleşmiş ASAS siparişlerini gösterir; model yalnız simülasyondur, sipariş satırlarına eklenmez.','The table shows placed ASAS orders; the model is a simulation and is not added to the order rows.') :''),
      rows:data.rows,columns,defaultVisible:columns.slice(0,12).map(col=>col.key),exactDefaultVisible:true,viewPresets:{extended:columns.map(col=>col.key)},images:true,fileName:'Collection_'+label+'_Orders'};
  }
  function countryRuleHtml(row){
    const rule=ruleFor(row),active=session(),selected=new Set(rule.countries),byName=(a,b)=>countryName(a).localeCompare(countryName(b),en()?'en':'tr');
    const countries=[...new Set([...(active.countries||[]),...rule.countries])].sort(byName);
    const owner=rule.ownerName||rule.ownerId||'—';
    const picker=`<div class="cpdInput"><span>${esc(T('Hesaba katılmayacak ülkeler','Countries to exclude'))}</span><details class="cpdCountryPicker"><summary class="tbtn">${esc(T('Ülke seçin…','Choose countries…'))}</summary><div class="cpdCountryList cardBox" role="group" aria-label="${esc(T('Hesaba katılmayacak ülkeler','Countries to exclude'))}">${countries.length?countries.map(code=>`<label><input type="checkbox" data-cpd-lfl-country="${esc(code)}"${selected.has(code)?' checked':''}${rule.canEdit?'':' disabled'}><span>${esc(countryName(code))}</span></label>`).join(''):`<p class="cpdEmpty">${esc(active.status==='ready'?T('Ülke bulunamadı','No countries found'):T('Ülkeler yükleniyor…','Loading countries…'))}</p>`}</div></details></div>`;
    const legacy=active.status==='ready'&&!active.countryAware;
    const status=legacy?T('Kayıtlı referanslar ülke kırılımı içermiyor; filtrenin uygulanması için Referansları yenile düğmesini kullanın.','Saved references have no country breakdown; use Refresh references to apply the filter.'):'';
    const note=rule.canEdit
      ?T(`Kural ${owner} buyer'ına aittir ve bu Koleksiyon'un tüm modellerine uygulanır; bu modellere bakan diğer kullanıcılar da aynı kurala göre görür. Türkiye siparişleri TRY olduğu için bu USD hesaplarına zaten girmez.`,`The rule belongs to buyer ${owner} and applies to every model in this Collection; other users viewing these models see the same rule. Türkiye orders are in TRY and are never part of these USD calculations.`)
      :T(`Kural ${owner} buyer'ına aittir; yalnız görüntülenir. Hesaplar bu buyer'ın kuralına göre yapılır.`,`The rule belongs to buyer ${owner} and is view-only here. Calculations follow this buyer's rule.`);
    return `<div class="cpdSection cpdCountryRule"><header><h4>${esc(T('Ülke filtresi','Country filter'))}</h4><span>${esc(T(`Buyer: ${owner}`,`Buyer: ${owner}`))}</span></header>
      ${picker}${status?`<p class="cpdNote" role="status">${esc(status)}</p>`:''}
      <p class="cpdNote">${esc(note)}</p></div>`;
  }
  function onDrawerChange(target,row){
    const checkbox=target.closest('[data-cpd-lfl-country]');if(!checkbox)return false;
    const code=checkbox.dataset.cpdLflCountry,rule=ruleFor(row);
    const countries=checkbox.checked?[...rule.countries,code]:rule.countries.filter(item=>item!==code);
    if(code&&rule.canEdit&&!setOwnerCountries(countries))global.showToast?.(T('Ülke filtresi kaydedilemedi.','Could not save the country filter.'));
    return true;
  }
  function refreshErrorMessage(code){
    const messages={
      LFL_REFERENCE_INCOMPLETE:T('LFL kaynağı boş olduğu için yenilenemedi. Kayıtlı referanslar korundu; LFL kaynak kapsamını kontrol edin.','Refresh could not complete because the LFL source is empty. Saved references were preserved; check the LFL source scope.'),
      SOURCE_FILTER_REQUIRED:T('Referanslar yenilenemedi. Kaynak Veri ekranında LFL filtresini tamamlayın, ardından tekrar deneyin. Kayıtlı değerler korundu.','Could not refresh references. Complete the LFL filter in Source Data, then retry. Saved values were preserved.'),
      LFL_SOURCE_UNAVAILABLE:T('LFL kaynağı yüklenmemiş. Kaynak Veri ekranında LFL verisini yükleyin veya yenileyin, ardından referansları tekrar yenileyin. Kayıtlı değerler korundu.','The LFL source is not loaded. Load or refresh LFL data in Source Data, then refresh references again. Saved values were preserved.'),
      COMPUTE_STALE_GENERATION:T('Kaynak işlem sırasında değişti. Yenileme tamamlandıktan sonra tekrar deneyin. Kayıtlı değerler korundu.','The source changed during refresh. Retry after the source refresh completes. Saved values were preserved.'),
      COMPUTE_QUEUE_BUSY:T('Hesaplama kuyruğu dolu. Kısa bir süre sonra tekrar deneyin. Kayıtlı değerler korundu.','The compute queue is full. Retry shortly. Saved values were preserved.'),
    };
    return messages[code]||T('Referanslar yenilenemedi. Kayıtlı değerler korundu; tekrar deneyebilirsiniz.','Could not refresh references. Saved values were preserved; you can retry.')+' '+T(`Hata kodu: ${code}`,`Error code: ${code}`);
  }
  function refreshNoticeMessage(notice){
    const removed=notice?.removed||0;
    return removed
      ?T(`Referanslar yenilendi. Güncel LFL kaynağında artık bulunmayan ${removed} referans grubu kaldırıldı (iptal edilen sipariş, değişen mağaza ayı, kaynak dışı sezon veya daraltılmış filtre).`,`References refreshed. ${removed} reference groups no longer in the current LFL source were removed (cancelled orders, changed in-store months, seasons outside the source or a narrower filter).`)
      :T('Referanslar yenilendi.','References refreshed.');
  }
  function drawer(row){
    void ensure();
    const sections=['__previousSeason__','__lfl__','__seasonImpact__'].map(key=>{const mode=modeForKey(key),m=model(row,mode),action=T('Sipariş detaylarını aç','Open order details');return `<div class="cpdSection"><header><h4><button type="button" class="tbtn" data-cpd-lfl-details="${mode}" title="${esc(action)}" aria-label="${esc(labelFor(key)+': '+action)}"${m.reference?'':' disabled'}>${esc(labelFor(key))} ↗</button></h4><span>${esc(key==='__seasonImpact__'?T('Tek model simülasyonu','Single-model simulation'):key==='__previousSeason__'?T('Sezon geneli','Full season'):T('Aynı MB ayı','Same MB month'))}</span></header>${content(row,m)}<p class="cpdNote">${esc(m.reference?m.detail:m.message)}</p></div>`;}).join('');
    const active=session(),note=active.refreshError
      ?refreshErrorMessage(active.refreshError)
      :active.refreshNotice?refreshNoticeMessage(active.refreshNotice)
      :T('Referanslar kalıcı saklanır. Güncellemek için Referansları yenile düğmesini kullanın.','References are saved permanently. Use Refresh references to update them.');
    return sections+countryRuleHtml(row)+`<p class="cpdNote" role="status">${esc(note)}</p><div class="cpdActions"><button type="button" class="tbtn" data-cpd-lfl-refresh${active.pending||active.status==='loading'?' disabled':''}>${esc(T('Referansları yenile','Refresh references'))}</button></div>`;
  }
  global.BLCollectionLfl={ensure,isPending:()=>Boolean(current&&current.pending),invalidate,model,cell,combinedCell,combinedText,modeForKey,drawer,onDrawerChange,detailReport,footerSummaries,footerCells,text:(row,mode='month')=>model(row,mode).text};
})(window);
