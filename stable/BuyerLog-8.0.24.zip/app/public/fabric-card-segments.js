/* Shared Fabric Card segment contract: pure, deterministic and bilingual. */
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.BLFabricSegments=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const FIELDS=Object.freeze(['type','yarn','weight','composition']);
  const SEPARATOR=' · ',BAD=/[·•|;\r\n]/;
  // A segment may be blank in both languages (e.g. unknown weight). The stored
  // summarySegments keep '' ; the composed summary keeps its 4 slots with this
  // marker so tables can still split it, and parse() turns it back into ''.
  const EMPTY_PIECE='—';
  const TERMS=Object.freeze([
    ['Üç İplik Şardonlu','Brushed Three Thread',['3 iplik şardonlu','brushed 3 thread']],
    ['Üç İplik Şardonsuz','Unbrushed Three Thread',['3 iplik şardonsuz','unbrushed 3 thread']],
    ['Üç İplik','Three Thread',['3 iplik','3 thread']],
    ['İki İplik Şardonlu','Brushed Two Thread',['2 iplik şardonlu','brushed 2 thread']],
    ['İki İplik Şardonsuz','Unbrushed Two Thread',['2 iplik şardonsuz','unbrushed 2 thread']],
    ['İki İplik','Two Thread',['2 iplik','2 thread']],
    ['Süprem','Single Jersey',['suprem']],['İnterlok','Interlock',[]],
    ['Ribana','Rib',[]],['Kaşkorse','Ribbed Knit',[]],['Pike','Pique',[]],
    ['Polar','Fleece',[]],['Scuba','Scuba',[]]
  ]);
  const FIBRES=Object.freeze([
    ['Geri Dönüşümlü Polyester','Recycled Poliester'],
    ['Geri Dönüşümlü Pamuk','Recycled Cotton'],
    ['Organik Pamuk','Organic Cotton'],
    ['Polyester','Poliester'],['Poliester','Poliester'],['Pamuk','Cotton'],
    ['Viskon','Viscose'],['Viskoz','Viscose'],['Elastan','Elastane'],
    ['Poliamid','Polyamide'],['Akrilik','Acrylic'],['Keten','Linen'],['Yün','Wool']
  ]);
  function clean(value){return String(value==null?'':value).replace(/\s+/g,' ').trim();}
  function fold(value){return clean(value).toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i');}
  function numbers(value){return (clean(value).match(/\d+(?:[.,]\d+)?/g)||[]).map(v=>v.replace(',','.'));}
  function numbersMatch(a,b){const x=numbers(a),y=numbers(b);return x.length===y.length&&x.every((v,i)=>v===y[i]);}
  function validPiece(value){const x=clean(value);return !!x&&x.length<=500&&!BAD.test(x);}
  function slotPiece(value){return !clean(value)||validPiece(value);}
  function parse(summary){
    const pieces=String(summary||'').split(SEPARATOR).map(x=>clean(x)===EMPTY_PIECE?'':x);
    return pieces.length===4&&pieces.every(slotPiece)&&pieces.some(x=>clean(x))?pieces.map(clean):null;
  }
  function compose(parts){
    return Array.isArray(parts)&&parts.length===4&&parts.every(slotPiece)&&parts.some(x=>clean(x))
      ?parts.map(x=>clean(x)||EMPTY_PIECE).join(SEPARATOR):'';
  }
  function weight(text){const m=clean(text).match(/^(\d+(?:[.,]\d+)?)\s*(?:gsm|gr|g|g\/m2|g\/m²)?$/i);return m?m[1].replace(',','.')+' gsm':null;}
  function translateKnown(value,field,from){
    const text=clean(value);
    if(!validPiece(text)||!FIELDS.includes(field))return {status:'invalid',value:''};
    if(field==='yarn'){
      const x=text.replace(/\s*\/\s*/g,'/');
      if(/^\d+(?:\/\d+)*(?:\s*(?:Ne|Nm|Tex))?$/i.test(x))return {status:'known',value:x};
      const translations=from==='tr'?[['Penye','Combed'],['Karde','Carded']]:[['Combed','Penye'],['Carded','Karde']];
      const translated=translations.reduce((value,pair)=>value.replace(new RegExp('\\b'+pair[0]+'\\b','gi'),pair[1]),x);
      return /^\d+(?:\/\d+)*(?:\s*(?:Ne|Nm|Tex))?\s+(?:Penye|Karde|Combed|Carded)$/i.test(translated)
        ? {status:'known',value:translated}:{status:'needs-review',value:''};
    }
    if(field==='weight'){const x=weight(text);return x?{status:'known',value:x}:{status:'needs-ai',value:''};}
    if(field==='type'){
      const pair=TERMS.find(pair=>[pair[0],pair[1],...(pair[2]||[])].some(a=>fold(a)===fold(text)));
      return pair?{status:'known',value:pair[from==='tr'?1:0],canonical:pair[from==='tr'?0:1]}:{status:'needs-ai',value:''};
    }
    const pairs=FIBRES.slice().sort((a,b)=>b[from==='tr'?0:1].length-a[from==='tr'?0:1].length);
    let rest=text,changed=false;const marks=[];
    for(const pair of pairs){
      const src=pair[from==='tr'?0:1],dst=pair[from==='tr'?1:0];
      const escaped=src.replace(/[\^$.*+?()[\]{}|]/g,'\\$&');
      const rx=new RegExp('(^|[^A-Za-zÇĞİÖŞÜçğıöşü])('+escaped+')(?![A-Za-zÇĞİÖŞÜçğıöşü])','gi'); // i18n-ignore — technical Unicode word-boundary regex, not a UI string.
      rest=rest.replace(rx,function(_,lead){changed=true;marks.push(dst);return lead+'\u0001'+(marks.length-1)+'\u0002';});
    }
    rest=rest.replace(/\u0001(\d+)\u0002/g,(_,i)=>marks[Number(i)]);
    const knownWords=['Geri Dönüşümlü','Organik','Polyester','Poliester','Pamuk','Viskon','Viskoz','Elastan','Poliamid','Akrilik','Keten','Yün','Cotton','Viscose','Elastane','Polyamide','Acrylic','Linen','Wool','Recycled','Organic'];
    let leftover=rest.replace(/\d+(?:[.,]\d+)?/g,'').replace(/[%\s\/.,()+-]/g,'');
    for(const word of knownWords)leftover=leftover.replace(new RegExp(word,'gi'),'');
    return changed&&!leftover&&numbersMatch(text,rest)?{status:'known',value:rest}:{status:'needs-ai',value:''};
  }
  function validatePair(tr,en){
    if(!Array.isArray(tr)||!Array.isArray(en)||tr.length!==4||en.length!==4||!tr.every(slotPiece)||!en.every(slotPiece))
      return {ok:false,code:'FABRIC_SEGMENTS_INVALID'};
    if(tr.some((x,i)=>!clean(x)!==!clean(en[i])))return {ok:false,code:'FABRIC_SEGMENTS_INCOMPLETE'};
    if(!tr.some(x=>clean(x)))return {ok:false,code:'FABRIC_SEGMENTS_EMPTY'};
    const yarnTechnical=x=>clean(x).replace(/[^\d\/.,]/g,'').replace(/,/g,'.');
    const weightOk=!clean(tr[2])||(weight(tr[2])!==null&&weight(tr[2])===weight(en[2]));
    if(yarnTechnical(tr[1])!==yarnTechnical(en[1])||!weightOk)
      return {ok:false,code:'FABRIC_TECHNICAL_MISMATCH'};
    if(![1,2,3].every(i=>numbersMatch(tr[i],en[i])))
      return {ok:false,code:'FABRIC_NUMBERS_MISMATCH'};
    return {ok:true,tr:tr.map(clean),en:en.map(clean)};
  }
  /* Older rule/AI summaries omit an unknown slot ("Type · 240 gsm · 60% Cotton").
     Each piece is assigned to a slot only by an unambiguous shape; any doubt
     returns null and the caller keeps the original text untouched. */
  const YARN_SHAPE=/^\d{1,4}(?:\s*\/\s*\d{1,4})*(?:\s*(?:Ne|Nm|Tex|dtex|D|Den|Denye|Denier))?(?:\s+[A-Za-zÇĞİÖŞÜçğıöşü][A-Za-zÇĞİÖŞÜçğıöşü ]*)?$/i; // i18n-ignore — technical yarn pattern, not a UI string.
  function slotOf(piece){
    if(weight(piece))return 2;
    if(/%/.test(piece))return 3;
    if(!/\d/.test(piece))return 0;
    return YARN_SHAPE.test(piece)?1:-1;
  }
  function classify(summary){
    const exact=parse(summary);if(exact)return exact;
    const pieces=String(summary||'').split(/\s*·\s*/).map(clean).filter(x=>x&&x!==EMPTY_PIECE);
    if(!pieces.length||pieces.length>4||!pieces.every(validPiece))return null;
    const out=['','','',''];
    for(const piece of pieces){const slot=slotOf(piece);if(slot<0||out[slot])return null;out[slot]=slot===2?weight(piece):piece;}
    // A lone free-text phrase is a type only when the glossary knows it.
    if(pieces.length===1&&out[0]&&!['tr','en'].some(lang=>translateKnown(out[0],'type',lang).status==='known'))return null;
    return out;
  }
  function slotOk(i,a,b){
    const x=clean(a),y=clean(b);
    if(!x||!y)return !x&&!y;
    if(i===2)return weight(x)!==null&&weight(x)===weight(y);
    if(i===1&&x.replace(/[^\d\/.,]/g,'').replace(/,/g,'.')!==y.replace(/[^\d\/.,]/g,'').replace(/,/g,'.'))return false;
    return i===0||numbersMatch(x,y);
  }
  const NUM=/\d+(?:[.,]\d+)?/g;
  function shape(text){return fold(text).replace(NUM,'#');}
  function fieldIndex(field){return typeof field==='number'?field:FIELDS.indexOf(field);}
  /* Translation memory learned from the user's saved (manual) cards: the most
     recent card wins. Exact segment first, then the same wording with other
     numbers ("60% Pamuk 40% Polyester" teaches "50% Pamuk 50% Polyester").
     Weight is deterministic and is never learned. Pure, rebuilt from cards. */
  function learn(cards){
    const memory={exact:new Map(),shape:new Map()},list=[];
    const each=typeof cards?.forEach==='function'?cards:Object.values(cards||{});
    each.forEach(card=>{if(card&&card.summarySource==='manual')list.push(card);});
    list.sort((a,b)=>String(a.updatedAt||'').localeCompare(String(b.updatedAt||'')));
    for(const card of list){
      const seg=fromCard(card);
      if(seg.legacy||!validatePair(seg.tr,seg.en).ok)continue;
      for(const i of [0,1,3])for(const lang of ['tr','en']){
        const a=seg[lang][i],b=seg[lang==='tr'?'en':'tr'][i];
        if(!a||!b)continue;
        memory.exact.set(i+'|'+lang+'|'+fold(a),b);
        if(numbers(a).length&&numbersMatch(a,b))memory.shape.set(i+'|'+lang+'|'+shape(a),b);
      }
    }
    return memory;
  }
  function recall(memory,field,from,text){
    const i=fieldIndex(field),src=clean(text);
    if(!memory||![0,1,3].includes(i)||!validPiece(src))return '';
    const lang=from==='en'?'en':'tr';
    let hit=memory.exact.get(i+'|'+lang+'|'+fold(src))||'';
    if(!hit&&numbers(src).length){
      const learned=memory.shape.get(i+'|'+lang+'|'+shape(src));
      if(learned){const values=numbers(src).map(String);let k=0;hit=learned.replace(NUM,()=>values[k++]);}
    }
    return hit&&validPiece(hit)&&slotOk(i,lang==='tr'?src:hit,lang==='tr'?hit:src)?clean(hit):'';
  }
  /* Segments for a card: stored pair → exact 4-part summaries → slot
     classification of shorter summaries. A missing/mismatched language piece is
     derived (memory, then glossary) or left empty for the editor to translate. */
  function fromCard(card,memory){
    const raw=card&&card.summarySegments;
    if(raw&&raw.tr&&raw.en){const c=validatePair(raw.tr,raw.en);if(c.ok)return {tr:c.tr,en:c.en,legacy:false};}
    const tr=parse(card&&card.summary),en=parse(card&&card.summaryEn);
    if(tr&&en&&validatePair(tr,en).ok)return {tr,en,legacy:false};
    const ctr=classify(card&&card.summary),cen=classify(card&&card.summaryEn);
    const base=ctr||cen;
    if(base){
      const from=ctr?'tr':'en',to=from==='tr'?'en':'tr',out={tr:['','','',''],en:['','','','']};
      const other=from==='tr'?cen:ctr;
      for(let i=0;i<4;i++){
        out[from][i]=base[i];
        if(!base[i])continue;
        if(other&&slotOk(i,from==='tr'?base[i]:other[i],from==='tr'?other[i]:base[i]))out[to][i]=other[i];
        else{const known=i===2?{status:'known',value:base[i]}:translateKnown(base[i],FIELDS[i],from);out[to][i]=recall(memory,i,from,base[i])||(known.status==='known'?known.value:'');}
      }
      return {tr:out.tr,en:out.en,legacy:false};
    }
    // Unsplittable legacy text: the warning keeps it visible; details only prefill.
    const d=card&&card.details||{},prefill=[d.type,d.yarn,d.weight,d.composition].map(x=>{const v=clean(x);return validPiece(v)?v:'';});
    if(prefill[2])prefill[2]=weight(prefill[2])||'';
    return {tr:tr||prefill,en:en||['','','',''],legacy:Boolean(card&&card.summary)};
  }
  /* Learned translations from one saved card → proposed updates for the other
     cards. Never writes; segments with a manual override are respected. */
  function suggestUpdates(cards,memory,options){
    const skip=String(options&&options.exclude||''),out=[];
    if(!memory)return out;
    // Cheap text prefilter: only cards mentioning a learned piece are parsed.
    const needles=[...memory.exact.keys(),...memory.shape.keys()].map(key=>key.split('|').slice(2).join('|').replace(NUM,'#')).filter(Boolean);
    const each=typeof cards?.forEach==='function'?cards:Object.values(cards||{});
    each.forEach(card=>{
      if(!card||!card.code||String(card.code)===skip)return;
      const hay=shape([card.summary,card.summaryEn,...(card.summarySegments?[].concat(card.summarySegments.tr||[],card.summarySegments.en||[]):[])].join(' · '));
      if(!needles.some(needle=>hay.includes(needle)))return;
      const seg=fromCard(card);if(seg.legacy)return;
      const tr=seg.tr.slice(),en=seg.en.slice(),ov=card.translationOverrides||{},changed=[];
      for(const i of [0,1,3]){
        if(tr[i]&&!(ov.en&&ov.en[i])){const hit=recall(memory,i,'tr',tr[i]);if(hit&&hit!==en[i]){en[i]=hit;changed.push(i);}}
        else if(!tr[i]&&en[i]&&!(ov.tr&&ov.tr[i])){const hit=recall(memory,i,'en',en[i]);if(hit){tr[i]=hit;changed.push(i);}}
      }
      if(!changed.length)return;
      const checked=validatePair(tr,en);
      if(checked.ok)out.push({code:String(card.code),card,before:{tr:seg.tr,en:seg.en},after:{tr:checked.tr,en:checked.en},changed});
    });
    return out.sort((a,b)=>a.code.localeCompare(b.code,'en',{numeric:true}));
  }
  /* New rule/AI cards adopt the user's learned translations (TR → EN). */
  function applyMemory(card,memory){
    if(!card||!memory)return card;
    const seg=fromCard(card,memory);if(seg.legacy)return card;
    const en=seg.en.slice();let changed=false;
    for(const i of [0,1,3]){const hit=seg.tr[i]&&recall(memory,i,'tr',seg.tr[i]);if(hit&&hit!==en[i]){en[i]=hit;changed=true;}}
    const checked=validatePair(seg.tr,en);
    if(!changed||!checked.ok)return card;
    return Object.assign({},card,{summary:compose(checked.tr),summaryEn:compose(checked.en),summarySegments:{tr:checked.tr,en:checked.en},
      translationOverrides:{tr:[false,false,false,false],en:[false,false,false,false]},segmentSourceLang:'tr'});
  }
  return Object.freeze({FIELDS,SEPARATOR,EMPTY_PIECE,TERMS,clean,parse,compose,validPiece,weight,numbers,numbersMatch,translateKnown,validatePair,classify,fromCard,learn,recall,suggestUpdates,applyMemory});
});
