/* Buyer Log — Fiyat Masası (Pricing Desk).

   Quotations ve Fiyat Geçmişi tek çalışma alanında birleşir:
     · Masa     — fiyat talepleri + model × üretici matrisi (görselli, hızlı giriş)
     · Turlar   — talep panosu (durum şeritleri) + pazarlık turları
     · Geçmiş   — model başına fiyat trendi (Fiyat Defteri olayları) + kayıt tablosu
     · Analiz   — klasman / MAG / MMYG / buyer × üretici fiyat analizi
   Üst çubuktaki Buyer kapsamı (Ben / seçili buyer'lar / tümü) dört sekmeye de
   uygulanır; yetki sunucudadır (yalnız görmeye yetkili olunan talepler gelir).

   Veri ve yazım quotations.js iç API'sinden (BL_QUOTATIONS.desk) geçer; hesap
   pricing-desk-engine.js saf motorundadır. Bu dosya yalnız görünüm ve etkileşimdir. */
(function(){
  'use strict';

  const E=window.BLPricingDeskEngine;
  if(!E)return;
  const Q=()=>window.BL_QUOTATIONS&&window.BL_QUOTATIONS.desk||null;
  const isEn=()=>typeof appLang!=='undefined'&&appLang==='en';
  const L=(tr,en)=>isEn()?en:tr;
  const clean=value=>String(value==null?'':value).trim();
  const clipboardLabel=value=>String(value??'').replace(/[\t\n\f\r ]+/g,' ');
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const locale=()=>isEn()?'en-GB':'tr-TR';
  const money=value=>Number.isFinite(value)?'$'+value.toLocaleString(locale(),{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
  const moneyPlain=value=>Number.isFinite(value)?value.toLocaleString(locale(),{minimumFractionDigits:2,maximumFractionDigits:2}):'';
  /* Matris para biçimi Koleksiyon tablosuyla aynıdır (dil ne olursa olsun
     ondalık virgül, binlik nokta: $1,62). Böylece aynı satırdaki Teklif & Onay
     kartı ile üretici fiyat hücreleri aynı rakamı aynı yazımla gösterir. */
  // Biçimleyici bir kez kurulur: toLocaleString(seçenekli) her çağrıda yeni Intl nesnesi üretir.
  const kformat=new Intl.NumberFormat('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2});
  const kplain=value=>Number.isFinite(value)?kformat.format(value):'';
  const kmoney=value=>Number.isFinite(value)?'$'+kplain(value):'—';
  const pctText=value=>{if(!Number.isFinite(value))return '—';const r=Math.round(value*10)/10;return `${r>0?'+':r<0?'−':''}${Math.abs(r).toLocaleString(locale(),{maximumFractionDigits:1})}%`;};
  const dateText=iso=>{const d=new Date(iso);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString(locale());};
  const toneOf=value=>!Number.isFinite(value)?'isNeutral':value<=0?'isGood':'isBad';
  const reducedMotion=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const store={get(key,fallback){try{const raw=BLStorage.getItem(key);return raw?JSON.parse(raw):fallback;}catch(_){return fallback;}},set(key,value){try{BLStorage.setItem(key,JSON.stringify(value));}catch(_){}}};

  const TAB_KEY='lcw.pricingDesk.tab.v1',SCOPE_KEY='lcw.pricingDesk.scope.v1',VIEW_KEY='lcw.pricingDesk.detailView.v1',ANALYSIS_KEY='lcw.pricingDesk.analysis.v1',HISTORY_KEY='lcw.pricingDesk.history.v1',SUPPLIERS_KEY='lcw.pricingDesk.suppliers.v1';
  const TABS=['desk','rounds','history','analysis'];
  const state={
    tab:TABS.includes(store.get(TAB_KEY,'desk'))?store.get(TAB_KEY,'desk'):'desk',
    scope:normalizeScope(store.get(SCOPE_KEY,null)),
    detailViews:store.get(VIEW_KEY,{})||{},
    expandedSuppliers:store.get(SUPPLIERS_KEY,{})||{},
    analysis:{groupBy:'classification',basis:'latest',view:'matrix',filters:{},allSuppliers:false,...(store.get(ANALYSIS_KEY,{})||{})},
    history:{view:'models',query:'',filters:{},selected:'',limit:48,...(store.get(HISTORY_KEY,{})||{})},
    hosts:new Set(),ownerRows:new Map(),ownerRowsLoading:null,ownerRowsFailed:new Set(),
    roundsSelected:'',lastBest:new Map(),flash:new Set(),focus:null,undo:[],drill:null,
  };
  function normalizeScope(raw){
    const src=raw&&typeof raw==='object'?raw:{};
    return {all:Boolean(src.all),ownerIds:Array.isArray(src.ownerIds)?[...new Set(src.ownerIds.map(clean).filter(Boolean))].slice(0,100):[]};
  }

  /* ---------------- Buyer kapsamı ---------------- */
  function me(){return clean(Q()?.currentUserId?.());}
  function scopeOwnerIds(){const ids=new Set(state.scope.ownerIds);if(!ids.size)ids.add(me());return ids;}
  function scopeAllows(req){
    if(!req)return false;
    if(state.scope.all)return true;
    const ids=scopeOwnerIds(),self=me();
    if(ids.has(clean(req.ownerId)))return true;
    // "Ben" seçiliyken düzenleme yetkisi bana verilmiş başkasının talebi de görünür.
    return ids.has(self)&&Array.isArray(req.editorIds)&&req.editorIds.includes(self);
  }
  function scopeIsMulti(){return state.scope.all||scopeOwnerIds().size>1||!scopeOwnerIds().has(me());}
  function availableOwners(){
    const api=Q();if(!api)return [];
    const map=new Map(),self=me();
    map.set(self,{id:self,name:L('Ben','Me'),count:0,self:true});
    api.requests().forEach(req=>{
      const id=clean(req.ownerId);if(!id)return;
      if(!map.has(id))map.set(id,{id,name:api.ownerLabel(req),count:0,self:id===self});
      map.get(id).count++;
    });
    return [...map.values()].sort((a,b)=>(b.self-a.self)||a.name.localeCompare(b.name,'tr'));
  }
  function scopeLabel(){
    if(state.scope.all)return L('Tüm erişilebilir buyer\'lar','All accessible buyers');
    const ids=[...scopeOwnerIds()],owners=new Map(availableOwners().map(owner=>[owner.id,owner]));
    if(ids.length===1)return ids[0]===me()?L('Benim kayıtlarım','My records'):(owners.get(ids[0])?.name||ids[0]);
    return L(`${ids.length} buyer`,`${ids.length} buyers`);
  }
  function setScope(next){
    state.scope=normalizeScope(next);store.set(SCOPE_KEY,state.scope);
    void loadOwnerRows().then(()=>renderAllHosts());
    renderAllHosts();
  }
  /* Talep sahibinin Koleksiyon satırları (salt okunur). Yüklü Koleksiyon sayfası
     o sahibin değilse görsel, klasman ve hedef fiyat için sahibin sayfası
     okunur; yetki sunucu tarafından kesişimle uygulanır (Multi-Buyer ile aynı uç). */
  function ownerRows(ownerId){const rows=state.ownerRows.get(clean(ownerId));return Array.isArray(rows)?rows:null;}
  async function loadOwnerRows(){
    const api=Q();if(!api)return false;
    const loadedOwner=typeof kolWorkspaceOwnerId!=='undefined'?clean(kolWorkspaceOwnerId):'',mode=typeof kolWorkspaceMode!=='undefined'?kolWorkspaceMode:'';
    const wanted=new Set();
    api.requests().filter(req=>req.source==='collection'&&scopeAllows(req)).forEach(req=>{
      const owner=clean(req.ownerId);
      if(!owner||state.ownerRows.has(owner)||state.ownerRowsFailed.has(owner))return;
      if(mode!=='multi'&&owner===loadedOwner)return;
      if(mode==='multi'&&typeof kolRows!=='undefined'&&kolRows.some(row=>clean(row._collectionOwnerId)===owner))return;
      wanted.add(owner);
    });
    if(!wanted.size)return false;
    if(state.ownerRowsLoading)return state.ownerRowsLoading;
    state.ownerRowsLoading=(async()=>{
      try{
        const ids=[...wanted].slice(0,50);
        const res=await fetch(`/api/collection-workspaces-batch?ownerIds=${encodeURIComponent(ids.join(','))}`,{credentials:'same-origin',cache:'no-store'});
        const data=await res.json().catch(()=>({}));
        if(!res.ok){ids.forEach(id=>state.ownerRowsFailed.add(id));return false;}
        (Array.isArray(data.workspaces)?data.workspaces:[]).forEach(item=>{
          const id=clean(item&&item.owner&&item.owner.id),rows=Array.isArray(item&&item.workspace&&item.workspace.rows)?item.workspace.rows:[];
          if(id)state.ownerRows.set(id,rows.map(row=>({...row,_collectionOwnerId:id,_collectionOwnerName:clean(item.owner.displayName)})));
        });
        ids.filter(id=>!state.ownerRows.has(id)).forEach(id=>state.ownerRowsFailed.add(id));
        return true;
      }catch(_){[...wanted].forEach(id=>state.ownerRowsFailed.add(id));return false;}
      finally{state.ownerRowsLoading=null;}
    })();
    return state.ownerRowsLoading;
  }
  function scopedRequests(source='collection'){
    const api=Q();if(!api)return [];
    return api.requests().filter(req=>(!source||req.source===source)&&scopeAllows(req));
  }

  /* ---------------- Satır bilgisi (görsel, klasman, hedef) ---------------- */
  let infoCache=new WeakMap();
  function lineInfo(req,item){
    if(infoCache.has(item))return infoCache.get(item);
    const api=Q(),row=req.source==='collection'?api.findRow(item):null;
    const v=key=>row?clean(api.rowValue(row,key)):'';
    const info={
      row,model:v('modelKod')||clean(item.modelCode)||clean(item.plmId)||clean(item.orderCode)||'—',plmId:v('plmId')||clean(item.plmId),
      colour:v('colour')||clean(item.colour),colourCode:clean(row&&row.colourCode)||clean(item.colourCode),
      classification:clean(api.itemCategory(req,item))||'—',mag:v('mag'),mmyg:v('mmyg'),buyingGroup:v('buyingGroup'),
      buyer:clean(api.ownerLabel(req)),season:v('season')||clean(item.season),license:v('lisans')||clean(item.license),
      productMainDefinition:api.fieldValue?api.fieldValue(req,item,'productMainDefinition'):v('productMainDefinition'),fabric:clean(api.itemFabricSummary?api.itemFabricSummary(req,item):api.itemFabric(req,item)),
      target:E.price(api.itemTarget(req,item)),image:req.source==='collection'?clean(api.imageSrc(row,item)):clean(item.picture),
    };
    infoCache.set(item,info);
    return info;
  }
  function thumbHtml(req,item,classes='pdThumb'){
    const api=Q(),info=lineInfo(req,item);
    return api.thumb(info.image,{modelId:info.plmId||info.model,plmId:info.plmId,modelName:info.model,colourCode:info.colourCode,colour:info.colour,classes})||`<span class="${esc(classes)} pdThumbEmpty" aria-hidden="true"></span>`;
  }
  function bindThumbs(host){try{window.BLDetailImages?.bindThumbs?.(host);}catch(_){}}

  /* ---------------- Bildirim + geri al ---------------- */
  let toastTimer=null;
  function toast(message,{undo=false}={}){
    let el=document.getElementById('pdToast');
    if(!el){el=document.createElement('div');el.id='pdToast';el.className='pdToast';el.setAttribute('role','status');document.body.appendChild(el);}
    el.innerHTML=`<span>${esc(message)}</span>${undo?`<button type="button" class="tbtn" data-pd-toast-undo>${esc(L('Geri al','Undo'))}</button>`:''}`;
    el.classList.remove('isOut');el.hidden=false;
    el.querySelector('[data-pd-toast-undo]')?.addEventListener('click',()=>{undoLast();hideToast();});
    clearTimeout(toastTimer);toastTimer=setTimeout(hideToast,undo?7000:3200);
  }
  function hideToast(){const el=document.getElementById('pdToast');if(!el)return;el.classList.add('isOut');setTimeout(()=>{el.hidden=true;},reducedMotion()?0:190);}
  function snapshot(line){return {price:clean(line.price),approved:!!line.approved,dropped:!!line.dropped};}
  function pushUndo(req,lines,label){
    const entries=lines.filter(Boolean).map(line=>({lineId:line.id,prev:snapshot(line)}));
    if(!entries.length)return;
    state.undo.push({requestId:req.id,entries,label});
    if(state.undo.length>50)state.undo.shift();
  }
  async function undoLast(){
    const api=Q(),group=state.undo[state.undo.length-1];if(!api||!group)return false;
    const req=api.requests().find(item=>item.id===group.requestId);if(!req)return false;
    if(group.bulkGuard){
      const guard=group.bulkGuard;
      if(!api.canEdit(req)||api.currentUserId()!==guard.user||req.ownerId!==guard.owner||group.entries.some(entry=>Number(req.items.find(item=>item.id===entry.lineId)?.rev)!==guard.revisions[entry.lineId])){toast(L('Toplu geri alma güncelliğini yitirdi; fiyatları yeniden kontrol edin.','This bulk undo is stale; review the current prices.'));return false;}
      if(group.saving)return false;group.saving=true;
      try{await api.applyPricesBatch(req.id,group.entries.map(entry=>({lineId:entry.lineId,baseRev:guard.revisions[entry.lineId],price:entry.prev.price})),'undo');const index=state.undo.indexOf(group);if(index>=0)state.undo.splice(index,1);api.renderDetail();toast(L('Son değişiklik kaydedilerek geri alındı.','Last change undone and saved.'));return true;}
      catch(error){toast(error.message||L('Geri alma doğrulanamadı.','Undo could not be confirmed.'));return false;}finally{group.saving=false;}
    }
    state.undo.pop();
    group.entries.forEach(entry=>{
      const line=req.items.find(item=>item.id===entry.lineId);if(!line)return;
      if(clean(line.price)!==entry.prev.price)api.applyPrice(req,line,entry.prev.price,'undo');
      if(!!line.dropped!==entry.prev.dropped)api.toggleDrop(req,line,'undo');
      if(!!line.approved!==entry.prev.approved)api.setApproval(req,line,entry.prev.approved,'undo');
      state.flash.add(line.id);
    });
    api.renderDetail();
    toast(L('Son değişiklik geri alındı.','Last change undone.'));
    return true;
  }

  /* ================= MASA: model × üretici matrisi ================= */
  function detailView(req){
    if(!req)return 'list';
    const saved=state.detailViews[req.id];
    if(saved==='matrix'||saved==='list')return saved;
    // Üretici seçilmeden açılan talepte liste boştur; modeller yalnız matriste görünür.
    if(!(req.items||[]).length&&(req.models||[]).length)return 'matrix';
    return req.source==='collection'?'matrix':'list';
  }
  function setDetailView(req,view){if(!req)return;state.detailViews[req.id]=view==='list'?'list':'matrix';store.set(VIEW_KEY,state.detailViews);}

  /* Alternatif fiyat rozeti hücrenin sol üst köşesinde, fiyat metninin üstündeki
     boşluktadır (hücre taşanı kırptığı ve üst şerit ilk satırda sabit başlığın
     altında kaldığı için hücre dışına çıkmaz). Alternatif varsa daima görünür;
     yoksa düzenleme yetkisinde yalnız üzerine gelince / odakta "+" çıkar. */
  function optionBadgeHtml(line,label,canEdit){
    const list=E.lineOptions(line);
    if(!list.length&&!canEdit)return '';
    const main=`${clean(line.priceLabel)||L('Ana teklif','Main offer')}: ${E.price(line.price)!=null?money(E.price(line.price)):'—'}`;
    const tip=list.length?[main,...list.map((option,i)=>`${option.label||L(`Opsiyon ${i+1}`,`Option ${i+1}`)}: ${option.value!=null?money(option.value):(option.price||'—')}${option.note?` · ${option.note}`:''}`)].join('\n'):L('Alternatif fiyat ekle (O)','Add alternative price (O)');
    return `<button type="button" class="pdOptBadge${list.length?' hasOptions':''}" data-pd-options="${esc(line.id)}" tabindex="-1" title="${esc(tip)}" aria-label="${esc(L(`${label}: alternatif fiyatlar (${list.length})`,`${label}: alternative prices (${list.length})`))}">${list.length?esc(L(`OPS ${list.length}`,`OPT ${list.length}`)):esc(L('+ OPS','+ OPT'))}</button>`;
  }
  function cellHtml(req,model,name,stats,ctx){
    const line=model.cell(name);
    if(!line){
      if(!ctx.canEdit)return `<td class="pdCell isEmpty"><span class="pdNoLine" aria-label="${esc(L('Teklif yok','No offer'))}">—</span></td>`;
      const label=`${lineInfo(req,model.first).model} · ${name}`;
      return `<td class="pdCell isEmpty"><button type="button" class="pdAddLine" data-pd-add-line="${esc(name)}" data-pd-add-model="${esc(model.modelKey)}" title="${esc(L('Bu üretici için fiyat hücresi aç','Open a price cell for this manufacturer'))}" aria-label="${esc(L(`${label} için teklif satırı ekle`,`Add an offer line for ${label}`))}"><span aria-hidden="true">—</span><b aria-hidden="true">+</b></button></td>`;
    }
    const info=lineInfo(req,model.first),value=E.price(line.price),dropped=!!line.dropped;
    const isBest=!dropped&&stats.best&&stats.best.lineId===line.id&&stats.priced>1,isAppr=!!line.approved&&!dropped,outlier=stats.outliers.has(line.id);
    const neg=E.negotiation(line,req),prev=neg&&neg.previous!=null&&Math.abs(neg.previous-(value||0))>0.0001?neg.previous:null;
    const classes=['pdCell',isBest?'isBest':'',isAppr?'isApproved':'',!isAppr&&stats.approved?'isNotChosen':'',dropped?'isDropped':'',outlier?'isOutlier':'',state.flash.has(line.id)?'pdFlash':''].filter(Boolean).join(' ');
    const label=`${info.model} · ${name}`;
    return `<td class="${classes}" data-pd-line="${esc(line.id)}">
      <div class="pdCellTop">${prev!=null?`<s class="pdPrev" title="${esc(L('Önceki teklif','Previous offer'))}">${esc(kplain(prev))}</s>`:''}${isBest?`<span class="pdBestTag${ctx.moved?' isMoved':''}">${esc(L('EN İYİ','BEST'))}</span>`:''}${isAppr?`<span class="pdApprovedTag">${esc(L('ONAYLI','APPROVED'))}</span>`:''}</div>
      <div class="pdCellMain">
        <input type="text" inputmode="decimal" class="pdCellInput" data-pd-input="${esc(line.id)}" data-r="${ctx.mi}" data-c="${ctx.ci}" value="${esc(value!=null?kplain(value):clean(line.price))}" placeholder="—" aria-label="${esc((isAppr?L('Onaylı · ','Approved · '):'')+L(`${label} teklif fiyatı`,`${label} quotation price`)+(E.lineOptions(line).length?L(` · ${E.lineOptions(line).length} alternatif fiyat`,` · ${E.lineOptions(line).length} alternative prices`):''))}" ${ctx.canEdit&&!dropped?'':'disabled'}>
        <button type="button" class="pdApprove${isAppr?' isOn':''}" data-pd-approve="${esc(line.id)}" tabindex="-1" aria-pressed="${isAppr?'true':'false'}" ${ctx.canEdit&&!dropped&&value!=null?'':'disabled'} title="${esc(isAppr?L('Onayı kaldır (A)','Remove approval (A)'):L('Onayla (A)','Approve (A)'))}" aria-label="${esc((isAppr?L('Onayı kaldır: ','Remove approval: '):L('Onayla: ','Approve: '))+label)}"><svg class="ic" aria-hidden="true"><use href="#i-check"/></svg></button>
        <button type="button" class="pdDrop${dropped?' isOn':''}" data-pd-drop="${esc(line.id)}" tabindex="-1" aria-pressed="${dropped?'true':'false'}" ${ctx.canEdit?'':'disabled'} title="${esc(dropped?L('Drop işaretini kaldır (D)','Remove Drop (D)'):L('Drop (D)','Drop (D)'))}" aria-label="${esc('Drop: '+label)}"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg></button>
      </div>
      <div class="pdCellOpt">${optionBadgeHtml(line,label,ctx.canEdit)}</div>${isAppr?`<span class="pdApprovedMark" aria-hidden="true">${esc(L('ONAYLI','APPROVED'))}</span>`:''}
      <div class="pdCellNote">${outlier?esc(L('Olağan dışı · emin misin?','Unusual · are you sure?')):(dropped?esc(L('Drop','Dropped')):(neg&&neg.rounds>1?esc(L(`${neg.rounds} tur · ${pctText(neg.gainPct)}`,`${neg.rounds} rounds · ${pctText(neg.gainPct)}`)):''))}</div>
    </td>`;
  }
  function matrixContext(){
    const api=Q(),selected=api.selectedColumns?.()||[];
    const summary=matrixLayout.hidden.includes('summary')?[]:selected.filter(key=>key==='quantity'||key==='inStoreMonth');
    const extra=selected.filter(key=>!['quantity','inStoreMonth','productMainDefinition','fabric'].includes(key));
    return {selected,summary,extra,count:(summary.length?1:0)+extra.length};
  }
  function matrixSummaryText(req,item,context=matrixContext()){
    return context.summary.map(key=>`${Q().columnLabel(key)}: ${Q().fieldValue(req,item,key)||'—'}`).join(' · ');
  }
  function matrixExtraCells(req,item,context=matrixContext()){
    return context.extra.map(key=>{const value=Q().fieldValue(req,item,key)||'—';return `<td><span class="pdCollectionValue" title="${esc(value)}">${esc(value)}</span></td>`;}).join('');
  }
  function modelMeta(info){
    const selected=matrixContext().selected;
    return [selected.includes('productMainDefinition')?info.productMainDefinition:'',info.colour].filter(Boolean).join(' · ');
  }
  /* ---------------- Koleksiyon fiyat sütunları ----------------
     Hedef · Teklif & Onay · Previous Season / LFL / Sezon Etkisi, Koleksiyon
     tablosunun Kompakt fiyat görünümüyle aynı kart dili (blCell*) ve işlevle
     çizilir. Teklif & Onay değerleri talebin canlı satırlarından gelir: matriste
     yazılan fiyat/onay aynı satırı anında yeniler ve başka buyer'ın talebinde de
     doğru kalır. Referans hücresi Koleksiyon'un kendi BLCollectionLfl
     çizicisidir; çift tık / ⤢ yalnız yüklü Koleksiyon satırında Fiyat
     Çekmecesini açar (Koleksiyon'daki ile aynı). */
  const REF_KEYS=['__previousSeason__','__lfl__','__seasonImpact__'];
  const refLabel=key=>key==='__seasonImpact__'?L('Sezon Etkisi','Season Impact'):key==='__previousSeason__'?'Previous Season':'LFL';
  function drawerRow(info){
    const row=info&&info.row;
    return row&&window.BLCollectionPriceDrawer?.open&&typeof kolRows!=='undefined'&&Array.isArray(kolRows)&&kolRows.includes(row)?row:null;
  }
  function quotesModel(model,info,stats){
    const live=model.lines.filter(line=>line&&!line.dropped);
    const offers=live.map(line=>({name:clean(line.manufacturer),price:E.price(line.price)})).filter(offer=>offer.price!=null).sort((a,b)=>a.price-b.price);
    const approved=stats.approved&&stats.approved.price!=null?stats.approved:null,main=approved||stats.best||null;
    const fobRaw=info.row?E.price(info.row.fob):null;
    return {offers,approved,main,delta:main&&info.target?E.pct(main.price,info.target):null,waiting:live.filter(line=>E.price(line.price)==null).length,fob:fobRaw};
  }
  function targetCellHtml(req,model,info,canEdit){
    const text=info.target!=null?kplain(info.target):'';
    if(canEdit&&Q()?.canEditTarget?.(req,model.first))return `<td class="pdNum pdTarget isEditable"><label class="pdTargetBox"><span aria-hidden="true">$</span><input type="text" inputmode="decimal" class="pdTargetInput" data-pd-target="${esc(model.modelKey)}" value="${esc(text)}" placeholder="—" aria-label="${esc(L(`${info.model} hedef fiyatı`,`${info.model} target price`))}"></label></td>`;
    return `<td class="pdNum pdTarget"><span class="pdTargetBox">${text?`<span aria-hidden="true">$</span><b>${esc(text)}</b>`:'<b>—</b>'}</span></td>`;
  }
  function quotesCellHtml(model,info,stats){
    const q=quotesModel(model,info,stats),label=text=>`<span class="blCellStackLabel">${esc(text)}</span>`,drawer=drawerRow(info);
    const tip=q.offers.map(offer=>`${offer.name}: ${kmoney(offer.price)}${q.approved&&E.keyOf(q.approved.manufacturer)===E.keyOf(offer.name)?L(' · onaylı',' · approved'):''}`);
    if(info.target!=null)tip.push(`Target Price: ${kmoney(info.target)}`);
    if(q.delta!=null)tip.push(`${L('Fark','Difference')}: ${pctText(q.delta)}`);
    if(q.fob!=null)tip.push(`FOB: ${kmoney(q.fob)}`);
    if(q.waiting)tip.push(L(`${q.waiting} teklif cevap bekliyor`,`${q.waiting} quotation(s) awaiting a reply`));
    if(drawer)tip.push(L('Çift tık: fiyat çekmecesini aç','Double-click: open the price drawer'));
    const deltaHtml=q.delta!=null?`<span class="blCellTag" data-tone="${q.delta<=0?'good':'bad'}">${esc(pctText(q.delta))}</span>`:'<span></span>';
    const supp=q.main?`${label('Supp. FOB')}<b class="blCellValue${q.approved?' isStrong':' isSoft'}">${esc(kmoney(q.main.price))}</b>${deltaHtml}`:`${label('Supp. FOB')}<span class="blCellNone">${esc(L('Teklif yok','No quotation'))}</span><span></span>`;
    const fob=q.fob!=null&&(!q.main||Math.abs(q.fob-q.main.price)>0.004)?`${label('FOB')}<b class="blCellValue">${esc(kmoney(q.fob))}</b><span class="blCellNone">${esc(q.main?L('+ masraf','+ costs'):L('hedef','target'))}</span>`:'';
    const waiting=q.waiting?`<span class="blCellTag" data-tone="4">${esc(L(`${q.waiting} bekliyor`,`${q.waiting} waiting`))}</span>`:'';
    const mfr=q.main?`<span class="blCellMfr${q.approved?' isConfirmed':''}"><em>${esc(q.approved?L('✓ Onaylı','✓ Approved'):L('Öneri','Best'))}</em><b>${esc(q.main.manufacturer)}</b></span>`:'';
    const count=q.offers.length?`<span class="blCellTotal" title="${esc(L('Teklif sayısı','Quotations'))}">${q.offers.length}</span>`:'';
    const who=mfr||waiting||count?`<div class="blCellLine">${mfr}${waiting}${count}</div>`:'';
    const open=drawer?`<button type="button" class="kolManualBtn kolPsOpenBtn" data-pd-drawer-open="${esc(model.modelKey)}" tabindex="-1" title="${esc(L('Fiyat çekmecesini aç','Open price drawer'))}" aria-label="${esc(L('Fiyat çekmecesini aç','Open price drawer'))}">⤢</button>`:'';
    const sourceFob=drawer?window.BLPriceHoverFacts?.(drawer,'collection'):null;
    const hover=sourceFob&&sourceFob.suppFob===q.main?.price&&q.fob===sourceFob.fob?window.BLPriceLineage.hoverAttributes(drawer,'collection','supplierFob',tip.join('\n')):` title="${esc(tip.join('\n'))}"`;
    return `<td class="pdQuotesCol kolPriceStripTd${q.approved?' isConfirmed':''}" data-pd-quotes${drawer?` data-pd-drawer="${esc(model.modelKey)}"`:''}${hover}><div class="kolPs blCellCol"><div class="blCellStack">${supp}${fob}</div>${who}</div>${open}</td>`;
  }
  function quotesText(model,info,stats){
    const q=quotesModel(model,info,stats);
    return q.main?[kmoney(q.main.price),q.delta!=null?pctText(q.delta):'',`${q.approved?L('✓ Onaylı','✓ Approved'):L('Öneri','Best')} ${clipboardLabel(q.main.manufacturer)}`,q.waiting?L(`${q.waiting} bekliyor`,`${q.waiting} waiting`):''].filter(Boolean).join(' · '):L('Teklif yok','No quotation');
  }
  /* Kompakt referans hücresi (masaya özel): her referans tek satırda kısa etiket
     + % etkisi; ortalama fiyat, dönem ve uyarılar satırın ipucundadır. Değerler
     Koleksiyon'un BLCollectionLfl.model hesabından gelir (Koleksiyon tablosu kendi
     tam görünümünü korur). */
  const refShort=key=>key==='__seasonImpact__'?L('SE','SI'):key==='__previousSeason__'?'PS':'LFL';
  function refsCellHtml(model,info){
    const lfl=window.BLCollectionLfl,drawer=drawerRow(info),attrs=` data-pd-refs${drawer?` data-pd-drawer="${esc(model.modelKey)}"`:''}`;
    if(!info.row||!lfl?.model)return `<td class="pdRefsCol"${attrs}><span class="blCellNone">—</span></td>`;
    const rows=REF_KEYS.map(key=>{
      let m=null;try{m=lfl.model(info.row,lfl.modeForKey(key));}catch(_){m=null;}
      const tip=[`${refLabel(key)}: ${m?.averageText||m?.emptyText||'—'}${m?.percentText?` · ${m.percentText}`:''}`,m?.detail||m?.message||''].filter(Boolean).join('\n');
      const tag=m?.percentText?`<span class="blCellTag" data-tone="${m.percent<=0?'good':'bad'}">${esc(m.percentText)}</span>`:'<span class="blCellNone">—</span>';
      const warn=m?.compactWarning?`<span class="blCellNone pdRefWarn">⚠</span>`:'';
      return `<span class="pdRefRow" title="${esc(tip)}"><span class="blCellStackLabel">${esc(refShort(key))}</span><span class="pdRefTail">${tag}${warn}</span></span>`;
    }).join('');
    return `<td class="pdRefsCol"${attrs}><div class="pdRefsCompact">${rows}</div></td>`;
  }
  function refsText(info){
    const lfl=window.BLCollectionLfl;
    if(!info.row||!lfl?.combinedText)return '—';
    try{return clipboardLabel(lfl.combinedText(info.row,REF_KEYS))||'—';}catch(_){return '—';}
  }
  /* Previous Season / LFL referansı Koleksiyon ile aynı oturum önbelleğinden
     okunur. Masa görünürken ve referans henüz yüklenmemişse tek istek atılır;
     yanıt gelince açık matrisler bir kez yeniden çizilir. */
  let referenceWait=null;
  function ensureReferences(){
    const lfl=window.BLCollectionLfl;if(!lfl?.ensure||referenceWait)return;
    let pending;try{pending=lfl.ensure();}catch(_){return;}
    if(!lfl.isPending?.()||!pending?.then)return;
    referenceWait=pending.catch(()=>{}).then(()=>{referenceWait=null;Q()?.withCollectionRead?Q().withCollectionRead(()=>rerenderMatrices()):rerenderMatrices();});
  }
  function rerenderMatrices(){
    document.querySelectorAll('[data-pd-matrix]').forEach(host=>{
      const view=matrixViews.get(host);if(!view||!host.isConnected||host.contains(document.activeElement))return;
      const left=view.scroll?.scrollLeft||0,top=view.scroll?.scrollTop||0;
      renderMatrixContent(host,view.req);
      const scroll=host.querySelector('.pdMatrixScroll');if(scroll){scroll.scrollLeft=left;scroll.scrollTop=top;}
    });
  }

  /* Sütun sıralama ve genişlikleri kullanıcı başına (BLStorage) saklanır. Sıralama
     modelleri yeniden dizer; sanal pencere, yapıştırma ve klavye gezinmesi aynı
     mantıksal sırayı (view.matrix.models) kullanır. Yazarken satırlar yerinden
     oynamaz: yeni sıra odak tablodan çıkınca uygulanır. */
  const MATRIX_LAYOUT_KEY='lcw.pricingDesk.matrixLayout.v1';
  /* Sütun gizleme: sabit fiyat sütunları (Adet/MB Ay · Hedef · Teklif & Onay ·
     referanslar) kullanıcı başına, üretici sütunları talep başına gizlenir (her
     talebin üretici kümesi farklıdır). Gizli üretici teklif hesabından çıkmaz;
     yalnız matriste görünmez. Model sütunu gizlenemez. */
  const HIDEABLE_FIXED=['summary','target','quotes','refs'];
  const matrixLayout=(()=>{
    const raw=store.get(MATRIX_LAYOUT_KEY,{})||{},sort=raw.sort,suppliers=raw.hiddenSuppliers&&typeof raw.hiddenSuppliers==='object'&&!Array.isArray(raw.hiddenSuppliers)?raw.hiddenSuppliers:{};
    return {widths:raw.widths&&typeof raw.widths==='object'&&!Array.isArray(raw.widths)?raw.widths:{},sort:sort&&typeof sort.key==='string'&&(sort.dir===1||sort.dir===-1)?{key:sort.key,dir:sort.dir}:null,
      hidden:Array.isArray(raw.hidden)?raw.hidden.filter(key=>HIDEABLE_FIXED.includes(key)):[],
      unapprovedOnly:raw.unapprovedOnly===true,
      hiddenSuppliers:Object.fromEntries(Object.entries(suppliers).filter(([id,list])=>id&&Array.isArray(list)).slice(-200).map(([id,list])=>[id,[...new Set(list.map(clean).filter(Boolean))].slice(0,100)]).filter(([,list])=>list.length))};
  })();
  function saveMatrixLayout(){store.set(MATRIX_LAYOUT_KEY,{widths:matrixLayout.widths,sort:matrixLayout.sort,hidden:matrixLayout.hidden,hiddenSuppliers:matrixLayout.hiddenSuppliers,unapprovedOnly:matrixLayout.unapprovedOnly});}
  /* "Yalnız onaysız": onaylı fiyatı olmayan modeller bir iş listesi gibi kalır.
     Onaylanan satır sonraki çizimde listeden çıkar, odak aynı sütunda sıradaki
     modele geçer. Tercih kullanıcıda saklanır; düğme sayıyı ve durumu gösterir. */
  function filterUnapproved(models){return matrixLayout.unapprovedOnly?models.filter(model=>!E.rowStats(model.lines).approved):models;}
  const fixedShown=key=>!matrixLayout.hidden.includes(key);
  const supplierHidden=(req,name)=>Boolean(req&&(matrixLayout.hiddenSuppliers[req.id]||[]).some(item=>E.keyOf(item)===E.keyOf(name)));
  function setColumnHidden(req,key,hidden){
    if(key.startsWith('mfr:')){
      if(!req)return;const name=key.slice(4),list=(matrixLayout.hiddenSuppliers[req.id]||[]).filter(item=>E.keyOf(item)!==E.keyOf(name));
      if(hidden)list.push(name);
      if(list.length)matrixLayout.hiddenSuppliers[req.id]=list;else delete matrixLayout.hiddenSuppliers[req.id];
    }else if(HIDEABLE_FIXED.includes(key)){
      matrixLayout.hidden=matrixLayout.hidden.filter(item=>item!==key);if(hidden)matrixLayout.hidden.push(key);
    }else return;
    if(hidden&&matrixLayout.sort&&(matrixLayout.sort.key===key||(key==='summary'&&matrixLayout.sort.key.startsWith('field:'))||(key==='refs'&&matrixLayout.sort.key.startsWith('ref:'))))matrixLayout.sort=null;
    saveMatrixLayout();
  }
  function hiddenColumnCount(req){return matrixLayout.hidden.length+(req?(matrixLayout.hiddenSuppliers[req.id]||[]).length:0);}
  function showAllColumns(req){matrixLayout.hidden=[];if(req)delete matrixLayout.hiddenSuppliers[req.id];saveMatrixLayout();}
  function visibleSupplierCards(req){return E.supplierScorecards(req).filter(card=>!supplierHidden(req,card.name));}
  const hideButton=(key,label)=>`<button type="button" class="pdColHide" data-pd-hide="${esc(key)}" tabindex="-1" title="${esc(L('Sütunu gizle','Hide column'))}" aria-label="${esc(L(`${label} sütununu gizle`,`Hide ${label} column`))}"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg></button>`;
  /* Sütunlar panelindeki "Matris sütunları" bölümü (quotations.js çağırır). */
  function matrixColumnsPanelHtml(req){
    if(!req||detailView(req)!=='matrix')return '';
    const api=Q(),summaryLabel=(api?.selectedColumns?.()||[]).filter(key=>key==='quantity'||key==='inStoreMonth').map(key=>api.columnLabel(key)).join(' / ');
    const fixed=[...(summaryLabel?[['summary',summaryLabel]]:[]),['target',L('Hedef Fiyat','Target Price')],['quotes',L('Teklif & Onay','Quotes & Approval')],['refs',REF_KEYS.map(refLabel).join(' / ')]];
    const suppliers=E.supplierScorecards(req).map(card=>['mfr:'+card.name,card.name]);
    const box=([key,label])=>`<label class="pdCheck"><input type="checkbox" data-pd-matrix-col="${esc(key)}" ${(key.startsWith('mfr:')?supplierHidden(req,key.slice(4)):!fixedShown(key))?'':'checked'}><span>${esc(label)}</span></label>`;
    return `<div class="pdPanelHead"><b>${esc(L('Matris sütunları','Matrix columns'))}</b><span>${esc(L('İşareti kaldırılan sütun gizlenir; teklif ve onay hesapları değişmez. Üretici seçimi bu talep için saklanır.','Unchecked columns are hidden; quotation and approval calculations do not change. Manufacturer choices are saved for this request.'))}</span></div>
      <div class="pdColumnsList" data-pd-matrix-columns>${[...fixed,...suppliers].map(box).join('')}</div>`;
  }
  function applyMatrixColumnsPanel(req,panel){
    if(!req||!panel)return;
    panel.querySelectorAll('[data-pd-matrix-col]').forEach(box=>setColumnHidden(req,box.dataset.pdMatrixCol,!box.checked));
  }
  const COL_DEFAULT={model:190,summary:104,target:88,quotes:268,refs:124,ctx:150,mfr:104,other:104,add:124};
  const COL_MIN={model:120,summary:72,target:72,quotes:150,refs:96,ctx:64,mfr:72,other:72,add:96};
  // Yalnız Model sütunu dondurulur; tablonun geri kalanı yatayda kayar.
  const STICKY_COLS=['model'];
  const colKind=key=>key.startsWith('ctx:')?'ctx':key.startsWith('mfr:')?'mfr':key;
  function colWidth(key){const kind=colKind(key),min=COL_MIN[kind]||64,saved=Number(matrixLayout.widths[key]);return Number.isFinite(saved)&&saved>0?Math.max(min,Math.min(900,Math.round(saved))):(COL_DEFAULT[kind]||120);}
  function matrixColumnKeys(context,layout,canEdit){
    return ['model',...(context.summary.length?['summary']:[]),...['target','quotes','refs'].filter(fixedShown),...context.extra.map(key=>'ctx:'+key),...layout.visible.map(card=>'mfr:'+card.name),...(layout.other.length?['other']:[]),...(canEdit?['add']:[])];
  }
  function matrixGeometry(keys){
    let total=0,left=0;const lefts={};
    keys.forEach(key=>{const width=colWidth(key);if(STICKY_COLS.includes(key)){lefts[key]=left;left+=width;}total+=width;});
    return {total,lefts};
  }
  function matrixTableStyle(keys){return `width:${matrixGeometry(keys).total}px`;}
  function applyMatrixWidths(table,keys){
    const g=matrixGeometry(keys);
    table.querySelectorAll('col[data-pd-col]').forEach(col=>{col.style.width=colWidth(col.dataset.pdCol)+'px';});
    table.style.width=g.total+'px';
  }
  function sortAttrs(key){
    const sort=matrixLayout.sort,dir=sort&&sort.key===key?(sort.dir===1?'asc':'desc'):'';
    return `data-pd-sort="${esc(key)}" data-dir="${dir}" role="button" tabindex="0" title="${esc(dir==='asc'?L('Artan sıralı · tıkla: azalan','Sorted ascending · click: descending'):dir==='desc'?L('Azalan sıralı · tıkla: sıralamayı kaldır','Sorted descending · click: clear sorting'):L('Sırala','Sort'))}"`;
  }
  const sortLabel=(key,label)=>`<span class="pdSortBtn" ${sortAttrs(key)}>${esc(label)}</span>`;
  const resizeHandle=key=>`<span class="pdColResize" data-pd-resize="${esc(key)}" role="separator" aria-orientation="vertical" title="${esc(L('Sütun genişliğini ayarla; çift tıklayarak sıfırla','Resize column; double-click to reset'))}"></span>`;
  function ariaSort(keys){const sort=matrixLayout.sort;return sort&&keys.includes(sort.key)?` aria-sort="${sort.dir===1?'ascending':'descending'}"`:'';}
  function sortValue(req,model,key){
    const api=Q(),info=lineInfo(req,model.first);
    if(key==='model')return info.model;
    if(key==='target')return info.target;
    if(key==='quotes'){const stats=E.rowStats(model.lines),main=stats.approved&&stats.approved.price!=null?stats.approved:stats.best;return main?main.price:null;}
    if(key.startsWith('ref:')){
      const lfl=window.BLCollectionLfl;if(!info.row||!lfl?.model)return null;
      try{const m=lfl.model(info.row,lfl.modeForKey(key.slice(4)));return m.reference&&Number.isFinite(m.percent)?m.percent:null;}catch(_){return null;}
    }
    if(key.startsWith('mfr:')){const line=model.cell(key.slice(4));return line&&!line.dropped?E.price(line.price):null;}
    if(key.startsWith('field:')){
      const field=key.slice(6),raw=api.fieldRaw?api.fieldRaw(req,model.first,field):api.fieldValue(req,model.first,field);
      if(field==='inStoreMonth'){const code=api.monthCode?api.monthCode(raw):'';return code?Number(code):null;}
      if(field==='quantity'){if(raw==null||raw==='')return null;const n=typeof raw==='number'?raw:(typeof kolParseQuantityNum==='function'?kolParseQuantityNum(raw):Number(String(raw).replace(/\./g,'').replace(',','.')));return Number.isFinite(n)?n:null;}
      return clean(api.fieldValue(req,model.first,field));
    }
    return null;
  }
  function sortModels(req,models,validKeys){
    const sort=matrixLayout.sort;if(!sort||!validKeys.has(sort.key))return models;
    const empty=value=>value==null||value===''||(typeof value==='number'&&!Number.isFinite(value));
    const items=models.map((model,index)=>({model,index,value:sortValue(req,model,sort.key)}));
    items.sort((a,b)=>{
      if(empty(a.value)||empty(b.value))return empty(a.value)===empty(b.value)?a.index-b.index:(empty(a.value)?1:-1);
      const diff=typeof a.value==='number'&&typeof b.value==='number'?a.value-b.value:String(a.value).localeCompare(String(b.value),'tr',{numeric:true,sensitivity:'base'});
      return diff*sort.dir||a.index-b.index;
    });
    return items.map(item=>item.model);
  }
  function sortKeysFor(context,layout){
    return new Set(['model',...['target','quotes'].filter(fixedShown),...(fixedShown('refs')?REF_KEYS.map(key=>'ref:'+key):[]),...context.summary.map(key=>'field:'+key),...context.extra.map(key=>'field:'+key),...layout.visible.map(card=>'mfr:'+card.name)]);
  }
  function cycleSort(key){
    const sort=matrixLayout.sort;
    matrixLayout.sort=!sort||sort.key!==key?{key,dir:1}:sort.dir===1?{key,dir:-1}:null;
    saveMatrixLayout();
  }
  const matrixViews=new WeakMap(),matrixScrollViews=new WeakMap();
  function matrixRowsHtml(req,matrix,ctx){
    const api=Q(),prevBest=state.lastBest.get(req.id)||new Map(),nextBest=new Map(prevBest),start=ctx.start||0;
    const html=matrix.models.slice(start,ctx.end??matrix.models.length).map((model,index)=>{
      const mi=start+index;
      const info=lineInfo(req,model.first),stats=E.rowStats(model.lines);
      const bestId=stats.best?stats.best.lineId:'';nextBest.set(model.modelKey,bestId);
      const moved=Boolean(bestId&&prevBest.has(model.modelKey)&&prevBest.get(model.modelKey)!==bestId);
      const cells=matrix.manufacturers.map((name,ci)=>cellHtml(req,model,name,stats,{mi,ci,canEdit:ctx.canEdit,moved:moved&&bestId===model.cell(name)?.id}));
      if(ctx.other.length){const offers=ctx.other.map(s=>model.cell(s.name)).filter(line=>line&&!line.dropped&&E.price(line.price)!=null).sort((a,b)=>E.price(a.price)-E.price(b.price));const best=offers[0];cells.push(`<td class="pdCell pdOther"><button type="button" data-pd-expand aria-label="${esc(L('Diğer üreticileri aç','Expand other manufacturers'))}">${best?`<b>${esc(kmoney(E.price(best.price)))}</b><small>${esc(best.manufacturer)}</small>`:'—'}</button></td>`);}
      const meta=modelMeta(info),context=matrixContext();
      return `<tr data-pd-model="${esc(model.modelKey)}" data-pd-row="${mi}" aria-rowindex="${mi+2}"${stats.approved?' class="pdRowApproved"':''}>
        <th scope="row" class="pdModelCell"><div class="pdModel">${thumbHtml(req,model.first)}<div class="pdModelText"><b title="${esc(info.model)}">${esc(info.model)}</b><span title="${esc(meta)}">${esc(meta||'—')}</span>${context.selected.includes('fabric')?`<small title="${esc(info.fabric)}">${esc(info.fabric||'—')}</small>`:''}</div></div></th>
        ${context.summary.length?`<td class="pdSummary"><span title="${esc(matrixSummaryText(req,model.first,context))}">${context.summary.map(key=>`<b>${esc(api.fieldValue(req,model.first,key)||'—')}</b>`).join('')}</span></td>`:''}
        ${fixedShown('target')?targetCellHtml(req,model,info,ctx.canEdit):''}${fixedShown('quotes')?quotesCellHtml(model,info,stats):''}${fixedShown('refs')?refsCellHtml(model,info):''}
        ${matrixExtraCells(req,model.first,context)}${cells.join('')}${ctx.canEdit?'<td class="pdAddMfrCell" aria-hidden="true"></td>':''}
      </tr>`;
    }).join('');
    state.lastBest.set(req.id,nextBest);
    return html;
  }
  function supplierHeadHtml(card){
    const coverage=L(`${card.models}/${card.total} model, ${card.wins} kazanma`,`${card.models}/${card.total} models, ${card.wins} wins`);
    return `<b class="pdSortBtn" ${sortAttrs('mfr:'+card.name)}>${esc(card.name)}</b><small title="${esc(coverage)}" aria-label="${esc(coverage)}">${card.models}/${card.total} · ${card.wins} ${esc(L('en iyi','best'))}</small><small class="${toneOf(card.modelIndex)}" title="${esc(L('Aynı modelin teklif ortalamasına göre fark','Difference to the same model’s average offer'))}">${esc(pctText(card.modelIndex))}</small>`;
  }
  // Clipboard values come from the complete request, including unmounted rows.
  // Keep the native matrix's plain-text layout for existing Excel workflows.
  function matrixClipboardText(req,ctx,{start=0,end=ctx.matrix.models.length,headers=true}={}){
    const {matrix}=ctx;let text=headers?matrixClipboardHeaderParts(req,ctx).join(''):'';
    for(let index=start;index<end;index++){
      const parts=matrixClipboardRowParts(req,matrix.models[index],ctx);
      text+=parts.join('');
    }
    return text;
  }
  // Kopyalanan sabit sütunlar görünen sütunlarla birebir hizalıdır.
  function fixedClip(target,quotes,refs){return [['target',target],['quotes',quotes],['refs',refs]].filter(([key])=>fixedShown(key)).map(([,text])=>text);}
  function matrixClipboardHeaderParts(req,ctx){
    const cards=E.supplierScorecards(req),other=ctx.other||ctx.layout?.other||[],parts=[L('Model','Model')+'\t',...(matrixContext().summary.length?[matrixContext().summary.map(key=>Q().columnLabel(key)).join(' / ')+'\t']:[]),...fixedClip(L('Hedef Fiyat','Target Price'),L('Teklif & Onay','Quotes & Approval'),REF_KEYS.map(refLabel).join(' / ')).map(text=>text+'\t')];
    parts.push(...matrixContext().extra.map(key=>Q().columnLabel(key)+'\t'));
    for(const name of ctx.matrix.manufacturers){const card=cards.find(card=>card.name===name);parts.push(`${clipboardLabel(name)}\n${card.models}/${card.total} · ${card.wins} ${L('en iyi','best')}\n${pctText(card.modelIndex)}\n`);}
    if(other.length)parts.push(L(`Diğer (${other.length})`,`Other (${other.length})`)+(ctx.canEdit?'\t':'\n'));if(ctx.canEdit)parts.push(L('Üretici','Manufacturer')+'\n');return parts;
  }
  function matrixClipboardRowParts(req,model,ctx){
    const {matrix,canEdit}=ctx,other=ctx.other||ctx.layout?.other||[],info=lineInfo(req,model.first),stats=E.rowStats(model.lines);
    const context=matrixContext(),meta=clipboardLabel(modelMeta(info)||'—');
    const imagePrefix=/<img\b/i.test(thumbHtml(req,model.first))?'\n':'';
    const parts=[`${imagePrefix}${clipboardLabel(info.model)}\n${meta}\n${context.selected.includes('fabric')?clipboardLabel(info.fabric||'—')+'\n':''}`, ...(context.summary.length?[clipboardLabel(matrixSummaryText(req,model.first,context))+'\t']:[]),...fixedClip(info.target!=null?kmoney(info.target):'—',fixedShown('quotes')?quotesText(model,info,stats):'',fixedShown('refs')?refsText(info):'').map(text=>text+'\t')];
    parts.push(...context.extra.map(key=>clipboardLabel(Q().fieldValue(req,model.first,key)||'—')+'\t'));
    for(const name of matrix.manufacturers){
      const line=model.cell(name);if(!line){parts.push(canEdit?'\n—\n':'—\n');continue;}
      const value=E.price(line.price),options=E.lineOptions(line),badge=options.length?L(`OPS ${options.length}`,`OPT ${options.length}`):(canEdit?L('+ OPS','+ OPT'):'');
      parts.push((value!=null?kplain(value):(clean(line.price).replace(/[\r\n]/g,'')||'—'))+'\n\n'+(badge?badge+'\n':''));
    }
    if(other.length){const offers=other.map(card=>model.cell(card.name)).filter(line=>line&&!line.dropped&&E.price(line.price)!=null).sort((a,b)=>E.price(a.price)-E.price(b.price));parts.push((offers[0]?kmoney(E.price(offers[0].price))+'\n'+clipboardLabel(offers[0].manufacturer):'—')+'\n');}
    if(canEdit)parts.push('');return parts;
  }
  function matrixPasteTargets(req,matrix,r0,c0,text){
    if(!Q()?.canEdit(req))return [];
    const rows=String(text||'').replace(/\r/g,'').split('\n');if(rows.at(-1)==='')rows.pop();
    const targets=[];
    rows.forEach((row,dr)=>row.split('\t').forEach((value,dc)=>{
      const model=matrix.models[r0+dr],name=matrix.manufacturers[c0+dc],line=model&&name&&model.cell(name);
      if(line&&!line.dropped)targets.push({line,value:clean(value),r:r0+dr,c:c0+dc});
    }));
    return targets;
  }
  function matrixWindow(total,scrollTop,height,rowHeight){
    const visible=Math.max(1,Math.ceil(height/rowHeight)),first=Math.min(Math.max(0,total-visible),Math.max(0,Math.floor(scrollTop/rowHeight)));
    return {start:Math.max(0,first-8),end:Math.min(total,first+visible+8)};
  }
  function matrixNextFocusRow(view,index,direction){
    for(let next=index+direction;next>=0&&next<view.matrix.models.length;next+=direction){
      if(view.other.length||(view.canEdit&&view.matrix.manufacturers.some(name=>!view.matrix.models[next].cell(name)?.dropped)))return next;
    }
    return -1;
  }
  function matrixCurrent(view){
    if(view.items===view.req.items)return view.matrix;
    // A server ACK preserves the request object but replaces its item objects.
    // Rebind values while keeping the model order currently shown to the user.
    const fresh=E.requestMatrix(view.req),order=new Map(view.matrix.models.map((model,index)=>[model.modelKey,index]));
    fresh.models.sort((a,b)=>(order.get(a.modelKey)??Infinity)-(order.get(b.modelKey)??Infinity));
    // "Yalnız onaysız" açıkken görünmeyen modeller yapıştırma/gezinme aralığına geri girmez.
    if(matrixLayout.unapprovedOnly)fresh.models=fresh.models.filter(model=>order.has(model.modelKey));
    view.matrix={...fresh,manufacturers:view.matrix.manufacturers};view.items=view.req.items;infoCache=new WeakMap();
    const indices=new Map(fresh.models.map((model,index)=>[model.modelKey,index]));
    view.scroll?.querySelector('table')?.setAttribute('aria-rowcount',String(fresh.models.length+1));
    view.scroll?.querySelectorAll('tr[data-pd-row]').forEach(row=>{const index=indices.get(row.dataset.pdModel);if(index==null){row.remove();return;}row.dataset.pdRow=String(index);row.setAttribute('aria-rowindex',String(index+2));row.querySelectorAll('.pdCellInput').forEach(input=>{input.dataset.r=String(index);});});
    return view.matrix;
  }
  function matrixRenderWindow(view){
    if(!view.virtual||!view.host.isConnected)return;
    const {host,scroll,req}=view,matrix=matrixCurrent(view),tbody=scroll.querySelector('tbody'),header=scroll.querySelector('thead').getBoundingClientRect().height;
    const range=matrixWindow(matrix.models.length,Math.max(0,scroll.scrollTop-header),Math.max(1,scroll.clientHeight-header),view.rowHeight),keep=new Set();
    for(let i=range.start;i<range.end;i++)keep.add(i);
    const pin=node=>{const row=(node?.nodeType===1?node:node?.parentElement)?.closest('tr[data-pd-row]');if(row&&tbody.contains(row))keep.add(Number(row.dataset.pdRow));};
    pin(document.activeElement);
    const selection=window.getSelection?.();if(selection&&!selection.isCollapsed){pin(selection.anchorNode);pin(selection.focusNode);}
    const existing=new Map([...tbody.querySelectorAll('tr[data-pd-row]')].map(row=>[Number(row.dataset.pdRow),row]));
    // Keep editing and selection endpoint nodes mounted; never move or replace them.
    for(const row of [...tbody.children])if(!row.hasAttribute('data-pd-row')||!keep.has(Number(row.dataset.pdRow)))row.remove();
    let cursor=tbody.firstChild,previous=0;
    const insert=node=>{if(node===cursor)cursor=cursor.nextSibling;else tbody.insertBefore(node,cursor);};
    for(const index of [...keep].sort((a,b)=>a-b)){
      if(index>previous){const spacer=document.createElement('tr');spacer.className='pdVirtualSpacer';spacer.setAttribute('aria-hidden','true');spacer.innerHTML=`<td colspan="${view.columns}" style="height:${(index-previous)*view.rowHeight}px"></td>`;insert(spacer);}
      let row=existing.get(index);
      if(!row){const fragment=document.createElement('tbody');fragment.innerHTML=matrixRowsHtml(req,matrix,{...view,start:index,end:index+1});row=fragment.firstElementChild;if(view.ready)bindMatrixRows(host,req,fragment);}
      insert(row);previous=index+1;
    }
    if(previous<matrix.models.length){const spacer=document.createElement('tr');spacer.className='pdVirtualSpacer';spacer.setAttribute('aria-hidden','true');spacer.innerHTML=`<td colspan="${view.columns}" style="height:${(matrix.models.length-previous)*view.rowHeight}px"></td>`;insert(spacer);}
    view.range=range;bindThumbs(host);
  }
  function matrixEnsureRow(host,index){
    const view=matrixViews.get(host);if(!view||index<0||index>=view.matrix.models.length)return false;
    if(view.virtual){
      const header=view.scroll.querySelector('thead').getBoundingClientRect().height,top=index*view.rowHeight,bottom=header+(index+1)*view.rowHeight;
      if(top<view.scroll.scrollTop)view.scroll.scrollTop=top;
      else if(bottom>view.scroll.scrollTop+view.scroll.clientHeight)view.scroll.scrollTop=bottom-view.scroll.clientHeight;
      matrixRenderWindow(view);
    }
    return true;
  }
  function matrixClipboardHtml(view,start=0,end=view.matrix.models.length,includeHeaders=true){
    const cards=E.supplierScorecards(view.req),headers=[L('Model','Model'),...(matrixContext().summary.length?[matrixContext().summary.map(key=>Q().columnLabel(key)).join(' / ')]:[]),...fixedClip(L('Hedef Fiyat','Target Price'),L('Teklif & Onay','Quotes & Approval'),REF_KEYS.map(refLabel).join(' / ')),...matrixContext().extra.map(key=>Q().columnLabel(key)),...view.matrix.manufacturers.map(name=>{const card=cards.find(card=>card.name===name);return `${clipboardLabel(name)}\n${card.models}/${card.total} · ${card.wins} ${L('en iyi','best')}\n${pctText(card.modelIndex)}`;})];
    if(view.other.length)headers.push(L(`Diğer (${view.other.length})`,`Other (${view.other.length})`));if(view.canEdit)headers.push(L('Üretici','Manufacturer'));
    const cell=value=>esc(value.trim()).replace(/\n/g,'<br>');
    const image=model=>{const html=thumbHtml(view.req,model.first),src=html.match(/\sdata-src="([^"]*)"/)?.[1];return src?html.replace(/\ssrc="[^"]*"/,' src="'+src+'"'):html;};
    return '<table>'+(includeHeaders?'<thead><tr>'+headers.map(value=>'<th>'+cell(value)+'</th>').join('')+'</tr></thead>':'')+'<tbody>'+view.matrix.models.slice(start,end).map(model=>'<tr>'+matrixClipboardRowParts(view.req,model,view).map((value,index)=>'<td>'+(index===0?image(model):'')+cell(value)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
  }
  function bindMatrixClipboard(view){
    const {host,scroll,req}=view,table=scroll.querySelector('table');
    const payload=()=>{const matrix=matrixCurrent(view),head=table.tHead?.querySelector('th'),headers=Boolean(head&&getComputedStyle(head).userSelect!=='none');return {text:matrixClipboardText(req,view,{headers}),html:matrixClipboardHtml(view,0,matrix.models.length,headers)};};
    host.querySelector('[data-pd-copy]')?.addEventListener('click',async()=>{
      try{const data=payload();if(navigator.clipboard.write&&typeof ClipboardItem!=='undefined')await navigator.clipboard.write([new ClipboardItem({'text/plain':new Blob([data.text],{type:'text/plain'}),'text/html':new Blob([data.html],{type:'text/html'})})]);else await navigator.clipboard.writeText(data.text);toast(L('Matrisin tamamı kopyalandı.','The complete matrix was copied.'));}
      catch(_){toast(L('Matris kopyalanamadı; tabloya odaklanıp Ctrl+A, Ctrl+C kullanın.','Could not copy the matrix; focus the table and use Ctrl+A, Ctrl+C.'));}
    });
    scroll.addEventListener('pointerdown',()=>{view.selectAll=false;});
    scroll.addEventListener('keydown',event=>{
      const matrix=matrixCurrent(view);
      const editing=event.target.closest('input,textarea,[contenteditable="true"]');
      if(!editing&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='c'){event.stopPropagation();return;}
      if(!editing&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='a'){
        event.preventDefault();view.selectAll=true;const range=document.createRange();range.selectNodeContents(table);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);return;
      }
      if(event.key!=='Tab'||!view.virtual)return;
      const row=event.target.closest('tr[data-pd-row]');if(!row)return;
      const controls=[...row.querySelectorAll('input:not(:disabled),button:not(:disabled):not([tabindex="-1"])')],edge=event.shiftKey?controls[0]:controls.at(-1),next=matrixNextFocusRow(view,Number(row.dataset.pdRow),event.shiftKey?-1:1);
      if(event.target!==edge||next<0||next>=matrix.models.length)return;
      const mounted=host.querySelector(`tr[data-pd-row="${next}"]`);if(mounted)return;
      event.preventDefault();if(editing?.classList.contains('pdCellInput'))commitInput(host,req,editing);
      matrixEnsureRow(host,next);const targets=host.querySelector(`tr[data-pd-row="${next}"]`)?.querySelectorAll('input:not(:disabled),button:not(:disabled):not([tabindex="-1"])');
      (event.shiftKey?targets?.[targets.length-1]:targets?.[0])?.focus();
    });
    view.copy=event=>{
      const matrix=matrixCurrent(view);
      if(event.target.closest?.('input,textarea,[contenteditable="true"]'))return;
      const selection=window.getSelection();if(!selection||selection.isCollapsed||!selection.rangeCount)return;
      const range=selection.getRangeAt(0);if(!range.intersectsNode(table))return;
      const whole=range.startContainer===table&&range.startOffset===0&&range.endContainer===table&&range.endOffset===table.childNodes.length;
      if((view.selectAll&&whole)||selection.containsNode(table,false)){const data=payload();event.preventDefault();event.stopImmediatePropagation();event.clipboardData.setData('text/plain',data.text);event.clipboardData.setData('text/html',data.html);return;}
      const cell=node=>(node.nodeType===1?node:node.parentElement)?.closest('td,th'),first=cell(range.startContainer),last=cell(range.endContainer);
      if(!first||!last||!table.contains(first)||!table.contains(last)||first.closest('tr')===last.closest('tr'))return;
      const start=Number(first.closest('tr').dataset.pdRow||0),end=Number(last.closest('tr').dataset.pdRow??matrix.models.length-1)+1,inHead=Boolean(first.closest('thead')),headers=inHead&&getComputedStyle(first).userSelect!=='none';
      const offset=(cell,node,position,part)=>{
        const element=node.nodeType===1?node:node.parentElement,opt=element.closest('.pdCellOpt'),prefix=document.createRange();
        const blocks=cell.querySelector('.pdModelText')||cell.querySelector('.pdMfrHeadBody');
        if(blocks){
          const fields=[...blocks.children].filter(field=>field.matches('b,span,small')&&getComputedStyle(field).display!=='none'),field=fields.find(field=>field===element||field.contains(element));
          const index=node===blocks?fields.filter(field=>[...blocks.childNodes].indexOf(field)<position).length:fields.indexOf(field);
          if(index>=0){const imageGap=cell.classList.contains('pdModelCell')&&part.startsWith('\n')?1:0,lines=part.slice(imageGap).split('\n'),base=imageGap+lines.slice(0,index).reduce((sum,line)=>sum+line.length+1,0);if(node===blocks)return Math.min(part.length,base);prefix.selectNodeContents(field);prefix.setEnd(node,position);return Math.min(part.length,base+clipboardLabel(prefix.toString()).length);}
        }
        if(node===cell)return position===0?0:part.length;
        prefix.selectNodeContents(opt||cell);prefix.setEnd(node,position);
        return Math.min(part.length,clipboardLabel(prefix.toString()).length+(opt?part.indexOf('\n\n')+2:0));
      };
      let text='',rows=[];
      if(headers){const parts=matrixClipboardHeaderParts(req,view).slice(first.cellIndex);parts[0]=parts[0].slice(offset(first,range.startContainer,range.startOffset,parts[0]));if(parts[0]==='\n')parts[0]='\t';text+=parts.join('');rows.push(parts);}
      for(let index=start;index<end;index++){
        let parts=matrixClipboardRowParts(req,matrix.models[index],view);
        if(index===end-1){parts=parts.slice(0,last.cellIndex+1);parts[parts.length-1]=parts.at(-1).slice(0,offset(last,range.endContainer,range.endOffset,parts.at(-1)));}
        if(index===start&&!inHead){parts=parts.slice(first.cellIndex);parts[0]=parts[0].slice(offset(first,range.startContainer,range.startOffset,parts[0]));if(parts[0]==='\n')parts[0]='\t';}
        text+=parts.join('');rows.push(parts);
      }
      event.preventDefault();event.stopImmediatePropagation();event.clipboardData.setData('text/plain',text);event.clipboardData.setData('text/html','<table>'+rows.map(parts=>'<tr>'+parts.map(value=>'<td>'+esc(value.trim()).replace(/\n/g,'<br>')+'</td>').join('')+'</tr>').join('')+'</table>');
    };
  }
  document.addEventListener('copy',event=>{
    const node=window.getSelection?.()?.anchorNode,scroll=(node?.nodeType===1?node:node?.parentElement)?.closest('.pdMatrixScroll');
    matrixScrollViews.get(scroll)?.copy?.(event);
  },true);
  function renderMatrix(host,req){
    return Q()?.withCollectionRead?Q().withCollectionRead(()=>renderMatrixContent(host,req)):renderMatrixContent(host,req);
  }
  function renderMatrixContent(host,req){
    const api=Q();if(!host||!req||!api)return;
    infoCache=new WeakMap();
    const canEdit=api.canEdit(req),layout=E.supplierLayout(visibleSupplierCards(req),Boolean(state.expandedSuppliers[req.id])),matrix={...E.requestMatrix(req),manufacturers:layout.visible.map(s=>s.name)};
    const gain=E.requestGain(req),round=Math.max(1,Number(req.round)||1);
    const heads=layout.visible.map(card=>`<th scope="col" class="pdMfrHead" data-pd-supplier="${esc(card.key)}"${ariaSort(['mfr:'+card.name])}><div class="pdMfrHeadBody">${supplierHeadHtml(card)}</div>${hideButton('mfr:'+card.name,card.name)}${resizeHandle('mfr:'+card.name)}</th>`).join('');
    const otherHead=layout.other.length?`<th scope="col" class="pdMfrHead"><button type="button" class="linkBtn" data-pd-expand aria-expanded="false">${esc(L(`Diğer (${layout.other.length})`,`Other (${layout.other.length})`))}</button>${resizeHandle('other')}</th>`:'';
    // Tablodan üretici ekleme sütunu (Send to Pricing kullanmadan fiyat veren üretici için).
    const addHead=canEdit?`<th scope="col" class="pdMfrHead pdAddMfrHead"><button type="button" class="pdAddMfr" data-pd-add-mfr title="${esc(L('Tabloya üretici ekle','Add a manufacturer to the table'))}"><svg class="ic" aria-hidden="true"><use href="#i-plus"/></svg>${esc(L('Üretici','Manufacturer'))}</button></th>`:'';
    const columnCount=matrix.manufacturers.length+(layout.other.length?1:0)+(canEdit?1:0);
    const virtual=matrix.models.length>100,initialEnd=virtual?40:matrix.models.length,context=matrixContext(),columnKeys=matrixColumnKeys(context,layout,canEdit);
    const allModels=matrix.models;
    matrix.models=filterUnapproved(sortModels(req,allModels,sortKeysFor(context,layout)));
    if(req.source==='collection'&&matrix.models.length)ensureReferences();
    const approvedModels=allModels.filter(model=>E.rowStats(model.lines).approved).length,openModels=allModels.length-approvedModels;
    const hintsText=[['Enter',L('alt satır','next row')],['Tab',L('sonraki üretici','next manufacturer')],['A',L('onayla','approve')],['D','Drop'],['O',L('alternatif fiyat','alternative price')],['Ctrl+V',L('Excel’den blok yapıştır','paste a block from Excel')],['Ctrl+Z',L('geri al','undo')],['Esc',L('vazgeç','cancel')]].map(([key,text])=>`${key}: ${text}`).join('\n');
    const contextHeads=context.extra.map(key=>`<th scope="col"${ariaSort(['field:'+key])}>${sortLabel('field:'+key,api.columnLabel(key))}${resizeHandle('ctx:'+key)}</th>`).join('');
    host.innerHTML=`<div class="pdMatrixBar">
        <span class="pdLegend" title="${esc(L('Yeşil dolu hücre onaylı fiyattır; açık yeşil, onay verilmemiş satırdaki en iyi tekliftir.','A solid green cell is the approved price; light green is the best offer in a row without approval.'))}"><i class="pdLegendAppr"></i>${esc(L('Onaylı','Approved'))}<i class="pdLegendBest"></i>${esc(L('En iyi','Best'))}<i class="pdLegendOut"></i>${esc(L('Olağan dışı','Unusual'))}</span>
        <span class="pdApprovalProgress${allModels.length&&approvedModels===allModels.length?' isComplete':''}" data-pd-approval-progress title="${esc(L('Onaylı fiyatı olan model sayısı','Models with an approved price'))}">${esc(L(`${approvedModels}/${allModels.length} model onaylı`,`${approvedModels}/${allModels.length} models approved`))}</span>
        <button type="button" class="tbtn pdFilterToggle${matrixLayout.unapprovedOnly?' isActive':''}" data-pd-unapproved aria-pressed="${matrixLayout.unapprovedOnly?'true':'false'}" title="${esc(matrixLayout.unapprovedOnly?L('Tüm modelleri göster','Show all models'):L('Yalnız onaylı fiyatı olmayan modelleri göster','Show only models without an approved price'))}">${esc(L(`Yalnız onaysız (${openModels})`,`Unapproved only (${openModels})`))}</button>
        <span class="pdRoundBadge" title="${esc(L('Bu talepteki pazarlık turu','Negotiation round of this request'))}">${esc(L(`Tur ${round}`,`Round ${round}`))}</span>
        ${gain&&Number.isFinite(gain.gainPct)&&Math.abs(gain.gainPct)>=0.05?`<span class="pdChip ${toneOf(gain.gainPct)}" title="${esc(L('İlk tur en iyi tekliflerine göre güncel fiyat','Current price versus first-round best offers'))}">${esc(L('Pazarlık','Negotiation'))} ${esc(pctText(gain.gainPct))}</span>`:''}
        ${hiddenColumnCount(req)?`<button type="button" class="tbtn" data-pd-show-hidden title="${esc(L('Gizlenen sütunları yeniden göster','Show the hidden columns again'))}">${esc(L(`${hiddenColumnCount(req)} gizli sütun · göster`,`${hiddenColumnCount(req)} hidden column(s) · show`))}</button>`:''}
        <span class="pdBarSpacer"></span>
        <span class="pdHintsBtn" tabindex="0" role="note" title="${esc(hintsText)}" aria-label="${esc(L('Klavye kısayolları','Keyboard shortcuts')+': '+hintsText.replace(/\n/g,' · '))}">${esc(L('Kısayollar','Shortcuts'))}</span>
        <button type="button" class="tbtn pdIconBtn" data-pd-copy title="${esc(L('Matrisi kopyala','Copy matrix'))}" aria-label="${esc(L('Matrisi kopyala','Copy matrix'))}"><svg class="ic" aria-hidden="true"><use href="#i-copy"/></svg></button>
        ${state.expandedSuppliers[req.id]&&matrix.manufacturers.length>8?`<button type="button" class="tbtn" data-pd-collapse aria-expanded="true">${esc(L('Üreticileri katla','Collapse manufacturers'))}</button>`:''}
        ${canEdit?`<button type="button" class="tbtn" data-pd-import title="${esc(L('Üreticinin doldurduğu fiyat talep Excel’ini seç ya da tabloya sürükle','Choose the pricing request Excel returned by the manufacturer, or drag it onto the table'))}"><svg class="ic"><use href="#i-file-import"/></svg>${esc(L('Dönüş Excel’i','Supplier Excel'))}</button><input type="file" accept=".xlsx,.xls" data-pd-import-file hidden>`:''}
        ${canEdit?`<button type="button" class="tbtn" data-pd-round><svg class="ic"><use href="#i-refresh"/></svg>${esc(L('Yeni tur','New round'))}</button>`:''}
        <button type="button" class="tbtn pdIconBtn" data-pd-undo ${state.undo.some(group=>group.requestId===req.id)?'':'disabled'} title="${esc(L('Geri al (Ctrl+Z)','Undo (Ctrl+Z)'))}" aria-label="${esc(L('Geri al','Undo'))}"><svg class="ic" aria-hidden="true"><use href="#i-arrow-back-up"/></svg></button>
      </div>
      <div class="pdRoundPanel" data-pd-round-panel hidden></div>
      <div class="pdImportPanel" data-pd-import-panel hidden></div>
      <div class="pdMfrPanel" data-pd-mfr-panel hidden></div>
      <div class="pdOptionsPanel" data-pd-options-panel hidden></div>
      <div class="pdMatrixScroll" tabindex="0"><table class="pdMatrix" style="${matrixTableStyle(columnKeys)}" aria-rowcount="${matrix.models.length+1}" aria-colcount="${columnKeys.length}" aria-label="${esc(L('Model × üretici teklif matrisi','Model × manufacturer quotation matrix'))}">
        <colgroup>${columnKeys.map(key=>`<col data-pd-col="${esc(key)}" style="width:${colWidth(key)}px">`).join('')}</colgroup>
        <thead><tr><th scope="col" class="pdModelHead"${ariaSort(['model'])}>${sortLabel('model',L('Model','Model'))}${resizeHandle('model')}</th>${context.summary.length?`<th scope="col" class="pdSummary"${ariaSort(context.summary.map(key=>'field:'+key))}><span class="pdHeadSorts">${context.summary.map(key=>sortLabel('field:'+key,api.columnLabel(key))).join('<span class="pdHeadSep" aria-hidden="true"> / </span>')}</span>${hideButton('summary',context.summary.map(key=>api.columnLabel(key)).join(' / '))}${resizeHandle('summary')}</th>`:''}${fixedShown('target')?`<th scope="col" class="pdNum pdTarget"${ariaSort(['target'])}>${sortLabel('target',L('Hedef Fiyat','Target Price'))}${hideButton('target',L('Hedef Fiyat','Target Price'))}${resizeHandle('target')}</th>`:''}${fixedShown('quotes')?`<th scope="col" class="pdQuotesCol"${ariaSort(['quotes'])}>${sortLabel('quotes',L('Teklif & Onay','Quotes & Approval'))}${hideButton('quotes',L('Teklif & Onay','Quotes & Approval'))}${resizeHandle('quotes')}</th>`:''}${fixedShown('refs')?`<th scope="col" class="pdRefsCol" title="${esc(REF_KEYS.map(key=>`${refShort(key)} = ${refLabel(key)}`).join('\n'))}"${ariaSort(REF_KEYS.map(key=>'ref:'+key))}><span class="pdHeadSorts">${REF_KEYS.map(key=>sortLabel('ref:'+key,refShort(key))).join('<span class="pdHeadSep" aria-hidden="true"> / </span>')}</span>${hideButton('refs',REF_KEYS.map(refLabel).join(' / '))}${resizeHandle('refs')}</th>`:''}${contextHeads}${heads}${otherHead}${addHead}</tr></thead>
        <tbody>${matrix.models.length?matrixRowsHtml(req,matrix,{canEdit,other:layout.other,end:initialEnd}):`<tr><td colspan="${columnKeys.length}"><div class="pricingEmptyState">${esc(allModels.length?L('Onay bekleyen model kalmadı. Tümünü görmek için "Yalnız onaysız" filtresini kapatın.','No models are waiting for approval. Turn off "Unapproved only" to see all models.'):L('Bu talepte model yok.','There are no models in this request.'))}</div></td></tr>`}</tbody>
      </table></div>`;
    host.querySelectorAll('thead [data-pd-expand],[data-pd-collapse]').forEach(button=>button.addEventListener('click',()=>{
      const scroll=host.querySelector('.pdMatrixScroll'),left=scroll?.scrollLeft||0;
      if(button.hasAttribute('data-pd-expand'))state.expandedSuppliers[req.id]=true;else delete state.expandedSuppliers[req.id];
      store.set(SUPPLIERS_KEY,state.expandedSuppliers);renderMatrix(host,req);
      const next=host.querySelector('.pdMatrixScroll');if(next)next.scrollLeft=left;
      host.querySelector('[data-pd-collapse],[data-pd-expand]')?.focus({preventScroll:true});
    }));
    // Yazarken ve hücreler arasında ilerlerken sütunları yerinden oynatma.
    host.onfocusout=()=>setTimeout(()=>{
      if(host.dataset.pdOrderDirty!=='1'||host.contains(document.activeElement))return;
      delete host.dataset.pdOrderDirty;
      const left=host.querySelector('.pdMatrixScroll')?.scrollLeft||0;
      renderMatrix(host,req);const scroll=host.querySelector('.pdMatrixScroll');if(scroll)scroll.scrollLeft=left;
    },0);
    const scroll=host.querySelector('.pdMatrixScroll'),view={host,scroll,req,matrix,items:req.items,layout,canEdit,other:layout.other,virtual,columnKeys,columns:columnKeys.length,rowHeight:scroll.querySelector('tr[data-pd-row]')?.getBoundingClientRect().height||42};
    matrixViews.set(host,view);matrixScrollViews.set(scroll,view);matrixRenderWindow(view);
    if(virtual){
      let frame=0;scroll.addEventListener('scroll',()=>{if(!frame)frame=requestAnimationFrame(()=>{frame=0;matrixRenderWindow(view);});},{passive:true});
      if(typeof ResizeObserver!=='undefined'){const observer=new ResizeObserver(()=>{if(!host.isConnected||matrixViews.get(host)!==view){observer.disconnect();return;}view.rowHeight=scroll.querySelector('tr[data-pd-row]')?.getBoundingClientRect().height||view.rowHeight;matrixRenderWindow(view);});observer.observe(scroll);}
    }
    state.flash.clear();
    bindMatrix(host,req,matrix);view.ready=true;bindMatrixClipboard(view);bindMatrixHead(view);
    bindThumbs(host);
    restoreFocus(host,req);
  }
  function restoreFocus(host,req){
    const target=state.focus;state.focus=null;
    if(!target||target.requestId!==req.id)return;
    const view=matrixViews.get(host),index=view?.matrix.models.findIndex(model=>model.lines.some(line=>line.id===target.lineId));
    if(index>=0)matrixEnsureRow(host,index);
    let input=host.querySelector(`[data-pd-input="${CSS.escape(target.lineId)}"]`);
    // Satır "Yalnız onaysız" listesinden çıktıysa aynı sütunda sıradaki modele geç.
    if(index<0&&view&&Number.isFinite(target.r)&&view.matrix.models.length){
      const row=Math.min(target.r,view.matrix.models.length-1);matrixEnsureRow(host,row);
      input=host.querySelector(`.pdCellInput[data-r="${row}"][data-c="${target.c}"]`)||host.querySelector(`tr[data-pd-row="${row}"] .pdCellInput:not(:disabled)`);
    }
    if(input&&!input.disabled){input.focus();if(target.select!==false)input.select();}
  }
  function lineOf(req,id){return (req.items||[]).find(item=>item.id===id)||null;}
  function moveFocus(host,input,dr,dc){
    const view=matrixViews.get(host);if(view)matrixCurrent(view);
    const r=Number(input.dataset.r)+dr,c=Number(input.dataset.c)+dc;
    if(view&&(c<0||c>=view.matrix.manufacturers.length||!matrixEnsureRow(host,r)))return false;
    const next=host.querySelector(`.pdCellInput[data-r="${r}"][data-c="${c}"]`);
    if(next&&!next.disabled){next.focus();next.select();return true;}
    return false;
  }
  /* Değer yazıldıktan sonra yalnız ilgili model satırının en iyi/onay/Δ
     bilgisi güncellenir; inputlar yeniden çizilmez, odak ve yazma akışı bozulmaz. */
  function refreshModelRow(host,req,modelKey){
    return Q()?.withCollectionRead?Q().withCollectionRead(()=>refreshModelRowContent(host,req,modelKey)):refreshModelRowContent(host,req,modelKey);
  }
  function refreshModelRowContent(host,req,modelKey){
    const model=E.requestMatrix({...req,models:[],items:req.items.filter(item=>item.modelKey===modelKey)}).models[0];
    const tr=host.querySelector(`tr[data-pd-model="${CSS.escape(modelKey)}"]`);
    if(!model)return;
    infoCache=new WeakMap();
    const stats=E.rowStats(model.lines);
    const prev=(state.lastBest.get(req.id)||new Map()).get(modelKey)||'',bestId=stats.best?stats.best.lineId:'';
    const map=state.lastBest.get(req.id)||new Map();map.set(modelKey,bestId);state.lastBest.set(req.id,map);
    if(!tr)return;
    const info=lineInfo(req,model.first);
    model.lines.forEach(line=>{
      const td=tr.querySelector(`td[data-pd-line="${CSS.escape(line.id)}"]`);if(!td)return;
      const name=line.manufacturer,fresh=document.createElement('tbody');
      fresh.innerHTML=`<tr>${cellHtml(req,model,name,stats,{mi:Number(td.querySelector('.pdCellInput')?.dataset.r||0),ci:Number(td.querySelector('.pdCellInput')?.dataset.c||0),canEdit:Q().canEdit(req),moved:Boolean(bestId&&prev&&prev!==bestId&&bestId===line.id)})}</tr>`;
      const next=fresh.querySelector('td');
      td.className=next.className;
      td.querySelector('.pdCellTop').innerHTML=next.querySelector('.pdCellTop').innerHTML;
      td.querySelector('.pdCellNote').innerHTML=next.querySelector('.pdCellNote').innerHTML;
      const opt=td.querySelector('.pdCellOpt');if(opt)opt.innerHTML=next.querySelector('.pdCellOpt').innerHTML;
      td.querySelector('.pdApprovedMark')?.remove();const mark=next.querySelector('.pdApprovedMark');if(mark)td.appendChild(mark);
      const input=td.querySelector('.pdCellInput'),freshInput=next.querySelector('.pdCellInput');if(input&&freshInput)input.setAttribute('aria-label',freshInput.getAttribute('aria-label'));
      ['.pdApprove','.pdDrop'].forEach(selector=>{const a=td.querySelector(selector),b=next.querySelector(selector);if(a&&b){a.className=b.className;a.disabled=b.disabled;a.setAttribute('aria-pressed',b.getAttribute('aria-pressed'));a.title=b.title;}});
    });
    const swap=(selector,html)=>{const td=tr.querySelector(selector);if(!td)return;const tmp=document.createElement('tbody');tmp.innerHTML=`<tr>${html}</tr>`;const next=tmp.querySelector('td');if(next)td.replaceWith(next);};
    swap('td[data-pd-quotes]',quotesCellHtml(model,info,stats));
    swap('td[data-pd-refs]',refsCellHtml(model,info));
    tr.classList.toggle('pdRowApproved',Boolean(stats.approved));
    updateApprovalProgress(host,req);
    E.supplierScorecards(req).forEach(card=>{const head=host.querySelector(`[data-pd-supplier="${CSS.escape(card.key)}"] .pdMfrHeadBody`);if(head)head.innerHTML=supplierHeadHtml(card);});
    host.dataset.pdOrderDirty='1';
    const undo=host.querySelector('[data-pd-undo]');if(undo)undo.disabled=!state.undo.some(group=>group.requestId===req.id);
  }
  function updateApprovalProgress(host,req){
    const chip=host.querySelector('[data-pd-approval-progress]'),view=matrixViews.get(host);if(!chip||!view)return;
    const models=E.requestMatrix(req).models,approved=models.filter(model=>E.rowStats(model.lines).approved).length;
    chip.textContent=L(`${approved}/${models.length} model onaylı`,`${approved}/${models.length} models approved`);
    chip.classList.toggle('isComplete',Boolean(models.length)&&approved===models.length);
  }
  /* Hedef fiyat Koleksiyon'daki Target Price hücresidir; yalnız Koleksiyon'un
     kendisinin yazmaya izin verdiği satırda (yüklü çalışma alanının sahibi,
     düzenleme yetkisi, modele bağlı olmayan alan) düzenlenir ve Koleksiyon'un
     kanonik hücre yazım yolundan (geri al, FOB yeniden hesabı, kayıt) geçer. */
  function commitTarget(host,req,input){
    const api=Q(),modelKey=input.dataset.pdTarget,item=[...(req.items||[]),...(req.models||[])].find(entry=>entry&&entry.modelKey===modelKey);
    const reset=()=>{input.value=input.defaultValue;};
    const raw=clean(input.value);
    if(raw===clean(input.defaultValue))return;
    if(!api?.setTarget||!item){reset();return;}
    if(raw&&E.price(raw)==null){toast(L('Geçerli bir hedef fiyat girin.','Enter a valid target price.'));reset();return;}
    if(!api.setTarget(req,item,raw)){reset();return;}
    infoCache=new WeakMap();
    const target=E.price(api.itemTarget(req,item));
    input.value=target!=null?kplain(target):'';input.defaultValue=input.value;
    refreshModelRow(host,req,modelKey);
  }
  function openPriceDrawer(host,req,modelKey){
    const view=matrixViews.get(host),model=view&&matrixCurrent(view).models.find(entry=>entry.modelKey===modelKey);if(!model)return false;
    const row=drawerRow(lineInfo(req,model.first)),drawer=window.BLCollectionPriceDrawer;
    if(!row||!drawer.open(row))return false;
    // Çekmecede yapılan onay/fiyat değişikliği kapanınca masaya yansır.
    if(typeof MutationObserver!=='undefined'&&drawer.isOpen){
      const watch=new MutationObserver(()=>{if(drawer.isOpen())return;watch.disconnect();if(host.isConnected)Q()?.renderDetail?.();});
      watch.observe(document.body,{childList:true});
    }
    return true;
  }
  /* Başlık: sıralama etiketi (tık / Enter / Boşluk) ve sürükleyerek genişlik. */
  function bindMatrixHead(view){
    const {host,scroll,req}=view,table=scroll.querySelector('table'),head=table?.tHead;if(!head)return;
    const sortBy=key=>{
      const active=document.activeElement;if(active?.classList?.contains('pdCellInput'))commitInput(host,req,active);
      cycleSort(key);const left=scroll.scrollLeft;renderMatrix(host,req);
      const next=host.querySelector('.pdMatrixScroll');if(next)next.scrollLeft=left;
      host.querySelector(`thead [data-pd-sort="${CSS.escape(key)}"]`)?.focus({preventScroll:true});
    };
    const rerender=focusSelector=>{const left=scroll.scrollLeft;renderMatrix(host,req);const next=host.querySelector('.pdMatrixScroll');if(next)next.scrollLeft=left;if(focusSelector)host.querySelector(focusSelector)?.focus({preventScroll:true});};
    head.addEventListener('click',event=>{
      const hide=event.target.closest('[data-pd-hide]');if(!hide||!head.contains(hide))return;
      event.preventDefault();event.stopPropagation();
      const active=document.activeElement;if(active?.classList?.contains('pdCellInput'))commitInput(host,req,active);
      setColumnHidden(req,hide.dataset.pdHide,true);rerender('[data-pd-show-hidden]');
    });
    host.querySelector('[data-pd-show-hidden]')?.addEventListener('click',()=>{showAllColumns(req);rerender();});
    head.addEventListener('click',event=>{const label=event.target.closest('[data-pd-sort]');if(label&&head.contains(label)){event.preventDefault();sortBy(label.dataset.pdSort);}});
    head.addEventListener('keydown',event=>{const label=event.target.closest('[data-pd-sort]');if(label&&(event.key==='Enter'||event.key===' ')){event.preventDefault();sortBy(label.dataset.pdSort);}});
    head.querySelectorAll('[data-pd-resize]').forEach(handle=>{
      const key=handle.dataset.pdResize;
      handle.addEventListener('pointerdown',event=>{
        if(event.button!==0)return;event.preventDefault();event.stopPropagation();
        const startX=event.clientX,start=colWidth(key);
        try{handle.setPointerCapture(event.pointerId);}catch(_){}
        table.classList.add('isResizing');
        const move=e=>{matrixLayout.widths[key]=start+e.clientX-startX;matrixLayout.widths[key]=colWidth(key);applyMatrixWidths(table,view.columnKeys);};
        const up=()=>{handle.removeEventListener('pointermove',move);handle.removeEventListener('pointerup',up);handle.removeEventListener('pointercancel',up);table.classList.remove('isResizing');saveMatrixLayout();view.rowHeight=scroll.querySelector('tr[data-pd-row]')?.getBoundingClientRect().height||view.rowHeight;matrixRenderWindow(view);};
        handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',up);handle.addEventListener('pointercancel',up);
      });
      handle.addEventListener('click',event=>event.stopPropagation());
      handle.addEventListener('dblclick',event=>{event.preventDefault();event.stopPropagation();delete matrixLayout.widths[key];applyMatrixWidths(table,view.columnKeys);saveMatrixLayout();});
    });
  }
  function flashCell(host,lineId){
    const td=host.querySelector(`td[data-pd-line="${CSS.escape(lineId)}"]`);if(!td||reducedMotion())return;
    td.classList.remove('pdFlash');void td.offsetWidth;td.classList.add('pdFlash');
  }
  function commitInput(host,req,input,source='matrix'){
    const api=Q(),line=lineOf(req,input.dataset.pdInput);if(!api||!line)return false;
    const raw=clean(input.value),current=clean(line.price);
    const same=(E.price(raw)!=null||E.price(current)!=null)?Math.abs((E.price(raw)||0)-(E.price(current)||0))<0.00005&&(E.price(raw)!=null)===(E.price(current)!=null):raw===current;
    if(same){const v=E.price(current);input.value=v!=null?kplain(v):current;return false;}
    pushUndo(req,[line],'price');
    api.applyPrice(req,line,raw,source);
    const v=E.price(line.price);input.value=v!=null?kplain(v):clean(line.price);
    refreshModelRow(host,req,line.modelKey);flashCell(host,line.id);
    return true;
  }
  function toggleApprove(host,req,line,source='matrix'){
    const api=Q();if(!api||!line)return;
    if(!E.price(line.price)){toast(L('Onaylamak için önce geçerli bir teklif fiyatı gir.','Enter a valid quotation price before approval.'));return;}
    const affected=(req.items||[]).filter(item=>item.modelKey===line.modelKey);
    pushUndo(req,affected,'approve');
    const cellInput=host?.querySelector?.(`[data-pd-input="${CSS.escape(line.id)}"]`);
    state.focus={requestId:req.id,lineId:line.id,r:cellInput?Number(cellInput.dataset.r):null,c:cellInput?Number(cellInput.dataset.c):null};state.flash.add(line.id);
    api.setApproval(req,line,!line.approved,source);
  }
  function toggleDrop(host,req,line){
    const api=Q();if(!api||!line)return;
    pushUndo(req,[line],'drop');
    state.focus={requestId:req.id,lineId:line.id,select:false};
    api.toggleDrop(req,line,'matrix');
  }
  /* Excel'den kopyalanan blok (sekme/satır ayrımlı) odaktaki hücreden başlayarak
     matrise yazılır. Tek geri alma adımıdır. */
  function pasteBlock(host,req,input,text){
    const rows=String(text||'').replace(/\r/g,'').split('\n');
    if(rows.length&&rows[rows.length-1]==='')rows.pop();
    const grid=rows.map(row=>row.split('\t'));
    if(grid.length<=1&&(grid[0]||[]).length<=1)return false;
    const view=matrixViews.get(host),matrix=view?matrixCurrent(view):E.requestMatrix(req),r0=Number(input.dataset.r),c0=Number(input.dataset.c);
    const targets=matrixPasteTargets(req,matrix,r0,c0,text).map(item=>({...item,el:host.querySelector(`[data-pd-input="${CSS.escape(item.line.id)}"]`)||{dataset:{pdInput:item.line.id},value:''}}));
    if(!targets.length)return false;
    pushUndo(req,targets.map(item=>item.line),'paste');
    let changed=0;
    targets.forEach(item=>{item.el.value=item.value;const before=state.undo.length;if(commitInput(host,req,item.el,'paste'))changed++;while(state.undo.length>before)state.undo.pop();});
    if(changed){const first=host.querySelector('tr[data-pd-model]');if(first)refreshModelRow(host,req,first.dataset.pdModel);}
    toast(L(`${changed} teklif hücresi yapıştırıldı.`,`${changed} quotation cells pasted.`),{undo:changed>0});
    return true;
  }
  function openRoundPanel(host,req){
    const panel=host.querySelector('[data-pd-round-panel]');if(!panel)return;
    if(!panel.hidden){panel.hidden=true;return;}
    const next=Math.max(1,Number(req.round)||1)+1;
    panel.innerHTML=`<div class="pdPanelHead"><b>${esc(L(`Tur ${next} başlat`,`Start round ${next}`))}</b><span>${esc(L('Mevcut fiyatlar korunur; bundan sonra girilen teklifler yeni tur olarak kaydedilir ve eski fiyatlar geçmişte üstü çizili görünür.','Current prices are kept; offers entered from now on are recorded as the new round and earlier prices appear struck through in history.'))}</span></div>
      <label class="pdField"><span>${esc(L('Tur notu (ör. karşı teklif hedefi)','Round note (e.g. counter-offer target)'))}</span><input type="text" maxlength="300" data-pd-round-note placeholder="${esc(L('Karşı teklif: …','Counter-offer: …'))}"></label>
      <div class="pdPanelActions"><button type="button" class="tbtn" data-pd-round-cancel>${esc(L('Vazgeç','Cancel'))}</button><button type="button" class="tbtn primary" data-pd-round-apply>${esc(L('Turu başlat','Start round'))}</button></div>`;
    panel.hidden=false;
    const note=panel.querySelector('[data-pd-round-note]');setTimeout(()=>note?.focus(),0);
    panel.querySelector('[data-pd-round-cancel]').addEventListener('click',()=>{panel.hidden=true;});
    panel.querySelector('[data-pd-round-apply]').addEventListener('click',async event=>{
      event.currentTarget.disabled=true;
      const saved=await Q().startRound(req,note?.value||'');
      if(saved){toast(L(`Tur ${saved.round} başladı.`,`Round ${saved.round} started.`));Q().renderDetail();}
      else event.currentTarget.disabled=false;
    });
  }
  function playPanel(panel){try{window.BLMotionPlus?.play?.('card',panel);}catch(_){}}
  function closeSiblingPanels(host,keep){host.querySelectorAll('[data-pd-mfr-panel],[data-pd-options-panel]').forEach(panel=>{if(panel!==keep)panel.hidden=true;});}
  /* Talepte yeni üretici: her model için boş fiyat hücresi açılır ve ilk hücreye
     odaklanılır. Ad, Koleksiyon üretici listesi ve diğer taleplerden önerilir. */
  function focusAdded(req,result){
    if(!result||!result.added.length)return false;
    if(E.requestMatrix(req).manufacturers.length>8&&!state.expandedSuppliers[req.id]){state.expandedSuppliers[req.id]=true;store.set(SUPPLIERS_KEY,state.expandedSuppliers);}
    state.focus={requestId:req.id,lineId:result.added[0].id};
    Q().renderDetail();
    return true;
  }
  function openManufacturerPanel(host,req){
    const api=Q(),panel=host.querySelector('[data-pd-mfr-panel]');if(!api||!panel)return;
    if(!panel.hidden){panel.hidden=true;return;}
    closeSiblingPanels(host,panel);
    const present=new Map(E.supplierScorecards(req).map(card=>[card.key,card])),models=E.requestMatrix(req).models.length;
    const suggestions=api.manufacturerSuggestions().filter(item=>{const card=present.get(E.keyOf(item.name));return !card||card.models<models;});
    const listId=`pdMfrList-${String(req.id).replace(/[^A-Za-z0-9_-]/g,'_')}`;
    panel.innerHTML=`<div class="pdPanelHead"><b>${esc(L('Tabloya üretici ekle','Add a manufacturer to the table'))}</b><span>${esc(L(`Listeden seç ya da listede olmayan yeni bir üretici adı yaz. Bu talepteki ${models} model için boş fiyat hücresi açılır; fiyatı doğrudan matrise yazarsın.`,`Pick from the list or type a new manufacturer name that is not listed. Empty price cells open for the ${models} models of this request; type prices straight into the matrix.`))}</span></div>
      <div class="pdMfrFields">
        <label class="pdField"><span>${esc(L('Üretici','Manufacturer'))}</span><input type="text" maxlength="240" list="${esc(listId)}" data-pd-mfr-name autocomplete="off" placeholder="${esc(L('Üretici adı','Manufacturer name'))}"></label>
        <label class="pdField"><span>${esc(L('E-posta (isteğe bağlı)','E-mail (optional)'))}</span><input type="email" maxlength="320" data-pd-mfr-email autocomplete="off" placeholder="name@example.com"></label>
        <datalist id="${esc(listId)}">${suggestions.map(item=>`<option value="${esc(item.name)}"></option>`).join('')}</datalist>
      </div>
      <div class="pdPanelActions"><button type="button" class="tbtn" data-pd-mfr-cancel>${esc(L('Vazgeç','Cancel'))}</button><button type="button" class="tbtn primary" data-pd-mfr-apply>${esc(L('Üreticiyi ekle','Add manufacturer'))}</button></div>`;
    panel.hidden=false;playPanel(panel);
    const name=panel.querySelector('[data-pd-mfr-name]'),email=panel.querySelector('[data-pd-mfr-email]');
    name?.focus();
    name.addEventListener('change',()=>{const hit=suggestions.find(item=>E.keyOf(item.name)===E.keyOf(name.value));if(hit&&hit.email&&!clean(email.value))email.value=hit.email;});
    const apply=()=>{
      const typed=clean(name.value);
      if(!typed){toast(L('Üretici adını yaz ya da listeden seç.','Type a manufacturer name or pick one from the list.'));name.focus();return;}
      const isNew=!suggestions.some(item=>E.keyOf(item.name)===E.keyOf(typed))&&!present.has(E.keyOf(typed));
      const result=api.addManufacturer(req,{name:typed,email:clean(email.value)});
      if(!result)return;
      if(!result.added.length){toast(L(`${result.manufacturer.name} bu talepteki bütün modellerde zaten var.`,`${result.manufacturer.name} is already on every model of this request.`));return;}
      toast(isNew?L(`Yeni üretici ${result.manufacturer.name} bu talebe eklendi; ${result.added.length} model için fiyat girebilirsin.`,`New manufacturer ${result.manufacturer.name} added to this request; enter prices for ${result.added.length} models.`):L(`${result.manufacturer.name} eklendi; ${result.added.length} model için fiyat girebilirsin.`,`${result.manufacturer.name} added; enter prices for ${result.added.length} models.`));
      focusAdded(req,result);
    };
    panel.querySelector('[data-pd-mfr-apply]').addEventListener('click',apply);
    panel.querySelector('[data-pd-mfr-cancel]').addEventListener('click',()=>{panel.hidden=true;});
    [name,email].forEach(input=>input.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.isComposing){event.preventDefault();apply();}if(event.key==='Escape'){event.preventDefault();panel.hidden=true;}}));
  }
  // Boş hücre: üretici talepte var ama bu model için satırı yok → tek satır açılır.
  function addLineFor(host,req,manufacturer,modelKey){
    const api=Q();if(!api||!manufacturer||!modelKey)return;
    const result=api.addManufacturer(req,{name:manufacturer},{modelKeys:[modelKey]});
    if(result&&result.added.length)focusAdded(req,result);
  }
  /* Alternatif fiyatlar: üretici aynı model için koşula bağlı ayrı fiyat
     verebilir (ör. kumaş gramajı / işçilik değişirse opsiyon 1, değişmezse
     opsiyon 2). Ana fiyat en iyi teklif, onay ve Koleksiyon hesabına girer;
     alternatif "Ana fiyat yap" ile seçilir, önceki ana fiyat alternatif olarak kalır. */
  function openOptionsPanel(host,req,line){
    const api=Q(),panel=host.querySelector('[data-pd-options-panel]');if(!api||!panel||!line)return;
    if(!panel.hidden&&panel.dataset.pdLine===line.id){panel.hidden=true;return;}
    closeSiblingPanels(host,panel);
    const canEdit=api.canEdit(req),info=lineInfo(req,line);
    const blank=()=>({id:`opt-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,label:'',price:'',note:''});
    const draft={priceLabel:clean(line.priceLabel),priceNote:clean(line.priceNote),options:E.lineOptions(line).map(option=>({id:option.id||blank().id,label:option.label,price:option.value!=null?moneyPlain(option.value):option.price,note:option.note}))};
    if(!draft.options.length&&canEdit)draft.options.push(blank());
    const mainValue=E.price(line.price);
    const dis=canEdit?'':'disabled';
    const render=focusIndex=>{
      panel.innerHTML=`<div class="pdPanelHead"><b>${esc(L('Alternatif fiyatlar','Alternative prices'))} · ${esc(info.model)} · ${esc(line.manufacturer)}</b><span>${esc(L('Üretici aynı model için farklı koşullarla fiyat verebilir (ör. kumaş gramajı ya da işçilik değişirse opsiyon 1, değişmezse opsiyon 2). En iyi teklif, onay ve Koleksiyon yalnız ana fiyatı kullanır; bir alternatifi “Ana fiyat yap” ile seçebilirsin.','A manufacturer may quote the same model under different conditions (e.g. option 1 if fabric weight or workmanship changes, option 2 if not). Best offer, approval and Collection use only the main price; pick an alternative with “Make main price”.'))}</span></div>
        <div class="pdOptGrid" role="table" aria-label="${esc(L('Alternatif fiyat listesi','Alternative price list'))}">
          <div class="pdOptRow pdOptHeadRow" role="row"><span role="columnheader">${esc(L('Seçenek','Option'))}</span><span role="columnheader" class="pdNum">${esc(L('Fiyat (USD)','Price (USD)'))}</span><span role="columnheader">${esc(L('Koşul / not','Condition / note'))}</span><span role="columnheader"></span></div>
          <div class="pdOptRow isMain" role="row"><input type="text" maxlength="120" data-pd-main-label value="${esc(draft.priceLabel)}" placeholder="${esc(L('Ana teklif','Main offer'))}" aria-label="${esc(L('Ana fiyat etiketi','Main price label'))}" ${dis}><span class="pdNum pdOptMainPrice" title="${esc(L('Ana fiyat matristeki hücreden girilir','The main price is entered in the matrix cell'))}">${esc(mainValue!=null?money(mainValue):'—')}</span><input type="text" maxlength="500" data-pd-main-note value="${esc(draft.priceNote)}" placeholder="${esc(L('ör. mevcut gramaj, mevcut işçilik','e.g. current fabric weight and workmanship'))}" aria-label="${esc(L('Ana fiyat notu','Main price note'))}" ${dis}><span class="pdOptMainTag">${esc(L('ANA FİYAT','MAIN PRICE'))}</span></div>
          ${draft.options.map((option,i)=>{const value=E.price(option.price);return `<div class="pdOptRow" role="row" data-pd-opt-row="${i}"><input type="text" maxlength="120" data-pd-opt-label="${i}" value="${esc(option.label)}" placeholder="${esc(L(`Opsiyon ${i+1}`,`Option ${i+1}`))}" aria-label="${esc(L(`Opsiyon ${i+1} etiketi`,`Option ${i+1} label`))}" ${dis}><input type="text" inputmode="decimal" class="pdNum" data-pd-opt-price="${i}" value="${esc(option.price)}" placeholder="—" aria-label="${esc(L(`Opsiyon ${i+1} fiyatı`,`Option ${i+1} price`))}" ${dis}><input type="text" maxlength="500" data-pd-opt-note="${i}" value="${esc(option.note)}" placeholder="${esc(L('ör. 160 gr kumaş, nakışsız','e.g. 160 gsm fabric, no embroidery'))}" aria-label="${esc(L(`Opsiyon ${i+1} notu`,`Option ${i+1} note`))}" ${dis}><span class="pdOptActions">${canEdit?`<button type="button" class="tbtn" data-pd-opt-promote="${i}" ${value!=null&&!line.dropped?'':'disabled'} title="${esc(L('Bu alternatifi ana fiyat yap; mevcut ana fiyat alternatif olarak saklanır','Make this alternative the main price; the current main price is kept as an alternative'))}">${esc(L('Ana fiyat yap','Make main price'))}</button><button type="button" class="pdOptRemove" data-pd-opt-remove="${i}" title="${esc(L('Alternatifi sil','Remove alternative'))}" aria-label="${esc(L(`Opsiyon ${i+1} sil`,`Remove option ${i+1}`))}"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg></button>`:''}</span></div>`;}).join('')}
        </div>
        <div class="pdPanelActions">${canEdit?`<button type="button" class="tbtn" data-pd-opt-add ${draft.options.length>=10?'disabled':''}><svg class="ic"><use href="#i-plus"/></svg>${esc(L('Alternatif ekle','Add alternative'))}</button><span class="pdBarSpacer"></span>`:''}<button type="button" class="tbtn" data-pd-opt-cancel>${esc(canEdit?L('Vazgeç','Cancel'):L('Kapat','Close'))}</button>${canEdit?`<button type="button" class="tbtn primary" data-pd-opt-save>${esc(L('Kaydet','Save'))}</button>`:''}</div>`;
      panel.dataset.pdLine=line.id;
      panel.querySelector('[data-pd-main-label]')?.addEventListener('input',event=>{draft.priceLabel=event.target.value;});
      panel.querySelector('[data-pd-main-note]')?.addEventListener('input',event=>{draft.priceNote=event.target.value;});
      panel.querySelectorAll('[data-pd-opt-label],[data-pd-opt-price],[data-pd-opt-note]').forEach(input=>input.addEventListener('input',()=>{
        const i=Number(input.dataset.pdOptLabel??input.dataset.pdOptPrice??input.dataset.pdOptNote),field=input.hasAttribute('data-pd-opt-label')?'label':input.hasAttribute('data-pd-opt-price')?'price':'note';
        if(draft.options[i])draft.options[i][field]=input.value;
        if(field==='price'){const promote=panel.querySelector(`[data-pd-opt-promote="${i}"]`);if(promote)promote.disabled=E.price(input.value)==null||!!line.dropped;}
      }));
      panel.querySelectorAll('[data-pd-opt-remove]').forEach(button=>button.addEventListener('click',()=>{draft.options.splice(Number(button.dataset.pdOptRemove),1);render();}));
      panel.querySelector('[data-pd-opt-add]')?.addEventListener('click',()=>{if(draft.options.length>=10)return;draft.options.push(blank());render(draft.options.length-1);});
      panel.querySelector('[data-pd-opt-cancel]')?.addEventListener('click',()=>{panel.hidden=true;});
      panel.querySelector('[data-pd-opt-save]')?.addEventListener('click',()=>{if(save())toast(L('Alternatif fiyatlar kaydedildi.','Alternative prices saved.'));});
      panel.querySelectorAll('[data-pd-opt-promote]').forEach(button=>button.addEventListener('click',()=>{
        const option=draft.options[Number(button.dataset.pdOptPromote)];if(!option)return;
        const id=option.id;if(!save({render:false}))return;
        if(api.promoteOption(req,line,id,'matrix')){state.flash.add(line.id);toast(L('Alternatif ana fiyat yapıldı; önceki ana fiyat alternatif olarak saklandı.','Alternative is now the main price; the previous main price is kept as an alternative.'));}
        api.renderDetail();
      }));
      if(focusIndex!=null)panel.querySelector(`[data-pd-opt-label="${focusIndex}"]`)?.focus();
    };
    // Boş satırlar atılır; fiyat yazılmışsa geçerli olmalıdır. Etiketsiz alternatif sırasıyla adlandırılır.
    const save=({render:rerender=true}={})=>{
      const options=[];
      for(const option of draft.options){
        const label=clean(option.label),price=clean(option.price),note=clean(option.note);
        if(!label&&!price&&!note)continue;
        if(price&&E.price(price)==null){toast(L(`Geçersiz fiyat: “${price}”. Sayı olarak yaz (ör. 4,15).`,`Invalid price: “${price}”. Enter a number (e.g. 4.15).`));return false;}
        options.push({id:option.id,label:label||L(`Opsiyon ${options.length+1}`,`Option ${options.length+1}`),price,note});
      }
      if(!api.saveLineOptions(req,line,{priceLabel:draft.priceLabel,priceNote:draft.priceNote,options}))return false;
      if(rerender){panel.hidden=true;state.focus={requestId:req.id,lineId:line.id,select:false};api.renderDetail();}
      return true;
    };
    panel.onkeydown=event=>{if(event.key==='Escape'){event.preventDefault();panel.hidden=true;}};
    render();panel.hidden=false;playPanel(panel);
    if(canEdit)panel.querySelector(draft.options.length===1&&!draft.options[0].label?'[data-pd-opt-label="0"]':'[data-pd-main-label]')?.focus();
  }
  function bindMatrixRows(host,req,root=host){
    const api=Q();
    root.querySelectorAll('.pdCellInput').forEach(input=>{
      input.addEventListener('focus',()=>{input.select();host.querySelectorAll('.pdFocusRow').forEach(el=>el.classList.remove('pdFocusRow'));input.closest('tr')?.classList.add('pdFocusRow');});
      input.addEventListener('change',()=>commitInput(host,req,input));
      input.addEventListener('blur',()=>commitInput(host,req,input));
      input.addEventListener('keydown',event=>{
        if(event.isComposing)return;
        const line=lineOf(req,input.dataset.pdInput);
        if(event.key==='Enter'||event.key==='ArrowDown'||event.key==='ArrowUp'){
          event.preventDefault();commitInput(host,req,input);
          moveFocus(host,input,(event.key==='ArrowUp'||(event.key==='Enter'&&event.shiftKey))?-1:1,0);return;
        }
        if(event.key==='Escape'){const v=E.price(line?.price);input.value=v!=null?kplain(v):clean(line?.price);input.blur();return;}
        if((event.ctrlKey||event.metaKey)&&!event.shiftKey&&event.key.toLowerCase()==='z'){
          const v=E.price(line?.price);if(clean(input.value)===(v!=null?kplain(v):clean(line?.price))){event.preventDefault();undoLast();}
          return;
        }
        if(event.ctrlKey||event.metaKey||event.altKey)return;
        const key=event.key.toLowerCase();
        if(key==='a'){event.preventDefault();commitInput(host,req,input);toggleApprove(host,req,line);return;}
        if(key==='d'){event.preventDefault();toggleDrop(host,req,line);return;}
        if(key==='o'){event.preventDefault();commitInput(host,req,input);openOptionsPanel(host,req,line);return;}
        if(key==='h'){event.preventDefault();openTab('history',{query:lineInfo(req,line).model});}
      });
      input.addEventListener('paste',event=>{const text=event.clipboardData?.getData('text/plain')||'';if(/[\t\n]/.test(text.replace(/\r?\n$/,''))){event.preventDefault();pasteBlock(host,req,input,text);}});
    });
    root.querySelectorAll('[data-pd-target]').forEach(input=>{
      input.addEventListener('focus',()=>input.select());
      input.addEventListener('change',()=>commitTarget(host,req,input));
      input.addEventListener('keydown',event=>{
        if(event.isComposing)return;
        if(event.key==='Enter'){event.preventDefault();commitTarget(host,req,input);}
        else if(event.key==='Escape'){event.preventDefault();input.value=input.defaultValue;input.blur();}
      });
    });
    root.querySelectorAll('[data-pd-approve]').forEach(button=>button.addEventListener('click',()=>{const active=document.activeElement;if(active?.classList?.contains('pdCellInput'))commitInput(host,req,active);toggleApprove(host,req,lineOf(req,button.dataset.pdApprove));}));
    root.querySelectorAll('[data-pd-drop]').forEach(button=>button.addEventListener('click',()=>toggleDrop(host,req,lineOf(req,button.dataset.pdDrop))));
    root.querySelectorAll('tr[data-pd-model] [data-pd-expand]').forEach(button=>button.addEventListener('click',()=>host.querySelector('thead [data-pd-expand]')?.click()));
  }
  function bindMatrix(host,req,matrix){
    const api=Q();bindMatrixRows(host,req);
    host.querySelector('[data-pd-round]')?.addEventListener('click',()=>openRoundPanel(host,req));
    host.querySelector('[data-pd-add-mfr]')?.addEventListener('click',()=>openManufacturerPanel(host,req));
    // Hücre içi rozet/boş hücre düğmeleri kısmi yenilemede yeniden çizildiği için tablo kabında dinlenir.
    host.querySelector('.pdMatrixScroll')?.addEventListener('click',event=>{
      const optionButton=event.target.closest('[data-pd-options]');
      if(optionButton){event.preventDefault();const active=document.activeElement;if(active?.classList?.contains('pdCellInput'))commitInput(host,req,active);openOptionsPanel(host,req,lineOf(req,optionButton.dataset.pdOptions));return;}
      const drawerButton=event.target.closest('[data-pd-drawer-open]');
      if(drawerButton){event.preventDefault();event.stopPropagation();openPriceDrawer(host,req,drawerButton.dataset.pdDrawerOpen);return;}
      const addButton=event.target.closest('[data-pd-add-line]');
      if(addButton){event.preventDefault();addLineFor(host,req,addButton.dataset.pdAddLine,addButton.dataset.pdAddModel);}
    });
    host.querySelector('.pdMatrixScroll')?.addEventListener('dblclick',event=>{
      const cell=event.target.closest('td[data-pd-drawer]');if(!cell||event.target.closest('button,input,select'))return;
      event.preventDefault();openPriceDrawer(host,req,cell.dataset.pdDrawer);
    });
    host.querySelector('[data-pd-unapproved]')?.addEventListener('click',()=>{
      const active=document.activeElement;if(active?.classList?.contains('pdCellInput'))commitInput(host,req,active);
      matrixLayout.unapprovedOnly=!matrixLayout.unapprovedOnly;saveMatrixLayout();
      renderMatrix(host,req);host.querySelector('[data-pd-unapproved]')?.focus({preventScroll:true});
    });
    host.querySelector('[data-pd-undo]')?.addEventListener('click',()=>undoLast());
    const fileInput=host.querySelector('[data-pd-import-file]');
    host.querySelector('[data-pd-import]')?.addEventListener('click',()=>fileInput?.click());
    fileInput?.addEventListener('change',()=>{const file=fileInput.files&&fileInput.files[0];fileInput.value='';if(file)void importSupplierWorkbook(host,req,file);});
    if(api.canEdit(req)){
      host.addEventListener('dragover',event=>{if([...(event.dataTransfer?.types||[])].includes('Files')){event.preventDefault();host.classList.add('pdDropActive');}});
      host.addEventListener('dragleave',event=>{if(!host.contains(event.relatedTarget))host.classList.remove('pdDropActive');});
      host.addEventListener('drop',event=>{const file=event.dataTransfer?.files&&event.dataTransfer.files[0];if(!file)return;event.preventDefault();host.classList.remove('pdDropActive');if(/\.xlsx?$/i.test(file.name))void importSupplierWorkbook(host,req,file);else toast(L('Yalnız Excel (.xlsx) dosyası içe aktarılabilir.','Only Excel (.xlsx) files can be imported.'));});
    }
  }

  /* ---------------- Üretici dönüş Excel'i ----------------
     Fiyat talep Excel'i Buyer Log tarafından üretilir; her satırda gizli bir
     satır anahtarı (BL Key = rowId) ve model adı bulunur. Üreticinin doldurduğu
     dosyada fiyat sütunu bulunur, satırlar anahtar (yoksa model adı / PLM ID)
     ile talepteki satıra eşlenir; önce fark gösterilir, onaysız yazılmaz. */
  async function readWorkbookRows(file,control={}){
    if(window.XLSX?.read){
      const wb=await window.BLFileParser.readWorkbook(file,{type:'array'},control);
      const sheet=wb.Sheets[wb.SheetNames[0]];
      return window.XLSX.utils.sheet_to_json(sheet,{header:1,raw:false,defval:''});
    }
    if(window.ExcelJS?.Workbook){
      const wb=new window.ExcelJS.Workbook();wb.model=await window.BLFileParser.readExcelJsModel(file,control);
      const ws=wb.worksheets[0],out=[];
      ws.eachRow({includeEmpty:false},row=>{const values=[];row.eachCell({includeEmpty:true},(cell,col)=>{const v=cell.value;values[col-1]=v&&typeof v==='object'?(v.result??v.text??(v.richText?v.richText.map(part=>part.text).join(''):'')):v;});out.push(values.map(value=>value==null?'':String(value)));});
      return out;
    }
    throw new Error(L('Excel okuyucu hazır değil.','Excel reader is not available.'));
  }
  // TR yerelinde "ID" → "ıd" olur; başlık eşlemesi noktasız ı'yı i'ye indirger.
  const headerKey=value=>clean(value).toLocaleLowerCase('tr-TR').replace(/ı/g,'i').replace(/\s+/g,' ');
  // Dosya adı karşılaştırması: Türkçe harfler ASCII'ye, alt çizgi/tire boşluğa indirgenir.
  const foldName=value=>clean(value).toLocaleLowerCase('tr-TR').replace(/ı/g,'i').replace(/ş/g,'s').replace(/ğ/g,'g').replace(/ü/g,'u').replace(/ö/g,'o').replace(/ç/g,'c').replace(/[^a-z0-9]+/g,' ').trim();
  function findColumn(header,patterns){return header.findIndex(cell=>patterns.some(pattern=>pattern.test(headerKey(cell))));}
  function supplierWorkbookPlan(req,rows,manufacturerHint){
    const headerIndex=rows.findIndex(row=>row.some(cell=>/(model|plm|bl key)/i.test(clean(cell))));
    if(headerIndex<0)return {error:L('Excel’de model başlığı bulunamadı.','No model header was found in the Excel file.')};
    const header=rows[headerIndex];
    const keyCol=findColumn(header,[/^bl key$/,/^bl row$/]),plmCol=findColumn(header,[/^plm id$/,/^plm$/]),modelCol=findColumn(header,[/^model name$/,/^model$/,/^model adi$/,/^model kodu$/]);
    let priceCol=findColumn(header,[/^(fob|quotation|offer|teklif|fiyat|price)( price| fiyati| fiyat)?( \(usd\)| usd| \$)?$/,/^supplier (fob|price)$/,/^üretici fiyati$/,/quotation price/]);
    if(priceCol<0)priceCol=header.findIndex(cell=>/price|fiyat|fob/i.test(clean(cell))&&!/target|hedef/i.test(clean(cell)));
    if(priceCol<0)return {error:L('Excel’de fiyat sütunu bulunamadı (ör. “Quotation Price”, “FOB”, “Fiyat”).','No price column was found (e.g. “Quotation Price”, “FOB”, “Price”).')};
    const manufacturers=[...new Set((req.items||[]).map(item=>clean(item.manufacturer)).filter(Boolean))];
    const hint=` ${foldName(manufacturerHint)} `;
    let manufacturer=manufacturers.find(name=>foldName(name)&&hint.includes(` ${foldName(name)} `))||'';
    if(!manufacturer&&manufacturers.length===1)manufacturer=manufacturers[0];
    const changes=[],unmatched=[],used=new Set();let same=0,invalid=0;
    const lower=value=>clean(value).toLocaleLowerCase('tr-TR');
    const own=(req.items||[]).filter(item=>clean(item.manufacturer)===manufacturer);
    rows.slice(headerIndex+1).forEach(row=>{
      const raw=clean(row[priceCol]);if(!raw)return;
      const value=E.price(raw);if(value==null){invalid++;return;}
      const key=keyCol>=0?clean(row[keyCol]):'',plm=plmCol>=0?clean(row[plmCol]):'',model=modelCol>=0?clean(row[modelCol]):'';
      /* Eşleme önceliği: satır anahtarı (BL Key) varsa YALNIZ ona bakılır; yoksa
         PLM ID, sonra model kodu. Aynı modelin birden çok renk satırı varsa PLM /
         model kodu belirsizdir: tek aday yoksa satır eşleşmemiş sayılır, bir
         talep satırına iki kez fiyat yazılmaz. */
      let candidates=key?own.filter(item=>String(item.rowId)===key):[];
      if(!key&&plm)candidates=own.filter(item=>lower(item.plmId)===lower(plm));
      if(!key&&!candidates.length&&model)candidates=own.filter(item=>lower(item.modelCode)===lower(model));
      const line=candidates.length===1&&!used.has(candidates[0].id)?candidates[0]:null;
      if(!line){unmatched.push(model||plm||key||'—');return;}
      used.add(line.id);
      const before=E.price(line.price);
      if(before!=null&&Math.abs(before-value)<0.00005){same++;return;}
      changes.push({line,before,value});
    });
    return {manufacturer,manufacturers,changes,unmatched,same,invalid};
  }
  const supplierReaders=new WeakMap();
  async function importSupplierWorkbook(host,req,file){
    const panel=host.querySelector('[data-pd-import-panel]');if(!panel)return;
    supplierReaders.get(host)?.abort();const reader=new AbortController();supplierReaders.set(host,reader);
    let rows;
    try{rows=await readWorkbookRows(file,{signal:reader.signal});}catch(err){if(err.code!=='FILE_PARSE_CANCELLED')toast(err?.message||L('Excel okunamadı.','Excel could not be read.'));return;}
    if(reader.signal.aborted||!host.isConnected||!panel.isConnected)return;
    let retryKeys=null;
    const render=manufacturerName=>{
      const plan=supplierWorkbookPlan(req,rows,manufacturerName||file.name);
      if(retryKeys&&plan.changes)plan.changes=plan.changes.filter(change=>retryKeys.has(change.line.id));
      if(plan.error){panel.innerHTML=`<div class="pdPanelHead"><b>${esc(file.name)}</b><span class="isBad">${esc(plan.error)}</span></div><div class="pdPanelActions"><button type="button" class="tbtn" data-pd-import-cancel>${esc(L('Kapat','Close'))}</button></div>`;}
      else{
        const picker=plan.manufacturers.length>1?`<label class="pdField isInline"><span>${esc(L('Üretici','Manufacturer'))}</span><select data-pd-import-mfr>${plan.manufacturers.map(name=>`<option value="${esc(name)}"${name===plan.manufacturer?' selected':''}>${esc(name)}</option>`).join('')}</select></label>`:'';
        panel.innerHTML=`<div class="pdPanelHead"><b>${esc(L('Dönüş Excel’i önizlemesi','Supplier Excel preview'))} · ${esc(file.name)}</b><span>${esc(L(`${plan.changes.length} değişiklik · ${plan.same} aynı · ${plan.unmatched.length} eşleşmeyen satır`,`${plan.changes.length} changes · ${plan.same} unchanged · ${plan.unmatched.length} unmatched rows`))}</span>${picker}</div>
          ${plan.manufacturer?'':`<div class="pdPanelNote isBad">${esc(L('Dosyanın hangi üreticiye ait olduğu seçilmeli.','Choose which manufacturer this file belongs to.'))}</div>`}
          <div class="pdPanelList">${plan.changes.map(change=>{const info=lineInfo(req,change.line);return `<div class="pdPanelRow">${thumbHtml(req,change.line,'pdThumb isSmall')}<b>${esc(info.model)}</b><span>${esc(change.line.manufacturer)}</span><s class="pdNum">${esc(change.before!=null?money(change.before):'—')}</s><b class="pdNum isGood">${esc(money(change.value))}</b></div>`;}).join('')||`<div class="pricingEmptyState">${esc(L('Uygulanacak yeni fiyat yok.','No new prices to apply.'))}</div>`}</div>
          ${plan.unmatched.length?`<div class="pdPanelNote">${esc(L('Eşleşmeyen: ','Unmatched: '))}${esc(plan.unmatched.slice(0,8).join(', '))}${plan.unmatched.length>8?'…':''}</div>`:''}
          <div class="pdPanelActions"><button type="button" class="tbtn" data-pd-import-cancel>${esc(L('Vazgeç','Cancel'))}</button><button type="button" class="tbtn primary" data-pd-import-apply ${plan.changes.length?'':'disabled'}>${esc(L(`${plan.changes.length} fiyatı uygula`,`Apply ${plan.changes.length} prices`))}</button></div>`;
        panel.querySelector('[data-pd-import-mfr]')?.addEventListener('change',event=>render(event.target.value));
        const previewUser=Q()?.currentUserId(),previewOwner=req.ownerId,baseline=new Map(plan.changes.map(change=>[change.line.id,JSON.stringify(change.line)]));
        panel.querySelector('[data-pd-import-apply]')?.addEventListener('click',async event=>{
          event.currentTarget.disabled=true;
          const api=Q(),items=plan.changes.map(change=>({key:change.line.id,label:lineInfo(req,change.line).model+' · '+change.line.manufacturer,before:change.before==null?'—':money(change.before),after:money(change.value)}));
          const guard=()=>!reader.signal.aborted&&api.currentUserId()===previewUser&&api.canEdit(req)&&req.ownerId===previewOwner&&plan.changes.every(change=>JSON.stringify(api.requests().find(item=>item.id===req.id)?.items.find(item=>item.id===change.line.id))===baseline.get(change.line.id));
          const spec={module:'supplier-prices',owner:previewOwner,items,expected:{lines:Object.fromEntries(plan.changes.map(change=>[change.line.id,change.line.rev||0]))},title:L('Üretici fiyatlarını kaydet','Save supplier prices'),counts:{skipped:plan.unmatched.length,invalid:plan.invalid,readonly:api.canEdit(req)?0:items.length},guard,
            async send(){
              const entries=plan.changes.map(change=>({lineId:change.line.id,prev:snapshot(change.line)}));
              const data=await api.applyPricesBatch(req.id,plan.changes.map(change=>({lineId:change.line.id,baseRev:change.line.rev||0,price:moneyPlain(change.value)})));
              state.undo.push({requestId:req.id,entries,label:'import',bulkGuard:{user:previewUser,owner:previewOwner,revisions:Object.fromEntries((data.request?.items||[]).map(item=>[item.id,item.rev||0]))}});
              panel.hidden=true;api.renderDetail();return data;
            },
            async retry(keys){await api.hydrate(true);if(reader.signal.aborted)return null;const current=api.requests().find(item=>item.id===req.id);if(current){req=current;retryKeys=new Set(keys);render(plan.manufacturer);}return null;}
          };
          await window.BLBulkOperations.run(spec);
          if(panel.isConnected)panel.querySelector('[data-pd-import-apply]')?.removeAttribute('disabled');
        });
      }
      panel.querySelector('[data-pd-import-cancel]')?.addEventListener('click',()=>{reader.abort();panel.hidden=true;});
      panel.hidden=false;bindThumbs(panel);
    };
    render('');
  }

  /* ================= SHELL ================= */
  const TAB_LABELS={desk:['Masa','Desk'],rounds:['Turlar','Rounds'],history:['Geçmiş','History'],analysis:['Analiz','Analysis']};
  const TAB_ICONS={desk:'i-table',rounds:'i-layout-dashboard',history:'i-chart-histogram',analysis:'i-chart-bar'};
  function shellHtml(tab){
    return `<div class="pdShell">
      <div class="pdTopBar">
        <nav class="pdTabs" role="tablist" aria-label="${esc(L('Fiyat Masası','Pricing Desk'))}">${TABS.map(key=>`<button type="button" role="tab" data-pd-tab="${key}" aria-selected="${key===tab?'true':'false'}" class="${key===tab?'isActive':''}"><svg class="ic" aria-hidden="true"><use href="#${TAB_ICONS[key]}"/></svg>${esc(L(...TAB_LABELS[key]))}</button>`).join('')}</nav>
        <span class="pdBarSpacer"></span>
        <div class="pdScope"><button type="button" class="tbtn" data-pd-scope aria-haspopup="dialog"><svg class="ic" aria-hidden="true"><use href="#i-users-group"/></svg><span>${esc(L('Buyer','Buyer'))}:</span> <b>${esc(scopeLabel())}</b><svg class="ic" aria-hidden="true"><use href="#i-chevron-down"/></svg></button><div class="pdScopePanel" data-pd-scope-panel hidden></div></div>
      </div>
      <div class="pdBody" data-pd-body></div>
    </div>`;
  }
  function scopePanelHtml(){
    const owners=availableOwners(),ids=scopeOwnerIds();
    return `<div class="pdPanelHead"><b>${esc(L('Buyer kapsamı','Buyer scope'))}</b><span>${esc(L('Yetkiniz olan buyer’ların fiyat çalışmalarını tek ekranda birlikte görün. Düzenleme yetkisi değişmez.','See the pricing work of buyers you have access to on one screen. Editing rights do not change.'))}</span></div>
      <label class="pdCheck"><input type="checkbox" data-pd-scope-all ${state.scope.all?'checked':''}><span>${esc(L('Tüm erişilebilir buyer’lar','All accessible buyers'))}</span></label>
      <div class="pdScopeList">${owners.map(owner=>`<label class="pdCheck"><input type="checkbox" value="${esc(owner.id)}" data-pd-scope-owner ${state.scope.all||ids.has(owner.id)?'checked':''} ${state.scope.all?'disabled':''}><span>${esc(owner.name)}</span><small>${esc(L(`${owner.count} talep`,`${owner.count} requests`))}</small></label>`).join('')}</div>
      <div class="pdPanelActions"><button type="button" class="tbtn" data-pd-scope-mine>${esc(L('Yalnız ben','Only me'))}</button><button type="button" class="tbtn primary" data-pd-scope-apply>${esc(L('Uygula','Apply'))}</button></div>`;
  }
  function bindShell(host){
    host.querySelectorAll('[data-pd-tab]').forEach(button=>button.addEventListener('click',()=>{Q()?.commitActive?.(host);openTab(button.dataset.pdTab);}));
    const panel=host.querySelector('[data-pd-scope-panel]'),toggle=host.querySelector('[data-pd-scope]');
    toggle?.addEventListener('click',event=>{
      event.stopPropagation();
      if(!panel.hidden){panel.hidden=true;return;}
      panel.innerHTML=scopePanelHtml();panel.hidden=false;
      const all=panel.querySelector('[data-pd-scope-all]');
      all?.addEventListener('change',()=>panel.querySelectorAll('[data-pd-scope-owner]').forEach(box=>{box.disabled=all.checked;if(all.checked)box.checked=true;}));
      panel.querySelector('[data-pd-scope-mine]')?.addEventListener('click',()=>{panel.hidden=true;setScope({all:false,ownerIds:[me()]});});
      panel.querySelector('[data-pd-scope-apply]')?.addEventListener('click',()=>{
        const ids=[...panel.querySelectorAll('[data-pd-scope-owner]:checked')].map(box=>box.value);
        panel.hidden=true;setScope({all:!!all?.checked,ownerIds:ids.length?ids:[me()]});
      });
    });
  }
  // Kapsam paneli dışına tıklanınca kapanır (tek, kalıcı dinleyici).
  document.addEventListener('mousedown',event=>{
    document.querySelectorAll('[data-pd-scope-panel]').forEach(panel=>{
      if(panel.hidden)return;
      const scope=panel.closest('.pdScope');
      if(scope&&!scope.contains(event.target))panel.hidden=true;
    });
  },{capture:true});
  async function mount(host,{tab}={}){
    const api=Q();if(!host||!api)return false;
    await api.ready();await api.hydrate(true);
    if(tab&&TABS.includes(tab))state.tab=tab;
    state.hosts.add(host);host.dataset.pdMounted='1';
    renderHost(host);
    void loadOwnerRows().then(changed=>{if(changed)renderHost(host);});
    return true;
  }
  function renderHost(host){
    if(!host||!host.isConnected)return;
    infoCache=new WeakMap();
    host.innerHTML=shellHtml(state.tab);
    bindShell(host);
    const body=host.querySelector('[data-pd-body]');
    body.classList.add('pdViewIn');
    // Klavyeyle seçilebilen kartlar/hücreler (role=button, tabindex=0) Enter/Space ile açılır.
    body.addEventListener('keydown',event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches?.('[data-pd-acell],[data-pd-asupplier],[data-pd-req]')){event.preventDefault();event.target.click();}});
    if(state.tab==='desk')void Q().mountWorkspace(body,{source:'collection',preserveContext:true});
    else if(state.tab==='rounds')renderRounds(body);
    else if(state.tab==='history')renderHistory(body);
    else renderAnalysis(body);
  }
  function renderAllHosts(){[...state.hosts].forEach(host=>{if(!host.isConnected){state.hosts.delete(host);return;}if(host.offsetParent!==null||host.closest('section')?.classList.contains('active'))renderHost(host);});}
  function openTab(tab,options={}){
    if(!TABS.includes(tab))return;
    state.tab=tab;store.set(TAB_KEY,tab);
    if(tab==='history'&&options.query!=null){state.history.query=clean(options.query);state.history.view='models';store.set(HISTORY_KEY,historyPrefs());}
    const active=typeof currentActiveTab==='function'?currentActiveTab():document.body?.dataset?.activeTab;
    if(active!=='quotations'&&active!=='pricinghistory'&&typeof switchTab==='function'){switchTab('quotations');return;}
    renderAllHosts();
  }

  /* ================= TURLAR ================= */
  const LANES=[['sent','Gönderildi','Sent'],['waiting','Teklif bekleniyor','Awaiting quotes'],['compare','Karşılaştırma','Comparing'],['approved','Onaylandı','Approved'],['closed','Kapandı','Closed']];
  function renderRounds(body){
    const api=Q(),requests=scopedRequests('collection').slice().sort((a,b)=>String(b.updatedAt||b.createdAt).localeCompare(String(a.updatedAt||a.createdAt)));
    const multi=scopeIsMulti();
    if(!state.roundsSelected||!requests.some(req=>req.id===state.roundsSelected))state.roundsSelected=requests.find(req=>E.lane(req)==='compare')?.id||requests[0]?.id||'';
    const lanes=LANES.map(([key,tr,en])=>{
      const list=requests.filter(req=>E.lane(req)===key);
      return `<section class="pdLane" data-lane="${key}"><div class="pdLaneHead"><b>${esc(L(tr,en))}</b><span>${list.length}</span></div><div class="pdLaneBody">${list.slice(0,key==='closed'?12:40).map(req=>roundCardHtml(req,multi)).join('')||`<div class="pdLaneEmpty">${esc(L('Kayıt yok','No records'))}</div>`}${key==='closed'&&list.length>12?`<div class="pdLaneEmpty">${esc(L(`+${list.length-12} kapalı talep`,`+${list.length-12} closed requests`))}</div>`:''}</div></section>`;
    }).join('');
    const selected=requests.find(req=>req.id===state.roundsSelected)||null;
    body.innerHTML=`<div class="pdRoundsGrid"><div class="pdBoard">${lanes}</div><aside class="pdRoundsPanel" aria-live="polite">${selected?roundsPanelHtml(selected):`<div class="pricingEmptyState">${esc(L('Kapsamda fiyat talebi yok.','No pricing requests in scope.'))}</div>`}</aside></div>`;
    body.querySelectorAll('[data-pd-req]').forEach(card=>card.addEventListener('click',event=>{if(event.target.closest('[data-pd-remind]'))return;state.roundsSelected=card.dataset.pdReq;renderRounds(body);}));
    body.querySelectorAll('[data-pd-remind]').forEach(button=>button.addEventListener('click',event=>{event.stopPropagation();const req=api.requests().find(item=>item.id===button.dataset.pdRemind);if(req)api.reminder(req);}));
    body.querySelector('[data-pd-open-desk]')?.addEventListener('click',event=>{api.selectRequest(event.currentTarget.dataset.pdOpenDesk);api.setStatusFilter('all');openTab('desk');});
    body.querySelector('[data-pd-new-round]')?.addEventListener('click',async event=>{const req=api.requests().find(item=>item.id===event.currentTarget.dataset.pdNewRound);if(!req)return;event.currentTarget.disabled=true;const saved=await api.startRound(req,'');if(saved){toast(L(`Tur ${saved.round} başladı.`,`Round ${saved.round} started.`));renderRounds(body);}});
    bindThumbs(body);
  }
  function roundCardHtml(req,multi){
    const api=Q(),rates=E.responseRates(req),priced=rates.reduce((a,r)=>a+r.priced,0),total=rates.reduce((a,r)=>a+r.total,0),rate=total?Math.round(priced/total*100):0;
    const waiting=rates.filter(r=>r.priced<r.total).length,gain=E.requestGain(req),models=E.requestMatrix(req).models.length,round=Math.max(1,Number(req.round)||1);
    const canEdit=api.canEdit(req);
    return `<div role="button" tabindex="0" class="pdCard${req.id===state.roundsSelected?' isActive':''}" data-pd-req="${esc(req.id)}">
      <div class="pdCardHead"><div><b title="${esc(api.workspaceTitle(req))}">${esc(api.workspaceTitle(req))}</b><span>${esc(api.date(req.createdAt,false))} · ${esc(L(`${models} model`,`${models} models`))}${round>1?` · ${esc(L(`Tur ${round}`,`Round ${round}`))}`:''}</span></div><span class="pdRing isLarge" style="--pd-rate:${rate}%" title="${esc(L(`${priced}/${total} satır fiyatlı`,`${priced}/${total} lines priced`))}" aria-hidden="true"></span></div>
      ${multi||clean(req.ownerId)!==me()?`<span class="pdOwnerChip">${esc(api.ownerLabel(req))}</span>`:''}
      <div class="pdCardChips">${rates.slice(0,6).map(r=>`<span class="pdMiniChip${r.approved?' isApproved':r.priced===r.total?' isDone':r.priced?' isPartial':''}" title="${esc(r.name)}">${esc(r.name.length>14?r.name.slice(0,13)+'…':r.name)} ${r.priced}/${r.total}</span>`).join('')}</div>
      <div class="pdCardFoot">${gain&&Number.isFinite(gain.gainPct)&&Math.abs(gain.gainPct)>=0.05?`<span class="pdChip ${toneOf(gain.gainPct)}">${esc(L('Pazarlık','Negotiation'))} ${esc(pctText(gain.gainPct))}</span>`:'<span></span>'}${canEdit&&waiting&&req.status!=='closed'?`<button type="button" class="tbtn sm" data-pd-remind="${esc(req.id)}"><svg class="ic" aria-hidden="true"><use href="#i-bell"/></svg>${esc(L(`Hatırlat (${waiting})`,`Remind (${waiting})`))}</button>`:''}</div>
    </div>`;
  }
  function roundOffersHtml(req,round,byLine){
    const groups=new Map();
    round.offers.forEach(offer=>{const line=byLine.get(offer.lineId),key=line?.modelKey||offer.lineId;if(!groups.has(key))groups.set(key,{line,offers:[]});groups.get(key).offers.push(offer);});
    return [...groups.values()].map(({line,offers})=>{const info=line?lineInfo(req,line):{model:'—'},prices=offers.map(o=>o.price).filter(Number.isFinite),best=prices.length?Math.min(...prices):null;
      return `<div class="pdRoundModelGroup"><div class="pdRoundModelHead">${line?thumbHtml(req,line,'pdThumb isSmall'):''}<b>${esc(info.model)}</b><span>${esc(L('En iyi','Best'))} ${esc(money(best))}</span></div><div class="pdRoundChips">${offers.map(offer=>{const change=offer.previous!=null&&offer.price!=null?E.pct(offer.price,offer.previous):null;return `<span class="pdRoundQuote${offer.price===best?' isBest':''}" title="${esc(change==null?'':pctText(change))}"><b>${esc(offer.manufacturer)}</b>${offer.previous!=null?`<s>${esc(moneyPlain(offer.previous))}</s>`:''}<strong>${offer.price!=null?esc(money(offer.price)):esc(L('geri çekildi','withdrawn'))}</strong>${change!=null?`<small class="${toneOf(change)}">${esc(pctText(change))}</small>`:''}</span>`;}).join('')}</div></div>`;
    }).join('')||`<div class="pdLaneEmpty">${esc(L('Bu turda henüz teklif yok.','No offers in this round yet.'))}</div>`;
  }
  function roundsPanelHtml(req){
    const api=Q(),rounds=E.rounds(req),gain=E.requestGain(req),byLine=new Map((req.items||[]).map(item=>[item.id,item]));
    const list=rounds.slice().reverse().map(round=>`<div class="pdRound">
      <div class="pdRoundHead"><i class="pdRoundDot${round.n===Math.max(1,Number(req.round)||1)?' isCurrent':''}" aria-hidden="true"></i><b>${esc(L(`Tur ${round.n}`,`Round ${round.n}`))}</b><span>${esc(round.at?dateText(round.at):'')}${round.byName?` · ${esc(round.byName)}`:''}</span></div>
      ${round.note?`<div class="pdRoundNote">${esc(round.note)}</div>`:''}
      <div class="pdRoundOffers">${roundOffersHtml(req,round,byLine)}</div>
    </div>`).join('');
    return `<div class="pdPanelHead"><b>${esc(api.workspaceTitle(req))}</b><span>${esc(api.ownerLabel(req))} · ${esc(api.date(req.createdAt,false))}</span></div>
      ${gain?`<div class="pdGain"><div><span>${esc(L('İlk tur ort. en iyi','First-round avg best'))}</span><b>${esc(money(gain.firstAvg))}</b></div><div><span>${esc(L('Güncel ort.','Current avg'))}</span><b>${esc(money(gain.currentAvg))}</b></div><div><span>${esc(L('Kazanım','Gain'))}</span><b class="${toneOf(gain.gainPct)}">${esc(pctText(gain.gainPct))}</b></div></div>`:''}
      <div class="pdPanelActions"><button type="button" class="tbtn primary" data-pd-open-desk="${esc(req.id)}"><svg class="ic" aria-hidden="true"><use href="#i-table"/></svg>${esc(L('Masada aç','Open in Desk'))}</button>${api.canEdit(req)&&req.status!=='closed'?`<button type="button" class="tbtn" data-pd-new-round="${esc(req.id)}"><svg class="ic" aria-hidden="true"><use href="#i-refresh"/></svg>${esc(L('Yeni tur başlat','Start new round'))}</button>`:''}</div>
      <div class="pdRoundList">${list}</div>`;
  }

  /* ================= GEÇMİŞ ================= */
  function historyPrefs(){return {view:state.history.view,query:state.history.query,filters:state.history.filters,limit:48};}
  /* Koleksiyon'dan "Fiyat Geçmişi" ile açıldığında yalnız seçili modeller gösterilir. */
  function setHistoryContext(rows){
    const loadedOwner=typeof kolWorkspaceOwnerId!=='undefined'?clean(kolWorkspaceOwnerId):me();
    const keys=(Array.isArray(rows)?rows:[]).filter(Boolean).map(row=>`${clean(row._collectionOwnerId)||loadedOwner}|kol:${row._collectionSourceId??row.id}`);
    state.history.context=keys.length?keys:null;state.history.view='models';state.history.query='';state.history.selected=keys.length===1?keys[0]:'';
    state.tab='history';
  }
  function historyEvents(){
    const out=[],context=Array.isArray(state.history.context)&&state.history.context.length?new Set(state.history.context):null;
    scopedRequests('collection').forEach(req=>(req.items||[]).forEach(line=>{
      if(line.dropped)return;
      if(context&&!context.has(`${clean(req.ownerId)}|${clean(line.modelKey)}`))return;
      const info=lineInfo(req,line);
      E.offers(line,req).forEach(event=>{
        if(event.value==null)return;
        out.push({identityKey:`${clean(req.ownerId)}|${clean(line.modelKey)}`,modelKey:line.modelKey,model:info.model,plmId:info.plmId,image:info.image,colourCode:info.colourCode,colour:info.colour,manufacturer:clean(line.manufacturer),value:event.value,at:event.at,round:event.round||1,approved:!!line.approved,target:info.target,
          classification:info.classification,season:info.season||'—',buyer:info.buyer,requestId:req.id,itemId:line.id,byName:clean(event.byName),source:event.source||'manual',req,line});
      });
    }));
    return out;
  }
  const SERIES_CLASSES=['pdS0','pdS1','pdS2','pdS3','pdS4','pdS5'];
  function seriesChart(model){
    const all=model.series.flatMap(entry=>entry.points);
    const times=all.map(point=>Date.parse(point.at)).filter(Number.isFinite);
    const values=all.map(point=>point.value).concat(model.target!=null?[model.target]:[]);
    let lo=Math.min(...values),hi=Math.max(...values);if(hi-lo<0.01){lo-=0.5;hi+=0.5;}
    const pad=(hi-lo)*0.12;lo-=pad;hi+=pad;
    const t0=Math.min(...times),t1=Math.max(...times),W=300,H=96,P=8;
    const x=at=>{const t=Date.parse(at);return t1>t0?P+(t-t0)/(t1-t0)*(W-2*P):W/2;};
    const y=v=>H-P-(v-lo)/(hi-lo)*(H-2*P);
    const lines=model.series.map((entry,index)=>{
      const cls=SERIES_CLASSES[index%SERIES_CLASSES.length],pts=entry.points.map(point=>`${x(point.at).toFixed(1)},${y(point.value).toFixed(1)}`).join(' ');
      const last=entry.points[entry.points.length-1];
      return `<polyline class="pdSeries ${cls}" points="${pts}"/>${entry.points.map(point=>`<rect class="pdDot ${cls}" x="${(x(point.at)-(point===last?3.4:2.2)).toFixed(1)}" y="${(y(point.value)-(point===last?3.4:2.2)).toFixed(1)}" width="${point===last?6.8:4.4}" height="${point===last?6.8:4.4}"><title>${esc(`${entry.manufacturer} · ${dateText(point.at)} · ${money(point.value)} · ${L('Tur','Round')} ${point.round}`)}</title></rect>`).join('')}`;
    }).join('');
    const target=model.target!=null?`<line class="pdTargetLine" x1="0" x2="${W}" y1="${y(model.target).toFixed(1)}" y2="${y(model.target).toFixed(1)}"/>`:'';
    return `<svg class="pdChart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(L(`${model.model} fiyat trendi`,`${model.model} price trend`))}">${target}${lines}</svg>`;
  }
  function renderHistory(body){
    const view=state.history.view==='records'?'records':'models';
    body.innerHTML=`<div class="pdHistory"><div class="pdSubBar"><div class="pdSeg" role="group" aria-label="${esc(L('Geçmiş görünümü','History view'))}"><button type="button" data-pd-hview="models" class="${view==='models'?'isActive':''}" aria-pressed="${view==='models'}">${esc(L('Modeller','Models'))}</button><button type="button" data-pd-hview="records" class="${view==='records'?'isActive':''}" aria-pressed="${view==='records'}">${esc(L('Kayıt tablosu','Records table'))}</button></div><div class="pdSubTools" data-pd-htools></div></div><div class="pdHistoryBody" data-pd-hbody></div></div>`;
    body.querySelectorAll('[data-pd-hview]').forEach(button=>button.addEventListener('click',()=>{state.history.view=button.dataset.pdHview;store.set(HISTORY_KEY,historyPrefs());renderHistory(body);}));
    const host=body.querySelector('[data-pd-hbody]');
    if(view==='records'){void Q().mountHistoryTable(host,{preserveContext:true});return;}
    renderHistoryModels(body,host);
  }
  function renderHistoryModels(body,host){
    const events=historyEvents(),tools=body.querySelector('[data-pd-htools]');
    const dims=[['classification','Klasman','Classification'],['manufacturer','Üretici','Manufacturer'],['season','Sezon','Season'],...(scopeIsMulti()?[['buyer','Buyer','Buyer']]:[])];
    const filters=state.history.filters||{};
    const contextCount=Array.isArray(state.history.context)?state.history.context.length:0;
    tools.innerHTML=`${contextCount?`<span class="pdContextChip">${esc(L(`Koleksiyon seçimi: ${contextCount} model`,`Collection selection: ${contextCount} models`))}<button type="button" class="linkBtn" data-pd-hcontext-clear>${esc(L('Tümünü göster','Show all'))}</button></span>`:''}<label class="pdSearch"><svg class="ic" aria-hidden="true"><use href="#i-search"/></svg><span class="pdSr">${esc(L('Model ara','Search model'))}</span><input type="search" data-pd-hsearch value="${esc(state.history.query)}" placeholder="${esc(L('Model, PLM ID veya üretici ara…','Search model, PLM ID or manufacturer…'))}"></label>${dims.map(([dim,tr,en])=>`<label class="pdField isInline"><span class="pdSr">${esc(L(tr,en))}</span><select data-pd-hfilter="${dim}"><option value="">${esc(L(`Tüm ${tr.toLocaleLowerCase('tr-TR')}`,`All ${en.toLowerCase()}`))}</option>${E.dimensionValues(events,dim).map(item=>`<option value="${esc(item.label)}"${(filters[dim]||[])[0]===item.label?' selected':''}>${esc(item.label)}</option>`).join('')}</select></label>`).join('')}`;
    const query=clean(state.history.query).toLocaleLowerCase('tr-TR');
    const filtered=E.filterObservations(events,filters).filter(event=>!query||`${event.model} ${event.plmId} ${event.manufacturer} ${event.classification}`.toLocaleLowerCase('tr-TR').includes(query));
    const series=E.historySeries(filtered);
    const limit=Math.max(12,Number(state.history.limit)||48);
    const selected=series.find(model=>model.identityKey===state.history.selected)||null;
    const totalModels=series.length,rounds=new Set(filtered.map(event=>`${event.requestId}|${event.round}`)).size;
    const improving=series.filter(model=>Number.isFinite(model.trendPct)&&model.trendPct<0);
    host.innerHTML=`<div class="pdKpis"><div class="pricingMetric isHistory"><span>${esc(L('Model','Models'))}</span><b>${totalModels}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Teklif olayı','Offer events'))}</span><b>${filtered.length}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Tur','Rounds'))}</span><b>${rounds}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Pazarlıkla düşen','Lowered by negotiation'))}</span><b>${improving.length}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Ort. tur kazancı','Avg negotiation gain'))}</span><b>${esc(pctText(E.mean(improving.map(model=>model.trendPct))))}</b></div></div>
      <div class="pdHistoryGrid"><div class="pdCards">${series.slice(0,limit).map((model,index)=>historyCardHtml(model,index)).join('')||`<div class="pricingEmptyState">${esc(L('Bu filtrelerde fiyat geçmişi yok.','No pricing history for these filters.'))}</div>`}${series.length>limit?`<button type="button" class="tbtn pdMore" data-pd-more>${esc(L(`${series.length-limit} model daha göster`,`Show ${series.length-limit} more models`))}</button>`:''}</div>
      <aside class="pdHistoryDetail" aria-live="polite">${selected?historyDetailHtml(selected):`<div class="pricingEmptyState">${esc(L('Ayrıntı ve tur kayıtları için bir model kartı seç.','Select a model card for details and round records.'))}</div>`}</aside></div>`;
    tools.querySelector('[data-pd-hcontext-clear]')?.addEventListener('click',()=>{state.history.context=null;renderHistoryModels(body,host);});
    tools.querySelector('[data-pd-hsearch]')?.addEventListener('input',event=>{state.history.query=event.target.value;clearTimeout(renderHistoryModels._t);renderHistoryModels._t=setTimeout(()=>{store.set(HISTORY_KEY,historyPrefs());renderHistoryModels(body,host);const input=body.querySelector('[data-pd-hsearch]');if(input){input.focus();input.setSelectionRange(input.value.length,input.value.length);}},160);});
    tools.querySelectorAll('[data-pd-hfilter]').forEach(select=>select.addEventListener('change',()=>{const next={...(state.history.filters||{})};if(select.value)next[select.dataset.pdHfilter]=[select.value];else delete next[select.dataset.pdHfilter];state.history.filters=next;store.set(HISTORY_KEY,historyPrefs());renderHistoryModels(body,host);}));
    host.querySelectorAll('[data-pd-hcard]').forEach(card=>card.addEventListener('click',()=>{state.history.selected=card.dataset.pdHcard;renderHistoryModels(body,host);}));
    host.querySelector('[data-pd-more]')?.addEventListener('click',()=>{state.history.limit=limit+48;renderHistoryModels(body,host);});
    host.querySelector('[data-pd-benchmark]')?.addEventListener('click',event=>{const event0=filtered.find(item=>`${item.requestId}:${item.itemId}`===event.currentTarget.dataset.pdBenchmark);if(event0)Q().applyBenchmark({requestId:event0.requestId,itemId:event0.itemId,price:event0.value,model:event0.model});});
    host.querySelectorAll('[data-pd-open-req]').forEach(button=>button.addEventListener('click',()=>{const api=Q();api.selectRequest(button.dataset.pdOpenReq);api.setStatusFilter('all');openTab('desk');}));
    bindThumbs(host);
  }
  function historyCardHtml(model,index){
    const first=model.events[0],req=first.req,line=first.line;
    const legend=model.series.map((entry,i)=>{const last=entry.points[entry.points.length-1];return `<span class="pdLegendItem"><i class="${SERIES_CLASSES[i%SERIES_CLASSES.length]}"></i>${esc(entry.manufacturer)} <b>${esc(moneyPlain(last.value))}</b></span>`;}).join('');
    return `<button type="button" class="pdHCard${model.identityKey===state.history.selected?' isActive':''}" data-pd-hcard="${esc(model.identityKey)}" style="--pd-delay:${Math.min(index,16)*30}ms">
      <div class="pdHCardHead">${thumbHtml(req,line)}<div class="pdHCardText"><b>${esc(model.model)}</b><span>${esc(first.classification)}${scopeIsMulti()?` · ${esc(first.buyer)}`:''}</span></div><div class="pdHCardValue"><b>${esc(money(model.latestBest))}</b><span class="pdChip ${toneOf(model.trendPct)}">${esc(pctText(model.trendPct))}</span></div></div>
      ${seriesChart(model)}
      <div class="pdLegendRow">${legend}${model.target!=null?`<span class="pdLegendItem isTarget"><i></i>${esc(L('Hedef','Target'))} <b>${esc(moneyPlain(model.target))}</b></span>`:''}</div>
    </button>`;
  }
  function historyDetailHtml(model){
    const first=model.events[0],events=model.events.slice().sort((a,b)=>String(b.at).localeCompare(String(a.at)));
    const latestBest=events.filter(event=>event.value===model.latestBest)[0];
    return `<div class="pdPanelHead"><div class="pdHDetailHead">${thumbHtml(first.req,first.line,'pdThumb isLarge')}<div><b>${esc(model.model)}</b><span>${esc(first.classification)} · ${esc(first.season)}</span><span>${esc(first.buyer)}</span></div></div></div>
      <dl class="pricingDecisionStats"><div><dt>${esc(L('İlk tur en iyi','First-round best'))}</dt><dd>${esc(money(model.firstBest))}</dd></div><div><dt>${esc(L('Güncel en iyi','Current best'))}</dt><dd>${esc(money(model.latestBest))}</dd></div><div><dt>${esc(L('Değişim','Change'))}</dt><dd class="${toneOf(model.trendPct)}">${esc(pctText(model.trendPct))}</dd></div><div><dt>${esc(L('Hedef','Target'))}</dt><dd>${esc(money(model.target))}</dd></div></dl>
      <div class="pdPanelActions">${latestBest?`<button type="button" class="tbtn" data-pd-benchmark="${esc(`${latestBest.requestId}:${latestBest.itemId}`)}">${esc(L('Hedef fiyat olarak uygula','Apply as Target Price'))}</button>`:''}</div>
      <div class="pdEventList">${events.map(event=>`<div class="pdEvent"><span class="pdEventDate">${esc(dateText(event.at))}</span><span><b>${esc(event.manufacturer)}</b><small>${esc(L(`Tur ${event.round}`,`Round ${event.round}`))}${event.byName?` · ${esc(event.byName)}`:''}${event.source&&event.source!=='manual'?` · ${esc(sourceLabel(event.source))}`:''}</small></span><b class="pdNum">${esc(money(event.value))}</b><button type="button" class="linkBtn" data-pd-open-req="${esc(event.requestId)}">${esc(L('Talep','Request'))}</button></div>`).join('')}</div>`;
  }
  function sourceLabel(source){return ({undo:L('geri alma','undo'),matrix:L('matris','matrix'),paste:L('yapıştırma','paste'),import:L('dönüş Excel’i','supplier Excel'),bulk:L('toplu onay','bulk approval'),legacy:L('eski kayıt','legacy record'),exclusive:L('tek onay kuralı','single approval rule'),ai:'LCW AI',collection:L('Koleksiyon','Collection')})[source]||source;}

  /* ================= ANALİZ ================= */
  const GROUP_LABELS={classification:['Klasman','Classification'],mag:['MAG','MAG'],mmyg:['MMYG','MMYG'],buyingGroup:['Buying Group','Buying Group'],buyer:['Buyer','Buyer'],productMainDefinition:['Ürün Ana Tanım','Product Main Definition'],season:['Sezon','Season'],license:['Lisans','License']};
  const FILTER_DIMS=['season','classification','manufacturer','buyer','mag','mmyg','buyingGroup'];
  const BASIS=[['latest','Son teklif','Latest offer'],['first','İlk tur teklifi','First-round offer'],['approved','Yalnız onaylı','Approved only']];
  function analysisObservations(){
    const basis=state.analysis.basis,out=[];
    scopedRequests('collection').forEach(req=>(req.items||[]).forEach(line=>{
      if(line.dropped)return;
      if(basis==='approved'&&!line.approved)return;
      let value=E.price(line.price);
      if(basis==='first'){const list=E.offers(line,req).filter(event=>event.value!=null);value=list.length?list[0].value:null;}
      if(value==null)return;
      const info=lineInfo(req,line);
      out.push({identityKey:`${clean(req.ownerId)}|${clean(line.modelKey)}`,modelKey:line.modelKey,model:info.model,plmId:info.plmId,manufacturer:clean(line.manufacturer),value,approved:!!line.approved,
        classification:info.classification,mag:info.mag||'—',mmyg:info.mmyg||'—',buyingGroup:info.buyingGroup||'—',buyer:info.buyer||'—',season:info.season||'—',license:info.license||'—',productMainDefinition:info.productMainDefinition||'—',
        target:info.target,requestId:req.id,itemId:line.id,req,line});
    }));
    return out;
  }
  function analysisPrefs(){return {groupBy:state.analysis.groupBy,basis:state.analysis.basis,view:state.analysis.view,filters:state.analysis.filters,allSuppliers:state.analysis.allSuppliers};}
  function heatClass(index){if(!Number.isFinite(index))return '';if(index<=-8)return 'isHeat-3';if(index<=-3)return 'isHeat-2';if(index<0)return 'isHeat-1';if(index>=8)return 'isHeat3';if(index>=3)return 'isHeat2';if(index>0)return 'isHeat1';return '';}
  function renderAnalysis(body){
    const observations=analysisObservations(),a=state.analysis;
    const result=E.analyze(observations,{groupBy:a.groupBy,filters:a.filters});
    const multi=scopeIsMulti();
    const views=[['matrix','Klasman × Üretici','Group × Manufacturer'],['scorecard','Üretici karnesi','Manufacturer scorecard'],...(multi?[['buyers','Buyer karşılaştırması','Buyer comparison']]:[])];
    const view=views.some(item=>item[0]===a.view)?a.view:'matrix';
    const filterChips=FILTER_DIMS.filter(dim=>dim!=='buyer'||multi).map(dim=>{
      const values=E.dimensionValues(observations,dim),chosen=new Set((a.filters[dim]||[]).map(E.keyOf));
      const label=dim==='manufacturer'?L('Üretici','Manufacturer'):L(...(GROUP_LABELS[dim]||[dim,dim]));
      return `<details class="pdFilter${chosen.size?' isOn':''}"><summary>${esc(label)}${chosen.size?` <b>${chosen.size}</b>`:''}<svg class="ic" aria-hidden="true"><use href="#i-chevron-down"/></svg></summary><div class="pdFilterList blMotionOverlay"><div class="cfpHeader"><button type="button" class="cfpAll" data-pd-abulk="all" data-pd-adim="${dim}">${esc(L('Tümünü seç','Select all'))}</button><button type="button" class="cfpAll" data-pd-abulk="clear" data-pd-adim="${dim}">${esc(L('Temizle','Clear'))}</button></div>${values.map(item=>`<label class="pdCheck"><input type="checkbox" data-pd-afilter="${dim}" value="${esc(item.label)}" ${chosen.has(item.key)?'checked':''}><span>${esc(item.label)}</span><small>${item.count}</small></label>`).join('')||`<span class="pdLaneEmpty">${esc(L('Değer yok','No values'))}</span>`}</div></details>`;
    }).join('');
    const spread=result.groups.filter(group=>Number.isFinite(group.spreadPct)).sort((x,y)=>y.spreadPct-x.spreadPct)[0];
    body.innerHTML=`<div class="pdAnalysis">
      <div class="pdSubBar">
        <label class="pdField isInline"><span>${esc(L('Kırılım','Group by'))}</span><select data-pd-agroup>${Object.keys(GROUP_LABELS).filter(key=>key!=='buyer'||multi).map(key=>`<option value="${key}"${a.groupBy===key?' selected':''}>${esc(L(...GROUP_LABELS[key]))}</option>`).join('')}</select></label>
        <label class="pdField isInline"><span>${esc(L('Fiyat','Price'))}</span><select data-pd-abasis>${BASIS.map(([key,tr,en])=>`<option value="${key}"${a.basis===key?' selected':''}>${esc(L(tr,en))}</option>`).join('')}</select></label>
        <div class="pdFilters">${filterChips}</div>
        ${Object.values(a.filters||{}).some(list=>list&&list.length)?`<button type="button" class="linkBtn" data-pd-aclear>${esc(L('Filtreleri temizle','Clear filters'))}</button>`:''}
        <span class="pdBarSpacer"></span>
        <div class="pdSeg" role="group" aria-label="${esc(L('Analiz görünümü','Analysis view'))}">${views.map(([key,tr,en])=>`<button type="button" data-pd-aview="${key}" class="${view===key?'isActive':''}" aria-pressed="${view===key}">${esc(L(tr,en))}</button>`).join('')}</div>
      </div>
      <div class="pdKpis"><div class="pricingMetric isHistory"><span>${esc(L('Model','Models'))}</span><b>${result.models}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Teklif','Offers'))}</span><b>${result.count}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Üretici','Manufacturers'))}</span><b>${result.suppliers.length}</b></div><div class="pricingMetric isHistory"><span>${esc(L('Ortalama','Average'))}</span><b>${esc(money(result.avg))}</b></div><div class="pricingMetric isHistory"><span>${esc(L('En geniş yayılım','Widest spread'))}</span><b title="${esc(spread?spread.label:'')}">${spread?esc(`${pctText(spread.spreadPct)} · ${spread.label}`):'—'}</b></div></div>
      <div class="pdAnalysisGrid"><div class="pdAnalysisMain" data-pd-amain></div><aside class="pdDrill" data-pd-drill aria-live="polite"></aside></div>
    </div>`;
    // MAG/MMYG süzgeç listeleri kodun altında hiyerarşi bağlamını gösterir (değer ham kod kalır).
    body.querySelectorAll('.pdFilterList').forEach(list=>{const dim=list.querySelector('[data-pd-afilter]')?.dataset.pdAfilter;if(dim)window.BLMerchHierarchy?.decorate?.(list,dim,{item:'.pdCheck',text:'span'});});
    const main=body.querySelector('[data-pd-amain]');
    if(view==='scorecard')main.innerHTML=scorecardHtml(result);
    else if(view==='buyers')main.innerHTML=buyersHtml(observations);
    else main.innerHTML=matrixAnalysisHtml(result);
    renderDrill(body.querySelector('[data-pd-drill]'),result);
    body.querySelector('[data-pd-agroup]')?.addEventListener('change',event=>{a.groupBy=event.target.value;state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);});
    body.querySelector('[data-pd-abasis]')?.addEventListener('change',event=>{a.basis=event.target.value;state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);});
    body.querySelectorAll('[data-pd-aview]').forEach(button=>button.addEventListener('click',()=>{a.view=button.dataset.pdAview;state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);}));
    body.querySelector('[data-pd-aclear]')?.addEventListener('click',()=>{a.filters={};state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);});
    body.querySelectorAll('[data-pd-abulk]').forEach(button=>button.addEventListener('click',()=>{
      const dim=button.dataset.pdAdim,next={...(a.filters||{})};
      if(button.dataset.pdAbulk==='all')next[dim]=E.dimensionValues(observations,dim).map(item=>item.label);else delete next[dim];
      a.filters=next;state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);
      body.querySelector(`[data-pd-afilter="${dim}"]`)?.closest('details')?.setAttribute('open','');
    }));
    body.querySelectorAll('[data-pd-afilter]').forEach(box=>box.addEventListener('change',()=>{
      const dim=box.dataset.pdAfilter,values=[...body.querySelectorAll(`[data-pd-afilter="${dim}"]:checked`)].map(input=>input.value);
      const next={...(a.filters||{})};if(values.length)next[dim]=values;else delete next[dim];a.filters=next;state.drill=null;store.set(ANALYSIS_KEY,analysisPrefs());
      const open=dim;renderAnalysis(body);body.querySelector(`[data-pd-afilter="${open}"]`)?.closest('details')?.setAttribute('open','');
    }));
    body.querySelectorAll('[data-pd-acell]').forEach(cell=>cell.addEventListener('click',()=>{const group=cell.dataset.pdAcellGroup,supplier=cell.dataset.pdAcell;state.drill={type:'cell',group,supplier};renderDrill(body.querySelector('[data-pd-drill]'),result);body.querySelectorAll('.isDrill').forEach(el=>el.classList.remove('isDrill'));cell.classList.add('isDrill');}));
    body.querySelector('[data-pd-all-suppliers]')?.addEventListener('click',()=>{a.allSuppliers=!a.allSuppliers;store.set(ANALYSIS_KEY,analysisPrefs());renderAnalysis(body);});
    body.querySelectorAll('[data-pd-asupplier]').forEach(row=>row.addEventListener('click',()=>{state.drill={type:'supplier',supplier:row.dataset.pdAsupplier};renderDrill(body.querySelector('[data-pd-drill]'),result);}));
  }
  function matrixAnalysisHtml(result){
    if(!result.groups.length)return `<div class="pricingEmptyState">${esc(L('Bu kapsamda analiz edilecek teklif yok. Buyer kapsamını veya filtreleri genişletin.','No offers to analyse in this scope. Widen the buyer scope or the filters.'))}</div>`;
    const columns=state.analysis.allSuppliers?result.columns:result.columns.slice(0,12);
    const groupLabel=L(...(GROUP_LABELS[result.groupBy]||['Grup','Group']));
    return `${result.columns.length>12?`<div class="pdSubBar"><button type="button" class="tbtn" data-pd-all-suppliers aria-pressed="${Boolean(state.analysis.allSuppliers)}">${esc(state.analysis.allSuppliers?L('İlk 12','Top 12'):L(`Tümü (${result.columns.length})`,`All (${result.columns.length})`))}</button></div>`:''}<div class="pdAnalysisNote">${esc(L('Hücre: üreticinin bu gruptaki ortalama teklifi; çip: grup ortalamasına göre fark (yeşil = daha ucuz). Çerçeveli hücre grubun en avantajlı üreticisidir. Ayrıntı için hücreye tıklayın.','Cell: the manufacturer’s average offer in this group; chip: difference to the group average (green = cheaper). The framed cell is the group’s most advantageous manufacturer. Click a cell for details.'))}</div>
      <div class="pdHeatScroll"><table class="pdHeat"><thead><tr><th scope="col" class="pdHeatGroup">${esc(groupLabel)}</th><th scope="col" class="pdNum">${esc(L('Ort.','Avg'))}</th>${columns.map(col=>`<th scope="col" title="${esc(col.name)}">${esc(col.name)}</th>`).join('')}</tr></thead>
      <tbody>${result.groups.map(group=>`<tr><th scope="row" class="pdHeatGroup"><b>${esc(group.label)}</b><small>${esc(L(`${group.models} model · ${group.count} teklif`,`${group.models} models · ${group.count} offers`))}</small></th><td class="pdNum"><b>${esc(money(group.avg))}</b></td>${columns.map(col=>{const cell=group.cell(col.key);if(!cell)return '<td class="pdHeatCell isEmpty">·</td>';const best=group.best&&group.best.key===cell.key;return `<td class="pdHeatCell ${heatClass(cell.index)}${best?' isBest':''}${cell.eligible?'':' isLowSample'}" data-pd-acell-group="${esc(group.key)}" data-pd-acell="${esc(cell.key)}" tabindex="0" title="${esc(`${cell.name} · ${money(cell.avg)} · ${L('min','min')} ${money(cell.min)} · ${L('maks','max')} ${money(cell.max)} · ${cell.models} ${L('model','models')}`)}"><b>${esc(moneyPlain(cell.avg))}</b><span>${esc(pctText(cell.index))}</span><small>${cell.models}</small></td>`;}).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  function scorecardHtml(result){
    if(!result.suppliers.length)return `<div class="pricingEmptyState">${esc(L('Bu kapsamda üretici teklifi yok.','No manufacturer offers in this scope.'))}</div>`;
    const groupLabel=L(...(GROUP_LABELS[result.groupBy]||['Grup','Group'])).toLocaleLowerCase(isEn()?'en-GB':'tr-TR');
    return `<div class="pdAnalysisNote">${esc(L(`Grup endeksi: üreticinin her ${groupLabel} içindeki fiyatının o grubun ortalamasına göre (teklif sayısıyla ağırlıklı) farkı. Aynı model endeksi: birden çok üreticinin fiyat verdiği modellerde, üreticinin fiyatının o modelin ortalamasına göre farkı — ürün karması etkisini eler.`,`Group index: the manufacturer’s price in each ${groupLabel} versus that group’s average (weighted by offers). Same-model index: on models priced by several manufacturers, the manufacturer’s price versus the model average — removes product-mix effects.`))}</div>
      <div class="pdHeatScroll"><table class="pdScore"><thead><tr><th scope="col">${esc(L('Üretici','Manufacturer'))}</th><th scope="col" class="pdNum">${esc(L('Teklif','Offers'))}</th><th scope="col" class="pdNum">${esc(L('Model','Models'))}</th><th scope="col" class="pdNum">${esc(L('Ort. fiyat','Avg price'))}</th><th scope="col" class="pdNum">${esc(L('Grup endeksi','Group index'))}</th><th scope="col" class="pdNum">${esc(L('Aynı model endeksi','Same-model index'))}</th><th scope="col" class="pdNum">${esc(L('En avantajlı','Most advantageous'))}</th><th scope="col" class="pdNum">${esc(L('Onay oranı','Approval rate'))}</th>${scopeIsMulti()?`<th scope="col">${esc(L('Buyer’lar','Buyers'))}</th>`:''}</tr></thead>
      <tbody>${result.suppliers.map(item=>`<tr data-pd-asupplier="${esc(item.key)}" tabindex="0"><th scope="row"><b>${esc(item.name)}</b></th><td class="pdNum">${item.count}</td><td class="pdNum">${item.models}</td><td class="pdNum">${esc(money(item.avg))}</td><td class="pdNum"><span class="pdChip ${toneOf(item.groupIndex)}">${esc(pctText(item.groupIndex))}</span></td><td class="pdNum">${item.modelIndexSample?`<span class="pdChip ${toneOf(item.modelIndex)}">${esc(pctText(item.modelIndex))}</span><small> (${item.modelIndexSample})</small>`:'—'}</td><td class="pdNum">${esc(L(`${item.wins} grup`,`${item.wins} groups`))}</td><td class="pdNum">${esc(pctText(item.approvalRate).replace(/^\+/,''))}</td>${scopeIsMulti()?`<td><small>${esc(item.buyers.join(', '))}</small></td>`:''}</tr>`).join('')}</tbody></table></div>`;
  }
  function buyersHtml(observations){
    const list=E.buyerComparison(observations,{groupBy:state.analysis.groupBy==='buyer'?'classification':state.analysis.groupBy,filters:state.analysis.filters});
    if(!list.length)return `<div class="pricingEmptyState">${esc(L('Karşılaştırılacak buyer verisi yok.','No buyer data to compare.'))}</div>`;
    return `<div class="pdAnalysisNote">${esc(L('Endeks: buyer’ın tekliflerinin aynı gruptaki tüm buyer ortalamasına göre farkı (yeşil = daha avantajlı fiyat).','Index: the buyer’s offers versus the average of all buyers in the same group (green = more advantageous price).'))}</div>
      <div class="pdBuyerBars">${list.map(item=>{const maxAbs=Math.max(1,...list.map(entry=>Math.abs(entry.index||0)));const width=Math.min(48,Math.abs(item.index||0)/maxAbs*48);return `<div class="pdBuyerRow"><b>${esc(item.name)}</b><span class="pdBuyerMeta">${esc(L(`${item.models} model · ${item.count} teklif · ${item.suppliers} üretici`,`${item.models} models · ${item.count} offers · ${item.suppliers} manufacturers`))}</span><div class="pdBuyerTrack"><i class="pdBuyerZero"></i><i class="pdBuyerBar ${toneOf(item.index)}" style="--pd-left:${item.index<0?50-width:50}%;--pd-width:${width}%"></i></div><span class="pdChip ${toneOf(item.index)}">${esc(pctText(item.index))}</span><span class="pdNum">${esc(money(item.avg))}</span></div>`;}).join('')}</div>`;
  }
  function renderDrill(host,result){
    if(!host)return;
    const drill=state.drill;
    let items=[],title='',sub='';
    if(drill&&drill.type==='cell'){const group=result.groups.find(item=>item.key===drill.group),cell=group&&group.cells.find(item=>item.key===drill.supplier);if(cell){items=cell.items;title=`${cell.name} · ${group.label}`;sub=L(`Ort. ${money(cell.avg)} · grup ort. ${money(group.avg)} · ${pctText(cell.index)}`,`Avg ${money(cell.avg)} · group avg ${money(group.avg)} · ${pctText(cell.index)}`);}}
    else if(drill&&drill.type==='supplier'){const supplier=result.suppliers.find(item=>item.key===drill.supplier);if(supplier){items=supplier.items;title=supplier.name;sub=L(`${supplier.models} model · ort. ${money(supplier.avg)}`,`${supplier.models} models · avg ${money(supplier.avg)}`);}}
    if(!items.length){
      const best=result.groups.filter(group=>group.best).slice(0,6);
      host.innerHTML=`<div class="pdPanelHead"><b>${esc(L('Öne çıkanlar','Highlights'))}</b><span>${esc(L('Her grubun en avantajlı üreticisi','The most advantageous manufacturer of each group'))}</span></div>${best.map(group=>`<div class="pdHighlight"><span><b>${esc(group.label)}</b><small>${esc(group.best.name)}</small></span><span class="pdChip isGood">${esc(pctText(group.best.index))}</span></div>`).join('')||`<div class="pricingEmptyState">${esc(L('Karşılaştırma için bir grupta en az iki üretici gerekir.','A group needs at least two manufacturers to compare.'))}</div>`}`;
      return;
    }
    const groupAvg=new Map(result.groups.map(group=>[group.key,group.avg]));
    host.innerHTML=`<div class="pdPanelHead"><b>${esc(title)}</b><span>${esc(sub)}</span></div><div class="pdDrillList">${items.slice().sort((a,b)=>a.value-b.value).slice(0,120).map(item=>{const base=groupAvg.get(E.keyOf(item[result.groupBy]||'—'));const diff=E.pct(item.value,base);return `<div class="pdDrillRow">${thumbHtml(item.req,item.line,'pdThumb isSmall')}<span class="pdRoundModel"><b>${esc(item.model)}</b><small>${esc(item.manufacturer)}${scopeIsMulti()?` · ${esc(item.buyer)}`:''}</small></span><b class="pdNum">${esc(money(item.value))}</b><span class="pdChip ${toneOf(diff)}">${esc(pctText(diff))}</span>${item.approved?`<span class="pdApprovedTag">${esc(L('ONAYLI','APPROVED'))}</span>`:'<span></span>'}</div>`;}).join('')}</div>`;
    bindThumbs(host);
  }

  window.BLPricingDesk={openOptions:openOptionsPanel,matrixColumnsPanelHtml,applyMatrixColumnsPanel,renderLanguage(){state.hosts.forEach(host=>{if(host.isConnected&&host.getClientRects().length)renderHost(host);});},mount,openTab,setHistoryContext,renderMatrix,detailView,setDetailView,scopeAllows,ownerRows,setScope,undo:undoLast,_test:{supplierWorkbookPlan,state,matrixClipboardText,matrixPasteTargets,matrixWindow,matrixNextFocusRow,matrixCurrent,quotesModel,quotesCellHtml,sortModels,sortKeysFor,matrixColumnKeys,matrixGeometry,colWidth,matrixLayout,cycleSort,setColumnHidden,showAllColumns,hiddenColumnCount,matrixClipboardHeaderParts,filterUnapproved}};
})();
