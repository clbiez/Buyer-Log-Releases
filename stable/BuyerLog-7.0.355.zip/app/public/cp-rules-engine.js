/* Buyer Log v9.49 — CP KURAL MOTORU (öncelik + özel kontrol kuralları)
 *
 * "Bu alandaki koşulları kullanıcı dilediği gibi ekle/çıkar yapabilsin."
 *
 * İki tür kural:
 *   · priority  → koşulu sağlayan siparişin ÖNCELİĞİNİ yükseltir
 *   · checklist → koşulu sağlayan siparişe kendi sorusunu sorar
 *
 * TASARIM KARARLARI:
 *
 * 1) YERLEŞİK KURALLAR DA AYNI BİÇİMDE YAZILIR. "Critical" ve "Bu Hafta
 *    Aksiyon" tanımları koda gömülü değil; DEFAULT_RULES içinde, kullanıcının
 *    ekranda görüp değiştirebileceği aynı koşul dilinde duruyor. Gizli bir
 *    kural kalırsa kullanıcı neden bir siparişin Kritik olduğunu göremez.
 *
 * 2) KURALLAR YALNIZ YÜKSELTİR. Bir kural önceliği düşüremez. Aksi hâlde
 *    yanlış yazılmış tek bir kural gerçekten geciken siparişleri listeden
 *    silebilirdi. Teslimat riski (ETA/sonuç) kurallardan HİÇ etkilenmez —
 *    onu yalnız kanonik motor belirler.
 *
 * 3) ALAN LİSTESİ VERİDEN GELİR. Kullanıcının CP'de kendi oluşturduğu
 *    hesaplamalı sütunlar (formül sütunları) da koşulda kullanılabilir;
 *    alan listesi satırın gerçek anahtarlarından üretilir, sabit liste yok.
 *
 * 4) BİLİNMEYEN DEĞER EŞLEŞMEZ. Boş/okunamayan bir alan sayısal
 *    karşılaştırmada asla doğru dönmez: veri yokluğundan uyarı üretmiyoruz.
 *
 * SAF: DOM yok, fetch yok, AI yok.
 */
(function (root, factory) {
  const isNode = typeof require === 'function' && typeof module === 'object';
  const api = factory(
    isNode ? require('./order-decision-engine') : (root && root.BLOrderDecisionEngine),
    isNode ? require('./cp-checklist-engine') : (root && root.BLCpChecklistEngine)
  );
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BLCpRulesEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (decisionEngine, checklistEngine) {
  'use strict';

  const OD = decisionEngine || {};
  const Checklist = checklistEngine || {};
  /* Compatibility list keeps UNKNOWN visible to legacy editors, but new rules
     can target only real Action Priority severities. Rank comes from the shared
     decision registry. */
  const SEVERITY = Object.freeze([...(OD.ACTION_PRIORITIES || ['CRITICAL', 'ACTION_TODAY', 'ACTION_THIS_WEEK', 'WATCH', 'ON_TRACK']), 'UNKNOWN']);
  const severityRank = (key, catalog) => OD.priorityRank ? OD.priorityRank(key, catalog) : (() => {
    const index = SEVERITY.indexOf(key);
    return index < 0 ? SEVERITY.length : index;
  })();

  function isValidPriorityTarget(target, catalog) {
    const raw = String(target || '').trim();
    if (!raw || raw === 'UNKNOWN') return false;
    if (SEVERITY.includes(raw)) return true;
    if (OD.isCustomPriorityCode && OD.isCustomPriorityCode(raw)) return true;
    if (/^prio:[a-z0-9_-]{1,35}$/.test(raw)) return true;
    if (Array.isArray(catalog) && catalog.some(entry => entry && entry.id === raw)) return true;
    return false;
  }

  const OPERATORS = Object.freeze([
    { id: 'eq', tr: 'eşittir', en: 'equals', value: true },
    { id: 'ne', tr: 'eşit değildir', en: 'not equals', value: true },
    { id: 'in', tr: 'şunlardan biri', en: 'is one of', value: true, list: true },
    { id: 'notIn', tr: 'şunlardan biri değil', en: 'is not one of', value: true, list: true },
    { id: 'contains', tr: 'içerir', en: 'contains', value: true },
    { id: 'lt', tr: 'küçüktür', en: 'less than', value: true, numeric: true },
    { id: 'lte', tr: 'küçük veya eşittir', en: 'at most', value: true, numeric: true },
    { id: 'gt', tr: 'büyüktür', en: 'greater than', value: true, numeric: true },
    { id: 'gte', tr: 'büyük veya eşittir', en: 'at least', value: true, numeric: true },
    { id: 'empty', tr: 'boş', en: 'is empty', value: false },
    { id: 'notEmpty', tr: 'dolu', en: 'is not empty', value: false },
  ]);
  const OPERATOR_IDS = Object.freeze(OPERATORS.map(item => item.id));

  /* Motorun türettiği alanlar. Ham sütunlardan ayrı tutulur ki kullanıcı
     "yüklemeye kalan gün" gibi hesaplanmış bir değeri de koşulda kullanabilsin. */
  const STAGE_VALUES = Object.freeze(['PRODUCTION', 'LOADING', 'SHORTAGE', 'IN_TRANSIT', 'CUSTOMS', 'IN_WAREHOUSE', 'AWAITING_RETAIL_TRANSFER', 'UNKNOWN']);
  const OUTCOME_VALUES = Object.freeze(['ON_TRACK', 'AT_RISK', 'EXPECTED_LATE', 'ALREADY_LATE', 'UNKNOWN']);
  /* meaning: alanın İŞ anlamı (TR/EN). Kural editöründeki LCW AI bağlamı ve
     sunucudaki LCW AI bilgi katmanı (server/lib/lcwai/lcwai-knowledge.js) bu
     tek kaynaktan okur; model "Teslimat sonucu"nun ne olduğunu tahmin etmez. */
  const DERIVED_FIELDS = Object.freeze([
    { id: '@daysToLoad', tr: 'Yüklemeye kalan gün', en: 'Days to load', numeric: true,
      meaning: { tr: 'Bugünden yükleme (Ex-Factory planı) tarihine kalan gün; negatifse yükleme tarihi geçmiş.', en: 'Days from today to the loading (ex-factory plan) date; negative means the loading date has passed.' } },
    { id: '@orderAgeDays', tr: 'Sipariş yaşı (gün)', en: 'Order age (days)', numeric: true,
      meaning: { tr: 'Siparişin açılışından bu yana geçen gün.', en: 'Days since the order was created.' } },
    { id: '@stage', tr: 'Aşama', en: 'Stage', values: STAGE_VALUES,
      meaning: { tr: 'Siparişin operasyon aşaması. PRODUCTION dışındaki aşamalar Ex-Factory/yüklemenin gerçekleştiğini gösterir.', en: 'Operational stage of the order. Any stage other than PRODUCTION means ex-factory/loading has happened.' } },
    { id: '@deliveryOutcome', tr: 'Teslimat sonucu', en: 'Delivery outcome', values: OUTCOME_VALUES,
      meaning: { tr: 'Yükleme tarihi + yol süresi kuralıyla hesaplanan tahmini varışın HEDEF tarihe (ekranda seçili Retail Depo ya da In Store) yetişme sonucu: ON_TRACK yetişir, AT_RISK tampon dar, EXPECTED_LATE yetişmeyecek, ALREADY_LATE hedef tarih geçti ve teslim edilmedi, UNKNOWN hesaplanamadı.', en: 'Whether the estimated arrival (loading date + transit-time rule) makes the TARGET date (Retail warehouse or In Store, as selected on screen): ON_TRACK makes it, AT_RISK narrow buffer, EXPECTED_LATE will miss it, ALREADY_LATE target passed without delivery, UNKNOWN could not be calculated.' } },
    { id: '@basePriority', tr: 'Sistem önerisi öncelik', en: 'System suggested priority', values: SEVERITY,
      meaning: { tr: 'Teslimat ve yükleme tarihlerinden motorun önerdiği öncelik. Tek başına hiçbir siparişi yükseltmez; yalnız bir kuralın koşulunda kullanılırsa etkili olur.', en: 'Priority suggested by the engine from delivery and loading dates. It escalates nothing on its own; it only takes effect when used in a rule condition.' } },
    { id: '@scheduleBufferDays', tr: 'Hedefe tampon (gün)', en: 'Buffer to target (days)', numeric: true,
      meaning: { tr: 'Hedef tarih ile yol süresine göre tahmini varış arasındaki gün farkı; negatifse hedefe yetişmez.', en: 'Days between the target date and the estimated arrival by transit time; negative means it misses the target.' } },
    { id: '@transitRuleMissing', tr: 'Yol süresi kuralı eksik', en: 'Transit rule missing', values: Object.freeze(['true', 'false']),
      meaning: { tr: 'Siparişe uyan yol süresi kuralı yoksa "true"; varış hesaplanamaz.', en: '"true" when no transit-time rule matches the order; arrival cannot be calculated.' } },
    { id: '@qty', tr: 'Adet', en: 'Quantity', numeric: true,
      meaning: { tr: 'Sipariş adedi.', en: 'Order quantity.' } },
    { id: '@loadingType', tr: 'Yükleme tipi', en: 'Loading type',
      meaning: { tr: 'Yükleme / sevkiyat tipi (Gemi, Uçak…).', en: 'Loading / shipment type (Sea, Air…).' } },
  ]);
  const DERIVED_IDS = Object.freeze(new Set(DERIVED_FIELDS.map(item => item.id)));

  /* Kontrol listesi durumu da koşulda kullanılabilir: "yükleme teyidi
     işaretlenmemiş" gibi bir kural ancak böyle yazılabilir. */
  const CHECKLIST_PREFIX = '@checklist:';
  /* v7.221 — durumlar kullanıcının seçtiği dört değerle aynıdır:
     open (Pending) · approved · rejected · notRequired, artı kapsam dışı. */
  const CHECKLIST_STATES = Object.freeze(['open', 'approved', 'rejected', 'notRequired', 'notApplicable']);
  const CHECKLIST_STATE_LABELS = Object.freeze({
    tr: { open: 'Bekliyor', approved: 'Onaylandı', rejected: 'Reddedildi', notRequired: 'Gerekmiyor', notApplicable: 'Kapsam dışı' },
    en: { open: 'Pending', approved: 'Approved', rejected: 'Rejected', notRequired: 'Not Required', notApplicable: 'Not applicable' },
  });
  /* Öncelik kuralları da koşulda kullanılabilir: "yalnız X kuralına takılan
     siparişlere sor" gibi bir checklist sorusu böyle yazılır. */
  const RULE_PREFIX = '@rule:';
  const RULE_STATES = Object.freeze(['matched', 'notMatched']);
  const RULE_STATE_LABELS = Object.freeze({
    tr: { matched: 'Eşleşiyor', notMatched: 'Eşleşmiyor' },
    en: { matched: 'Matches', notMatched: 'Does not match' },
  });
  /* Eski (v1) kayıtlarda 'open' = cevapsız, 'answered' = işaretli demekti.
     Reddedilen durum yoktu; reddedilen bir kontrol hâlâ "yapılmadı"dır. Bu
     yüzden eski anlam yeni durumlara KAYIPSIZ taşınır. */
  const LEGACY_CHECKLIST_VALUE_SETS = Object.freeze({
    open: Object.freeze(['open', 'rejected']),
    answered: Object.freeze(['approved', 'notRequired']),
    done: Object.freeze(['approved']),
  });

  const text = value => String(value == null ? '' : value).trim();
  // The same statuses and rule operands occur thousands of times. Cache only
  // immutable, short strings; arbitrary objects must still run toString each time.
  const lowerCache=new Map(),LOWER_CACHE_LIMIT=1024;
  const lower = value => {
    if(typeof value!=='string'||value.length>1024)return text(value).toLocaleLowerCase('tr-TR');
    let result=lowerCache.get(value);
    if(result===undefined){
      result=text(value).toLocaleLowerCase('tr-TR');
      if(lowerCache.size>=LOWER_CACHE_LIMIT)lowerCache.delete(lowerCache.keys().next().value);
      lowerCache.set(value,result);
    }
    return result;
  };

  function numberOf(value) {
    if (value == null || value === '') return null;
    if (value instanceof Date) return Math.round(Date.UTC(value.getFullYear(), value.getMonth(), value.getDate()) / 86400000);
    if (typeof value === 'boolean') return value ? 1 : 0;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function listOf(value) {
    if (Array.isArray(value)) return value.map(text).filter(Boolean);
    return text(value).split(/[;,]/).map(item => item.trim()).filter(Boolean);
  }

  /* --------------------------------------------------------- expression core
     Formula mode deliberately uses a small parser instead of JavaScript
     evaluation.  The parser is shared by basic conditions and formula rules,
     so a saved rule is parsed once and only its AST is evaluated per order. */
  const FORMULA_FUNCTIONS = Object.freeze(new Set([
    'IF', 'AND', 'OR', 'NOT', 'TODAY', 'ISBLANK', 'ISNOTBLANK',
    'IN', 'CONTAINS', 'DAYS_BETWEEN', 'BETWEEN',
  ]));
  const FORMULA_COMPARATORS = Object.freeze(new Set(['=', '<>', '>', '>=', '<', '<=']));

  function formulaError(message, position) {
    const error = new Error(`${message}${Number.isFinite(position) ? ` at ${position}` : ''}`);
    error.code = 'RULE_FORMULA_INVALID';
    error.position = position;
    return error;
  }

  function tokenizeFormula(source) {
    const input = String(source == null ? '' : source).trim().replace(/^=/, '').trim();
    if (!input) throw formulaError('Formula boş olamaz');
    const tokens = [];
    let index = 0;
    while (index < input.length) {
      const ch = input[index];
      if (/\s/.test(ch)) { index += 1; continue; }
      if (ch === '[') {
        const end = input.indexOf(']', index + 1);
        if (end < 0) throw formulaError('Eksik kapatma köşeli parantezi', index);
        const field = input.slice(index + 1, end).trim();
        if (!field) throw formulaError('Boş alan referansı', index);
        tokens.push({ type: 'field', value: field, position: index });
        index = end + 1;
        continue;
      }
      if (ch === '"') {
        let value = '';
        const start = index;
        index += 1;
        let closed = false;
        while (index < input.length) {
          const current = input[index++];
          if (current === '"') { closed = true; break; }
          if (current === '\\') {
            const escaped = input[index++];
            if (escaped === 'n') value += '\n';
            else if (escaped === 'r') value += '\r';
            else value += escaped || '\\';
          } else value += current;
        }
        if (!closed) throw formulaError('Eksik kapatma tırnağı', start);
        tokens.push({ type: 'string', value, position: start });
        continue;
      }
      const number = input.slice(index).match(/^\d+(?:\.\d+)?/);
      if (number) {
        tokens.push({ type: 'number', value: Number(number[0]), position: index });
        index += number[0].length;
        continue;
      }
      const identifier = input.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (identifier) {
        tokens.push({ type: 'identifier', value: identifier[0], position: index });
        index += identifier[0].length;
        continue;
      }
      const two = input.slice(index, index + 2);
      if (FORMULA_COMPARATORS.has(two)) {
        tokens.push({ type: 'operator', value: two, position: index });
        index += 2;
        continue;
      }
      if (FORMULA_COMPARATORS.has(ch) || '+-(),'.includes(ch)) {
        tokens.push({ type: ch === ',' ? 'comma' : ch === '(' || ch === ')' ? 'paren' : 'operator', value: ch, position: index });
        index += 1;
        continue;
      }
      throw formulaError(`Desteklenmeyen karakter: ${ch}`, index);
    }
    tokens.push({ type: 'eof', value: '', position: input.length });
    return tokens;
  }

  function parseFormula(source) {
    const tokens = tokenizeFormula(source);
    let cursor = 0;
    const fields = new Set();
    const peek = () => tokens[cursor];
    const take = () => tokens[cursor++];
    const expect = (type, value) => {
      const token = peek();
      if (token.type !== type || (value != null && token.value !== value)) {
        throw formulaError(`Beklenmeyen ifade; ${value || type} bekleniyordu`, token.position);
      }
      return take();
    };
    const parseExpression = () => parseComparison();
    const parseComparison = () => {
      const left = parseAdditive();
      const token = peek();
      if (token.type === 'operator' && FORMULA_COMPARATORS.has(token.value)) {
        take();
        return { type: 'compare', operator: token.value, left, right: parseAdditive() };
      }
      return left;
    };
    const parseAdditive = () => {
      let node = parsePrimary();
      while (peek().type === 'operator' && (peek().value === '+' || peek().value === '-')) {
        const operator = take().value;
        node = { type: 'binary', operator, left: node, right: parsePrimary() };
      }
      return node;
    };
    const parsePrimary = () => {
      const token = peek();
      if (token.type === 'operator' && (token.value === '+' || token.value === '-')) {
        take();
        return { type: 'unary', operator: token.value, value: parsePrimary() };
      }
      if (token.type === 'number' || token.type === 'string') {
        take();
        return { type: 'literal', value: token.value };
      }
      if (token.type === 'field') {
        take();
        fields.add(token.value);
        return { type: 'field', value: token.value };
      }
      if (token.type === 'paren' && token.value === '(') {
        take();
        const node = parseExpression();
        expect('paren', ')');
        return node;
      }
      if (token.type === 'identifier') {
        const name = String(take().value).toUpperCase();
        if (name === 'TRUE' || name === 'FALSE') return { type: 'literal', value: name === 'TRUE' };
        if (!FORMULA_FUNCTIONS.has(name)) throw formulaError(`Geçersiz fonksiyon: ${name}`, token.position);
        expect('paren', '(');
        const args = [];
        if (!(peek().type === 'paren' && peek().value === ')')) {
          args.push(parseExpression());
          while (peek().type === 'comma') { take(); args.push(parseExpression()); }
        }
        expect('paren', ')');
        const arity = {
          TODAY: [0, 0], NOT: [1, 1], ISBLANK: [1, 1], ISNOTBLANK: [1, 1],
          IF: [3, 3], DAYS_BETWEEN: [2, 2], BETWEEN: [3, 3], IN: [2, Infinity], CONTAINS: [2, 2],
          AND: [1, Infinity], OR: [1, Infinity],
        }[name];
        if (args.length < arity[0] || args.length > arity[1]) {
          throw formulaError(`${name} için geçersiz argüman sayısı`, token.position);
        }
        return { type: 'call', name, args };
      }
      throw formulaError('Beklenmeyen ifade', token.position);
    };
    const ast = parseExpression();
    if (peek().type !== 'eof') throw formulaError('Beklenmeyen ifade', peek().position);
    return { ast, fields: [...fields] };
  }

  function dateOrdinalOf(value) {
    if (value && value.__ruleDateOrdinal != null) return Number(value.__ruleDateOrdinal);
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return Math.floor(Date.UTC(value.getFullYear(), value.getMonth(), value.getDate()) / 86400000);
    }
    const raw = text(value);
    if (!raw) return null;
    const iso = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (iso) return Math.floor(Date.UTC(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3])) / 86400000);
    const slash = raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
    if (slash) return Math.floor(Date.UTC(Number(slash[3]), Number(slash[2]) - 1, Number(slash[1])) / 86400000);
    return null;
  }

  function todayOrdinal(value) {
    const provided = dateOrdinalOf(value);
    if (provided != null) return provided;
    const now = new Date();
    return Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000);
  }

  function blank(value) { return value == null || text(value) === ''; }
  function numericValue(value) {
    if (blank(value)) return null;
    if (value && value.__ruleDateOrdinal != null) return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  function dateValue(value) {
    const ordinal = dateOrdinalOf(value);
    return ordinal == null ? null : ordinal;
  }
  function dateMarker(ordinal) { return { __ruleDateOrdinal: ordinal }; }
  function truthy(value) { return typeof value === 'boolean' ? value : !blank(value) && value !== 0; }

  function compareValues(left, right, operator) {
    if (blank(left) || blank(right)) return false;
    const leftDate = dateValue(left);
    const rightDate = dateValue(right);
    let a = left;
    let b = right;
    if (leftDate != null && rightDate != null) { a = leftDate; b = rightDate; }
    else {
      const leftNumber = numericValue(left);
      const rightNumber = numericValue(right);
      if (leftNumber != null && rightNumber != null) { a = leftNumber; b = rightNumber; }
      else { a = lower(left); b = lower(right); }
    }
    if (operator === '=') return a === b;
    if (operator === '<>') return a !== b;
    if (operator === '>') return a > b;
    if (operator === '>=') return a >= b;
    if (operator === '<') return a < b;
    return a <= b;
  }

  function evaluateAst(ast, facts, options, diagnostics) {
    const opts = options || {};
    const diag = diagnostics || { fields: new Set(), values: [] };
    const evaluate = node => {
      if (node.type === 'literal') return node.value;
      if (node.type === 'field') {
        diag.fields.add(node.value);
        const value = readField(node.value, facts || { row: {}, derived: {}, checklist: {} });
        diag.values.push({ field: node.value, value });
        return value;
      }
      if (node.type === 'unary') {
        const value = numericValue(evaluate(node.value));
        return value == null ? null : (node.operator === '-' ? -value : value);
      }
      if (node.type === 'binary') {
        const left = evaluate(node.left);
        const right = evaluate(node.right);
        const leftDate = dateValue(left);
        const rightDate = dateValue(right);
        const leftNumber = numericValue(left);
        const rightNumber = numericValue(right);
        if (leftDate != null && rightNumber != null) return dateMarker(leftDate + (node.operator === '+' ? rightNumber : -rightNumber));
        if (node.operator === '+' && rightDate != null && leftNumber != null) return dateMarker(rightDate + leftNumber);
        if (node.operator === '-' && leftDate != null && rightDate != null) return leftDate - rightDate;
        if (leftNumber == null || rightNumber == null) return null;
        return node.operator === '+' ? leftNumber + rightNumber : leftNumber - rightNumber;
      }
      if (node.type === 'compare') return compareValues(evaluate(node.left), evaluate(node.right), node.operator);
      if (node.type !== 'call') return null;
      const args = node.args.map(evaluate);
      switch (node.name) {
        case 'TODAY': return dateMarker(todayOrdinal(opts.today || (facts && facts.today)));
        case 'IF': return truthy(args[0]) ? args[1] : args[2];
        case 'AND': return args.every(truthy);
        case 'OR': return args.some(truthy);
        case 'NOT': return !truthy(args[0]);
        case 'ISBLANK': return blank(args[0]);
        case 'ISNOTBLANK': return !blank(args[0]);
        case 'IN': return args.slice(1).some(item => compareValues(args[0], item, '='));
        case 'CONTAINS': return lower(args[0]).includes(lower(args[1]));
        case 'DAYS_BETWEEN': {
          const first = dateValue(args[0]); const second = dateValue(args[1]);
          return first == null || second == null ? null : second - first;
        }
        case 'BETWEEN': {
          const value = args[0];
          return compareValues(value, args[1], '>=') && compareValues(value, args[2], '<=');
        }
        default: return null;
      }
    };
    return { value: evaluate(ast), fields: [...diag.fields], diagnostics: diag.values };
  }

  function compileExpression(source, options) {
    const parsed = parseFormula(source);
    const opts = options || {};
    const catalog = Array.isArray(opts.fields) ? opts.fields.map(item => text(item && (item.id || item.key) || item)).filter(Boolean) : null;
    const errors = catalog ? parsed.fields.filter(field => !catalog.includes(field)).map(field => `Unknown field: ${field}`) : [];
    if (errors.length) throw formulaError(errors.join('; '));
    return {
      ast: parsed.ast,
      fields: parsed.fields,
      evaluate(facts, runtimeOptions) { return evaluateAst(parsed.ast, facts, runtimeOptions, { fields: new Set(), values: [] }); },
    };
  }

  function evaluateExpression(source, facts, options) {
    try { return compileExpression(source, options).evaluate(facts, options); }
    catch (error) { return { value: false, fields: [], diagnostics: [], error: error.message || String(error) }; }
  }

  function validateExpression(source, options) {
    try {
      const compiled = compileExpression(source, options);
      return { valid: true, errors: [], fields: compiled.fields, compiled };
    } catch (error) {
      return { valid: false, errors: [error.message || String(error)], fields: [] };
    }
  }

  function normalizeOffset(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const value = Number(raw.value);
    const offset = { value: Number.isFinite(value) ? value : 0, unit: text(raw.unit).toLowerCase() === 'weeks' ? 'weeks' : 'days' };
    return offset.value ? offset : null;
  }

  function normalizeOperand(raw, fallback) {
    const source = raw && typeof raw === 'object' ? raw : (fallback || {});
    const type = ['field', 'value', 'today'].includes(text(source.type)) ? text(source.type) : (fallback && fallback.type) || 'value';
    const operand = {
      type,
      field: text(source.field == null ? (fallback && fallback.field) : source.field),
      value: source.value == null ? ((fallback && fallback.value) == null ? '' : fallback.value) : source.value,
      offset: normalizeOffset(source.offset || (fallback && fallback.offset)),
      offsetField: text(source.offsetField == null ? (fallback && fallback.offsetField) : source.offsetField),
    };
    if (type === 'today') operand.field = '';
    if (type === 'field' && !operand.field) operand.type = 'value';
    return operand;
  }

  function normalizeCondition(raw) {
    const item = raw && typeof raw === 'object' ? raw : {};
    const operator = OPERATOR_IDS.includes(text(item.operator)) ? text(item.operator) : 'eq';
    const left = normalizeOperand(item.left, { type: 'field', field: text(item.field) });
    const valueType = text(item.valueType);
    const right = normalizeOperand(item.right || (valueType ? { type: valueType, field: item.valueField, value: item.value } : { type: 'value', value: item.value }), { type: 'value' });
    return {
      field: left.field,
      operator,
      value: right.type === 'value' ? right.value : (right.field || right.type),
      left,
      right,
    };
  }

  function formulaQuote(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
    if (typeof value === 'boolean') return value ? 'TRUE' : 'FALSE';
    const raw = text(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return `"${raw}"`;
  }

  function formulaOperand(operand, fallbackField) {
    const item = normalizeOperand(operand, { type: 'field', field: fallbackField || '' });
    let value = item.type === 'field' ? `[${item.field}]` : item.type === 'today' ? 'TODAY()' : formulaQuote(item.value);
    if (item.offset) {
      const days = Number(item.offset.value) * (item.offset.unit === 'weeks' ? 7 : 1);
      if (Number.isFinite(days) && days) value = `(${value}${days < 0 ? '' : '+'}${days})`;
    }
    if (item.offsetField) value = `(${value}+[${item.offsetField}])`;
    return value;
  }

  function conditionsToFormula(conditions, match) {
    const items = (Array.isArray(conditions) ? conditions : []).map(normalizeCondition).filter(item => item.left && item.left.field);
    const expressions = items.map(item => {
      const left = formulaOperand(item.left, item.field);
      const right = item.right;
      if (item.operator === 'empty') return `ISBLANK(${left})`;
      if (item.operator === 'notEmpty') return `ISNOTBLANK(${left})`;
      if (item.operator === 'in' || item.operator === 'notIn') {
        const values = Array.isArray(right.value) ? right.value : listOf(right.value);
        const expression = `IN(${left},${values.map(formulaQuote).join(',')})`;
        return item.operator === 'notIn' ? `NOT(${expression})` : expression;
      }
      if (item.operator === 'contains') return `CONTAINS(${left},${formulaOperand(right)})`;
      const operator = ({ eq: '=', ne: '<>', lt: '<', lte: '<=', gt: '>', gte: '>=' })[item.operator] || '=';
      return `${left}${operator}${formulaOperand(right)}`;
    });
    if (!expressions.length) return '';
    if (expressions.length === 1) return `=${expressions[0]}`;
    return `=${match === 'any' ? 'OR' : 'AND'}(${expressions.join(',')})`;
  }

  function formulaNodeOperand(node) {
    if (!node) return null;
    if (node.type === 'field') return { type: 'field', field: node.value, value: '' };
    if (node.type === 'literal') return { type: 'value', field: '', value: node.value };
    if (node.type === 'call' && node.name === 'TODAY') return { type: 'today', field: '', value: '' };
    if (node.type === 'binary' && (node.operator === '+' || node.operator === '-')) {
      const base = formulaNodeOperand(node.left);
      const delta = node.right && node.right.type === 'literal' ? Number(node.right.value) : NaN;
      if (base && Number.isFinite(delta)) {
        return { ...base, offset: { value: node.operator === '-' ? -delta : delta, unit: 'days' } };
      }
    }
    return null;
  }

  function formulaNodeConditions(node) {
    if (!node) return null;
    if (node.type === 'compare') {
      const left = formulaNodeOperand(node.left);
      const right = formulaNodeOperand(node.right);
      const operator = ({ '=': 'eq', '<>': 'ne', '<': 'lt', '<=': 'lte', '>': 'gt', '>=': 'gte' })[node.operator];
      if (!left || left.type !== 'field' || !right || !operator) return null;
      return [{ field: left.field, operator, value: right.type === 'value' ? right.value : (right.field || right.type), left, right }];
    }
    if (node.type !== 'call') return null;
    if (node.name === 'ISBLANK' || node.name === 'ISNOTBLANK') {
      const left = formulaNodeOperand(node.args[0]);
      return left && left.type === 'field' ? [{ field: left.field, operator: node.name === 'ISBLANK' ? 'empty' : 'notEmpty', value: '', left, right: { type: 'value', value: '' } }] : null;
    }
    if (node.name === 'CONTAINS') {
      const left = formulaNodeOperand(node.args[0]);
      const right = formulaNodeOperand(node.args[1]);
      return left && left.type === 'field' && right ? [{ field: left.field, operator: 'contains', value: right.value, left, right }] : null;
    }
    if (node.name === 'IN' || (node.name === 'NOT' && node.args[0] && node.args[0].type === 'call' && node.args[0].name === 'IN')) {
      const source = node.name === 'IN' ? node : node.args[0];
      const left = formulaNodeOperand(source.args[0]);
      const values = source.args.slice(1).map(formulaNodeOperand);
      if (!left || left.type !== 'field' || values.some(item => !item || item.type !== 'value')) return null;
      return [{ field: left.field, operator: node.name === 'NOT' ? 'notIn' : 'in', value: values.map(item => item.value), left, right: { type: 'value', value: values.map(item => item.value) } }];
    }
    if (node.name === 'BETWEEN') {
      const value = formulaNodeOperand(node.args[0]);
      const lowerBound = formulaNodeOperand(node.args[1]);
      const upperBound = formulaNodeOperand(node.args[2]);
      if (!value || value.type !== 'field' || !lowerBound || !upperBound) return null;
      return [
        { field: value.field, operator: 'gte', value: lowerBound.value, left: value, right: lowerBound },
        { field: value.field, operator: 'lte', value: upperBound.value, left: value, right: upperBound },
      ];
    }
    return null;
  }

  function formulaToConditions(source) {
    let parsed;
    try { parsed = parseFormula(source); } catch (_) { return null; }
    const root = parsed.ast;
    if (root && root.type === 'literal' && root.value === false) return { match: 'all', conditions: [] };
    const match = root.type === 'call' && (root.name === 'AND' || root.name === 'OR') ? (root.name === 'OR' ? 'any' : 'all') : 'all';
    const nodes = root.type === 'call' && (root.name === 'AND' || root.name === 'OR') ? root.args : [root];
    const conditions = nodes.flatMap(node => formulaNodeConditions(node) || []);
    if (!conditions.length || conditions.length !== nodes.length && !(nodes.length === 1 && conditions.length === 2)) return null;
    return { match, conditions };
  }

  const EXPRESSION_VERSION = 2;
  function migrateLegacyChecklistCondition(condition) {
    if (!condition || condition.field.indexOf(CHECKLIST_PREFIX) !== 0) return condition;
    if (!condition.right || condition.right.type !== 'value') return condition;
    if (!['eq', 'ne'].includes(condition.operator)) return condition;
    const legacy = LEGACY_CHECKLIST_VALUE_SETS[text(condition.right.value)];
    if (!legacy) return condition;
    const values = legacy.slice();
    const operator = condition.operator === 'eq' ? 'in' : 'notIn';
    return { ...condition, operator, value: values, right: { ...condition.right, value: values } };
  }
  function migrateLegacyChecklistFormula(formula) {
    if (!formula || formula.indexOf(CHECKLIST_PREFIX) < 0) return formula;
    return formula.replace(/(\[@checklist:[^\]]+\])\s*(=|<>)\s*"(open|answered|done)"/g, (_all, field, operator, value) => {
      const list = LEGACY_CHECKLIST_VALUE_SETS[value].map(item => `"${item}"`).join(',');
      return operator === '=' ? `IN(${field},${list})` : `NOT(IN(${field},${list}))`;
    });
  }

  function normalizeRule(raw, kindOrOptions) {
    const item = raw && typeof raw === 'object' ? raw : {};
    const opts = kindOrOptions && typeof kindOrOptions === 'object' ? kindOrOptions : {};
    const explicitKind = typeof kindOrOptions === 'string' ? kindOrOptions : text(opts.kind);
    const ruleKind = explicitKind || (['priority', 'checklist'].includes(text(item.kind)) ? text(item.kind) : 'priority');
    const legacyExpression = (Number(item.expressionVersion) || 1) < EXPRESSION_VERSION;
    const conditions = (Array.isArray(item.conditions) ? item.conditions : []).slice(0, 12).map(normalizeCondition)
      .filter(rule => rule.field)
      .map(condition => (legacyExpression ? migrateLegacyChecklistCondition(condition) : condition));
    const rawFormula = text(item.formula).slice(0, 4000);
    const base = {
      id: text(item.id) || `rule_${Math.random().toString(36).slice(2, 10)}`,
      kind: ruleKind,
      name: text(item.name).slice(0, 160),
      // İngilizce arayüz adı. Kullanıcı adı değiştirince ikisi birlikte yazılır.
      nameEn: text(item.nameEn).slice(0, 160),
      enabled: item.enabled !== false,
      builtIn: item.builtIn === true,
      mode: text(item.mode) === 'formula' ? 'formula' : 'basic',
      formula: legacyExpression ? migrateLegacyChecklistFormula(rawFormula) : rawFormula,
      expressionVersion: EXPRESSION_VERSION,
      conditions,
      // Koşulların hepsi mi biri mi? Varsayılan "hepsi": daha dar, daha güvenli.
      match: text(item.match) === 'any' ? 'any' : 'all',
    };
    // Moderatörün tüm kullanıcılara yayımladığı kural. Yalnız true iken yazılır.
    if (item.managed === true) base.managed = true;
    if (ruleKind === 'priority') {
      const target = text(item.target);
      base.target = isValidPriorityTarget(target, opts.priorityCatalog) ? target : 'ACTION_THIS_WEEK';
      base.reasonTr = text(item.reasonTr).slice(0, 200);
      base.reasonEn = text(item.reasonEn).slice(0, 200);
    } else {
      // Asking a checklist question and automatically assigning a status are
      // independent conditions. Empty autoFormula intentionally never writes.
      const requestedAutoStatus = text(item.autoStatus);
      base.autoStatus = Checklist.normalizeStatus && Checklist.normalizeStatus(requestedAutoStatus) || '';
      const autoMode = text(item.autoMode) === 'basic' ? 'basic' : 'formula';
      const autoMatch = text(item.autoMatch) === 'any' ? 'any' : 'all';
      const autoConditions = (Array.isArray(item.autoConditions) ? item.autoConditions : [])
        .slice(0, 12).map(normalizeCondition).filter(cond => cond.field);
      if (item.autoMode === 'basic' || Array.isArray(item.autoConditions)) {
        base.autoMode = autoMode;
        base.autoMatch = autoMatch;
        base.autoConditions = autoConditions;
      }
      base.autoFormula = autoMode === 'basic'
        ? (autoConditions.length ? conditionsToFormula(autoConditions, autoMatch) : '')
        : text(item.autoFormula).slice(0, 4000);
      base.questionTr = text(item.questionTr).slice(0, 300);
      base.questionEn = text(item.questionEn).slice(0, 300);
      base.tr = text(item.tr).slice(0, 160) || base.name;
      base.en = text(item.en).slice(0, 160) || base.name;
      // order: her PO kendi cevabını ister.
      // option: Approved, PLM ID + Model Name + Colour Code eşleşen PO'larda
      // yeniden kullanılır. Kullanıcının oluşturduğu checklistlerde varsayılan
      // option'dır; yerleşik kontroller güvenli tarafta kalıp PO bazında başlar.
      base.separateSetParts = item.separateSetParts !== false;
      const approvalScope = text(item.approvalScope);
      base.approvalScope = approvalScope === 'order' || approvalScope === 'option'
        ? approvalScope
        : (base.builtIn ? 'order' : 'option');
      const evidence = item.evidenceFields && typeof item.evidenceFields === 'object' ? item.evidenceFields : {};
      base.evidenceFields = {
        reportNumber: evidence.reportNumber === true,
        actualDate: evidence.actualDate === true,
        attachments: evidence.attachments === true,
      };
    }
    if (base.mode === 'formula' && base.formula) {
      try {
        Object.defineProperty(base, '_compiledFormula', { value: compileExpression(base.formula), enumerable: false, configurable: true });
        Object.defineProperty(base, '_compiledFormulaSource', { value: base.formula, enumerable: false, configurable: true });
      } catch (error) {
        Object.defineProperty(base, '_formulaError', { value: error.message || String(error), enumerable: false, configurable: true });
        Object.defineProperty(base, '_compiledFormulaSource', { value: base.formula, enumerable: false, configurable: true });
      }
      Object.defineProperty(base, '_compiledFormulaVersion', { value: EXPRESSION_VERSION, enumerable: false, configurable: true });
    }
    return base;
  }

  /* ------------------------------------------------ BASİT CHECKLIST ŞABLONLARI
     Kullanıcının ham formül görmeden "Tüm aktif siparişlere sor" veya
     "Yüklemeye ≤ X gün kala sor" diyebilmesini sağlar. */
  function checklistScopePreset(rule) {
    if (!rule || rule.kind !== 'checklist') return { preset: 'custom', maxDaysToLoad: 28, minOrderAgeDays: null };
    if (rule.mode === 'formula' && text(rule.formula)) {
      const compact = text(rule.formula).replace(/\s+/g, '');
      const winWithAge = compact.match(/^=AND\(IN\(\[@stage\],"PRODUCTION","LOADING","SHORTAGE"\),OR\(ISBLANK\(\[@daysToLoad\]\),\[@daysToLoad\]>=-?\d+\),OR\(\[@daysToLoad\]<=(-?\d+),\[@orderAgeDays\]>=(\d+)\)\)$/i);
      if (winWithAge) {
        return { preset: 'window', maxDaysToLoad: Number(winWithAge[1]), minOrderAgeDays: Number(winWithAge[2]) };
      }
      const winNoAge = compact.match(/^=AND\(IN\(\[@stage\],"PRODUCTION","LOADING","SHORTAGE"\),OR\(ISBLANK\(\[@daysToLoad\]\),\[@daysToLoad\]>=-?\d+\),\[@daysToLoad\]<=(-?\d+)\)$/i);
      if (winNoAge) {
        return { preset: 'window', maxDaysToLoad: Number(winNoAge[1]), minOrderAgeDays: null };
      }
      if (/^=IN\(\[@stage\],"PRODUCTION","LOADING","SHORTAGE"\)$/i.test(compact)) {
        return { preset: 'all', maxDaysToLoad: 28, minOrderAgeDays: null };
      }
      return { preset: 'custom', maxDaysToLoad: 28, minOrderAgeDays: null };
    }
    const conds = Array.isArray(rule.conditions) ? rule.conditions : [];
    if (rule.match !== 'any' && conds.length === 1) {
      const only = conds[0];
      if (only.field === '@stage' && only.operator === 'in') {
        const vals = Array.isArray(only.value) ? only.value : [];
        if (vals.length === 3 && vals.includes('PRODUCTION') && vals.includes('LOADING') && vals.includes('SHORTAGE')) {
          return { preset: 'all', maxDaysToLoad: 28, minOrderAgeDays: null };
        }
      }
      if (only.field === '@daysToLoad' && only.operator === 'lte' && Number.isFinite(Number(only.value))) {
        return { preset: 'window', maxDaysToLoad: Number(only.value), minOrderAgeDays: null };
      }
    }
    if (rule.match !== 'any' && conds.length >= 2 && conds.length <= 3) {
      const allowed = conds.every(c =>
        (c.field === '@stage' && c.operator === 'in')
        || (c.field === '@daysToLoad' && (c.operator === 'lte' || c.operator === 'gte'))
      );
      const lte = conds.find(c => c.field === '@daysToLoad' && c.operator === 'lte');
      if (allowed && lte && Number.isFinite(Number(lte.value))) {
        return { preset: 'window', maxDaysToLoad: Number(lte.value), minOrderAgeDays: null };
      }
    }
    return { preset: 'custom', maxDaysToLoad: 28, minOrderAgeDays: null };
  }

  function applyChecklistScopePreset(rule, spec = {}) {
    if (!rule || rule.kind !== 'checklist') return rule;
    const preset = text(spec.preset);
    if (preset === 'all') {
      rule.mode = 'basic';
      rule.match = 'all';
      rule.conditions = [normalizeCondition({ field: '@stage', operator: 'in', value: ['PRODUCTION', 'LOADING', 'SHORTAGE'] })];
      rule.formula = conditionsToFormula(rule.conditions, 'all');
      delete rule._compiledFormula;
      delete rule._formulaError;
      return rule;
    }
    if (preset === 'window') {
      const maxDays = Number.isFinite(Number(spec.maxDaysToLoad)) ? Math.max(0, Math.min(365, Math.round(Number(spec.maxDaysToLoad)))) : 28;
      const minAgeRaw = spec.minOrderAgeDays === '' || spec.minOrderAgeDays == null ? null : Number(spec.minOrderAgeDays);
      const minAge = minAgeRaw != null && Number.isFinite(minAgeRaw) && minAgeRaw > 0 ? Math.min(365, Math.round(minAgeRaw)) : null;
      if (minAge != null) {
        rule.mode = 'formula';
        rule.formula = `=AND(IN([@stage],"PRODUCTION","LOADING","SHORTAGE"),OR(ISBLANK([@daysToLoad]),[@daysToLoad]>=-30),OR([@daysToLoad]<=${maxDays},[@orderAgeDays]>=${minAge}))`;
        rule.conditions = [
          normalizeCondition({ field: '@stage', operator: 'in', value: ['PRODUCTION', 'LOADING', 'SHORTAGE'] }),
          normalizeCondition({ field: '@daysToLoad', operator: 'lte', value: maxDays }),
        ];
        delete rule._compiledFormula;
        delete rule._formulaError;
      } else {
        rule.mode = 'basic';
        rule.match = 'all';
        rule.conditions = [
          normalizeCondition({ field: '@stage', operator: 'in', value: ['PRODUCTION', 'LOADING', 'SHORTAGE'] }),
          normalizeCondition({ field: '@daysToLoad', operator: 'gte', value: -30 }),
          normalizeCondition({ field: '@daysToLoad', operator: 'lte', value: maxDays }),
        ];
        rule.formula = conditionsToFormula(rule.conditions, 'all');
        delete rule._compiledFormula;
        delete rule._formulaError;
      }
      return rule;
    }
    return rule;
  }

  /* ------------------------------------------------------------- YERLEŞİK
     Kullanıcının tarif ettiği tanımlar, düzenlenebilir kural olarak. */
  const DEFAULT_PRIORITY_RULES = Object.freeze([
    Object.freeze(normalizeRule({
      id: 'builtin_critical_late', builtIn: true, kind: 'priority', target: 'CRITICAL',
      name: 'Yükleme geçti ve Retail tarihine yetişmiyor',
      nameEn: 'Load date passed and it will not make the Retail date',
      reasonTr: 'Yükleme tarihi geçmiş ve hedef tarihe yetişmiyor',
      reasonEn: 'Load date passed and will not make the target date',
      match: 'all',
      conditions: [
        { field: '@daysToLoad', operator: 'lt', value: 0 },
        { field: '@deliveryOutcome', operator: 'in', value: ['EXPECTED_LATE', 'ALREADY_LATE'] },
      ],
    })),
    Object.freeze(normalizeRule({
      id: 'builtin_action_confirmation', builtIn: true, kind: 'priority', target: 'ACTION_THIS_WEEK',
      name: 'Gelecek hafta yüklenecek, üretici teyidi yok',
      nameEn: 'Loads next week, no supplier confirmation',
      reasonTr: 'Gelecek hafta yükleme var, üretici teyidi işaretlenmemiş',
      reasonEn: 'Loading next week without supplier confirmation',
      match: 'all',
      conditions: [
        { field: '@daysToLoad', operator: 'gte', value: 0 },
        { field: '@daysToLoad', operator: 'lte', value: 14 },
        { field: '@checklist:supplierConfirmation', operator: 'in', value: ['open', 'rejected'] },
      ],
    })),
    Object.freeze(normalizeRule({
      id: 'builtin_action_samples', builtIn: true, kind: 'priority', target: 'ACTION_THIS_WEEK',
      name: 'Gelecek hafta yüklenecek, numune onayı işaretlenmemiş',
      nameEn: 'Loads next week, sample approval not ticked',
      reasonTr: 'Gelecek hafta yükleme var, numune onayları işaretlenmemiş',
      reasonEn: 'Loading next week without sample approvals',
      match: 'all',
      conditions: [
        { field: '@daysToLoad', operator: 'gte', value: 0 },
        { field: '@daysToLoad', operator: 'lte', value: 14 },
        { field: '@checklist:pps', operator: 'in', value: ['open', 'rejected'] },
      ],
    })),
    /* PLM numune talepleri (CoreNectum Requests): Ex-factory yaklaşırken PPS
       hâlâ onaysız. Eşik (21 gün) kural düzenleyicisinden değiştirilebilir.
       PPS sorusu PLM onayı, aşama zinciri veya üretim sonrası sipariş
       aşamasıyla kapanır; açık kalması gerçekten onay olmadığı demektir. */
    Object.freeze(normalizeRule({
      id: 'builtin_action_pps_exfactory', builtIn: true, kind: 'priority', target: 'ACTION_THIS_WEEK',
      name: "Ex-factory'ye 21 gün kala PPS onayı yok",
      nameEn: '21 days to ex-factory and no PPS approval',
      reasonTr: "Ex-factory yaklaşıyor, PPS onayı yok",
      reasonEn: 'Ex-factory is approaching without PPS approval',
      match: 'all',
      conditions: [
        { field: '@daysToLoad', operator: 'gte', value: 0 },
        { field: '@daysToLoad', operator: 'lte', value: 21 },
        { field: '@checklist:pps', operator: 'in', value: ['open', 'rejected'] },
      ],
    })),
    Object.freeze(normalizeRule({
      id: 'builtin_action_tests', builtIn: true, kind: 'priority', target: 'ACTION_THIS_WEEK',
      name: 'Gelecek hafta yüklenecek, test onayı işaretlenmemiş',
      nameEn: 'Loads next week, test approval not ticked',
      reasonTr: 'Gelecek hafta yükleme var, testler işaretlenmemiş',
      reasonEn: 'Loading next week without test approvals',
      match: 'all',
      conditions: [
        { field: '@daysToLoad', operator: 'gte', value: 0 },
        { field: '@daysToLoad', operator: 'lte', value: 14 },
        { field: '@checklist:tests', operator: 'in', value: ['open', 'rejected'] },
      ],
    })),
  ]);

  /* Yerleşik checklist tanımları da aynı kural editörüne taşınır. Böylece
     kullanıcı ön tanımlı soruları görebilir, değiştirebilir, kapatabilir veya
     kullanıcı bazında silebilir. Kimlikler Checklist.ITEMS ile aynıdır; bu,
     mevcut cevap anahtarlarını ve @checklist:<id> priority koşullarını korur. */
  const DEFAULT_CHECKLIST_RULE_IDS = Object.freeze(
    (Array.isArray(Checklist.ITEMS) ? Checklist.ITEMS : []).map(item => item.id)
  );
  function checklistDefaultRule(item) {
    const stages = Array.isArray(item.stages) ? item.stages.slice() : [];
    const maxDays = Number(item.maxDaysToLoad);
    const minAge = item.minOrderAgeDays == null ? null : Number(item.minOrderAgeDays);
    const conditions = [
      { field: '@stage', operator: 'in', value: stages },
      { field: '@daysToLoad', operator: 'gte', value: -30 },
      { field: '@daysToLoad', operator: 'lte', value: Number.isFinite(maxDays) ? maxDays : 365 },
    ];
    if (Number.isFinite(minAge)) conditions.push({ field: '@orderAgeDays', operator: 'gte', value: minAge });
    const raw = {
      id: item.id, builtIn: true, kind: 'checklist', enabled: item.defaultEnabled !== false,
      name: item.tr || item.en || item.id, nameEn: item.en || item.tr || item.id, tr: item.tr || item.id, en: item.en || item.tr || item.id,
      questionTr: item.questionTr || item.tr || item.id,
      questionEn: item.questionEn || item.en || item.tr || item.id,
      match: 'all', conditions,
    };
    if (Number.isFinite(minAge)) {
      const stageArgs = stages.map(stage => JSON.stringify(String(stage))).join(',');
      const loadLimit = Number.isFinite(maxDays) ? maxDays : 365;
      raw.mode = 'formula';
      raw.formula = `=AND(IN([@stage],${stageArgs}),OR(ISBLANK([@daysToLoad]),[@daysToLoad]>=-30),OR([@daysToLoad]<=${loadLimit},[@orderAgeDays]>=${minAge}))`;
    }
    return Object.freeze(normalizeRule(raw));
  }
  const DEFAULT_CHECKLIST_RULES = Object.freeze(
    (Array.isArray(Checklist.ITEMS) ? Checklist.ITEMS : []).map(checklistDefaultRule)
  );
  const DEFAULT_RULES = Object.freeze([...DEFAULT_PRIORITY_RULES, ...DEFAULT_CHECKLIST_RULES]);

  /* --------------------------------------------------------------- gerçekler
     Bir sipariş için koşulların okuyacağı değerler. Ham satır alanları da
     dahildir; kullanıcının kendi hesaplamalı sütunu da böyle okunur. */
  function factsFor(analysis, checklistState) {
    const row = analysis && analysis.sourceRow ? analysis.sourceRow : {};
    return {
      derived: {
        '@daysToLoad': analysis.daysToLoad,
        '@orderAgeDays': analysis.orderAgeDays,
        '@stage': analysis.stage,
        '@deliveryOutcome': analysis.deliveryOutcome,
        // Kurallar uygulanmadan önceki (motorun) önceliği; kural sonucu değil.
      '@basePriority': analysis.calculatedPriority != null ? analysis.calculatedPriority : analysis.priority,
        '@scheduleBufferDays': analysis.scheduleBufferDays,
        '@transitRuleMissing': analysis.transitRuleMissing ? 'true' : 'false',
        '@qty': analysis.qty,
        '@loadingType': row['Del. Type'],
      },
      row,
      checklist: checklistState || {},
    };
  }

  function readField(field, facts) {
    const source = facts || {};
    if (DERIVED_IDS.has(field)) return source.derived ? source.derived[field] : undefined;
    if (field.indexOf(CHECKLIST_PREFIX) === 0) {
      const itemId = field.slice(CHECKLIST_PREFIX.length);
      // Canlı değerlendirmede durum, bağımlılık sırasına göre tembel hesaplanır.
      if (typeof source.resolveChecklist === 'function') return source.resolveChecklist(itemId);
      return (source.checklist && source.checklist[itemId]) || 'notApplicable';
    }
    if (field.indexOf(RULE_PREFIX) === 0) {
      const ruleId = field.slice(RULE_PREFIX.length);
      if (typeof source.resolveRule === 'function') return source.resolveRule(ruleId);
      return (source.ruleState && source.ruleState[ruleId]) || 'notMatched';
    }
    return source.row ? source.row[field] : undefined;
  }

  function resolveOperand(operand, facts, options) {
    const item = operand || { type: 'value', value: '' };
    let value;
    if (item.type === 'field') value = readField(item.field, facts);
    else if (item.type === 'today') value = dateMarker(todayOrdinal((options && options.today) || (facts && facts.today)));
    else value = item.value;
    const baseDate = dateValue(value);
    let offset = 0;
    if (item.offsetField) offset = numericValue(readField(item.offsetField, facts)) || 0;
    if (item.offset) offset += Number(item.offset.value) * (item.offset.unit === 'weeks' ? 7 : 1);
    if (baseDate != null && offset) return dateMarker(baseDate + offset);
    return value;
  }

  function matchesCondition(condition, facts, options) {
    const item = facts?._rulePreparation?.conditions.get(condition) || normalizeCondition(condition);
    const left = resolveOperand(item.left, facts || {}, options || {});
    const right = resolveOperand(item.right, facts || {}, options || {});
    if (item.operator === 'empty') return blank(left);
    if (item.operator === 'notEmpty') return !blank(left);
    if (item.operator === 'in' || item.operator === 'notIn') {
      const values = listOf(item.right.type === 'value' ? item.right.value : right);
      const hit = values.some(value => compareValues(left, value, '='));
      return item.operator === 'in' ? hit : !hit;
    }
    if (item.operator === 'contains') return lower(left).includes(lower(right));
    const operator = ({ eq: '=', ne: '<>', lt: '<', lte: '<=', gt: '>', gte: '>=' })[item.operator] || '=';
    return compareValues(left, right, operator);
  }

  function matchesRule(rule, facts) {
    if (!rule.enabled) return false;
    if (rule.mode === 'formula') {
      let compiled = rule._compiledFormula;
      if (rule._compiledFormulaSource !== rule.formula || rule._compiledFormulaVersion !== EXPRESSION_VERSION
        || (!compiled && !rule._formulaError)) {
        try {
          compiled = compileExpression(rule.formula);
          Object.defineProperty(rule, '_compiledFormula', { value: compiled, enumerable: false, configurable: true });
          Object.defineProperty(rule, '_compiledFormulaSource', { value: rule.formula, enumerable: false, configurable: true });
          Object.defineProperty(rule, '_compiledFormulaVersion', { value: EXPRESSION_VERSION, enumerable: false, configurable: true });
          if (Object.prototype.hasOwnProperty.call(rule, '_formulaError')) delete rule._formulaError;
        } catch (error) {
          Object.defineProperty(rule, '_formulaError', { value: error.message || String(error), enumerable: false, configurable: true });
          Object.defineProperty(rule, '_compiledFormulaSource', { value: rule.formula, enumerable: false, configurable: true });
          Object.defineProperty(rule, '_compiledFormulaVersion', { value: EXPRESSION_VERSION, enumerable: false, configurable: true });
          return false;
        }
      }
      if (!compiled || rule._formulaError) return false;
      const result = compiled.evaluate(facts || {}, { today: facts && facts.today });
      return !result.error && (typeof result.value === 'boolean' ? result.value : !blank(result.value));
    }
    if (!rule.conditions.length) return false;
    return rule.match === 'any'
      ? rule.conditions.some(condition => matchesCondition(condition, facts))
      : rule.conditions.every(condition => matchesCondition(condition, facts));
  }

  /* Öncelik kuralları: YALNIZ yükseltir (§2). Eşleşen kuralların adları
     döner ki kullanıcı bir siparişin neden Kritik olduğunu görebilsin. */
  function applyPriorityRules(analysis, rules, checklistState, preparedFacts) {
    const stateOrOpts = checklistState && typeof checklistState === 'object' ? checklistState : {};
    const catalog = (preparedFacts && preparedFacts.priorityCatalog) || stateOrOpts.priorityCatalog || undefined;
    const isTracking = target => OD.priorityMeta?.(target, catalog)?.usage === 'tracking';
    if (stateOrOpts.evaluated && Array.isArray(stateOrOpts.evaluated.matched)) {
      let priority = analysis.priority;
      const trackingTags = [];
      for (const rule of stateOrOpts.evaluated.matched) {
        if (isTracking(rule.target)) { if (!trackingTags.includes(rule.target)) trackingTags.push(rule.target); continue; }
        if (OD.moreUrgent) priority = OD.moreUrgent(priority, rule.target, catalog);
        else if (severityRank(rule.target, catalog) < severityRank(priority, catalog)) priority = rule.target;
      }
      return {
        priority, trackingTags,
        matched: stateOrOpts.evaluated.matched,
        signals: stateOrOpts.evaluated.signals || [],
      };
    }
    const list = preparedFacts?._rulePreparation?.rules===rules
      ?preparedFacts._rulePreparation.priorityRules
      :(Array.isArray(rules) ? rules : []).filter(rule => rule.kind === 'priority');
    if (!list.length) return { priority: analysis.priority, matched: [], signals: [], trackingTags: [] };
    const cleanChecklistState = stateOrOpts.priorityCatalog || stateOrOpts.evaluated ? {} : checklistState;
    const facts = preparedFacts || factsFor(analysis, cleanChecklistState);
    let priority = analysis.priority;
    const matched = [];
    const signals = [];
    const trackingTags = [];
    for (const rule of list) {
      if (!matchesRule(rule, facts)) continue;
      matched.push(rule);
      if (isTracking(rule.target)) { if (!trackingTags.includes(rule.target)) trackingTags.push(rule.target); continue; }
      const signal = {
        code: `CUSTOM_RULE:${rule.id}`,
        source: 'custom_rule',
        actionFloor: rule.target,
        textTr: rule.reasonTr || rule.name,
        textEn: rule.reasonEn || rule.name,
        ruleId: rule.id,
      };
      signals.push(signal);
      if (OD.moreUrgent) priority = OD.moreUrgent(priority, rule.target, catalog);
      else if (severityRank(rule.target, catalog) < severityRank(priority, catalog)) priority = rule.target;
    }
    return { priority, matched, signals, trackingTags };
  }

  /* Özel kontrol kuralları: koşulu sağlayan siparişe kendi sorusunu ekler.
     Kapsam koşulu buradadır — "yalnız şu lisanslar" gibi. */
  function customChecklistItems(analysis, rules, checklistState) {
    const list = (Array.isArray(rules) ? rules : []).filter(rule => rule.kind === 'checklist');
    if (!list.length) return [];
    const facts = factsFor(analysis, checklistState);
    return list.filter(rule => matchesRule(rule, facts)).map(rule => ({
      id: rule.id, group: 'custom', custom: true,
      tr: rule.tr || rule.name, en: rule.en || rule.name,
      questionTr: rule.questionTr || rule.name, questionEn: rule.questionEn || rule.name,
      separateSetParts: rule.separateSetParts !== false,
      approvalScope: rule.approvalScope === 'option' ? 'option' : 'order',
    }));
  }

  /* Koşulda seçilebilecek alanların listesi. Sabit değil: örnek satırların
     gerçek anahtarlarından üretilir, böylece kullanıcının CP'de kendi
     oluşturduğu hesaplamalı sütunlar da listede çıkar (§3). */
  function fieldCatalog(rows, options) {
    const opts = options || {};
    const sample = (Array.isArray(rows) ? rows : []).slice(0, 50);
    const seen = new Map();
    const cleanLabel = value => text(value);
    const humanLabel = value => {
      const source = text(value).replace(/^__f_/, '').replace(/^cp:/, '');
      if (!source) return '';
      return source
        .replace(/[_-]+/g, ' ')
        .replace(/([a-zçğıöşü])([A-ZÇĞİÖŞÜ])/g, '$1 $2')
        .replace(/\s+/g, ' ')
        .trim()
        .replace(/\b\p{L}/gu, letter => letter.toLocaleUpperCase('tr-TR'));
    };
    const columnCatalog = new Map(
      (Array.isArray(opts.columnCatalog) ? opts.columnCatalog : [])
        .filter(item => item && text(item.key || item.id))
        .map(item => [text(item.key || item.id), item])
    );
    const metaFor = key => columnCatalog.get(key) || {};
    const entryFor = (key, fallbackSource) => {
      const meta = metaFor(key);
      const label = cleanLabel(meta.displayName || meta.label || meta.title || meta.header || meta.headerName || meta.name || meta.fieldName || meta.key)
        || humanLabel(key) || key;
      const dataType = lower(meta.dataType || meta.type);
      return {
        id: key,
        tr: label,
        en: label,
        source: fallbackSource || (meta.formulaCustom ? 'formula' : 'column'),
        type: dataType || '',
        numeric: meta.numeric === true || /^(number|numeric|integer|int|decimal|money|percent|percentage|pct)$/.test(dataType),
        date: meta.date === true || /^(date|datetime|timestamp)$/.test(dataType),
      };
    };

    // Canlı CP sütun kaydı birincil metadata kaynağıdır. Böylece bir sütunun
    // aktif ilk 50 satırda değeri olmasa bile Field listesinde doğru etiketiyle
    // görünür; yalnız CP'nin gerçekten kullanıcıya sunduğu kolonlar alınır.
    for (const [key, meta] of columnCatalog.entries()) {
      if (key.indexOf('_') === 0 && !meta.formulaCustom && !meta.modelCustom) continue;
      seen.set(key, entryFor(key, meta.formulaCustom ? 'formula' : 'column'));
    }
    for (const row of sample) {
      for (const key of Object.keys(row || {})) {
        if (key.indexOf('_') === 0) continue;          // iç alanlar
        if (seen.has(key)) continue;
        seen.set(key, entryFor(key, 'column'));
      }
    }
    // Hesaplamalı sütunlar teknik anahtarla (__f_<id>) durur; kullanıcı onları
    // KENDİ VERDİĞİ ADLA görmeli. Formula Columns tanımı `label` kullanır;
    // eski `name` fallback'i geriye dönük uyumluluk içindir.
    for (const definition of (Array.isArray(opts.formulaColumns) ? opts.formulaColumns : [])) {
      const key = `__f_${definition.id}`;
      const label = cleanLabel(definition.label || definition.name) || cleanLabel(metaFor(key).label) || humanLabel(key) || key;
      const dataType = lower(definition.dataType || definition.format || metaFor(key).dataType || metaFor(key).type);
      seen.set(key, {
        ...entryFor(key, 'formula'),
        tr: label,
        en: label,
        type: dataType || '',
        numeric: /^(number|numeric|integer|int|decimal|money|percent|percentage|pct)$/.test(dataType),
        date: /^(date|datetime|timestamp)$/.test(dataType),
      });
    }
    const columns = [...seen.values()]
      .map(item => ({ ...item, tr: cleanLabel(item.tr) || humanLabel(item.id) || item.id, en: cleanLabel(item.en) || cleanLabel(item.tr) || humanLabel(item.id) || item.id }))
      .sort((a, b) => String(a.tr).localeCompare(String(b.tr), 'tr-TR', { sensitivity: 'base' }));
    /* Checklist ve öncelik başlıkları CANLI kural listesinden gelir: yeni
       eklenen başlık anında seçilebilir, silinen başlık listede görünmez.
       `excludeId` düzenlenen kuralın kendisini dışarıda bırakır (kendine
       bağlı koşul yazılamaz). */
    const excludeId = text(opts.excludeId);
    const checklist = (Array.isArray(opts.checklistItems) ? opts.checklistItems : [])
      .filter(item => item && text(item.id) && text(item.id) !== excludeId)
      .map(item => ({
        id: `${CHECKLIST_PREFIX}${item.id}`, tr: `Kontrol: ${text(item.tr || item.name || item.id)}`, en: `Check: ${text(item.en || item.name || item.tr || item.id)}`,
        source: 'checklist', ref: text(item.id), enabled: item.enabled !== false, values: [...(Checklist.statusIds ? Checklist.statusIds() : CHECKLIST_STATES.slice(0, 4)), 'notApplicable'],
      }));
    const rules = (Array.isArray(opts.priorityRules) ? opts.priorityRules : [])
      .filter(rule => rule && text(rule.id) && text(rule.id) !== excludeId && (!rule.kind || rule.kind === 'priority'))
      .map(rule => ({
        id: `${RULE_PREFIX}${rule.id}`, tr: `Kural: ${text(rule.name || rule.reasonTr || rule.id)}`, en: `Rule: ${text(rule.nameEn || rule.name || rule.reasonEn || rule.id)}`,
        source: 'rule', ref: text(rule.id), enabled: rule.enabled !== false, values: RULE_STATES.slice(),
      }));
    return { derived: DERIVED_FIELDS.slice(), checklist, rules, columns };
  }

  /* -------------------------------------------------------- canlı değerlendirme
     Checklist soruları ve öncelik kuralları BİRBİRİNE koşul olarak bağlanabilir:
       · öncelik kuralı  → [@checklist:<id>] durumunu okur
       · checklist sorusu → [@rule:<id>] eşleşmesini ya da başka bir sorunun
                            durumunu okur
     Sabit bir "önce checklist, sonra öncelik" sırası bu zinciri doğru
     çözemez. Bu yüzden her sipariş için değerler TEMBEL ve önbellekli
     hesaplanır: bir koşul hangi değeri okursa o anda hesaplanır. Döngü
     (A, B'ye; B, A'ya bağlı) güvenle kırılır: döngüdeki değer "bilinmiyor"
     sayılır ve bilinmeyen değer hiçbir koşulu sağlamaz (§4). */
  // One preparation per synchronous batch; never retain mutable rule objects
  // across batches. Single-order calls continue to normalize their current input.
  function prepareEvaluation(rules) {
    const list=Array.isArray(rules)?rules:[];
    const checklistRules=list.filter(rule=>rule.kind==='checklist');
    const conditions=new Map();
    for(const rule of list)for(const condition of (rule.conditions||[]))conditions.set(condition,normalizeCondition(condition));
    return {rules:list,byId:new Map(list.map(rule=>[rule.id,rule])),itemDefinitions:Object.fromEntries(list.map(rule=>[rule.id,rule])),checklistRules,
      priorityRules:list.filter(rule=>rule.kind==='priority'),conditions,
      itemScopes:Object.fromEntries(checklistRules.map(rule=>[rule.id,rule.approvalScope==='option'?'option':'order']))};
  }

  // One compiled auto-condition per rule object/formula, not per order.
  const automaticProbeCache = new WeakMap();
  function automaticProbe(rule) {
    const cached = automaticProbeCache.get(rule);
    if (cached && cached.source === rule.autoFormula) return cached.probe;
    const probe = { ...rule, kind: 'checklist', mode: 'formula', formula: rule.autoFormula,
      enabled: true, _compiledFormula: undefined, _compiledFormulaSource: '' };
    automaticProbeCache.set(rule, { source: rule.autoFormula, probe });
    return probe;
  }

  function evaluateOrder(analysis, options) {
    const opts = options || {};
    const rules = Array.isArray(opts.rules) ? opts.rules : [];
    const checklistEnabled = opts.checklistEnabled !== false;
    const prepared=opts.preparedRules?.rules===rules?opts.preparedRules:null;
    const byId = prepared?prepared.byId:new Map(rules.map(rule => [rule.id, rule]));
    const itemScopes = prepared?prepared.itemScopes:Object.fromEntries(
      rules.filter(rule => rule && rule.kind === 'checklist')
        .map(rule => [rule.id, rule.approvalScope === 'option' ? 'option' : 'order'])
    );
    const statusContext = { answers: opts.answers || {}, plmEvidence: opts.plmEvidence, itemScopes, itemDefinitions: prepared ? prepared.itemDefinitions : Object.fromEntries(byId) };
    const memo = new Map();
    const visiting = new Set();
    const facts = factsFor(analysis, {});
    if(prepared)facts._rulePreparation=prepared;
    if (opts.today != null) facts.today = opts.today;
    if (Array.isArray(opts.priorityCatalog)) facts.priorityCatalog = opts.priorityCatalog;
    const guarded = (key, compute, cycleValue) => {
      if (memo.has(key)) return memo.get(key);
      if (visiting.has(key)) return cycleValue;
      visiting.add(key);
      let value;
      try { value = compute(); } finally { visiting.delete(key); }
      memo.set(key, value);
      return value;
    };
    const autoMatches = id => guarded(`auto:${id}`, () => {
      const rule = byId.get(id);
      return Boolean(checklistEnabled && rule && rule.kind === 'checklist'
        && rule.enabled && rule.autoStatus && rule.autoFormula
        && matchesRule(automaticProbe(rule), facts));
    }, false);
    const checklistApplies = id => guarded(`applies:${id}`, () => {
      const rule = byId.get(id);
      // An auto rule can finish a check after its original "ask" stage ends
      // (e.g. ask during production, approve once loading begins).
      return Boolean(checklistEnabled && rule && rule.kind === 'checklist'
        && (matchesRule(rule, facts) || autoMatches(id)));
    }, false);
    const autoDecisions = [];
    const componentTracking = Boolean(Checklist.componentsFor && (Checklist.componentsFor(analysis, statusContext).length
      || Checklist.Components.isSet(analysis.sourceRow || analysis, 'cp')));
    const statusOf = id => {
      // A whole-set legacy decision or automatic formula is not evidence for
      // individual pieces. Every consumer must use the same part aggregate.
      if (componentTracking && Checklist.Components.tracksParts(analysis, opts.answers, byId.get(id))) return Checklist.statusOf(analysis, id, statusContext);
      const rule = byId.get(id);
      const directKey = Checklist.answerKey ? Checklist.answerKey(analysis.orderKey, id) : '';
      const direct = directKey && opts.answers && opts.answers[directKey];
      const directState = direct && Checklist.normalizeStatus && Checklist.normalizeStatus(direct.state);
      // Explicit edits and imported evidence always win over automation,
      // including a deliberate Pending selection.
      if (directState && direct.source !== 'auto_rule') return directState;
      const existing = typeof Checklist.statusOf === 'function'
        ? Checklist.statusOf(analysis, id, statusContext) : 'open';
      // Respect PLM evidence and manual approvals reused from another PO.
      if (!directState && existing !== 'open') return existing;
      if (rule && rule.kind === 'checklist' && autoMatches(id)) {
        autoDecisions.push({ itemId: id, state: rule.autoStatus });
        return rule.autoStatus;
      }
      return typeof Checklist.statusOf === 'function' ? Checklist.statusOf(analysis, id, statusContext) : 'open';
    };
    facts.resolveChecklist = id => guarded(`checklist:${id}`, () => (checklistApplies(id) ? statusOf(id) : 'notApplicable'), undefined);
    facts.resolveRule = id => guarded(`rule:${id}`, () => {
      const rule = byId.get(id);
      return rule && rule.kind === 'priority' && matchesRule(rule, facts) ? 'matched' : 'notMatched';
    }, undefined);

    const checklistRules = prepared?prepared.checklistRules:rules.filter(rule => rule.kind === 'checklist');
    const customItems = checklistRules.filter(rule => checklistApplies(rule.id)).map(rule => ({
      id: rule.id, group: 'custom', custom: true,
      tr: rule.tr || rule.name, en: rule.en || rule.name,
      questionTr: rule.questionTr || rule.name, questionEn: rule.questionEn || rule.name,
      separateSetParts: rule.separateSetParts !== false,
      approvalScope: rule.approvalScope === 'option' ? 'option' : 'order',
    }));
    const checklistState = {};
    for (const id of DEFAULT_CHECKLIST_RULE_IDS) checklistState[id] = 'notApplicable';
    for (const rule of checklistRules) checklistState[rule.id] = facts.resolveChecklist(rule.id) || 'notApplicable';
    const applied = applyPriorityRules(analysis, rules, checklistState, facts);
    const ruleState = {};
    for (const rule of rules) if (rule.kind === 'priority') ruleState[rule.id] = applied.matched.includes(rule) ? 'matched' : 'notMatched';
    return { ...applied, checklistState, customItems, ruleState, autoDecisions };
  }

  // Pure, side-effect-free comparison of saved rules and the proposed rule set.
  function previewRuleImpact(orders, candidate, options = {}) {
    const rows = Array.isArray(orders) ? orders : [];
    const baselineRules = Array.isArray(options.rules) ? options.rules : [];
    const nextRules = Array.isArray(options.proposedRules) ? options.proposedRules
      : [...baselineRules.filter(rule => rule.id !== candidate.id), candidate];
    const shared = { answers: options.answers || {}, plmEvidence: options.plmEvidence,
      checklistEnabled: options.checklistEnabled, priorityCatalog: options.priorityCatalog };
    let count = 0, changed = 0, qty = 0, automaticAnswers = 0;
    const sample = [];
    const resultKey = result => JSON.stringify([result.priority, [...(result.trackingTags || [])].sort(), Object.entries(result.checklistState || {}).sort(([a], [b]) => a.localeCompare(b))]);
    for (const original of rows) {
      const analysis = { ...original, sourceRow: original.sourceRow, priority: original.basePriority || 'ON_TRACK' };
      const before = evaluateOrder(analysis, { ...shared, rules: baselineRules });
      const after = evaluateOrder(analysis, { ...shared, rules: nextRules });
      const hit = candidate.kind === 'checklist' ? after.customItems.some(item => item.id === candidate.id)
        : after.ruleState[candidate.id] === 'matched';
      if (resultKey(before) !== resultKey(after)) changed++;
      for (const auto of after.autoDecisions || []) {
        if (auto.itemId !== candidate.id) continue;
        const existing = (options.answers || {})[Checklist.answerKey(original.orderKey, auto.itemId)];
        if ((!existing || existing.source === 'auto_rule') && existing?.state !== auto.state) automaticAnswers++;
      }
      if (!hit) continue;
      count++; qty += Number(original.qty) || 0;
      if (sample.length < 4) sample.push(`${original.orderCode || ''} ${original.modelName || ''}`.trim());
    }
    return { count, changed, qty, automaticAnswers, total: rows.length, sample };
  }

  /* ---------------------------------------------------------- bağımlılıklar
     Bir kural/checklist başka bir kuralın koşulunda kullanılıyorsa silmeden
     önce kullanıcı uyarılmalı; silinmiş bir başlığa bağlı koşul sessizce
     "hiç eşleşmez" hâline gelir. */
  function referenceFieldOf(rule) {
    if (!rule || !text(rule.id)) return '';
    return `${rule.kind === 'checklist' ? CHECKLIST_PREFIX : RULE_PREFIX}${rule.id}`;
  }

  function referencedFields(rule) {
    const fields = new Set();
    if (!rule) return fields;
    const add = value => { const id = text(value); if (id) fields.add(id); };
    if (rule.mode === 'formula' && text(rule.formula)) {
      try { parseFormula(rule.formula).fields.forEach(add); } catch (_) { /* geçersiz formül: koşullara düş */ }
    }
    for (const condition of (Array.isArray(rule.conditions) ? rule.conditions : [])) {
      const item = normalizeCondition(condition);
      add(item.field);
      if (item.left) { if (item.left.type === 'field') add(item.left.field); add(item.left.offsetField); }
      if (item.right) { if (item.right.type === 'field') add(item.right.field); add(item.right.offsetField); }
    }
    return fields;
  }

  function dependentsOf(target, rules) {
    const field = typeof target === 'string' ? target : referenceFieldOf(target);
    const targetId = typeof target === 'string' ? '' : text(target && target.id);
    if (!field) return [];
    return (Array.isArray(rules) ? rules : []).filter(rule => rule && rule.id !== targetId && referencedFields(rule).has(field));
  }

  /* Kuralın, artık var olmayan bir checklist/kural başlığına bağlı koşulları. */
  function danglingReferences(rule, rules) {
    const known = new Set((Array.isArray(rules) ? rules : []).map(referenceFieldOf).filter(Boolean));
    return [...referencedFields(rule)].filter(field =>
      (field.indexOf(CHECKLIST_PREFIX) === 0 || field.indexOf(RULE_PREFIX) === 0) && !known.has(field));
  }

  /* Döngüsel bağımlılık: A → B → A. Değerlendirme döngüde güvenle durur ama
     kullanıcı bunu kayıttan önce görmeli. Döngüdeki kural adlarını döner. */
  function findCycle(rule, rules) {
    const list = Array.isArray(rules) ? rules : [];
    const byField = new Map(list.map(item => [referenceFieldOf(item), item]));
    const start = referenceFieldOf(rule);
    const path = [];
    const seen = new Set();
    const walk = current => {
      for (const field of referencedFields(current)) {
        const next = byField.get(field);
        if (!next) continue;
        if (referenceFieldOf(next) === start) { path.push(next); return true; }
        if (seen.has(next.id)) continue;
        seen.add(next.id);
        path.push(next);
        if (walk(next)) return true;
        path.pop();
      }
      return false;
    };
    return walk(rule) ? path : [];
  }

  /* ------------------------------------------------- formül görünen adları
     Saklanan formül teknik kimlik kullanır ([@daysToLoad], [__f_x]). Kullanıcı
     ve AI ise ekrandaki adı yazar ([Days to load]). İki yönlü çeviri yalnız
     köşeli parantezleri değiştirir; tırnak içindeki metne dokunmaz. */
  function mapFormulaFields(formula, mapper) {
    const input = String(formula == null ? '' : formula);
    let out = '';
    let index = 0;
    while (index < input.length) {
      const ch = input[index];
      if (ch === '"') {
        let end = index + 1;
        while (end < input.length) {
          if (input[end] === '\\') { end += 2; continue; }
          if (input[end] === '"') break;
          end += 1;
        }
        out += input.slice(index, end + 1);
        index = end + 1;
        continue;
      }
      if (ch === '[') {
        const end = input.indexOf(']', index + 1);
        if (end < 0) { out += input.slice(index); break; }
        out += `[${mapper(input.slice(index + 1, end).trim())}]`;
        index = end + 1;
        continue;
      }
      out += ch;
      index += 1;
    }
    return out;
  }

  function catalogEntries(catalog) {
    if (Array.isArray(catalog)) return catalog;
    const source = catalog || {};
    return [...(source.derived || []), ...(source.checklist || []), ...(source.rules || []), ...(source.columns || [])];
  }

  function formulaToDisplay(formula, catalog, lang) {
    const byId = new Map(catalogEntries(catalog).map(item => [text(item.id), item]));
    return mapFormulaFields(formula, field => {
      const item = byId.get(field);
      if (!item) return field;
      const label = text(lang === 'en' ? item.en : item.tr) || text(item.label) || field;
      return label.indexOf(']') >= 0 ? field : label;
    });
  }

  function formulaFromDisplay(formula, catalog) {
    const entries = catalogEntries(catalog);
    const ids = new Set(entries.map(item => text(item.id)));
    const byLabel = new Map();
    const ambiguous = new Set();
    for (const item of entries) {
      for (const label of [item.tr, item.en, item.label]) {
        const key = lower(label);
        if (!key) continue;
        if (byLabel.has(key) && byLabel.get(key) !== item.id) ambiguous.add(key);
        else byLabel.set(key, text(item.id));
      }
    }
    return mapFormulaFields(formula, field => {
      if (ids.has(field)) return field;
      const key = lower(field);
      return byLabel.has(key) && !ambiguous.has(key) ? byLabel.get(key) : field;
    });
  }

  /* -------------------------------------------------------------- AI rehberi
     Kullanıcı istediğini ChatGPT gibi bir araca sorar; bu Markdown rehberi
     o araca Buyer Log'un kural dilini, fonksiyonlarını ve YALNIZ alan
     ADLARINI anlatır. Satır verisi (sipariş, fiyat, tedarikçi) asla girmez.
     AI'ın cevabı yine Buyer Log'da doğrulanır; burada AI çağrısı YOKTUR. */
  function buildAiGuide(options) {
    const opts = options || {};
    const en = opts.lang === 'en';
    const kind = opts.kind === 'checklist' ? 'checklist' : 'priority';
    const fields = catalogEntries(opts.fields || []).slice(0, 400);
    const label = item => text(en ? item.en : item.tr) || text(item.label) || text(item.id);
    const typeOf = item => (item.numeric ? 'number' : item.date ? 'date' : item.source === 'checklist' || item.source === 'rule' ? 'status' : 'text');
    const valuesOf = item => {
      if (Array.isArray(item.values) && !item.source) return item.values.map(value => `"${value}"`).join(', ');
      if (item.source === 'checklist') return (Checklist.statusIds ? [...Checklist.statusIds(), 'notApplicable'] : CHECKLIST_STATES).map(state => `"${state}"`).join(', ');
      if (item.source === 'rule') return RULE_STATES.map(state => `"${state}"`).join(', ');
      return '';
    };
    const group = (title, list) => (list.length
      ? [`### ${title}`, '', '| Field | Type | Allowed values |', '|---|---|---|',
        ...list.map(item => `| [${label(item).replace(/\|/g, '/')}] | ${typeOf(item)} | ${valuesOf(item)} |`), ''].join('\n')
      : '');
    const by = source => fields.filter(item => item.source === source);
    const derived = fields.filter(item => text(item.id).indexOf('@') === 0 && !item.source);
    const purpose = kind === 'checklist'
      ? (opts.autoStatus
        ? (en ? 'The formula decides WHEN the checklist automatically saves status "' + opts.autoStatus + '" on a matching order. TRUE = assign that status; manual decisions always win. It is independent of the rule condition that chooses which orders are asked.'
          : 'Formül, uygun sipariş için "' + opts.autoStatus + '" durumunun NE ZAMAN otomatik yazılacağını belirler. TRUE = bu durum kaydedilir; manuel kararlar korunur. Bu formül, sorunun hangi siparişlere sorulacağını belirleyen koşuldan BAĞIMSIZDIR.')
        : (en ? 'The formula decides WHICH ORDERS are asked this checklist question. TRUE = the question is asked for that order.'
          : 'Formül, bu checklist sorusunun HANGİ SİPARİŞLERE sorulacağını belirler. TRUE = soru o siparişe sorulur.'))
      : (en ? 'The formula decides which orders are ESCALATED to the rule\'s priority. TRUE = the order is escalated. Rules can only raise priority, never lower it.'
        : 'Formül, hangi siparişlerin kuralın önceliğine YÜKSELTİLECEĞİNİ belirler. TRUE = sipariş yükseltilir. Kurallar önceliği yalnız yükseltir, düşürmez.');
    const request = text(opts.request);
    const lines = [
      en ? '# Buyer Log — Rule Formula Guide for AI' : '# Buyer Log — AI için Kural Formülü Rehberi',
      '',
      en ? 'You are helping a buyer write ONE Buyer Log rule formula. Reply with the formula in a single ```formula code block, then one short sentence that explains it. Use only the fields and functions below.'
        : 'Bir buyer\'ın TEK bir Buyer Log kural formülü yazmasına yardım ediyorsun. Formülü tek bir ```formula kod bloğunda ver, ardından kısa bir cümleyle açıkla. Yalnız aşağıdaki alanları ve fonksiyonları kullan.',
      '',
      `## ${en ? 'What the formula does' : 'Formül ne yapar'}`,
      '',
      purpose,
      '',
      `## ${en ? 'Syntax' : 'Sözdizimi'}`,
      '',
      en ? '- Start with `=`. The result must be TRUE or FALSE.' : '- `=` ile başlar. Sonuç TRUE ya da FALSE olmalıdır.',
      en ? '- Field: write the field name in square brackets exactly as listed, e.g. `[Days to load]`.' : '- Alan: listedeki adı köşeli parantez içinde aynen yaz, ör. `[Yüklemeye kalan gün]`.',
      en ? '- Text in double quotes: `"In Production"`. Numbers without quotes: `14`. Text comparison ignores case.' : '- Metin çift tırnakta: `"In Production"`. Sayı tırnaksız: `14`. Metin karşılaştırması büyük/küçük harf duyarsızdır.',
      en ? '- Comparison: `=` `<>` `>` `>=` `<` `<=`. Arithmetic: `+` `-` (date + number = date shifted by days).' : '- Karşılaştırma: `=` `<>` `>` `>=` `<` `<=`. Aritmetik: `+` `-` (tarih + sayı = gün kaydırılmış tarih).',
      en ? '- Empty or unreadable values never match a comparison.' : '- Boş ya da okunamayan değer hiçbir karşılaştırmayı sağlamaz.',
      en ? '- Not allowed: JavaScript, cell references like A1, `*` `/` `&`, any function not listed below.' : '- Yasak: JavaScript, A1 gibi hücre referansları, `*` `/` `&`, aşağıda olmayan fonksiyonlar.',
      '',
      `## ${en ? 'Functions' : 'Fonksiyonlar'}`,
      '',
      '| Function | ' + (en ? 'Meaning' : 'Anlamı') + ' |',
      '|---|---|',
      `| AND(a, b, …) | ${en ? 'all are TRUE' : 'hepsi TRUE'} |`,
      `| OR(a, b, …) | ${en ? 'at least one is TRUE' : 'en az biri TRUE'} |`,
      `| NOT(a) | ${en ? 'reverses TRUE/FALSE' : 'TRUE/FALSE tersine çevirir'} |`,
      `| IF(test, a, b) | ${en ? 'a when test is TRUE, else b' : 'test TRUE ise a, değilse b'} |`,
      `| IN(value, "x", "y", …) | ${en ? 'value equals one of the list' : 'değer listedekilerden birine eşit'} |`,
      `| CONTAINS(text, "part") | ${en ? 'text contains part' : 'metin parçayı içerir'} |`,
      `| ISBLANK(value) / ISNOTBLANK(value) | ${en ? 'empty / not empty' : 'boş / dolu'} |`,
      `| BETWEEN(value, low, high) | ${en ? 'low <= value <= high' : 'alt <= değer <= üst'} |`,
      `| TODAY() | ${en ? 'today\'s date' : 'bugünün tarihi'} |`,
      `| DAYS_BETWEEN(date1, date2) | ${en ? 'date2 − date1 in days' : 'tarih2 − tarih1 (gün)'} |`,
      '',
      `## ${en ? 'Checklist and rule statuses' : 'Checklist ve kural durumları'}`,
      '',
      en ? '- A checklist field `[Check: …]` is one of: `"open"` (Pending, no answer yet), `"approved"`, `"rejected"`, `"notRequired"`, `"notApplicable"` (the question is not asked for that order).'
        : '- Checklist alanı `[Kontrol: …]` şu değerlerden biridir: `"open"` (Bekliyor, henüz cevap yok), `"approved"`, `"rejected"`, `"notRequired"`, `"notApplicable"` (soru o siparişe sorulmuyor).',
      en ? '- A rule field `[Rule: …]` is `"matched"` or `"notMatched"`.' : '- Kural alanı `[Kural: …]` `"matched"` ya da `"notMatched"` değerini alır.',
      en ? '- "Not done yet" usually means `IN([Check: X], "open", "rejected")`.' : '- "Henüz tamamlanmadı" genelde `IN([Kontrol: X], "open", "rejected")` demektir.',
      '',
      `## ${en ? 'Examples' : 'Örnekler'}`,
      '',
      '```formula',
      en ? '=AND([Days to load]>=0,[Days to load]<=14,IN([Stage],"PRODUCTION","LOADING"))' : '=AND([Yüklemeye kalan gün]>=0,[Yüklemeye kalan gün]<=14,IN([Aşama],"PRODUCTION","LOADING"))',
      '```',
      '',
      '```formula',
      en ? '=AND([Days to load]<=21,IN([Check: PPS approval],"open","rejected"))' : '=AND([Yüklemeye kalan gün]<=21,IN([Kontrol: PPS onayı],"open","rejected"))',
      '```',
      '',
      `## ${en ? 'Available fields' : 'Kullanılabilir alanlar'}`,
      '',
      `${en ? 'Stage values' : 'Aşama değerleri'}: ${STAGE_VALUES.join(', ')}. ${en ? 'Delivery outcome values' : 'Teslimat sonucu değerleri'}: ${OUTCOME_VALUES.join(', ')}. ${en ? 'Priority values' : 'Öncelik değerleri'}: ${SEVERITY.join(', ')}.`,
      '',
      group(en ? 'Calculated' : 'Hesaplanan', derived),
      group(en ? 'Checklist questions' : 'Checklist soruları', by('checklist')),
      group(en ? 'Priority rules' : 'Öncelik kuralları', by('rule')),
      group(en ? 'CP columns' : 'CP sütunları', fields.filter(item => item.source === 'column' || item.source === 'formula')),
      `## ${en ? 'Request' : 'İstek'}`,
      '',
      request || (en ? '(Describe here what the rule should do.)' : '(Kuralın ne yapması gerektiğini buraya yazın.)'),
      '',
    ];
    return lines.join('\n').replace(/\n{3,}/g, '\n\n');
  }

  /* AI cevabının tamamı yapıştırılabilir: ```formula bloğu, ilk `=` ile
     başlayan satır ya da metnin kendisi formül olarak alınır. */
  function extractFormula(answer) {
    const raw = String(answer == null ? '' : answer).replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
    const fenced = raw.match(/```(?:formula|excel|text)?\s*\n?([\s\S]*?)```/i);
    if (fenced && fenced[1].trim()) return fenced[1].trim().split('\n').map(line => line.trim()).filter(Boolean).join('');
    const line = raw.split(/\r?\n/).map(item => item.trim()).find(item => /^=/.test(item));
    if (line) return line;
    const inline = raw.match(/`(=[^`]+)`/);
    if (inline) return inline[1].trim();
    return raw.trim();
  }

  function normalizeRules(raw) {
    const list = (Array.isArray(raw) ? raw : []).slice(0, 100).map(item => normalizeRule(item));
    const seen = new Set();
    return list.filter(rule => {
      if (seen.has(rule.id)) return false;
      seen.add(rule.id);
      return true;
    });
  }

  function validateRule(rule, options) {
    const item = normalizeRule(rule);
    const catalog = options && Array.isArray(options.fields) ? options : undefined;
    const errors = [];
    if (item.mode !== 'formula' && !item.conditions.length) errors.push('En az bir koşul ekleyin');
    if (item.mode === 'formula') {
      const result = validateExpression(item.formula, catalog);
      errors.push(...(result.errors || []));
    }
    if (item.kind === 'checklist' && item.autoStatus && item.autoFormula) {
      const result = validateExpression(item.autoFormula, catalog);
      errors.push(...(result.errors || []).map(message => 'Auto status: ' + message));
    }
    if (item.kind === 'checklist' && item.autoStatus && !item.autoFormula)
      errors.push('Automatic status requires a separate TRUE/FALSE formula.');
    return { valid: errors.length === 0, errors, rule: item };
  }

  /* Kaydedilmiş kurallar ile yerleşikleri birleştirir. Kullanıcı yerleşik bir
     kuralı kapatmış ya da eşiğini değiştirmişse KAYDI kazanır; hiç dokunmadığı
     yerleşikler güncel tanımıyla gelir (yeni sürümde eklenen kural kaybolmaz). */
  function mergeWithDefaults(savedRules, deletedRuleIds) {
    const deleted = new Set((Array.isArray(deletedRuleIds) ? deletedRuleIds : []).map(text).filter(Boolean));
    const saved = normalizeRules(savedRules).filter(rule => !deleted.has(rule.id));
    const byId = new Map(saved.map(rule => [rule.id, rule]));
    const merged = DEFAULT_RULES
      .filter(rule => !deleted.has(rule.id))
      .map(rule => {
        if (!byId.has(rule.id)) return normalizeRule(rule);
        const own = byId.get(rule.id);
        // Eski kayıtta İngilizce ad yoksa ve ad hiç değiştirilmediyse yerleşik çeviri kullanılır.
        if (!own.nameEn && own.name === rule.name) own.nameEn = rule.nameEn;
        return own;
      });
    for (const rule of saved) {
      if (!DEFAULT_RULES.some(item => item.id === rule.id)) merged.push(rule);
    }
    return merged;
  }

  /* v7.0.290 — MODERATÖR YAYINI. Moderatörün "tüm kullanıcılara uygula"
     dediği kurallar/checklistler ve "tüm kullanıcılardan sil" dediği kimlikler
     tek bir kayıtta durur ve Master kural yayınıyla her cihaza gider.
     Kullanıcının KENDİ oluşturduğu kurallara dokunulmaz: silme listesi yalnız
     aynı kimliği taşıyan (yerleşik / yayımlanmış / paylaşılmış) kopyaları
     kaldırır; kullanıcı kurallarının kimliği kendine özgüdür. */
  const MAX_MANAGED_DELETED = 500;
  function normalizeManagedRules(raw) {
    const source = raw && typeof raw === 'object' ? raw : {};
    const priorityCatalog = (Array.isArray(source.priorityCatalog) ? source.priorityCatalog : [])
      .map(entry => OD.normalizePriorityEntry ? OD.normalizePriorityEntry({ ...entry, managed: true }) : null)
      .filter(Boolean)
      .slice(0, 40);
    const checklistStatuses = (Array.isArray(source.checklistStatuses) ? source.checklistStatuses : [])
      .map(entry => Checklist.normalizeCustomStatusEntry ? Checklist.normalizeCustomStatusEntry({ ...entry, managed: true }) : null)
      .filter(Boolean)
      .slice(0, 24);
    const rules = normalizeRules(source.rules).map(rule => ({ ...normalizeRule({ ...rule, managed: true }, { priorityCatalog }) }));
    const ids = new Set(rules.map(rule => rule.id));
    const deletedRuleIds = [...new Set((Array.isArray(source.deletedRuleIds) ? source.deletedRuleIds : []).map(text).filter(Boolean))]
      .filter(id => !ids.has(id)).slice(0, MAX_MANAGED_DELETED);
    return {
      version: 1,
      revision: Math.max(0, Math.floor(Number(source.revision) || 0)),
      updatedAt: text(source.updatedAt).slice(0, 40),
      updatedBy: text(source.updatedBy).slice(0, 160),
      rules,
      deletedRuleIds,
      priorityCatalog,
      checklistStatuses,
    };
  }
  /* Kişisel kayıt + yerleşikler + Moderatör yayını → çalışan kural listesi.
     Aynı kimlikte Moderatör kopyası kazanır (Master kural sözleşmesi). */
  function effectiveRules(personalRules, deletedRuleIds, managed) {
    const shared = normalizeManagedRules(managed);
    const managedIds = new Set(shared.rules.map(rule => rule.id));
    const deleted = [...(Array.isArray(deletedRuleIds) ? deletedRuleIds : []), ...shared.deletedRuleIds];
    const own = mergeWithDefaults((Array.isArray(personalRules) ? personalRules : []).filter(rule => !(rule && rule.managed === true)), deleted)
      .filter(rule => !managedIds.has(rule.id));
    return [...own, ...shared.rules];
  }

  return {
    SEVERITY, severityRank, isValidPriorityTarget, OPERATORS, OPERATOR_IDS, DERIVED_FIELDS, CHECKLIST_PREFIX, CHECKLIST_STATES,
    CHECKLIST_STATE_LABELS, STAGE_VALUES, OUTCOME_VALUES, RULE_PREFIX, RULE_STATES, RULE_STATE_LABELS, EXPRESSION_VERSION,
    evaluateOrder, previewRuleImpact, prepareEvaluation, referenceFieldOf, referencedFields, dependentsOf, danglingReferences, findCycle,
    mapFormulaFields, formulaToDisplay, formulaFromDisplay, buildAiGuide, extractFormula,
    DEFAULT_RULES, DEFAULT_PRIORITY_RULES, DEFAULT_CHECKLIST_RULES, DEFAULT_CHECKLIST_RULE_IDS,
    normalizeCondition, normalizeRule, normalizeRules, checklistScopePreset, applyChecklistScopePreset,
    conditionsToFormula, formulaToConditions, validateRule, mergeWithDefaults,
    normalizeManagedRules, effectiveRules,
    compileExpression, evaluateExpression, validateExpression,
    factsFor, readField, matchesCondition, matchesRule,
    applyPriorityRules, customChecklistItems, fieldCatalog,
  };
});
