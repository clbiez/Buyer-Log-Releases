@echo off
setlocal DisableDelayedExpansion
title Buyer Log Mini Patch PR 605 + 606
set "BL_PATCH_ROOT=%~1"
if not defined BL_PATCH_ROOT (
  echo Buyer Log kurulum klasorunu secin / Select the folder containing BuyerLog.exe.
  set /p "BL_PATCH_ROOT=Klasor / Folder: "
)
set "BL_PATCH_ROOT=%BL_PATCH_ROOT:"=%"
if not exist "%BL_PATCH_ROOT%\BuyerLog.exe" (
  echo BuyerLog.exe bulunamadi / BuyerLog.exe was not found.
  pause
  exit /b 1
)
set "ELECTRON_RUN_AS_NODE=1"
"%BL_PATCH_ROOT%\BuyerLog.exe" "%~dp0apply-patch.cjs" --root "%BL_PATCH_ROOT%" --undo
set "BL_PATCH_EXIT=%ERRORLEVEL%"
if not "%BL_PATCH_EXIT%"=="0" echo Islem tamamlanamadi; mesaji kontrol edin / Operation failed; check the message.
pause
exit /b %BL_PATCH_EXIT%
