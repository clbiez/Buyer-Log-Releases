'use strict';
// Offline mini patch: stage a separate core, then let the existing launcher
// perform activation, health verification and automatic rollback.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const fileHash=file=>hash(fs.readFileSync(file));
const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const inside=(root,file)=>{const rel=path.relative(path.resolve(root),path.resolve(file));return rel===''||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));};
function fail(tr,en){throw new Error(tr+' / '+en);}
function json(file,value){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.tmp-'+process.pid;fs.writeFileSync(tmp,JSON.stringify(value,null,2)+'\n',{flag:'wx'});fs.renameSync(tmp,file);}
function safeFile(root,rel){if(typeof rel!=='string'||!rel||rel.includes('\\')||rel.split('/').some(p=>!p||p==='.'||p==='..')||path.isAbsolute(rel))fail('Güvensiz paket yolu.','Unsafe package path.');const file=path.resolve(root,...rel.split('/'));if(!inside(root,file))fail('Paket yolu dışarı taşıyor.','Package path escapes its root.');return file;}
function noLinks(root){for(const entry of fs.readdirSync(root,{withFileTypes:true})){const full=path.join(root,entry.name);if(entry.isSymbolicLink())fail('Uygulama çekirdeğinde bağlantı/reparse point var.','The app core contains a link/reparse point.');if(entry.isDirectory())noLinks(full);}}
function assertClosed(root){
 if(process.platform!=='win32')return; // Linux is used only by the integration harness.
 const ps="$ErrorActionPreference='Stop'; $rows=@(Get-CimInstance Win32_Process -Filter \"Name='BuyerLog.exe'\"); foreach($row in $rows){ if($row.ProcessId -eq [int]$env:BL_PATCH_PID){continue}; if(-not $row.ExecutablePath){throw 'Cannot verify BuyerLog process ownership'}; if([IO.Path]::GetFullPath($row.ExecutablePath) -eq [IO.Path]::Combine($env:BL_PATCH_INSTALL_ROOT,'BuyerLog.exe')){throw 'Buyer Log is still running. Close it first.'} }";
 const encoded=Buffer.from(ps,'utf16le').toString('base64');
 try{cp.execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',encoded],{env:{...process.env,BL_PATCH_PID:String(process.pid),BL_PATCH_INSTALL_ROOT:root},stdio:['ignore','pipe','pipe'],windowsHide:true});}
 catch(_){fail('Buyer Log açık veya süreç durumu doğrulanamadı. Uygulamayı kapatıp yeniden deneyin.','Buyer Log is running or its process state could not be verified. Close it and retry.');}
}
function loadBundle(bundle){
 const manifestFile=path.join(bundle,'patch-manifest.json'),manifest=read(manifestFile);
 if(manifest.schemaVersion!==1||manifest.patchId!=='pr605-606'||manifest.baseVersion!=='7.0.284'||manifest.version!=='7.0.284+pr605-606'||!Array.isArray(manifest.files)||!manifest.files.length)fail('Geçersiz mini patch manifesti.','Invalid mini patch manifest.');
 const names=new Set();
 for(const item of manifest.files){
  if(!item||names.has(item.path)||!/^((public\/)|(server\/(?!data(?:\/|$))))/.test(item.path)||!Array.isArray(item.acceptedBefore)||!/^[a-f0-9]{64}$/.test(item.sha256))fail('Desteklenmeyen veya tekrarlanan payload yolu.','Unsupported or duplicate payload path.');
  names.add(item.path);const full=safeFile(path.join(bundle,'payload'),item.path);
  if(fs.lstatSync(full).isSymbolicLink()||fileHash(full)!==item.sha256)fail('Patch dosyası bozuk: '+item.path,'Corrupt patch file: '+item.path);
 }
 return {manifest,identity:fileHash(manifestFile)};
}
function bootstrap(root){const base=path.join(root,'resources','app');if(!fs.existsSync(path.join(root,'BuyerLog.exe'))||!fs.existsSync(path.join(base,'package.json')))fail('BuyerLog.exe bulunan kurulum klasörünü seçin.','Select the installation folder containing BuyerLog.exe.');return base;}
function makeLife(root,core){return require(path.join(core,'electron/update/launcher-state.js')).createLauncherState({portableRoot:root,bootstrapCore:path.join(root,'resources','app')});}
function verifyProtected(core,manifest){for(const [rel,expected] of Object.entries(manifest.protectedFiles||{})){if(!(Array.isArray(expected)?expected:[expected]).includes(fileHash(safeFile(core,rel))))fail('Güncelleyici sürümü bu patch ile eşleşmiyor: '+rel,'The updater does not match this patch: '+rel);}}
async function validateCore(core,version){const check=await require(path.join(core,'electron/update/integrity.js')).verifyIntegrity(core,{version});if(check.status!=='ok')fail('Uygulama bütünlüğü doğrulanamadı ('+check.status+').','App integrity verification failed ('+check.status+').');}
const runtimeExclude=rel=>rel==='tests'||rel.startsWith('tests/')||rel==='server/data'||rel.startsWith('server/data/')||rel==='.desktop-dev'||rel.startsWith('.desktop-dev/')||rel==='dist-updates'||rel.startsWith('dist-updates/')||rel==='dist-installer'||rel.startsWith('dist-installer/')||rel==='.release-pending.json';
function nativeStateSafe(state){if(state.activation)fail('Sürüm sağlık kontrolü henüz tamamlanmamış. Önce normal açılışı tamamlayın.','Version health verification is unfinished. Complete a normal launch first.');}
function assertCurrentUnchanged(life,previous,beforeState){const now=life.currentPointer();if(now.version!==previous.version||path.resolve(now.appCoreRoot)!==path.resolve(previous.appCoreRoot)||JSON.stringify(life.readState())!==JSON.stringify(beforeState))fail('Hazırlık sırasında güncelleme durumu değişti; patch uygulanmadı.','Updater state changed during preparation; the patch was not applied.');}
async function apply(root,bundle=__dirname){
 root=fs.realpathSync(root);assertClosed(root);const {manifest:m,identity}=loadBundle(bundle),base=bootstrap(root);
 // Resolve only through the shipped launcher. Never guess that resources/app
 // is the active app: a normal update may have selected a managed core.
 const probe=makeLife(root,base);for(const file of [probe.currentFile,probe.stateFile])if(fs.existsSync(file)&&read(file).schemaVersion!==1)fail('Güncelleme durumu geçersiz.','Invalid updater state.');const previous=probe.currentPointer(),core=fs.realpathSync(previous.appCoreRoot);
 const receiptFile=path.join(root,'data/local/mini-patches',m.patchId,'receipt.json');
 if(previous.version===m.version){if(!fs.existsSync(receiptFile)||read(receiptFile).identity!==identity)fail('Farklı patch kaydı mevcut.','A different patch receipt exists.');await validateCore(core,m.version);return {status:'already-active',version:m.version};}
 if(previous.version!==m.baseVersion)fail('Bu paket yalnız '+m.baseVersion+' içindir; bulunan: '+previous.version,'This package requires '+m.baseVersion+'; found: '+previous.version);
 verifyProtected(core,m);const life=makeLife(root,core),state=life.readState();nativeStateSafe(state);
 if(state.pending){if(state.pending.version===m.version&&state.pending.sha256===identity&&fs.existsSync(receiptFile)&&read(receiptFile).identity===identity){await validateCore(state.pending.appCoreRoot,m.version);return {status:'already-ready',version:m.version};}fail('Bekleyen başka güncelleme var. Önce onu tamamlayın.','Another update is pending. Complete it first.');}
 if(fs.existsSync(receiptFile))fail('Önceki patch kaydı var. Önce GERI-AL.cmd çalıştırın.','A previous patch receipt exists. Run GERI-AL.cmd first.');
 await validateCore(core,m.baseVersion);noLinks(core);
 for(const item of m.files){const file=safeFile(core,item.path),found=fs.existsSync(file)?fileHash(file):null;if(found!==item.sha256&&!item.acceptedBefore.includes(found))fail('Yerel dosya beklenen sürümden farklı: '+item.path,'Unexpected local file version: '+item.path);}
 const key=m.version.replace(/[^0-9A-Za-z._-]/g,'_'),target=path.join(life.versionsRoot,key),stage=target+'.partial-'+process.pid;
 if(fs.existsSync(target)||fs.existsSync(stage))fail('Hedef patch klasörü zaten var. Mevcut kuruluma dokunulmadı.','The patch target already exists. The current installation was preserved.');
 const backupCore=path.join(path.dirname(receiptFile),'base-core');if(fs.existsSync(backupCore))fail('Önceki yedek klasörü mevcut.','A previous backup folder exists.');
 const beforeFiles={};for(const [name,file] of Object.entries({current:life.currentFile,state:life.stateFile}))beforeFiles[name]=fs.existsSync(file)?fs.readFileSync(file).toString('base64'):null;
 let moved=false,recorded=false,backupCreated=false;
 try{
  fs.mkdirSync(stage,{recursive:false});const stagedCore=path.join(stage,'app');
  fs.mkdirSync(path.dirname(backupCore),{recursive:true});backupCreated=true;
  fs.cpSync(core,backupCore,{recursive:true,errorOnExist:true,force:false,filter:source=>!runtimeExclude(path.relative(core,source).replace(/\\/g,'/'))});await validateCore(backupCore,m.baseVersion);
  const originalRelease=path.join(path.dirname(core),'release.json');if(fs.existsSync(originalRelease))fs.copyFileSync(originalRelease,path.join(path.dirname(receiptFile),'base-release.json'));
  fs.cpSync(core,stagedCore,{recursive:true,errorOnExist:true,force:false,filter:source=>!runtimeExclude(path.relative(core,source).replace(/\\/g,'/'))});
  for(const item of m.files){const file=safeFile(stagedCore,item.path);fs.mkdirSync(path.dirname(file),{recursive:true});fs.copyFileSync(safeFile(path.join(bundle,'payload'),item.path),file);}
  const pkg=read(path.join(stagedCore,'package.json'));pkg.version=m.version;fs.writeFileSync(path.join(stagedCore,'package.json'),JSON.stringify(pkg,null,2)+'\n');
  const integrity=require(path.join(core,'electron/update/integrity.js'));integrity.writeIntegrityManifest(stagedCore,{version:m.version,exclude:runtimeExclude});await validateCore(stagedCore,m.version);verifyProtected(stagedCore,m);
  // Explicit offline/local record, never forge or replace a signed official release.
  json(path.join(stage,'release.json'),{schemaVersion:1,version:m.version,sha256:identity,source:'manual-mini-patch',patchId:m.patchId,baseVersion:m.baseVersion,sourceCommit:m.sourceCommit});
  assertClosed(root);assertCurrentUnchanged(life,previous,state);
  fs.renameSync(stage,target);moved=true;
  const receipt={schemaVersion:1,patchId:m.patchId,identity,version:m.version,target,previous,backupCore,beforeFiles,createdAt:new Date().toISOString()};json(receiptFile,receipt);recorded=true;
  life.writeState({state:'READY_TO_INSTALL',pending:{version:m.version,sha256:identity,channel:'stable',mandatory:false,releaseNotes:'PR 605 + 606 mini patch',ready:true,manualPatch:true,versionRoot:target,appCoreRoot:path.join(target,'app'),preparedAt:new Date().toISOString()},lastError:null});
  return {status:'ready-to-install',version:m.version,activeCoreUntouched:true,nextLaunch:'native-health-check',receiptFile};
 }catch(error){
  // Before native staging succeeds, only the new, private staging area exists.
  if(recorded){try{restoreFile(life.stateFile,beforeFiles.state);}catch(restoreError){throw new Error(error.message+'; updater state recovery failed: '+restoreError.message);}try{fs.unlinkSync(receiptFile);}catch(_){}}
  if(moved)fs.rmSync(target,{recursive:true,force:true});else fs.rmSync(stage,{recursive:true,force:true});
  if(backupCreated)fs.rmSync(backupCore,{recursive:true,force:true});
  throw error;
 }
}
function restoreFile(file,encoded){if(encoded===null){fs.rmSync(file,{force:true});return;}const tmp=file+'.restore-'+process.pid;fs.writeFileSync(tmp,Buffer.from(encoded,'base64'),{flag:'wx'});fs.renameSync(tmp,file);}
async function undo(root,bundle=__dirname){
 root=fs.realpathSync(root);assertClosed(root);const {manifest:m,identity}=loadBundle(bundle),base=bootstrap(root),probe=makeLife(root,base),current=probe.currentPointer();
 const receiptFile=path.join(root,'data/local/mini-patches',m.patchId,'receipt.json');if(!fs.existsSync(receiptFile))fail('Geri alınacak patch kaydı bulunamadı.','No patch receipt was found.');
 const receipt=read(receiptFile),life=makeLife(root,current.appCoreRoot),state=life.readState();nativeStateSafe(state);
 const target=path.join(life.versionsRoot,m.version.replace(/[^0-9A-Za-z._-]/g,'_'));
 if(receipt.identity!==identity||receipt.version!==m.version||receipt.target!==target||!inside(root,receipt.previous.appCoreRoot)||receipt.previous.version!==m.baseVersion||receipt.backupCore!==path.join(path.dirname(receiptFile),'base-core'))fail('Geri alma kaydı doğrulanamadı.','Rollback receipt verification failed.');
 if(state.pending&&!(state.pending.version===m.version&&state.pending.sha256===identity))fail('Başka güncelleme bekliyor; geri alma durduruldu.','Another update is pending; rollback stopped.');
 if(current.version!==m.version&&(current.version!==receipt.previous.version||path.resolve(current.appCoreRoot)!==path.resolve(receipt.previous.appCoreRoot)))fail('Uygulama daha sonraki bir sürüme geçmiş. Geri alma uygulanmadı.','The app has moved to a later version. Rollback was not applied.');
 await validateCore(receipt.backupCore,m.baseVersion);
 const previousExists=life.validManagedCore(receipt.previous.appCoreRoot,m.baseVersion);let restoreStage='';
 if(previousExists)await validateCore(receipt.previous.appCoreRoot,m.baseVersion);
 else{
  if(!inside(life.versionsRoot,receipt.previous.appCoreRoot)||fs.existsSync(path.dirname(receipt.previous.appCoreRoot)))fail('Eski çekirdek yolu başka içerik taşıyor.','The previous core path contains different content.');
  restoreStage=path.join(path.dirname(receiptFile),'restore-'+process.pid);if(fs.existsSync(restoreStage))fail('Önceki geri alma hazırlığı mevcut.','An earlier restore staging folder exists.');
  fs.mkdirSync(restoreStage);fs.cpSync(receipt.backupCore,path.join(restoreStage,'app'),{recursive:true,errorOnExist:true,force:false});
  const savedRelease=path.join(path.dirname(receiptFile),'base-release.json');if(fs.existsSync(savedRelease))fs.copyFileSync(savedRelease,path.join(restoreStage,'release.json'));
  await validateCore(path.join(restoreStage,'app'),m.baseVersion);
 }
 assertClosed(root);assertCurrentUnchanged(life,current,state);
 if(restoreStage)fs.renameSync(restoreStage,path.dirname(receipt.previous.appCoreRoot));
 // Code selection only. Never restore a database checkpoint after the user
 // has worked in the patched app: current business data must survive undo.
 restoreFile(life.currentFile,receipt.beforeFiles.current);restoreFile(life.stateFile,receipt.beforeFiles.state);
 const archive=path.dirname(receiptFile)+'.undone-'+Date.now();fs.renameSync(path.dirname(receiptFile),archive);
 if(fs.existsSync(target))fs.renameSync(target,target+'.undone-'+Date.now());
 return {status:'undone',version:m.baseVersion,businessDataUntouched:true,archive};
}
async function cli(){const args=process.argv.slice(2),i=args.indexOf('--root');if(i<0||!args[i+1])fail('Kurulum klasörü gerekli (--root).','Installation folder is required (--root).');const result=args.includes('--undo')?await undo(args[i+1]):await apply(args[i+1]);console.log(JSON.stringify(result,null,2));console.log('Tamamlandı. Buyer Log normal başlatıcısıyla açılabilir. / Done. Start Buyer Log normally.');}
if(require.main===module)cli().catch(error=>{console.error(error.message);process.exitCode=1;});
module.exports={apply,undo,loadBundle};
