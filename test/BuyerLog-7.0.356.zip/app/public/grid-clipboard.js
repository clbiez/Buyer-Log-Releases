(function(root,factory){
  const api=factory(root);
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.BLGridClipboard=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  'use strict';

  const tables=new Map();
  let dragging=null;
  let bound=false;

  // Only the outside of a rectangular cell selection gets an accent border.
  // Edge classes are independent of the row-checkbox selection state.
  function edgeClassesForCell(row,column,range){
    if(!range||row<range.startRow||row>range.endRow||column<range.startColumn||column>range.endColumn)return [];
    const edges=[];
    if(row===range.startRow)edges.push('blGridRangeTop');
    if(row===range.endRow)edges.push('blGridRangeBottom');
    if(column===range.startColumn)edges.push('blGridRangeLeft');
    if(column===range.endColumn)edges.push('blGridRangeRight');
    return edges;
  }

  function selectionSize(range){
    const rows=range?Math.max(0,range.endRow-range.startRow+1):0;
    const columns=range?Math.max(0,range.endColumn-range.startColumn+1):0;
    return {rows,columns,cells:rows*columns,label:`${rows}×${columns}`};
  }
  function serialize(matrix,exporter,options={}){
    const includeHeaders=options.includeHeaders!==false;
    return {plain:exporter.toTSV(matrix,{includeHeaders}),html:exporter.toSafeHTML(matrix,{includeHeaders}),includeHeaders};
  }
  function createDiagnostics(limit=50){
    const entries=[];const max=Math.max(1,Math.min(200,Number(limit)||50));
    const shape=value=>value&&typeof value==='object'?{rows:Math.max(0,Number(value.rows)||0),columns:Math.max(0,Number(value.columns)||0)}:undefined;
    return {
      record(raw={}){const error=raw.error;const entry={at:new Date().toISOString(),module:identity(raw.module),operation:['copy','paste'].includes(raw.operation)?raw.operation:'copy',selection:shape(raw.selection),clipboard:shape(raw.clipboard),includeHeaders:raw.includeHeaders!==false,transport:identity(raw.transport),ok:raw.ok===true,error:error?identity(error.name||error.code||'ClipboardError'):(raw.ok===false?'ClipboardWriteFailed':'')};entries.push(entry);while(entries.length>max)entries.shift();return entry;},
      list(){return entries.map(entry=>({...entry,selection:entry.selection&&{...entry.selection},clipboard:entry.clipboard&&{...entry.clipboard}}));},
      clear(){entries.length=0;},
    };
  }
  const diagnostics=createDiagnostics(50);

  function identity(value){return value==null?'':String(value);}
  function domToken(value){return encodeURIComponent(identity(value)).replace(/%/g,'_');}
  function cellDomId(tableId,rowId,columnId){return `bl-grid-${domToken(tableId)}-${domToken(rowId)}-${domToken(columnId)}`;}
  function resolveRange(anchor,focus,options){
    if(!anchor||!focus)return null;
    const rows=Array.isArray(options?.rows)?options.rows:[];
    const columns=Array.isArray(options?.columns)?options.columns:[];
    const rowId=typeof options?.rowId==='function'?options.rowId:row=>row?._id;
    const columnId=typeof options?.columnId==='function'?options.columnId:column=>column?.k;
    const ar=rows.findIndex(row=>identity(rowId(row))===identity(anchor.rowId));
    const fr=rows.findIndex(row=>identity(rowId(row))===identity(focus.rowId));
    const ac=columns.findIndex(column=>identity(columnId(column))===identity(anchor.columnId));
    const fc=columns.findIndex(column=>identity(columnId(column))===identity(focus.columnId));
    if(ar<0||fr<0||ac<0||fc<0)return null;
    return {startRow:Math.min(ar,fr),endRow:Math.max(ar,fr),startColumn:Math.min(ac,fc),endColumn:Math.max(ac,fc)};
  }

  function buildMatrix(options){
    const rows=Array.isArray(options?.rows)?options.rows:[];
    const columns=Array.isArray(options?.columns)?options.columns:[];
    const range=options?.range;
    const exporter=options?.exporter;
    if(!range||!exporter?.buildMatrix)return null;
    const records=rows.slice(range.startRow,range.endRow+1);
    const selectedColumns=columns.slice(range.startColumn,range.endColumn+1);
    return exporter.buildMatrix({
      records,
      columns:selectedColumns,
      columnLabel:typeof options.header==='function'?options.header:column=>column?.label||column?.k||'',
      cellText:typeof options.value==='function'?(column,row,rowIndex)=>options.value(row,column,rowIndex):undefined,
    });
  }

  function nativeEditingTarget(target){
    return Boolean(target?.closest?.('input,textarea,select,[contenteditable="true"],[role="textbox"]'));
  }

  // A virtual body may be completed for native copy/selection. DOM Ranges
  // cannot survive replaceChildren; retain logical rows and paths inside each
  // unchanged row, including reverse selections and partial text offsets.
  function withNativeSelection(table,update){
    const body=table?.tBodies?.[0],doc=table?.ownerDocument,selection=doc?.defaultView?.getSelection?.();
    if(!body)return false;
    if(table.getClientRects&&!table.getClientRects().length)return false;
    const focused=body.contains(doc.activeElement)?doc.activeElement:null;
    const selected=selection?.rangeCount===1&&!selection.isCollapsed&&selection.getRangeAt(0).intersectsNode(body);
    if(!selected&&!focused)return false;
    function point(node,offset){
      if(node===body){
        if(offset===0)return {edge:'start'};
        if(offset===body.childNodes.length)return {edge:'end'};
        const next=body.childNodes[offset],index=next?.dataset?.blVirtualIndex;
        if(index!=null)return {before:index};
      }
      const element=node?.nodeType===1?node:node?.parentNode,row=element?.closest?.('tr');
      if(row&&body.contains(row)&&row.dataset.blVirtualIndex!=null){
        const path=[];for(let child=node;child!==row;child=child.parentNode)path.unshift(Array.prototype.indexOf.call(child.parentNode.childNodes,child));
        return {row:row.dataset.blVirtualIndex,path,offset};
      }
      return {node,offset};
    }
    function resolve(saved){
      if(saved.edge)return [body,saved.edge==='start'?0:body.childNodes.length];
      const index=saved.row??saved.before;
      if(index!=null){
        let node=body.querySelector('tr[data-bl-virtual-index="'+index+'"]');
        if(!node)return null;
        if(saved.before!=null)return [body,Array.prototype.indexOf.call(body.childNodes,node)];
        for(const child of saved.path)node=node?.childNodes[child];
        return node?[node,saved.offset]:null;
      }
      return [saved.node,saved.offset];
    }
    const anchor=selected?point(selection.anchorNode,selection.anchorOffset):null;
    const focus=selected?point(selection.focusNode,selection.focusOffset):null;
    const original=selected?selection.getRangeAt(0):null;
    const forward=selected&&selection.anchorNode===original.startContainer&&selection.anchorOffset===original.startOffset;
    const active=focused?point(focused,0):null;
    if(selected)selection.removeAllRanges();
    try{update();}finally{
      const target=active&&resolve(active);target?.[0]?.focus?.({preventScroll:true});
      if(selected){
        const a=resolve(anchor),b=resolve(focus);
        if(a&&b){
          if(forward&&doc.createRange){
            const range=doc.createRange();range.setStart(a[0],a[1]);range.setEnd(b[0],b[1]);selection.addRange(range);
          }else selection.setBaseAndExtent(a[0],a[1],b[0],b[1]);
        }
      }
    }
    return true;
  }

  function cellIdentity(td){
    const tr=td?.closest?.('tbody tr[data-id]');
    const columnId=td?.dataset?.key;
    if(!tr||columnId==null)return null;
    return {rowId:identity(tr.dataset.id),columnId:identity(columnId)};
  }

  function tableEntryFromCell(td){
    const table=td?.closest?.('table');
    return table?tables.get(table.id)||null:null;
  }

  function currentData(entry){
    const table=root.document?.getElementById?.(entry.tableId);
    const rows=entry.config.rows?.(table)||table?._blRenderedRows||[];
    const columns=entry.config.columns?.(table)||table?._blRenderedColumns||[];
    return {table,rows:Array.isArray(rows)?rows:[],columns:Array.isArray(columns)?columns:[]};
  }

  function currentRange(entry){
    const data=currentData(entry);
    return {
      ...data,
      range:resolveRange(entry.state.selectionAnchor,entry.state.selectionFocus,{
        rows:data.rows,columns:data.columns,
        rowId:entry.config.rowId,columnId:entry.config.columnId,
      }),
    };
  }

  function clearPaint(table){
    table?.querySelectorAll?.('.blGridActiveCell,.blGridRangeCell,.blGridRangeEdge,.blGridRangeTop,.blGridRangeRight,.blGridRangeBottom,.blGridRangeLeft').forEach(cell=>{
      cell.classList.remove('blGridActiveCell','blGridRangeCell','blGridRangeEdge');
      cell.classList.remove('blGridRangeTop','blGridRangeRight','blGridRangeBottom','blGridRangeLeft');
      cell.setAttribute('aria-selected','false');
    });
  }

  function paint(entry){
    const {table,range}=currentRange(entry);
    if(!table)return;
    entry.state.selectionRange=range;
    clearPaint(table);
    entry.config.selectionChanged?.(range?selectionSize(range):null,entry.state);
    if(!range){table.removeAttribute('aria-activedescendant');return;}
    let activeDomId='';
    table.querySelectorAll('tbody td[data-key]').forEach(td=>{
      const row=Number(td.dataset.r),column=Number(td.dataset.c);
      if(row<range.startRow||row>range.endRow||column<range.startColumn||column>range.endColumn)return;
      td.classList.add('blGridRangeCell');
      td.classList.add(...edgeClassesForCell(row,column,range));
      td.setAttribute('aria-selected','true');
      if(row===range.startRow||row===range.endRow||column===range.startColumn||column===range.endColumn)td.classList.add('blGridRangeEdge');
      const id=cellIdentity(td);
      if(id&&identity(id.rowId)===identity(entry.state.activeCell?.rowId)&&identity(id.columnId)===identity(entry.state.activeCell?.columnId)){
        td.classList.add('blGridActiveCell');
        activeDomId=td.id||cellDomId(entry.tableId,id.rowId,id.columnId);td.id=activeDomId;
      }
    });
    if(activeDomId)table.setAttribute('aria-activedescendant',activeDomId);else table.removeAttribute('aria-activedescendant');
  }

  function setFocus(entry,cell,{extend=false,focus=true}={}){
    if(!cell)return false;
    if(!extend||!entry.state.selectionAnchor)entry.state.selectionAnchor=cell;
    entry.state.activeCell=cell;
    entry.state.selectionFocus=cell;
    if(focus)entry.config.ensureVisible?.(cell);
    paint(entry);
    if(focus)root.document?.getElementById?.(entry.tableId)?.focus?.({preventScroll:true});
    return true;
  }

  function entryIsActive(entry){
    return typeof entry.config.isActive==='function'?Boolean(entry.config.isActive()):true;
  }

  // Üstte açılan katman (ör. alt detay raporu çekmecesi) arkadaki CP/Orders
  // seçiminden önce gelir: priority yüksek olan etkin tablo kazanır.
  function activeEntry(){
    let best=null;
    for(const entry of tables.values()){
      if(!entryIsActive(entry)||!entry.state.activeCell)continue;
      if(!best||(Number(entry.config.priority)||0)>(Number(best.config.priority)||0))best=entry;
    }
    return best;
  }

  // Sağ tık yeni bir seçim başlangıcı değildir. Yalnızca tıklanan hücre
  // mevcut dikdörtgenin dışındaysa aktif hücreye taşınır.
  function prepareContextMenu(tableId,cell){
    const entry=tables.get(tableId);if(!entry||!entryIsActive(entry))return false;
    const clicked=cellIdentity(cell);if(!clicked)return false;
    const data=currentRange(entry);
    const rowIndex=data.rows.findIndex(row=>identity(entry.config.rowId(row))===clicked.rowId);
    const columnIndex=data.columns.findIndex(column=>identity(entry.config.columnId(column))===clicked.columnId);
    const cellInRange=Boolean(data.range&&rowIndex>=data.range.startRow&&rowIndex<=data.range.endRow&&columnIndex>=data.range.startColumn&&columnIndex<=data.range.endColumn);
    if(!cellInRange)setFocus(entry,clicked,{focus:false});
    return true;
  }

  async function copyEntry(entry,event,options={}){
    const data=currentRange(entry);
    if(!data.range)return false;
    const matrix=buildMatrix({
      rows:data.rows,columns:data.columns,range:data.range,
      rowId:entry.config.rowId,columnId:entry.config.columnId,
      header:entry.config.header,value:entry.config.value,exporter:entry.config.exporter,
    });
    if(!matrix)return false;
    event?.preventDefault?.();
    event?.stopImmediatePropagation?.();
    const result=await entry.config.copy?.(matrix,data.range,entry.state,options);
    return result!==false;
  }

  function parseClipboardText(text){
    const lines=identity(text).replace(/\r\n?/g,'\n').split('\n');
    if(lines.length>1&&lines[lines.length-1]==='')lines.pop();
    return lines.map(line=>line.split('\t'));
  }
  function isMultiCellText(text){
    const matrix=parseClipboardText(text);
    return matrix.length>1||(matrix[0]||[]).length>1;
  }

  // Kopyalanan matrisi seçili aralığa yerleştirir (Excel): tek değer seçimin
  // tamamını doldurur, seçim kopyanın tam katıysa desen tekrarlanır; aksi
  // hâlde sol üst hücreden kopya boyutunca yapıştırılır. Düzenlenemeyen veya
  // değeri geçersiz hücre atlanır, tablo dışına taşan kısım sayılır.
  function planPaste(options){
    const rows=Array.isArray(options?.rows)?options.rows:[];
    const columns=Array.isArray(options?.columns)?options.columns:[];
    const range=options?.range;
    const matrix=parseClipboardText(options?.text);
    const height=matrix.length,width=matrix.reduce((max,line)=>Math.max(max,line.length),0);
    const plan={ops:[],readonly:0,invalid:0,skipped:0,mode:'',source:{rows:height,columns:width},target:null};
    if(!range||!height||!width)return plan;
    const selectionRows=range.endRow-range.startRow+1,selectionColumns=range.endColumn-range.startColumn+1;
    let outRows=height,outColumns=width,mode='anchor';
    if(selectionRows*selectionColumns>1){
      if(height===1&&width===1){outRows=selectionRows;outColumns=selectionColumns;mode='fill';}
      else if(selectionRows%height===0&&selectionColumns%width===0){outRows=selectionRows;outColumns=selectionColumns;mode=selectionRows===height&&selectionColumns===width?'exact':'tile';}
    }
    plan.mode=mode;
    for(let r=0;r<outRows;r++){
      for(let c=0;c<outColumns;c++){
        const rowIndex=range.startRow+r,columnIndex=range.startColumn+c;
        const row=rows[rowIndex],column=columns[columnIndex];
        if(!row||!column){plan.skipped++;continue;}
        const target=typeof options.target==='function'?options.target(row,column):null;
        if(!target){plan.readonly++;continue;}
        const raw=matrix[r%height][c%width]??'';
        const parsed=typeof options.parse==='function'?options.parse(raw,target,row,column):{ok:true,value:raw};
        if(!parsed||parsed.ok===false){plan.invalid++;continue;}
        plan.ops.push({row,column,rowIndex,columnIndex,target,value:parsed.value});
      }
    }
    plan.target={
      startRow:range.startRow,endRow:Math.min(rows.length-1,range.startRow+outRows-1),
      startColumn:range.startColumn,endColumn:Math.min(columns.length-1,range.startColumn+outColumns-1),
    };
    return plan;
  }

  async function pasteEntry(entry,event,text){
    if(typeof entry.config.applyPaste!=='function')return false;
    const data=currentRange(entry);
    if(!data.range)return false;
    const plan=planPaste({
      text,rows:data.rows,columns:data.columns,range:data.range,
      target:entry.config.pasteTarget,parse:entry.config.pasteValue,
    });
    // Düzenlenecek hücre yoksa panodaki görsel, görsel hücresine yapıştırma
    // akışına (ör. CP görsel sütunu) bırakılır.
    if(!plan.ops.length&&clipboardHasImage(event))return false;
    event?.preventDefault?.();
    event?.stopImmediatePropagation?.();
    // Önizleme açıkken kullanıcının başka bir hücre/alan seçmesi yeni bir
    // niyettir; async yanıt o yeni seçimin üzerine yazmamalıdır.
    const selectionBefore={
      anchor:entry.state.selectionAnchor&&{...entry.state.selectionAnchor},
      focus:entry.state.selectionFocus&&{...entry.state.selectionFocus},
    };
    const result=await entry.config.applyPaste(plan,data.range,entry.state);
    // 7.0.300 toplu işlem önizlemesi asenkrondur. İptal/ret sonrasında
    // seçimi ve düzenleyici odağını değiştirmek bir sonraki Ctrl+C/V'yi bozar.
    if(result===false||result?.ok===false)return false;
    // Excel gibi: başarıyla yapıştırılan alan seçili kalır; kullanıcı
    // bu sırada başka bir seçim yaptıysa onun en son niyeti korunur.
    const sameCell=(a,b)=>Boolean(a&&b&&a.rowId===b.rowId&&a.columnId===b.columnId);
    const selectionStillCurrent=sameCell(entry.state.selectionAnchor,selectionBefore.anchor)&&sameCell(entry.state.selectionFocus,selectionBefore.focus);
    const target=plan.target;
    const first=target&&cellAt(entry,target.startRow,target.startColumn);
    const last=target&&cellAt(entry,target.endRow,target.endColumn);
    if(selectionStillCurrent&&first&&last){entry.state.selectionAnchor=entry.state.activeCell=first;entry.state.selectionFocus=last;}
    afterRender(entry.tableId);
    const table=root.document?.getElementById?.(entry.tableId);
    const focused=root.document?.activeElement;
    // Onay makbuzu hâlâ açıkken veya kullanıcı başka alana geçmişken,
    // tabloya focus vermek modal/yerel metin kopyalama davranışını bozmasın.
    const bulkDialogOpen=Boolean(root.document?.querySelector?.('.blBulkOverlay,.kolSpreadsheetPasteOverlay'));
    if(!bulkDialogOpen&&entryIsActive(entry)&&(!focused||focused===root.document?.body||focused===table||table?.contains?.(focused))){
      table?.focus?.({preventScroll:true});
    }
    return true;
  }

  function clipboardText(event){
    try{return identity(event?.clipboardData?.getData?.('text/plain'));}catch{return '';}
  }
  function clipboardHasImage(event){
    try{return Array.from(event?.clipboardData?.items||[]).some(item=>String(item?.type||'').startsWith('image/'));}catch{return false;}
  }

  function cellAt(entry,rowIndex,columnIndex){
    const {table,rows,columns}=currentData(entry);
    if(!table||!rows[rowIndex]||!columns[columnIndex])return null;
    const rowId=entry.config.rowId(rows[rowIndex]);
    const columnId=entry.config.columnId(columns[columnIndex]);
    return {rowId:identity(rowId),columnId:identity(columnId)};
  }

  function move(entry,dr,dc,extend){
    const data=currentRange(entry),range=data.range;
    if(!range||!entry.state.activeCell)return false;
    const activeRange=resolveRange(entry.state.activeCell,entry.state.activeCell,{
      rows:data.rows,columns:data.columns,rowId:entry.config.rowId,columnId:entry.config.columnId,
    });
    if(!activeRange)return false;
    let row=Math.max(0,Math.min(data.rows.length-1,activeRange.startRow+dr));
    let column=activeRange.startColumn+dc;
    if(column>=data.columns.length){row=Math.min(data.rows.length-1,row+1);column=0;}
    if(column<0){row=Math.max(0,row-1);column=Math.max(0,data.columns.length-1);}
    return setFocus(entry,cellAt(entry,row,column),{extend});
  }

  // Tablonun görünen tüm hücreleri (Ctrl+A).
  function selectAll(tableId){
    const entry=tables.get(tableId);if(!entry||!entryIsActive(entry))return false;
    const {rows,columns}=currentData(entry);if(!rows.length||!columns.length)return false;
    const first=cellAt(entry,0,0),last=cellAt(entry,rows.length-1,columns.length-1);if(!first||!last)return false;
    entry.state.selectionAnchor=first;entry.state.activeCell=first;entry.state.selectionFocus=last;
    paint(entry);return true;
  }

  /* Çift tıkla düzenleme (config.editOnDoubleClick — CP/Orders). Koleksiyon
     tablosuyla aynı model: tek tık yalnız hücre seçer (sürükleyerek aralık
     seçimi ve Ctrl+C/Ctrl+V bu modda çalışır), çift tık hücre editörünü açar.
     Klavyeyle (ok/Tab/Enter) varılan düzenlenebilir hücre ise doğrudan
     düzenleme modunda açılır. Açılır menü/tarih tetikleyicileri
     (config.editTriggerSelector) ilk tıklamada değil, çift tıklamanın ikinci
     tıklamasında veya klavyeyle (detail=0) açılır. */
  const NATIVE_EDITOR='input,textarea,select,[contenteditable="true"],[role="textbox"]';
  const DEFAULT_EDITOR_SELECTOR='input.editCell:not(:disabled),textarea.editCell:not(:disabled),select.editCell:not(:disabled)';
  const editOriginals=new WeakMap();
  let suppressMouseDown=false;
  function isChoiceInput(el){
    const type=String(el?.type||'').toLowerCase();
    return String(el?.tagName||'').toUpperCase()==='INPUT'&&(type==='checkbox'||type==='radio'||type==='file'||type==='hidden');
  }
  function doubleClickEntry(td){
    const entry=tableEntryFromCell(td);
    return entry&&entry.config.editOnDoubleClick&&entryIsActive(entry)?entry:null;
  }
  function isEditing(editor){
    const active=root.document?.activeElement;
    return Boolean(active&&editor&&(active===editor||editor.contains?.(active)));
  }
  // Seçim modundaki bir hücre editörüne yapılan tek tık, editörü odaklamadan
  // hücreyi seçer. Zaten düzenlenen editörün içindeki tık (imleç/metin seçimi)
  // tarayıcıya bırakılır.
  function selectInsteadOfEdit(target){
    const editor=target?.closest?.(NATIVE_EDITOR);if(!editor||isChoiceInput(editor))return false;
    const td=editor.closest?.('tbody td[data-key]');
    return Boolean(doubleClickEntry(td))&&!isEditing(editor);
  }
  function cellEditor(entry,td){
    if(!td?.querySelector)return null;
    const editor=td.querySelector(entry.config.editorSelector||DEFAULT_EDITOR_SELECTOR);
    return editor&&!editor.readOnly&&!isChoiceInput(editor)?editor:null;
  }
  function cellTrigger(entry,td){
    const selector=entry.config.editTriggerSelector;
    return selector&&td?.querySelector?td.querySelector(selector):null;
  }
  function focusEditor(editor,{selectAll=true}={}){
    if(!editor)return false;
    try{editor.focus({preventScroll:false});}catch{editor.focus?.();}
    if(!isEditing(editor))return false;
    if(String(editor.tagName||'').toUpperCase()==='SELECT')return true;
    try{
      if(selectAll)editor.select?.();
      else if(typeof editor.setSelectionRange==='function'){const end=String(editor.value||'').length;editor.setSelectionRange(end,end);}
    }catch{}
    return true;
  }
  function cellElement(entry,cell){
    const table=root.document?.getElementById?.(entry.tableId);
    if(!table||!cell)return null;
    // afterRender her hücreye kararlı bir DOM kimliği verir: tüm hücreleri taramadan bul.
    const byId=root.document.getElementById(cellDomId(entry.tableId,cell.rowId,cell.columnId));
    if(byId&&table.contains?.(byId))return byId;
    return Array.from(table.querySelectorAll('tbody td[data-key]')).find(td=>{
      const id=cellIdentity(td);return id&&id.rowId===identity(cell.rowId)&&id.columnId===identity(cell.columnId);
    })||null;
  }
  // Klavyeyle varılan hücrenin editörünü açar. Editörü olmayan (salt okunur,
  // hesaplanan veya açılır menü tetikleyicili) hücre seçim modunda kalır.
  function editActiveCell(entry,{selectAll=true,triggers=false}={}){
    if(!entry?.config?.editOnDoubleClick)return false;
    const td=cellElement(entry,entry.state.activeCell);if(!td)return false;
    const editor=cellEditor(entry,td);
    if(editor)return focusEditor(editor,{selectAll});
    const trigger=triggers?cellTrigger(entry,td):null;
    if(trigger){trigger.click?.();return true;}
    return false;
  }
  function onDoubleClick(event){
    if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
    const td=event.target?.closest?.('tbody td[data-key]'),entry=doubleClickEntry(td);if(!entry)return;
    if(event.target?.closest?.('a,img'))return;
    const editor=cellEditor(entry,td);if(!editor||isEditing(editor))return;
    if(!focusEditor(editor,{selectAll:false}))return;
    if(String(editor.tagName||'').toUpperCase()==='SELECT'){try{editor.showPicker?.();}catch{}}
  }
  function onTriggerClick(event){
    if(!(event.detail>=1&&event.detail<2))return;
    const td=event.target?.closest?.('tbody td[data-key]'),entry=doubleClickEntry(td);
    const selector=entry?.config?.editTriggerSelector;if(!selector)return;
    const trigger=event.target.closest(selector);
    if(!trigger||!td.contains(trigger))return;
    // İlk tık yalnız seçimdir: tetikleyicinin kendi click işleyicisine ulaşmaz.
    // Açık menülerin "dışarı tıklandı" kapanışı yine çalışsın diye aynı tık
    // hücrenin kendisine (tetikleyicinin dışına) yeniden yönlendirilir.
    event.preventDefault();event.stopImmediatePropagation();
    try{
      const View=root.MouseEvent||root.Event;
      td.dispatchEvent(new View('click',{bubbles:true,cancelable:true,clientX:event.clientX,clientY:event.clientY}));
    }catch{}
  }
  function onEditorFocusIn(event){
    const target=event.target,td=target?.closest?.('tbody td[data-key]'),entry=doubleClickEntry(td);if(!entry)return;
    if(target?.matches?.(NATIVE_EDITOR)&&!isChoiceInput(target))editOriginals.set(target,String(target.value??''));
    const cell=cellIdentity(td);
    if(cell&&!(identity(entry.state.activeCell?.rowId)===cell.rowId&&identity(entry.state.activeCell?.columnId)===cell.columnId))setFocus(entry,cell,{focus:false});
  }
  // Düzenleme modundaki klavye: Esc değeri geri alıp seçim moduna döner;
  // Shift+Yukarı/Aşağı düzenlemeyi kapatıp kopyalama aralığını genişletir.
  function onEditorKeyDown(event){
    const target=event.target,td=target?.closest?.('tbody td[data-key]'),entry=doubleClickEntry(td);if(!entry)return false;
    if(!target?.matches?.(NATIVE_EDITOR)||isChoiceInput(target)||!isEditing(target))return false;
    const table=root.document.getElementById(entry.tableId);
    if(event.key==='Escape'&&!event.ctrlKey&&!event.metaKey&&!event.altKey){
      if(target.classList?.contains('dateKeyboardInput'))return false;
      event.preventDefault();event.stopImmediatePropagation();
      if(editOriginals.has(target))target.value=editOriginals.get(target);
      setFocus(entry,cellIdentity(td),{focus:false});
      table?.focus?.({preventScroll:true});
      return true;
    }
    if(event.shiftKey&&!event.ctrlKey&&!event.metaKey&&!event.altKey&&(event.key==='ArrowDown'||event.key==='ArrowUp')&&String(target.tagName||'').toUpperCase()!=='TEXTAREA'){
      event.preventDefault();event.stopImmediatePropagation();
      setFocus(entry,cellIdentity(td),{focus:false});
      table?.focus?.({preventScroll:true});
      move(entry,event.key==='ArrowDown'?1:-1,0,true);
      return true;
    }
    return false;
  }
  // Çift tıkla düzenlenen tabloda tek tık artık editörü açmıyor. Tek hücreye tek
  // değer yapıştırma, eskiden editöre tıklayıp Ctrl+V yapmak gibi doğrudan
  // hücre editörü üzerinden kaydedilir; toplu önizleme yalnız çoklu hücre içindir.
  function pasteIntoSingleEditor(entry,event,text){
    if(!entry.config.editOnDoubleClick||isMultiCellText(text))return false;
    const range=currentRange(entry).range;
    if(!range||range.startRow!==range.endRow||range.startColumn!==range.endColumn)return false;
    const td=cellElement(entry,entry.state.activeCell),editor=cellEditor(entry,td);
    if(!editor||String(editor.tagName||'').toUpperCase()==='SELECT'||editor.classList?.contains?.('dateKeyboardInput'))return false;
    event.preventDefault?.();
    editor.value=parseClipboardText(text)[0]?.[0]??'';
    const ChangeEvent=root.Event;
    if(typeof ChangeEvent==='function')editor.dispatchEvent?.(new ChangeEvent('change',{bubbles:true}));
    return true;
  }
  function isPrintableKey(event){
    return String(event.key||'').length===1&&!event.ctrlKey&&!event.metaKey&&!event.altKey;
  }

  function bind(){
    if(bound||!root.document?.addEventListener)return;bound=true;
    root.document.addEventListener('dblclick',onDoubleClick,true);
    root.document.addEventListener('focusin',onEditorFocusIn,true);
    (root.addEventListener?root:root.document).addEventListener('click',onTriggerClick,true);
    // Tarayıcılar iptal edilmiş pointerdown sonrasında mousedown'ı genelde hiç
    // göndermez; gönderen sürümde de editörün odak almasını engelle.
    root.document.addEventListener('mousedown',event=>{
      if(!suppressMouseDown)return;suppressMouseDown=false;event.preventDefault();
    },true);
    root.document.addEventListener('pointerdown',event=>{
      if(event.button!==0)return;
      if(nativeEditingTarget(event.target)&&!selectInsteadOfEdit(event.target))return;
      const td=event.target?.closest?.('tbody td[data-key]'),entry=tableEntryFromCell(td);
      if(!entry||!entryIsActive(entry))return;
      const cell=cellIdentity(td);if(!cell)return;
      // Bağlantı/düğme/görsel taşıyan hücre de seçilebilir olmalı: eskiden bu
      // hedefler hiç seçilmiyordu ve model adı, sipariş kodu, görsel gibi
      // hücreler Ctrl+C ile kopyalanamıyordu. İç öğenin kendi tıklaması
      // korunur (preventDefault yok); sürükleyerek aralık seçimi başlatılmaz.
      if(event.target?.closest?.('button,a,img,label')){
        setFocus(entry,cell,{extend:event.shiftKey,focus:false});
        return;
      }
      event.preventDefault();
      if(entry.config.editOnDoubleClick){suppressMouseDown=true;setTimeout(()=>{suppressMouseDown=false;},0);}
      root.getSelection?.()?.removeAllRanges?.();
      setFocus(entry,cell,{extend:event.shiftKey});
      dragging={entry};
    },true);
    root.document.addEventListener('pointermove',event=>{
      if(!dragging)return;
      const td=event.target?.closest?.(`#${dragging.entry.tableId} tbody td[data-key]`);
      if(td)setFocus(dragging.entry,cellIdentity(td),{extend:true,focus:false});
    },true);
    root.document.addEventListener('pointerup',()=>{dragging=null;},true);
    // Ctrl+V: yalnız applyPaste tanımlayan tablolar (ör. CP) yapıştırma alır.
    root.document.addEventListener('paste',event=>{
      if(event.defaultPrevented)return;
      const text=clipboardText(event);if(!text)return;
      const target=event.target;
      if(nativeEditingTarget(target)){
        // Serbest metin/not textarea'sındaki satır sonu ve TAB karakterleri
        // hücre sınırı değildir; tarayıcının yerel yapıştırmasını koru.
        if(String(target?.tagName||'').toUpperCase()==='TEXTAREA')return;
        // Hücre düzenleyicisinde tek değer yerel olarak yapıştırılır; sekme veya
        // satır sonu içeren (Excel'den çoklu hücre) metin bu hücreden başlayarak dağıtılır.
        if(!isMultiCellText(text))return;
        const td=target.closest?.('tbody td[data-key]'),entry=tableEntryFromCell(td);
        if(!entry||!entryIsActive(entry)||typeof entry.config.applyPaste!=='function')return;
        const cell=cellIdentity(td);if(!cell)return;
        setFocus(entry,cell,{focus:false});
        void pasteEntry(entry,event,text);return;
      }
      // Birden çok tabloda aralık tutulabilir: olayın geldiği tablo,
      // arkada kalmış en son aktif aralıktan önce gelir.
      const direct=tableEntryFromCell(target?.closest?.('tbody td[data-key]'));
      const entry=direct&&entryIsActive(direct)&&direct.state.activeCell?direct:activeEntry();
      if(!entry||typeof entry.config.applyPaste!=='function')return;
      const table=root.document.getElementById(entry.tableId);
      if(target!==table&&!table?.contains?.(target)&&target!==root.document.body)return;
      if(pasteIntoSingleEditor(entry,event,text))return;
      void pasteEntry(entry,event,text);
    },true);
    root.document.addEventListener('keydown',event=>{
      if(nativeEditingTarget(event.target)){onEditorKeyDown(event);return;}
      const nativeSelection=root.getSelection?.();
      if(nativeSelection&&nativeSelection.rangeCount&&!nativeSelection.isCollapsed)return;
      const entry=activeEntry();if(!entry)return;
      const key=String(event.key||'').toLowerCase();
      // Ctrl+C varsayılanı başlıksız "Kopyala"dır (Excel davranışı). Başlıklı
      // kopya sağ tık › "Başlıklarla kopyala" ile bilerek seçilir.
      if((event.ctrlKey||event.metaKey)&&!event.altKey&&!event.shiftKey&&key==='c'){
        void copyEntry(entry,event,{includeHeaders:false});return;
      }
      const table=root.document.getElementById(entry.tableId);
      if(event.target!==table&&!table?.contains?.(event.target))return;
      if((event.ctrlKey||event.metaKey)&&!event.altKey&&!event.shiftKey&&key==='a'){
        if(selectAll(entry.tableId))event.preventDefault();return;
      }
      if(event.key==='Escape'){event.preventDefault();clear(entry.tableId);return;}
      const editMode=Boolean(entry.config.editOnDoubleClick);
      const arrows={ArrowDown:[1,0],ArrowUp:[-1,0],ArrowRight:[0,1],ArrowLeft:[0,-1]};
      if(arrows[event.key]){
        event.preventDefault();
        if(move(entry,...arrows[event.key],event.shiftKey)&&editMode&&!event.shiftKey)editActiveCell(entry);
        return;
      }
      if(event.key==='Tab'){event.preventDefault();if(move(entry,0,event.shiftKey?-1:1,false)&&editMode)editActiveCell(entry);return;}
      if(event.key==='Enter'){event.preventDefault();if(move(entry,event.shiftKey?-1:1,0,false)&&editMode)editActiveCell(entry);return;}
      if(!editMode||!entry.state.activeCell)return;
      if(event.key==='F2'){if(editActiveCell(entry,{selectAll:false,triggers:true}))event.preventDefault();return;}
      // Seçili hücrede yazmaya başlamak Excel'deki gibi düzenlemeyi açar; tuşun
      // karakteri odaklanan ve tümü seçili editöre düşer.
      if(isPrintableKey(event))editActiveCell(entry);
    },true);
  }

  function register(tableId,config){
    const existing=tables.get(tableId);
    const entry=existing||{tableId,state:{activeCell:null,selectionAnchor:null,selectionFocus:null,selectionRange:null,editingCell:null},config:{}};
    entry.config={...entry.config,...config};tables.set(tableId,entry);bind();afterRender(tableId);return entry.state;
  }

  function afterRender(tableId){
    const entry=tables.get(tableId),table=root.document?.getElementById?.(tableId);if(!entry||!table)return;
    const data=currentRange(entry);
    const label=typeof entry.config.label==='function'?entry.config.label():entry.config.label;
    table.setAttribute('role','grid');table.setAttribute('tabindex','0');table.setAttribute('aria-multiselectable','true');
    table.setAttribute('aria-rowcount',String(data.rows.length+1));table.setAttribute('aria-colcount',String(data.columns.length));
    if(label)table.setAttribute('aria-label',identity(label));
    table.querySelectorAll('thead th[data-k]').forEach((th,index)=>{th.setAttribute('role','columnheader');th.setAttribute('aria-colindex',String(index+1));});
    table.querySelectorAll('tbody tr[data-id]').forEach((tr,rowIndex)=>{
      tr.setAttribute('role','row');tr.setAttribute('aria-rowindex',String(rowIndex+2));
      tr.querySelectorAll('td[data-key]').forEach((td,columnIndex)=>{
        const id=cellIdentity(td);td.id=id?cellDomId(tableId,id.rowId,id.columnId):'';
        td.setAttribute('role','gridcell');td.setAttribute('aria-rowindex',String(rowIndex+2));td.setAttribute('aria-colindex',String(columnIndex+1));td.setAttribute('aria-selected','false');
      });
    });
    entry.state.selectionRange=data.range;
    if(entry.state.activeCell&&!resolveRange(entry.state.activeCell,entry.state.activeCell,{rows:data.rows,columns:data.columns,rowId:entry.config.rowId,columnId:entry.config.columnId})){
      entry.state.activeCell=entry.state.selectionAnchor=entry.state.selectionFocus=entry.state.selectionRange=null;
    }
    paint(entry);
  }

  function clear(tableId){
    const entry=tables.get(tableId);if(!entry)return;
    entry.state.activeCell=entry.state.selectionAnchor=entry.state.selectionFocus=entry.state.selectionRange=entry.state.editingCell=null;
    const table=root.document?.getElementById?.(tableId);clearPaint(table);table?.removeAttribute?.('aria-activedescendant');
  }

  function copyActive(event,options){const entry=activeEntry();return entry?copyEntry(entry,event,options):false;}
  function state(tableId){return tables.get(tableId)?.state||null;}
  function restoreActive(tableId,cell){
    const entry=tables.get(tableId);if(!entry||!cell)return false;
    const data=currentRange(entry);
    if(!resolveRange(cell,cell,{rows:data.rows,columns:data.columns,rowId:entry.config.rowId,columnId:entry.config.columnId}))return false;
    return setFocus(entry,cell,{focus:false});
  }

  return {editActiveCell:tableId=>editActiveCell(tables.get(tableId)),resolveRange,buildMatrix,selectionSize,edgeClassesForCell,serialize,createDiagnostics,diagnostics,nativeEditingTarget,withNativeSelection,parseClipboardText,isMultiCellText,planPaste,register,afterRender,clear,copyActive,selectAll,state,restoreActive,prepareContextMenu};
});
