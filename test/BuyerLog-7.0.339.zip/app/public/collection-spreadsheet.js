(function(global){
  'use strict';
  const Engine=global.BLCollectionSpreadsheetEngine;
  const state={active:null,anchor:null,focus:null,editingCell:null,pendingPointerEdit:null,dragging:false,wholeRowSelection:false,multiCells:new Set(),cellIntent:0,rowIntent:0,dragOrigin:null,lastRender:null,lastCopyHeaderLine:'',lastCopyRaw:null,menu:null,menuOutsideHandler:null,enabled:true,businessSelectedCount:0,cellRows:[],coordByCell:new WeakMap(),rowById:new Map(),headerByKey:new Map(),letterCells:[],paintedCells:new Set(),paintedHeader:null,paintedRowNumber:null};
  const bridge=()=>global.BLCollectionSpreadsheetBridge;
  const q=id=>document.getElementById(id);
  const lang=()=>document.documentElement.lang==='en'?'en':'tr';
  function grid(){return q('kolTable');}
  /* "En son yapılan seçim kazanır": hücre/aralık seçimi ve satır kutusu
     işaretleme aynı sayaçtan sıra numarası alır. Ctrl+C, işaretli model varken
     bile kullanıcı ondan SONRA bir hücre seçtiyse hücreyi kopyalar; kutu
     işaretlemek ise hücre seçimini temizleyip satırları hedef yapar. */
  let intentSeq=0;
  const nextIntent=()=>++intentSeq;
  function cellSelectionWins(){return Boolean(state.active)&&state.cellIntent>state.rowIntent;}
  function domToken(value){return encodeURIComponent(String(value??'')).replace(/%/g,'_');}
  function cellDomId(rowId,key){return `bl-grid-kolTable-${domToken(rowId)}-${domToken(key)}`;}
  function isCollectionActive(){return (document.body.dataset.activeTab||document.querySelector('nav.tabs button.active')?.dataset.tab||'')==='koleksiyon';}
  /* v7.81 — ÖLÇÜLEN HATA: bu kontrol VARLIĞA bakıyordu, GÖRÜNÜRLÜĞE değil.
     index.html üç adet [role="dialog"][aria-modal="true"] öğesini statik olarak
     taşıyor (lflScenarioEditorDialog, ocCompareCard, ocFxCard). Üçü de 'hidden'
     bir sarmalayıcının içinde; querySelector ise CSS'i ve ata 'hidden'ını
     umursamadığı için modalOpen() KALICI OLARAK true dönüyordu. Sonuç: bu
     kapıdan geçen her şey Koleksiyon'da ölüydü — Ctrl+C (handleCopyShortcut),
     Ctrl+V (paste dinleyicisi), ok tuşları ve yazarak düzenleme. İşaretçiyle
     çoklu seçim modalOpen()'a bakmadığı için çalışmaya devam ediyordu; kullanıcının
     "seçebiliyorum ama kopyalayamıyorum" tarifi tam olarak bu.
     getClientRects() ata display:none'ı da hesaba katar ve position:fixed
     pencerelerde offsetParent'in aksine doğru çalışır.
     v7.0.290 — ikinci ölçülen hata: ortak detay çekmecesi (BLDetailDrawer)
     kapanınca paneli DOM'da, ekran DIŞINA kaydırılmış (translateX) ve
     aria-hidden bir sarmalayıcı içinde bırakıyor. getClientRects() bunu da
     "görünür" sayıyordu; herhangi bir detay raporu bir kez açılıp kapandıktan
     sonra Koleksiyon'da Ctrl+C/Ctrl+V/ok tuşları yine ölüyordu ("bazen
     kopyalayamıyorum"). aria-hidden/inert ata ve görüntü alanı dışı da kapalı. */
  function modalVisible(el){if(!(el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden'))return false;if(el.closest?.('[aria-hidden="true"],[inert]'))return false;const r=el.getBoundingClientRect?.(),w=global.innerWidth,h=global.innerHeight;return !(r&&w&&h&&(r.right<=0||r.bottom<=0||r.left>=w||r.top>=h));}
  function modalOpen(){return [...document.querySelectorAll('[role="dialog"][aria-modal="true"],.warnOverlay,.kolSpreadsheetPasteOverlay')].some(modalVisible);}
  function visibleCells(){return state.cellRows;}
  function rebuildGridCache(){
    state.cellRows=[];state.coordByCell=new WeakMap();state.rowById=new Map();state.headerByKey=new Map();state.letterCells=[];
    const sourceRows=bridge()?.rows?.()||[];sourceRows.forEach(row=>state.rowById.set(String(row.id),row));
    [...document.querySelectorAll('#kolTable tbody tr')].forEach((tr,r)=>{const cells=[...tr.cells].filter(td=>td.dataset.key);cells.forEach((td,c)=>{const coord={r,c,rowId:String(tr.dataset.id||''),key:String(td.dataset.key||''),td};td.dataset.sheetR=String(r);td.dataset.sheetC=String(c);state.coordByCell.set(td,coord);});state.cellRows.push(cells);});
    document.querySelectorAll('#kolTable thead tr.colRow th[data-kcol]').forEach(th=>state.headerByKey.set(String(th.dataset.kcol),th));const pic=q('kolPicTh');if(pic)state.headerByKey.set('__picture__',pic);
    state.letterCells=[...document.querySelectorAll('#kolTable thead .kolSpreadsheetLetter')];
  }
  function coordForCell(td){if(!td)return null;const cached=state.coordByCell.get(td);if(cached)return cached;const r=Number(td.dataset.sheetR),c=Number(td.dataset.sheetC);if(Number.isInteger(r)&&Number.isInteger(c))return {r,c,rowId:String(td.closest('tr')?.dataset.id||''),key:String(td.dataset.key||''),td};return null;}
  // Renderer-independent event -> Collection data-cell resolver. Native form
  // controls, wrappers and custom formatted content all resolve through the td;
  // composedPath is a defensive fallback for retargeted DOM events.
  function collectionDataCellFromEvent(event){const target=event?.target,closest=target?.closest?.('#kolTable tbody td[data-key]');if(closest)return closest;const path=typeof event?.composedPath==='function'?event.composedPath():[];return path.find(node=>node?.matches?.('#kolTable tbody td[data-key]'))||null;}
  function cellAt(r,c){return state.cellRows[r]?.[c]||null;}
  function clearClasses(){for(const el of state.paintedCells){el?.classList?.remove('kolSpreadsheetActiveCell','kolSpreadsheetRangeCell','kolSpreadsheetRangeEdge');el?.setAttribute?.('aria-selected','false');}state.paintedCells.clear();state.paintedHeader?.classList?.remove('kolSpreadsheetActiveHeader');state.paintedHeader=null;state.paintedRowNumber?.classList?.remove('isActive');state.paintedRowNumber=null;state.letterCells.forEach(el=>el.classList.remove('kolSpreadsheetLetterActive'));}
  function liveRowSnapshot(){const map=new Map(),rows=bridge()?.rows?.();if(Array.isArray(rows))rows.forEach(row=>{if(row&&row.id!=null)map.set(String(row.id),row);});return map;}
  function valueForCoord(coord,liveRows=null){if(!coord)return '';if(coord.td?.dataset?.kolGroupSummary==='1')return coord.td.dataset.kolSummaryDisplay??'';const liveSelect=coord.td?.querySelector?.('select.editCell:not(:disabled)');if(liveSelect&&(!liveSelect.dataset?.k||String(liveSelect.dataset.k)===String(coord.key)))return liveSelect.value??'';const row=liveRows?.get(String(coord.rowId))||state.rowById.get(String(coord.rowId));const raw=bridge()?.rawValue?.(row,coord.key)??'';return coord.key==='fabric'&&typeof global.kolFabricDisplay==='function'?global.kolFabricDisplay(raw):raw;}
  /* Kumaş hücresinin ham PLM metni ("3859-Süprem …"): uygulama içi yapıştırma ve
     Ctrl+D bununla kartı korur; panoya Excel için görünen özet yazılır. */
  function rawFabricValueForCoord(coord,liveRows=null){if(coord?.key!=='fabric'||coord.td?.dataset?.kolGroupSummary==='1')return valueForCoord(coord,liveRows);const row=liveRows?.get(String(coord.rowId))||state.rowById.get(String(coord.rowId));return bridge()?.rawValue?.(row,coord.key)??'';}
  function metadata(coord){return coord?bridge()?.columnMeta?.(coord.key):null;}
  function setEditing(td,on){if(state.editingCell&&state.editingCell!==td)state.editingCell.classList.remove('kolSpreadsheetEditing');state.editingCell=on?td:null;if(td)td.classList.toggle('kolSpreadsheetEditing',Boolean(on));}
  // Collection floating editors (catalog dropdown/date picker/period drawer) live outside
  // the table DOM. Closing only the td editing class leaves those surfaces orphaned
  // when spreadsheet pointer navigation changes the active cell. Keep one canonical
  // editor-exit path and invoke it before every real active-cell transition.
  function closeCurrentCellEditor(nextCoord=null,{force=false,preservePending=false}={}){
    const current=state.active;
    if(!force&&sameCellIdentity(current,nextCoord))return false;
    try{global.BLCollectionCellEditorLifecycle?.close?.({nextCell:force?null:(nextCoord?.td||null)});}catch(_){}
    if(state.editingCell)state.editingCell.classList.remove('kolSpreadsheetEditing');
    state.editingCell=null;
    if(!preservePending&&state.pendingPointerEdit&&!sameCellIdentity(state.pendingPointerEdit,nextCoord))state.pendingPointerEdit=null;
    return true;
  }
  function clearActive(){
    closeCurrentCellEditor(null,{force:true});
    state.active=null;state.anchor=null;state.focus=null;state.multiCells.clear();clearClasses();grid()?.removeAttribute?.('aria-activedescendant');updateStatus();updatePasteButton();
  }
  function clearActiveIfMatches(rowId,key){
    if(!state.active||String(state.active.rowId)!==String(rowId)||String(state.active.key)!==String(key))return false;
    clearActive();return true;
  }
  // Escape düzenlemeden çıkar ama hücreyi SEÇİLİ bırakır (Excel). Eskiden seçim
  // tamamen siliniyordu; Escape'ten hemen sonra Ctrl+C hiçbir şey kopyalamıyor ya
  // da işaretli modellere düşüyordu. İkinci Escape (ızgara modunda) seçimi temizler.
  function endEdit(){closeCurrentCellEditor(null,{force:true});state.pendingPointerEdit=null;state.cellIntent=nextIntent();paint();grid()?.focus?.({preventScroll:true});}
  function updateSelectedCount(){const n=bridge()?.selectedCount?.()||0;state.businessSelectedCount=n;const el=q('kolSelectedCount');if(el)el.textContent=lang()==='en'?`${n} models selected`:`${n} model seçili`;const helper=q('kolSpreadsheetHelper');if(helper)helper.dataset.selected=String(n);}
  function updatePasteButton(){const btn=q('kolSpreadsheetPasteBtn');if(!btn)return;const api=Boolean(navigator.clipboard&&typeof navigator.clipboard.readText==='function');btn.disabled=!api||!state.active||!bridge()?.canEdit?.();btn.title=!api?(lang()==='en'?'Clipboard button is unavailable; use Ctrl+V.':'Pano butonu kullanılamıyor; Ctrl+V kullanın.'):(lang()==='en'?'Paste from Excel or clipboard into the active cell':'Excel veya panodan aktif hücreye yapıştır');}
  function selectionToken(coord){return coord?`${coord.rowId}\u0000${coord.key}`:'';}
  function selectedMatrix(liveRows=null){const rows=visibleCells(),multi=state.multiCells.size>0,coordinates=multi?rows.flatMap(line=>line.map(td=>coordForCell(td)).filter(coord=>state.multiCells.has(selectionToken(coord)))):[],bounds=multi&&coordinates.length?{r1:Math.min(...coordinates.map(c=>c.r)),r2:Math.max(...coordinates.map(c=>c.r)),c1:Math.min(...coordinates.map(c=>c.c)),c2:Math.max(...coordinates.map(c=>c.c))}:Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);if(!bounds)return {bounds:null,matrix:[],rawMatrix:[]};const matrix=[],rawMatrix=[];for(let r=bounds.r1;r<=bounds.r2;r++){const line=[],rawLine=[];for(let c=bounds.c1;c<=bounds.c2;c++){const td=rows[r]?.[c],coord=td&&coordForCell(td),included=td&&(!multi||state.multiCells.has(selectionToken(coord))),value=included?valueForCoord(coord,liveRows):'';line.push(value);rawLine.push(included&&coord.key==='fabric'?rawFabricValueForCoord(coord,liveRows):(included&&coord.key==='trLanded'&&bridge()?.landedCopyToken?bridge().landedCopyToken(coord.rowId):value));}matrix.push(line);rawMatrix.push(rawLine);}return {bounds,matrix,rawMatrix};}

  /* Başlık etiketi tek yerden üretilir: kopyalama bunu panoya yazar,
     yapıştırma da gelen ilk satırın başlık olup olmadığını bununla tanır. */
  function headerLabelFor(key){const meta=bridge()?.columnMeta?.(key);return meta?.label||state.headerByKey.get(key)?.textContent?.replace(/[▲▼▾]/g,'').replace(/\s+/g,' ').trim()||key;}
  function knownHeaderLabels(){const set=new Set();for(const td of (state.cellRows[0]||[])){const label=headerLabelFor(td?.dataset?.key||'');if(label)set.add(String(label).trim().toLowerCase());}return set;}
  /* UYGULAMA İÇİ YAPIŞTIRMA: kopyalama başlık satırını da yazdığı için
     E2:G4 kopyalayıp başka hücrelere yapıştırıldığında başlıklar veri
     olarak hücrelere giriyordu. İki kademeli tanıma:
       1) Panodaki ilk satır, en son bu uygulamadan kopyalanan başlık
          satırının BİREBİR aynısıysa (aynı oturum, en güvenilir kanıt),
       2) ya da ilk satırın her hücresi tablonun bilinen bir sütun
          başlığıysa (sayfa yenilendikten veya başka sekmeden sonra).
     Tek satırlık veriye dokunulmaz; başlığı ayıklayınca yapıştıracak
     veri kalmayacaksa da ayıklama yapılmaz. */
  function stripCopiedHeaderRow(matrix,text){
    if(matrix.length<2)return matrix;
    const first=(matrix[0]||[]).map(v=>String(v==null?'':v).trim());
    if(!first.length)return matrix;
    const copied=state.lastCopyHeaderLine;
    if(copied&&String(text==null?'':text).split(/\r?\n/)[0].trim()===copied.trim())return matrix.slice(1);
    const labels=knownHeaderLabels();
    if(labels.size&&first.every(v=>v&&labels.has(v.toLowerCase())))return matrix.slice(1);
    return matrix;
  }
  /* Kumaş hücresi panoya Excel için kart özetiyle yazılır ("Single Jersey · …");
     özet kumaş kodunu taşımadığından uygulama içi yapıştırma bu metni ham
     değer olarak kaydedince kart kayboluyordu. Kopyalanan ham PLM metni
     hafızada tutulur; panodan aynı metin geri yapıştırıldığında ham değer
     yazılır ve kart korunur. */
  function clipboardKey(text){return String(text==null?'':text).replace(/\r\n?/g,'\n').replace(/\n+$/,'');}
  function sameMatrix(a,b){return a.length===b.length&&a.every((line,r)=>line.length===b[r]?.length&&line.every((value,c)=>String(value??'')===String(b[r][c]??'')));}
  function selectedClipboard(includeHeaders=true){const {bounds,matrix,rawMatrix}=selectedMatrix(liveRowSnapshot());if(!bounds||!matrix.length)return null;const headers=[];for(let c=bounds.c1;c<=bounds.c2;c++){const td=state.cellRows[bounds.r1]?.[c]||state.cellRows.find(row=>row[c])?.[c],key=td?.dataset?.key||'';headers.push(headerLabelFor(key));}const keepRaw=!sameMatrix(matrix,rawMatrix);const exporter=global.BLTableExport;if(!exporter)return {plain:Engine.tsv(includeHeaders?[headers,...matrix]:matrix),html:'',count:matrix.length*headers.length,rawPlain:keepRaw?Engine.tsv(includeHeaders?[headers,...rawMatrix]:rawMatrix):''};const rows=matrix.map(row=>row.map(exporter.normalizeCell)),safe={headers:headers.map(exporter.normalizeCell),rows,rawRows:rows,recordCount:rows.length,columnCount:headers.length},plain=includeHeaders?exporter.toTSV(safe):exporter.toTSV(safe,{includeHeaders:false}),html=includeHeaders?exporter.toSafeHTML(safe):exporter.toSafeHTML(safe,{includeHeaders:false});let rawPlain='';if(keepRaw){const rawRows=rawMatrix.map(row=>row.map(exporter.normalizeCell)),rawSafe={...safe,rows:rawRows,rawRows};rawPlain=includeHeaders?exporter.toTSV(rawSafe):exporter.toTSV(rawSafe,{includeHeaders:false});}return {plain,html,count:safe.recordCount*safe.columnCount,includeHeaders,rawPlain};}
  function rememberCopiedRaw(payload){state.lastCopyRaw=payload?.rawPlain?{key:clipboardKey(payload.plain),plain:payload.rawPlain}:null;}
  function restoreCopiedRaw(text){const memo=state.lastCopyRaw;return memo&&clipboardKey(text)===memo.key?memo.plain:text;}
  function updateStatus(){const el=q('kolSpreadsheetStatusBar');if(!el)return;const visibleCount=Array.isArray(state.lastRender?.rows)?state.lastRender.rows.length:state.cellRows.length,business=state.businessSelectedCount,{bounds,matrix}=selectedMatrix(),stats=Engine.selectionStats(matrix,bridge()?.parseNumber),rows=bounds?bounds.r2-bounds.r1+1:0,columns=bounds?bounds.c2-bounds.c1+1:0;const bits=[`<span><b>${visibleCount}</b> ${lang()==='en'?'Models':'Model'}</span>`,`<span>${lang()==='en'?'Selected':'Seçili'} <b>${business}</b></span>`];if(stats.count>0){bits.push(`<span>${lang()==='en'?'Range':'Alan'} <b>${rows}×${columns}</b></span>`);bits.push(`<span>Count <b>${stats.count}</b></span>`);if(stats.numericCount){bits.push(`<span>Sum <b>${formatNumber(stats.sum)}</b></span>`);bits.push(`<span>Average <b>${formatNumber(stats.average)}</b></span>`);}}el.innerHTML=bits.join('');}
  function formatNumber(n){if(!Number.isFinite(Number(n)))return '—';return Number(n).toLocaleString(lang()==='en'?'en-GB':'tr-TR',{maximumFractionDigits:2});}
  function paint(){clearClasses();if(!state.active){grid()?.removeAttribute?.('aria-activedescendant');updateStatus();updatePasteButton();return;}const active=cellAt(state.active.r,state.active.c);if(active){active.id=active.id||cellDomId(state.active.rowId,state.active.key);grid()?.setAttribute?.('aria-activedescendant',active.id);active.classList.add('kolSpreadsheetActiveCell');active.setAttribute('aria-selected','true');state.paintedCells.add(active);state.paintedRowNumber=active.closest('tr')?.querySelector('.kolSpreadsheetRowNumber')||null;state.paintedRowNumber?.classList.add('isActive');state.paintedHeader=state.headerByKey.get(state.active.key)||null;state.paintedHeader?.classList.add('kolSpreadsheetActiveHeader');state.letterCells[state.active.c]?.classList.add('kolSpreadsheetLetterActive');}
    const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);if(state.multiCells.size){for(const row of state.cellRows)for(const td of row){const coord=coordForCell(td);if(!state.multiCells.has(selectionToken(coord)))continue;td.classList.add('kolSpreadsheetRangeCell');state.paintedCells.add(td);td.classList.add('kolSpreadsheetRangeEdge');}}else if(bounds){for(const pos of Engine.cellsInRange(bounds)){const td=cellAt(pos.r,pos.c);if(!td)continue;td.classList.add('kolSpreadsheetRangeCell');state.paintedCells.add(td);if(pos.r===bounds.r1||pos.r===bounds.r2||pos.c===bounds.c1||pos.c===bounds.c2)td.classList.add('kolSpreadsheetRangeEdge');}}
    updateStatus();updatePasteButton();
  }
  function ensureCellVisible(td){const wrap=td?.closest?.('.tablewrap');if(!td||!wrap)return;const cellRect=td.getBoundingClientRect(),wrapRect=wrap.getBoundingClientRect();if(cellRect.left<wrapRect.left||cellRect.right>wrapRect.right||cellRect.top<wrapRect.top||cellRect.bottom>wrapRect.bottom)td.scrollIntoView({block:'nearest',inline:'nearest'});}
  function setActive(td,{extend=false,focusGrid=true}={}){const coord=coordForCell(td);if(!coord)return false;closeCurrentCellEditor(coord);state.wholeRowSelection=false;state.cellIntent=nextIntent();if(!extend){state.anchor=coord;state.focus=coord;}else{if(!state.anchor)state.anchor=state.active||coord;state.focus=coord;}state.active=coord;paint();if(focusGrid)grid()?.focus({preventScroll:true});ensureCellVisible(td);return true;}
  function prepareCellContext(td){const coord=coordForCell(td);if(!coord)return false;const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);const inMulti=state.multiCells.size>0&&state.multiCells.has(selectionToken(coord));const inRange=state.multiCells.size?inMulti:Boolean(bounds&&coord.r>=bounds.r1&&coord.r<=bounds.r2&&coord.c>=bounds.c1&&coord.c<=bounds.c2);if(!inRange)setActive(td,{focusGrid:false});return true;}
  function move(dr,dc,{extend=false}={}){if(!state.active){const first=cellAt(0,0);return first?setActive(first):false;}const rows=visibleCells();let r=Math.max(0,Math.min(rows.length-1,state.active.r+dr)),c=Math.max(0,Math.min((rows[r]?.length||1)-1,state.active.c+dc));const td=cellAt(r,c);return td?setActive(td,{extend}):false;}
  function moveTab(dir){
    const rows=visibleCells();if(!state.active||!rows.length)return false;
    let r=state.active.r,c=state.active.c;const editableOnly=Boolean(bridge()?.canEdit?.());
    const maxSteps=rows.reduce((n,row)=>n+row.length,0);
    for(let step=0;step<maxSteps;step++){
      c+=dir;
      if(c>=rows[r].length){r++;c=0;}
      if(c<0){r--;if(r>=0)c=rows[r].length-1;}
      if(r<0||r>=rows.length)return false;
      const td=cellAt(r,c);if(!td)continue;
      if(!editableOnly||bridge()?.columnMeta?.(td.dataset.key)?.editable)return setActive(td);
    }
    return false;
  }
  function editorNativeSelection(editor){if(!editor)return false;if((editor.tagName==='INPUT'||editor.tagName==='TEXTAREA')&&Number.isInteger(editor.selectionStart)&&Number.isInteger(editor.selectionEnd))return editor.selectionStart!==editor.selectionEnd;const sel=global.getSelection?.();return Boolean(sel&&sel.rangeCount&&!sel.isCollapsed&&editor.contains?.(sel.anchorNode));}
  function focusEditor(editor,{selectAll=true,caretEnd=false}={}){if(!editor)return false;editor.focus({preventScroll:true});if(selectAll){editor.select?.();return true;}if(caretEnd&&(editor.tagName==='INPUT'||editor.tagName==='TEXTAREA')&&typeof editor.setSelectionRange==='function'){try{const end=String(editor.value??'').length;editor.setSelectionRange(end,end);}catch(_){}}return true;}
  function beginEdit(td=state.active?.td,{source='keyboard',selectAll=source!=='pointer',caretEnd=source==='pointer'}={}){if(!td||!bridge()?.canEdit?.())return false;const meta=bridge()?.columnMeta?.(td.dataset.key);if(!meta?.editable)return false;td.classList.add('kolSpreadsheetEditing');state.editingCell=td;const date=td.querySelector('.kolDateDisplay');if(date){bridge()?.enterDateEdit?.(date);setTimeout(()=>{const editor=td.querySelector('.editCell:not(:disabled)');if(editor)focusEditor(editor,{selectAll,caretEnd});},0);return true;}const editor=td.querySelector('.editCell:not(:disabled)');if(!editor)return false;return focusEditor(editor,{selectAll,caretEnd});}
  function pointerEditIdentity(td){const coord=coordForCell(td);return coord?{rowId:coord.rowId,key:coord.key}:null;}
  function sameCellIdentity(a,b){return Boolean(a&&b&&String(a.rowId)===String(b.rowId)&&String(a.key)===String(b.key));}
  function findCellByIdentity(identity){if(!identity)return null;const tr=[...document.querySelectorAll('#kolTable tbody tr')].find(row=>String(row.dataset.id||'')===String(identity.rowId));return tr?.querySelector(`td[data-key="${selectorValue(identity.key)}"]`)||null;}
  function markPointerEditing(td){const coord=coordForCell(td);if(!coord)return false;closeCurrentCellEditor(coord);state.multiCells.clear();state.cellIntent=nextIntent();state.active=coord;state.anchor=coord;state.focus=coord;setEditing(td,true);paint();ensureCellVisible(td);return true;}
  function schedulePendingPointerFallback(identity,editorKey=''){setTimeout(()=>{if(!sameCellIdentity(state.pendingPointerEdit,identity))return;const activeEditor=document.activeElement?.closest?.('#kolTable .editCell');if(activeEditor){const current=pointerEditIdentity(activeEditor.closest('td[data-key]'));if(sameCellIdentity(current,identity)){state.pendingPointerEdit=null;return;}}const td=findCellByIdentity(identity);state.pendingPointerEdit=null;if(td){const editor=editorKey&&td.querySelector(`.editCell[data-k="${selectorValue(editorKey)}"]:not(:disabled)`);markPointerEditing(td);if(editor&&bridge()?.columnMeta?.(editorKey)?.editable&&bridge()?.canEdit?.()){focusEditor(editor,{selectAll:false,caretEnd:true});return;}beginEdit(td,{source:'pointer',selectAll:false,caretEnd:true});}},0);}
  function kolSpreadsheetHandlePointerEdit(event,td){const meta=bridge()?.columnMeta?.(td.dataset.key),editable=Boolean(meta?.editable&&bridge()?.canEdit?.()),directEditor=event.target.closest?.('.editCell:not(:disabled)')||event.target.closest?.('label')?.querySelector?.('.editCell:not(:disabled)'),editorEditable=Boolean(directEditor&&bridge()?.columnMeta?.(directEditor.dataset.k)?.editable&&bridge()?.canEdit?.());if(event.ctrlKey||event.metaKey){const coord=coordForCell(td),token=selectionToken(coord);closeCurrentCellEditor(coord);if(!state.multiCells.size&&state.active)seedMultiFromRange();if(state.multiCells.has(token)&&state.multiCells.size>1)state.multiCells.delete(token);else state.multiCells.add(token);state.wholeRowSelection=false;state.cellIntent=nextIntent();state.active=coord;state.anchor=coord;state.focus=coord;state.pendingPointerEdit=null;event.preventDefault();event.stopImmediatePropagation();paint();grid()?.focus({preventScroll:true});return true;}if(event.shiftKey){state.multiCells.clear();state.pendingPointerEdit=null;event.preventDefault();event.stopImmediatePropagation();setActive(td,{extend:true});return true;}if(!directEditor&&event.target===td){state.pendingPointerEdit=null;event.preventDefault();event.stopImmediatePropagation();state.multiCells.clear();setActive(td);state.dragging=true;return true;}if(!editable){if(!editorEditable){state.pendingPointerEdit=null;event.preventDefault();event.stopImmediatePropagation();setActive(td);return true;}}const identity=pointerEditIdentity(td);state.pendingPointerEdit=identity;markPointerEditing(td);state.dragging=true;state.dragOrigin=identity;if(directEditor){schedulePendingPointerFallback(identity,directEditor.dataset.k);return true;}event.preventDefault();event.stopImmediatePropagation();beginEdit(td,{source:'pointer',selectAll:false,caretEnd:true});state.pendingPointerEdit=null;return true;}
  // Ctrl+tık ilk kez çoklu seçime geçerken mevcut hücre/aralık korunur.
  function seedMultiFromRange(){const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);if(!bounds)return;for(const pos of Engine.cellsInRange(bounds)){const cell=cellAt(pos.r,pos.c),coord=cell&&coordForCell(cell);if(coord)state.multiCells.add(selectionToken(coord));}}
  function kolSpreadsheetResumePendingPointerEdit(){const identity=state.pendingPointerEdit;if(!identity)return false;const td=findCellByIdentity(identity);if(!td){state.pendingPointerEdit=null;return false;}state.pendingPointerEdit=null;markPointerEditing(td);return beginEdit(td,{source:'pointer',selectAll:false,caretEnd:true});}
  async function writeClipboard(html,text){if(typeof global.BLCopyRichToClipboard==='function')return global.BLCopyRichToClipboard(html,text);try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true;}}catch(_){}try{const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return ok;}catch(_){return false;}}
function handleCopyShortcut(event,options={}){if(!isCollectionActive()||modalOpen())return false;
  // Satır checkbox'ıyla model işaretlemek, hücre/aralık seçiminden daha güçlü ve
  // daha güncel bir niyettir: klavye/global Copy işaretli modelleri esas alır.
  // Hücrenin kendi sağ-tık menüsündeki açık Copy komutu ise forceCellCopy ile
  // özellikle o hücre/aralığı hedefler (Excel-benzeri bağlam davranışı).
  // v7.0.290 — "en son seçim kazanır": modeller işaretliyken kullanıcı SONRADAN
  // hücre/aralık seçtiyse Ctrl+C o hücreleri kopyalar; aksi halde işaretli
  // modeller kazanır. Önceki kural işaretli model varken hiçbir hücrenin
  // kopyalanmasına izin vermiyordu ("her hücreyi kopyalayamıyorum").
  const checkedModels=bridge()?.selectedCount?.()||0;
  if(!options.forceCellCopy&&checkedModels>0&&!cellSelectionWins())return false;
  if(!state.active)return false;const target=event?.target,formControl=target?.closest?.('input,textarea,select,[contenteditable="true"]'),gridEditor=target?.closest?.('#kolTable .editCell'),selectedCellCount=state.multiCells.size||(()=>{const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);return bounds?Engine.cellsInRange(bounds).length:1;})();if(formControl&&!gridEditor)return false;if(gridEditor&&editorNativeSelection(gridEditor)&&selectedCellCount<2)return false;const includeHeaders=options.includeHeaders===true,payload=includeHeaders?selectedClipboard():selectedClipboard(false);if(!payload)return false;rememberCopiedRaw(payload);state.lastCopyHeaderLine=includeHeaders?String(payload.plain==null?'':payload.plain).split(/\r?\n/)[0]:'';event?.preventDefault?.();event?.stopImmediatePropagation?.();void writeClipboard(payload.html,payload.plain).then(ok=>{global.BLGridClipboard?.diagnostics?.record({module:'collection',operation:'copy',selection:{rows:Math.max(1,payload.count/(selectedMatrix().matrix[0]?.length||1)),columns:selectedMatrix().matrix[0]?.length||1},includeHeaders,transport:'rich',ok});const hint=ok&&checkedModels>0?(lang()==='en'?` Checked models were not copied; right-click › Copy ${checkedModels} checked model(s).`:` İşaretli modeller kopyalanmadı; sağ tık › İşaretli ${checkedModels} modeli kopyala.`):'';if(global.showToast)global.showToast(ok?(lang()==='en'?`${payload.count} cell(s) copied${includeHeaders?' with headers':''}.`:`${payload.count} hücre${includeHeaders?' başlıklarıyla':''} kopyalandı.`)+hint:(lang()==='en'?'Copy failed.':'Kopyalama başarısız.'));});return true;}
  function selectedCoordinates(){return state.cellRows.flatMap(row=>row.map(td=>coordForCell(td)).filter(coord=>state.multiCells.has(selectionToken(coord))));}
  function validatePasteAtCoord(coord,value){
    const meta=metadata(coord);
    if(meta?.col?.status){
      const select=coord.td?.querySelector?.('select.editCell');
      // Status values must be real catalog choices, not arbitrary pasted text.
      // Match both canonical option values and translated visible labels.
      const options=select?[...select.options].map(option=>({value:option.value,label:option.textContent})):[];
      const resolved=Engine.resolveSelectPasteValue(value,options);
      if(!resolved.ok)return resolved;
      value=resolved.value;
    }
    return bridge()?.validateValue?.(coord.rowId,coord.key,value);
  }
  function targetPlan(matrix){const rows=visibleCells(),active=state.active;if(!active)return null;const selected=selectedCoordinates();if(selected.length){const sourceHeight=matrix.length,sourceWidth=matrix.reduce((max,row)=>Math.max(max,Array.isArray(row)?row.length:0),0),minR=Math.min(...selected.map(c=>c.r)),minC=Math.min(...selected.map(c=>c.c)),ops=[],issues=[];let skipped=0,invalid=0,readonly=0;selected.forEach(c=>{const row=matrix[(c.r-minR)%sourceHeight]||[],value=row[(c.c-minC)%sourceWidth]??'';const result=validatePasteAtCoord(c,value);if(result?.ok)ops.push({rowId:c.rowId,key:c.key,value:result.value});else{if(result?.reason==='calculated'||result?.reason==='readonly'||result?.reason==='linked')readonly++;else invalid++;issues.push(`${Engine.columnLetter(c.c)}${c.r+1}: ${result?.reason||'invalid'}`);}});return {ops,issues,total:selected.length,skipped,invalid,readonly};}const selectedBounds=Engine.rangeBounds(state.anchor||active,state.focus||active),sourceWidth=matrix.reduce((max,row)=>Math.max(max,Array.isArray(row)?row.length:0),0),pasteBounds=state.wholeRowSelection&&selectedBounds?{...selectedBounds,c2:Math.min((rows[0]?.length||1)-1,selectedBounds.c1+Math.max(1,sourceWidth)-1)}:selectedBounds,planned=Engine.planPasteGeometry(matrix,pasteBounds),geometry=planned.mode==='mismatch'?{...planned,ok:true,mode:'anchor',mismatch:true,matrix}:planned;if(!geometry.ok)return {ops:[],issues:[],total:0,skipped:0,invalid:0,readonly:0,geometry};const source=geometry.matrix,start={r:pasteBounds.r1,c:pasteBounds.c1},ops=[],issues=[];let skipped=0,invalid=0,readonly=0,total=0;source.forEach((line,ro)=>line.forEach((value,co)=>{total++;const td=rows[start.r+ro]?.[start.c+co];if(!td){skipped++;issues.push(`${Engine.columnLetter(start.c+co)}${start.r+ro+1}: ${lang()==='en'?'outside visible grid':'görünür tablonun dışında'}`);return;}const c=coordForCell(td),result=validatePasteAtCoord(c,value);if(result?.ok){ops.push({rowId:c.rowId,key:c.key,value:result.value});return;}if(result?.reason==='calculated'||result?.reason==='readonly'||result?.reason==='linked'){readonly++;}else{invalid++;}issues.push(`${Engine.columnLetter(c.c)}${c.r+1}: ${result?.reason||'invalid'}`);}));return {ops,issues,total,skipped,invalid,readonly,geometry};}
  function pasteModeLabel(mode){const en=lang()==='en',labels={anchor:en?'from top-left cell':'sol üst hücreden',fill:en?'fill selection':'seçimi doldur',exact:en?'exact size':'birebir boyut',tile:en?'repeat pattern':'deseni tekrarla'};return labels[mode]||(en?'selected cells':'seçili hücreler');}
  function pastePreview(plan,{kind='paste'}={}){return new Promise(resolve=>{document.querySelector('.kolSpreadsheetPasteOverlay')?.remove();const summary=Engine.pasteSummary(plan),overlay=document.createElement('div');overlay.className='kolSpreadsheetPasteOverlay';overlay.innerHTML=`<div class="kolSpreadsheetPasteCard" role="dialog" aria-modal="true" aria-labelledby="kolPastePreviewTitle" tabindex="-1"><div class="kolSpreadsheetPasteHead"><b id="kolPastePreviewTitle">${kind==='clear'?(lang()==='en'?'Clear Preview':'Temizleme Önizlemesi'):kind==='fill'?(lang()==='en'?'Fill Down Preview':'Aşağı Doldurma Önizlemesi'):(lang()==='en'?'Paste Preview':'Yapıştırma Önizlemesi')}</b><span>${escapeHtmlLocal(summary.source.rows&&summary.source.columns?`${summary.source.rows}×${summary.source.columns}`:'—')} → ${escapeHtmlLocal(summary.target.rows&&summary.target.columns?`${summary.target.rows}×${summary.target.columns}`:`${plan.total} ${lang()==='en'?'cells':'hücre'}`)} · ${escapeHtmlLocal(pasteModeLabel(summary.mode))}</span></div><div class="kolSpreadsheetPasteBody">${plan.geometry?.mismatch?`<div class="kolSpreadsheetPasteIssues">${lang()==='en'?'The copied size does not match the selection; data is pasted starting from the top-left selected cell.':'Kopyalanan boyut seçimle eşleşmiyor; veri seçimin sol üst hücresinden başlayarak yapıştırılır.'}</div>`:''}<div class="kolSpreadsheetPasteMetric"><b>${summary.changed}</b><span>${lang()==='en'?'cells will be updated':'hücre güncellenecek'}</span></div><div class="kolSpreadsheetPasteMetric"><b>${summary.readonly}</b><span>${lang()==='en'?'calculated/read-only skipped':'hesaplanan/salt-okunur atlanacak'}</span></div><div class="kolSpreadsheetPasteMetric"><b>${summary.invalid}</b><span>${lang()==='en'?'invalid values':'geçersiz değer'}</span></div><div class="kolSpreadsheetPasteMetric"><b>${summary.skipped}</b><span>${lang()==='en'?'outside-grid skipped':'tablo dışı atlanacak'}</span></div>${plan.issues.length?`<div class="kolSpreadsheetPasteIssues">${plan.issues.slice(0,20).map(x=>`<div>${escapeHtmlLocal(x)}</div>`).join('')}</div>`:''}</div><div class="kolSpreadsheetPasteFoot"><button class="tbtn" data-cancel>${lang()==='en'?'Cancel':'Vazgeç'}</button><button class="tbtn primary" data-apply ${plan.ops.length?'':'disabled'}>${lang()==='en'?'Apply':'Uygula'}</button></div></div>`;const onKey=e=>{if(e.key==='Escape')done(false)};const done=v=>{document.removeEventListener('keydown',onKey,true);overlay.remove();resolve(v)};overlay.querySelector('[data-cancel]').onclick=()=>done(false);overlay.querySelector('[data-apply]').onclick=()=>done(true);overlay.addEventListener('click',e=>{if(e.target===overlay)done(false)});document.addEventListener('keydown',onKey,true);document.body.appendChild(overlay);overlay.querySelector('.kolSpreadsheetPasteCard')?.focus();});}
  function escapeHtmlLocal(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
  function isSingleCellPasteTarget(){if(selectedCoordinates().length||state.wholeRowSelection)return false;const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);return !bounds||(bounds.r1===bounds.r2&&bounds.c1===bounds.c2);}
  async function pasteText(text){if(!state.active||!bridge()?.canEdit?.())return false;text=restoreCopiedRaw(text);const scalarPaste=!/\t/.test(text)&&isSingleCellPasteTarget();const matrix=scalarPaste?[[Engine.normalizeSingleCellPasteText(text)]]:stripCopiedHeaderRow(Engine.parseClipboardMatrix(text),text);return applyMatrix(matrix);}
  async function applyMatrix(matrix,{kind='paste',excludeRowId=null}={}){if(!state.active||!bridge()?.canEdit?.()||!matrix.length)return false;const plan=targetPlan(matrix);if(plan&&excludeRowId!=null){const before=plan.ops.length;plan.ops=plan.ops.filter(op=>String(op.rowId)!==String(excludeRowId));plan.total=Math.max(0,plan.total-(before-plan.ops.length));}if(plan?.geometry&&!plan.geometry.ok){const c=plan.geometry.clipboard,s=plan.geometry.selection;global.showToast?.(lang()==='en'?`Pasted data is ${c.rows}×${c.columns}; selected range is ${s.rows}×${s.columns}.`:`Yapıştırılan veri ${c.rows}×${c.columns}, seçili alan ${s.rows}×${s.columns}.`);return false;}if(!plan||!plan.ops.length){global.showToast?.(plan?.invalid?(lang()==='en'?'Invalid value for the target column; nothing was changed.':'Hedef sütun için geçersiz değer; hiçbir veri değiştirilmedi.'):(lang()==='en'?'Nothing editable to paste.':'Yapıştırılabilecek düzenlenebilir hücre yok.'));return false;}const summary=Engine.pasteSummary(plan),multi=plan.total>1||plan.invalid||plan.readonly||plan.skipped;if(bridge()?.previewBatch){const result=await bridge().previewBatch(plan.ops,{...summary,source:kind});if(result?.ok)restoreActiveAfterRender();return Boolean(result?.ok);}if(multi&&!(await pastePreview(plan,{kind})))return false;const result=bridge()?.batchEdit?.(plan.ops,summary);if(result?.ok){const skipped=summary.readonly?` · ${summary.readonly} ${lang()==='en'?'read-only skipped':'salt okunur atlandı'}`:'',rows=result.updatedRows||new Set(plan.ops.map(op=>String(op.rowId))).size;global.BLGridClipboard?.diagnostics?.record({module:'collection',operation:'paste',selection:summary.target,source:summary.source,mode:summary.mode,changed:result.changed,readonly:summary.readonly,invalid:summary.invalid,skipped:summary.skipped,ok:true});global.showToast?.((kind==='clear'?(lang()==='en'?`${result.changed} cell(s) cleared across ${rows} row(s); one undo will revert it.`:`${result.changed} hücre ${rows} satırda temizlendi; tek geri alma işlemi geri alır.`):kind==='fill'?(lang()==='en'?`${result.changed} cell(s) filled down across ${rows} row(s); one undo will revert it.`:`${result.changed} hücre ${rows} satırda aşağı dolduruldu; tek geri alma işlemi geri alır.`):(lang()==='en'?`${result.changed} cell(s) pasted across ${rows} row(s); one undo will revert the paste.`:`${result.changed} hücre ${rows} satırda yapıştırıldı; tek geri alma işlemi yapıştırmayı geri alır.`))+skipped);restoreActiveAfterRender();return true;}global.BLGridClipboard?.diagnostics?.record({module:'collection',operation:'paste',selection:summary.target,source:summary.source,mode:summary.mode,ok:false,error:result?.error});global.showToast?.(lang()==='en'?'Paste failed; changes were rolled back.':'Yapıştırma başarısız; değişiklikler geri alındı.');return false;}
  function selectionCellCount(){if(state.multiCells.size)return state.multiCells.size;const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);return bounds?Engine.cellsInRange(bounds).length:0;}
  // Seçimde en az bir düzenlenebilir hücre var mı? Aktif hücre hesaplanan bir
  // sütunda olsa bile aralıktaki düzenlenebilir hücrelere yapıştırılabilir.
  function selectionHasEditable(){if(!state.active||!bridge()?.canEdit?.())return false;if(state.multiCells.size)return selectedCoordinates().some(c=>metadata(c)?.editable);const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);if(!bounds)return false;for(let c=bounds.c1;c<=bounds.c2;c++){const td=cellAt(bounds.r1,c)||state.cellRows.find(row=>row[c])?.[c];if(td&&bridge()?.columnMeta?.(td.dataset.key)?.editable)return true;}return false;}
  // Delete: tek hücrede doğrudan, aralık/çoklu seçimde önizlemeli tek işlem (tek geri alma).
  function clearSelection(){if(!state.active||!bridge()?.canEdit?.())return false;if(selectionCellCount()<2){const meta=metadata(state.active);if(!meta?.editable)return false;bridge()?.batchEdit?.([{rowId:state.active.rowId,key:state.active.key,value:''}]);restoreActiveAfterRender();return true;}void applyMatrix([['']],{kind:'clear'});return true;}
  // Ctrl+D: seçimin ilk satırını aşağıdaki satırlara doldurur (Excel "Aşağı Doldur").
  function fillDown(){if(!state.active||state.multiCells.size||!bridge()?.canEdit?.())return false;const {bounds,rawMatrix:matrix}=selectedMatrix(liveRowSnapshot());if(!bounds||bounds.r2<=bounds.r1||!matrix.length)return false;const top=cellAt(bounds.r1,bounds.c1),topCoord=top&&coordForCell(top);void applyMatrix([matrix[0].map(v=>v==null?'':String(v))],{kind:'fill',excludeRowId:topCoord?.rowId??null});return true;}
  // Ctrl+A: görünen tüm hücreler; sütun harfi: o sütunun tamamı (Shift ile aralık).
  function selectAllCells(){const last=state.cellRows.length-1,lastRow=state.cellRows[last]||[],first=cellAt(0,0),end=lastRow[lastRow.length-1];if(!first||!end)return false;closeCurrentCellEditor(coordForCell(first));state.multiCells.clear();state.wholeRowSelection=false;state.cellIntent=nextIntent();state.anchor=coordForCell(first);state.active=state.anchor;state.focus=coordForCell(end);paint();grid()?.focus({preventScroll:true});return true;}
  function selectColumn(index,{extend=false}={}){const lastRow=state.cellRows.length-1;if(lastRow<0)return false;const anchorCol=extend&&state.anchor?state.anchor.c:index,top=cellAt(0,anchorCol),bottom=cellAt(lastRow,index)||cellAt(lastRow,Math.min(index,(state.cellRows[lastRow]||[]).length-1));if(!top||!bottom)return false;closeCurrentCellEditor(coordForCell(top));state.multiCells.clear();state.wholeRowSelection=false;state.cellIntent=nextIntent();state.anchor=coordForCell(top);state.active=extend&&state.active?state.active:state.anchor;state.focus=coordForCell(bottom);paint();grid()?.focus({preventScroll:true});return true;}
  // Düzenlenebilir hücrede başlayan sürükleme başka bir hücreye taşınınca
  // düzenleme bırakılır ve aralık seçimine geçilir (tek tıkla düzenleme korunur).
  function beginRangeDragFromEditor(){const origin=findCellByIdentity(state.dragOrigin);state.dragOrigin=null;state.pendingPointerEdit=null;const editor=document.activeElement?.closest?.('#kolTable .editCell');if(editor)editor.blur?.();global.getSelection?.()?.removeAllRanges?.();q('view-koleksiyon')?.classList.add('kolSpreadsheetDragSelecting');closeCurrentCellEditor(null,{force:true});const coord=origin&&coordForCell(origin);if(coord){state.active=coord;state.anchor=coord;state.focus=coord;}grid()?.focus({preventScroll:true});}
  function endDrag(){state.dragging=false;state.dragOrigin=null;q('view-koleksiyon')?.classList.remove('kolSpreadsheetDragSelecting');}
  function restoreActiveAfterRender(){setTimeout(()=>{if(!state.active)return;const active=remapCoord(state.active);if(!active)return;const anchor=remapCoord(state.anchor)||active,focus=remapCoord(state.focus)||active;state.active=active;state.anchor=anchor;state.focus=focus;paint();},0);}
  function selectorValue(v){return String(v).replace(/(["\\])/g,'\\$1');}
  async function pasteFromClipboard(){try{const text=await navigator.clipboard.readText();return pasteText(text);}catch(_){global.showToast?.(lang()==='en'?'Clipboard permission is not available. Use Ctrl+V.':'Pano izni kullanılamıyor. Ctrl+V kullanın.');return false;}}
  function removeLetterHeaders(){const thead=grid()?.tHead;if(!thead)return;thead.querySelector('.kolSpreadsheetLettersRow')?.remove();thead.classList.add('isLettersHidden');}
  function decorateCells(){const table=grid(),rows=[...document.querySelectorAll('#kolTable tbody tr')],columns=[...(rows[0]?.cells||[])].filter(td=>td.dataset.key);if(!table)return;table.setAttribute('role','grid');table.setAttribute('tabindex','0');table.setAttribute('aria-label',lang()==='en'?'Collection data grid':'Koleksiyon veri tablosu');table.setAttribute('aria-multiselectable','true');table.setAttribute('aria-rowcount',String(rows.length+1));table.setAttribute('aria-colcount',String(columns.length));document.querySelectorAll('#kolTable thead tr.colRow th[data-kcol],#kolPicTh').forEach((th,ci)=>{th.setAttribute('role','columnheader');th.setAttribute('aria-colindex',String(ci+1));});rows.forEach((tr,ri)=>{tr.setAttribute('role','row');tr.setAttribute('aria-rowindex',String(ri+2));[...tr.cells].filter(td=>td.dataset.key).forEach((td,ci)=>{const meta=bridge()?.columnMeta?.(td.dataset.key),rowId=String(tr.dataset.id||'');td.id=cellDomId(rowId,td.dataset.key);td.setAttribute('role','gridcell');td.setAttribute('aria-rowindex',String(ri+2));td.setAttribute('aria-colindex',String(ci+1));td.setAttribute('aria-selected','false');if(meta&&!meta.editable){td.classList.add('kolSpreadsheetReadonly');td.dataset.kolFormulaTip=meta.formula||meta.label||'';}else{td.classList.remove('kolSpreadsheetReadonly');delete td.dataset.kolFormulaTip;}});});}
  function applyWorkspace(){const view=q('view-koleksiyon');if(view)view.classList.add('kolSpreadsheetWorkspace');}
  function remapCoord(identity){if(!identity)return null;const tr=[...document.querySelectorAll('#kolTable tbody tr')].find(x=>String(x.dataset.id)===String(identity.rowId)),td=tr?.querySelector(`td[data-key="${selectorValue(identity.key)}"]`);return td?coordForCell(td):null;}
  function afterRender(meta){const identities={active:state.active&&{rowId:state.active.rowId,key:state.active.key},anchor:state.anchor&&{rowId:state.anchor.rowId,key:state.anchor.key},focus:state.focus&&{rowId:state.focus.rowId,key:state.focus.key}};closeCurrentCellEditor(state.active,{force:true,preservePending:true});state.lastRender=meta||null;applyWorkspace();removeLetterHeaders();bridge()?.reapplyFreeze?.();decorateCells();rebuildGridCache();updateSelectedCount();if(state.pendingPointerEdit&&kolSpreadsheetResumePendingPointerEdit())return;if(identities.active){state.active=remapCoord(identities.active);if(state.active){state.anchor=remapCoord(identities.anchor)||state.active;state.focus=remapCoord(identities.focus)||state.active;}else state.active=state.anchor=state.focus=null;}paint();}
  function selectWholeSpreadsheetRow(button,event){const tr=button.closest('tr'),cells=[...tr.cells].filter(td=>td.dataset.key);if(!cells.length)return;state.multiCells.clear();state.wholeRowSelection=true;state.cellIntent=nextIntent();const first=coordForCell(cells[0]),last=coordForCell(cells[cells.length-1]),next=(event.shiftKey&&state.anchor)?last:first;closeCurrentCellEditor(next);if(event.shiftKey&&state.anchor){state.active=last;state.focus=last;}else{state.anchor=first;state.active=first;state.focus=last;}paint();grid()?.focus({preventScroll:true});}
  function selectedWholeRowIds(){if(!state.wholeRowSelection||!state.anchor||!state.focus)return [];const r1=Math.min(state.anchor.r,state.focus.r),r2=Math.max(state.anchor.r,state.focus.r),ids=[];for(let r=r1;r<=r2;r++){const td=state.cellRows[r]?.[0],coord=td&&coordForCell(td);if(coord?.rowId)ids.push(coord.rowId);}return ids;}
  function closeMenu(){if(state.menuOutsideHandler){document.removeEventListener('pointerdown',state.menuOutsideHandler,true);state.menuOutsideHandler=null;}if(state.menu){global.BLLayerSystem?.closeMenu(state.menu);state.menu.remove();}state.menu=null;}
  function openMenu(x,y,items){closeMenu();const menu=document.createElement('div');menu.className='kolSpreadsheetContextMenu';items.forEach(item=>{if(item==='sep'){const sep=document.createElement('div');sep.className='sep';menu.appendChild(sep);return;}const b=document.createElement('button');b.type='button';b.disabled=Boolean(item.disabled);b.innerHTML=`<span>${escapeHtmlLocal(item.label)}</span>${item.key?`<kbd>${escapeHtmlLocal(item.key)}</kbd>`:''}`;b.addEventListener('click',()=>{closeMenu();if(!b.disabled)item.run?.();});menu.appendChild(b);});document.body.appendChild(menu);state.menu=menu;const rect=menu.getBoundingClientRect();menu.style.left=Math.max(4,Math.min(x,innerWidth-rect.width-4))+'px';menu.style.top=Math.max(4,Math.min(y,innerHeight-rect.height-4))+'px';global.BLLayerSystem?.openMenu(menu,{trigger:document.activeElement,onClose:closeMenu,label:lang()==='en'?'Table options':'Tablo seçenekleri'});state.menuOutsideHandler=outsideEvent=>{if (!menu.contains(outsideEvent.target)) closeMenu();};setTimeout(()=>document.addEventListener('pointerdown',state.menuOutsideHandler,true),0);}
  function headerContext(event,th){event.preventDefault();event.stopImmediatePropagation();const key=th.dataset.kcol||'__picture__',meta=bridge()?.columnMeta?.(key);openMenu(event.clientX,event.clientY,[{label:lang()==='en'?'Sort ascending':'Artan sırala',run:()=>bridge()?.sort?.(key,1),disabled:key==='__picture__'},{label:lang()==='en'?'Sort descending':'Azalan sırala',run:()=>bridge()?.sort?.(key,-1),disabled:key==='__picture__'},'sep',{label:'Filter…',run:()=>bridge()?.filter?.(key,th),disabled:key==='__picture__'||meta?.col?.noFilter},{label:'AutoFit Column',run:()=>{bridge()?.autoFitColumn?.(key);bridge()?.render?.();},disabled:key==='__picture__'},'sep',{label:lang()==='en'?'Freeze Up To This Column':'Bu Sütuna Kadar Dondur',run:()=>bridge()?.freezeToKey?.(key)},{label:lang()==='en'?'Unfreeze':'Dondurmayı Kaldır',run:()=>bridge()?.unfreeze?.()},'sep',{label:lang()==='en'?'Hide Column':'Sütunu Gizle',run:()=>bridge()?.hideColumn?.(key)}]);}
  function cellContext(event,td){
    event.preventDefault();event.stopImmediatePropagation();
    const contextCoord=coordForCell(td);if(!contextCoord||!prepareCellContext(td))return;
    const meta=metadata(state.active),row=bridge()?.rows?.().find(r=>String(r.id)===state.active.rowId);
    const contextRow=state.rowById.get(String(contextCoord.rowId))||bridge()?.rows?.().find(r=>String(r.id)===String(contextCoord.rowId));
    const modelNameContext=contextCoord.key==='modelKod';
    const canOpenContextPlm=modelNameContext&&Boolean(bridge()?.canOpenPlm?.(contextRow));
    const groupActions=bridge()?.modelGroupActions?.(row,state.active.key,selectedWholeRowIds())||[];
    const checkedModels=bridge()?.selectedCount?.()||0,editableSelection=selectionHasEditable(),selectionSize=selectionCellCount();
    const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active),multiRowRange=!state.multiCells.size&&Boolean(bounds&&bounds.r2>bounds.r1);
    openMenu(event.clientX,event.clientY,[
      // Ctrl+C = Kopyala (başlıksız). Başlıklı kopya yalnız buradan bilerek seçilir.
      {label:lang()==='en'?'Copy':'Kopyala',key:'Ctrl+C',run:()=>handleCopyShortcut({preventDefault(){},stopImmediatePropagation(){}},{includeHeaders:false,forceCellCopy:true})},
      {label:lang()==='en'?'Copy with headers':'Başlıklarla kopyala',run:()=>handleCopyShortcut({preventDefault(){},stopImmediatePropagation(){}},{includeHeaders:true,forceCellCopy:true})},
      // İşaretli model varken iki hedef de açıkça sunulur: hücreler mi, modeller mi.
      ...(checkedModels>0&&q('kolCopySelectedBtn')?[{label:lang()==='en'?`Copy ${checkedModels} checked model(s)`:`İşaretli ${checkedModels} modeli kopyala`,run:()=>q('kolCopySelectedBtn')?.click()}]:[]),
      {label:lang()==='en'?'Paste':'Yapıştır',key:'Ctrl+V',run:pasteFromClipboard,disabled:!editableSelection},
      ...(multiRowRange?[{label:lang()==='en'?'Fill Down':'Aşağı Doldur',key:'Ctrl+D',run:fillDown,disabled:!editableSelection}]:[]),
      {label:selectionSize>1?(lang()==='en'?'Clear Selected Cells':'Seçili Hücreleri Temizle'):(lang()==='en'?'Clear Cell':'Hücreyi Temizle'),key:'Delete',run:clearSelection,disabled:!editableSelection},
      ...(groupActions.length?['sep',...groupActions]:[]),
      ...(modelNameContext?['sep',{label:lang()==='en'?'Go to PLM Page':'PLM Sayfasına Git',run:()=>bridge()?.openPlm?.(contextRow),disabled:!canOpenContextPlm}]:[]),
      ...(contextCoord.key==='artworkDetail'&&bridge()?.openArtworkBom?['sep',{label:lang()==='en'?'Open BOM Detail':'BOM Detayını Aç',run:()=>bridge().openArtworkBom(contextRow)}]:[]),
      'sep',{label:'Open Quotations',run:()=>bridge()?.openQuotations?.(row)},{label:'Pricing History',run:()=>bridge()?.openPricingHistory?.(row)},
      'sep',{label:lang()==='en'?'Freeze Up To This Column':'Bu Sütuna Kadar Dondur',run:()=>bridge()?.freezeToKey?.(state.active.key)},{label:lang()==='en'?'Hide Column':'Sütunu Gizle',run:()=>bridge()?.hideColumn?.(state.active.key)}
    ]);
  }
  function bind(){const table=grid();if(!table)return;
    document.addEventListener('pointermove',e=>{
      if(!state.dragging)return;
      // Fare bırakıldığı hâlde pointerup kaçtıysa (ör. yerel açılır liste) seçim uzamaz.
      if(typeof e.buttons==='number'&&!(e.buttons&1)){endDrag();return;}
      // Metin seçimi sürerken olay hedefi giriş kutusunda kalabilir; imlecin altındaki hücre esas alınır.
      const under=typeof document.elementFromPoint==='function'&&Number.isFinite(e.clientX)?document.elementFromPoint(e.clientX,e.clientY):null;
      const td=(under||e.target)?.closest?.('#kolTable tbody td[data-key]');if(!td)return;
      if(state.dragOrigin){if(sameCellIdentity(coordForCell(td),state.dragOrigin))return;beginRangeDragFromEditor();}
      setActive(td,{extend:true,focusGrid:false});
    },true);
    document.addEventListener('pointerup',()=>{endDrag();},true);
    table.addEventListener('keydown',e=>{if(e.target!==table||modalOpen()||!state.active||e.key.length!==1||e.ctrlKey||e.metaKey||e.altKey)return;const bounds=Engine.rangeBounds(state.anchor||state.active,state.focus||state.active);if(!bounds||Engine.cellsInRange(bounds).length<2)return;e.preventDefault();e.stopImmediatePropagation();void pasteText(e.key);},true);
    table.addEventListener('pointerdown',e=>{if(e.button!==0)return;const groupToggle=e.target.closest('[data-kol-group-toggle]');if(groupToggle){state.pendingPointerEdit=null;e.preventDefault();e.stopImmediatePropagation();return;}const letter=e.target.closest('.kolSpreadsheetLetter');if(letter){state.pendingPointerEdit=null;e.preventDefault();e.stopImmediatePropagation();selectColumn(Number(letter.dataset.letterIndex),{extend:e.shiftKey});return;}const rowNo=e.target.closest('.kolSpreadsheetRowNumber');if(rowNo){state.pendingPointerEdit=null;e.preventDefault();e.stopImmediatePropagation();selectWholeSpreadsheetRow(rowNo,e);return;}const td=collectionDataCellFromEvent(e);if(!td)return;if(e.target.closest('img.kolThumb')){state.pendingPointerEdit=null;setActive(td,{extend:e.shiftKey,focusGrid:false});return;}if(e.target.closest('button:not(.kolSpreadsheetRowNumber),a')){state.pendingPointerEdit=null;setActive(td,{extend:e.shiftKey,focusGrid:false});return;}kolSpreadsheetHandlePointerEdit(e,td);},true);table.addEventListener('contextmenu',e=>{if(e.target.closest('img.kolThumb'))return;const th=e.target.closest('thead tr.colRow th');if(th){headerContext(e,th);return;}const td=collectionDataCellFromEvent(e);if(td)cellContext(e,td);},true);
    table.addEventListener('keydown',e=>{if(e.target!==table||modalOpen())return;const extend=e.shiftKey;if(['ArrowDown','ArrowUp','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();move(e.key==='ArrowDown'?1:e.key==='ArrowUp'?-1:0,e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0,{extend});return;}if(e.key==='Tab'){e.preventDefault();moveTab(e.shiftKey?-1:1);return;}if(e.key==='Enter'){e.preventDefault();move(e.shiftKey?-1:1,0);return;}if(e.key==='F2'){e.preventDefault();beginEdit();return;}if(e.key==='Escape'&&state.active){e.preventDefault();clearActive();return;}const key=String(e.key||'').toLowerCase();if((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey&&key==='a'){if(selectAllCells())e.preventDefault();return;}if((e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey&&key==='d'){e.preventDefault();fillDown();return;}if(e.key==='Delete'&&state.active){if(selectionHasEditable()){e.preventDefault();clearSelection();}}});
    document.addEventListener('paste',e=>{
      if(!isCollectionActive()||modalOpen()||!state.active)return;
      const text=e.clipboardData?.getData('text/plain')||'';
      if(!text)return;
      const formControl=e.target.closest?.('input,textarea,select,[contenteditable="true"]');
      const gridEditor=e.target.closest?.('#kolTable .editCell');
      const matrixLike=/\t/.test(text);
      if(formControl&&!gridEditor)return;
      // Keep free-text and multi-line notes native; dropdowns instead need
      // the validated spreadsheet transaction, including scalar Ctrl+V.
      if(gridEditor?.dataset?.k==='not'&&gridEditor.tagName==='TEXTAREA'&&!matrixLike)return;
      const editorKey=gridEditor?.dataset?.k||gridEditor?.closest('td[data-key]')?.dataset?.key;
      const col=editorKey?bridge()?.columnMeta?.(editorKey)?.col:null;
      const choiceEditor=gridEditor?.tagName==='SELECT'||Boolean(col?.select||col?.status||col?.inStorePeriod);
      if(gridEditor&&!matrixLike&&!choiceEditor)return;
      e.preventDefault();e.stopImmediatePropagation();
      void pasteText(text);
    },true);
    q('kolSpreadsheetPasteBtn')?.addEventListener('click',()=>void pasteFromClipboard());
    // Yedek yol: Ctrl+C keydown'a ulaşmadan yerel 'copy' olayı gelirse (ör. başka
    // bir dinleyici olayı yuttuysa) seçili hücreler yine eşzamanlı olarak panoya yazılır.
    document.addEventListener('copy',e=>{
      if(e.defaultPrevented||!e.clipboardData||!isCollectionActive()||modalOpen()||!state.active)return;
      const sel=global.getSelection?.();if(sel&&sel.rangeCount&&!sel.isCollapsed)return;
      const formControl=e.target?.closest?.('input,textarea,select,[contenteditable="true"]'),gridEditor=e.target?.closest?.('#kolTable .editCell');
      if(formControl&&!gridEditor)return;if(gridEditor&&editorNativeSelection(gridEditor))return;
      if((bridge()?.selectedCount?.()||0)>0&&!cellSelectionWins())return;
      const payload=selectedClipboard(false);if(!payload)return;
      e.preventDefault();e.clipboardData.setData('text/plain',payload.plain);if(payload.html)e.clipboardData.setData('text/html',payload.html);
      state.lastCopyHeaderLine='';rememberCopiedRaw(payload);
      global.showToast?.(lang()==='en'?`${payload.count} cell(s) copied.`:`${payload.count} hücre kopyalandı.`);
    },true);
    document.addEventListener('change',e=>{
      const chk=e.target.closest('#kolTable .rowChk,#kolSelAll');if(!chk)return;
      // Kutuyla model işaretleme, önceki hücre/aralık seçimini geçersiz kılar —
      // aksi halde Kopyala hâlâ bayat tek hücreyi kopyalar.
      if(chk.checked&&state.active)clearActive();
      state.rowIntent=nextIntent();
      setTimeout(()=>{if(state.active&&!cellSelectionWins()&&(bridge()?.selectedCount?.()||0)>0)clearActive();updateSelectedCount();updateStatus();},0);
    },true);
    // Editor focus can also move via the legacy Enter/Tab navigation helpers. Keep
    // spreadsheet state aligned with the editor without creating a second render path.
    document.addEventListener('focusin',e=>{
      const editor=e.target?.closest?.('#kolTable .editCell');if(!editor)return;
      const td=editor.closest('td[data-key]'),coord=coordForCell(td);if(!coord)return;
      if(sameCellIdentity(state.pendingPointerEdit,coord))state.pendingPointerEdit=null;
      closeCurrentCellEditor(coord);
      state.active=coord;state.anchor=coord;state.focus=coord;state.editingCell=td;state.cellIntent=nextIntent();td.classList.add('kolSpreadsheetEditing');paint();ensureCellVisible(td);
    },true);
    // Editing focus is transient; spreadsheet selection is durable. Clear only the
    // editing marker so a later Ctrl+C still has a stable row/key selection anchor.
    document.addEventListener('focusout',e=>{
      const editor=e.target?.closest?.('#kolTable .editCell'),td=editor?.closest?.('td[data-key]');if(!td)return;
      setTimeout(()=>{
        if(document.activeElement?.closest?.('#kolTable .editCell'))return;
        if(state.editingCell===td){td.classList.remove('kolSpreadsheetEditing');state.editingCell=null;try{global.BLCollectionCellEditorLifecycle?.close?.({nextCell:null});}catch(_){}}
        paint();
      },0);
    },true);
  }
  function init(){const root=q('view-koleksiyon');if(!root||!grid())return;root.classList.add('kolSpreadsheetWorkspace');bind();afterRender();}
  global.BLCollectionSpreadsheet={enabled:()=>state.enabled,afterRender,handleCopyShortcut,pasteText,setActive,move,beginEdit,endEdit,clearActive,clearActiveIfMatches,kolSpreadsheetHandlePointerEdit,kolSpreadsheetResumePendingPointerEdit,state};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
