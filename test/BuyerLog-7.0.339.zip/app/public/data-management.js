/* ===================================================================
   VERİ YÖNETİMİ — Overview (v7.81, P2)

   Bu ekran, kaynak yapılandırmasının TEK bakış noktasıdır. Bugüne kadar
   aynı bilgi dört yere dağılmıştı: Kaynak Veri çekmecesi, "Horizon ve
   Bağlantı" modalı, sayfa içi Horizon rozetleri ve sayfa başına ayrı
   Yenile düğmeleri.

   P2'DE NE VAR, NE YOK — bilerek:

   VAR : kaynakların durumu, hangi modülü hangi filtreyle beslediği,
         paylaşılan filtrelerin kaç modülde kullanıldığı, yapısal olarak
         imkânsız bağlantıların açıkça imkânsız gösterilmesi.
   YOK : düzenleme. Bir filtreye ya da eşlemeye tıklamak MEVCUT çalışan
         modalı açar.

   Yarım bir editör çizmiyoruz: çalışmayan bir alan, olmayan bir alandan
   daha kötüdür. Düzenleme P3'te bu ekrana taşınacak.

   ÜÇ HÜCRE DURUMU birbirine karıştırılmaz (read-model.js ile aynı sözleşme):
     on          bağlı ve etkin
     off         bağlanabilir ama kapalı
     unavailable bu kaynak bu modülü YAPISAL OLARAK besleyemez

   Üçüncüsü olmadan ekran, var olmayan bağlantıları kapatılabilir bir
   anahtar gibi gösterir ve kullanıcıya yanlış bir zihinsel model öğretir.
   =================================================================== */
(() => {
  'use strict';

  const en = () => typeof appLang !== 'undefined' && appLang === 'en';
  const T = (tr, enText) => (en() ? enText : tr);
  const esc = value => (typeof escapeHtml === 'function'
    ? escapeHtml(String(value == null ? '' : value))
    : String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])));

  let root = null;
  let model = null;
  let lab = null;
  let labTab = 'integrations';
  let selectedLabSourceId = '';
  let selectedAutomationId = '';
  let labBusy = '';
  let labMessage = '';
  let automationPreview = null;
  let loading = false;
  let loadError = '';
  let merchCalendar = { configured:false, calendar:null, summary:null };
  let merchBusy = false;
  let merchMessage = '';
  let expandedSourceId = '';
  /* Eşleme düzenleyicisi hangi kaynak için açık. Açıkken o kaynağın statik
     sorun listesi çizilmez: aynı iki satırın ekranda iki kez görünmesi
     §48'in istemediği gürültüydü (canlı ölçümde görüldü). */
  let mappingEditorSourceId = '';
  // Aynı gerekçe CP sütunları için de geçerli: açıkken satır içi özet çizilmez.
  let cpColumnsSourceId = '';
  // Eşleştirme kuralları açıkken satır içi özet çizilmez (aynı gürültü gerekçesi).
  let matchRuleOpen = false;
  // Satır içi açılan araç (şu an yalnız Data Maintenance).
  let openTool = '';
  // Yazma sürerken o hücre kilitlenir: çift tıklama iki istek göndermemeli.
  let busyCell = '';
  let writeError = '';

  /* ---------------------------------------------------------------- */

  const STATUS_TEXT = {
    ready: { tr: 'Bağlı', en: 'Connected', tone: 'ok' },
    'needs-mapping': { tr: 'Zorunlu alan eksik', en: 'Required field missing', tone: 'bad' },
    'needs-filter': { tr: 'Filtre gerekli', en: 'Filter required', tone: 'warn' },
    error: { tr: 'Son yenileme başarısız', en: 'Last refresh failed', tone: 'bad' },
    disabled: { tr: 'Kapalı', en: 'Disabled', tone: 'muted' },
    unconfigured: { tr: 'Yapılandırılmamış', en: 'Not configured', tone: 'muted' },
  };

  /* Filtre hangi katmandan geliyor. 'source' rozet GÖSTERMEZ: ortak ayarın
     geçerli olması normal durumdur ve her satıra rozet basmak gürültüdür.
     Rozet yalnız ortak ayarın EZİLDİĞİ hâlde çıkar — çünkü açıklanması
     gereken durum odur. */
  const LAYER = {
    personal: { tr: 'Kişisel', en: 'Personal', hint: { tr: 'Bu modül için kendi ayarınız ortak ayarı eziyor.', en: 'Your own setting for this module overrides the shared one.' } },
    personalDefault: { tr: 'Kişisel', en: 'Personal', hint: { tr: 'Tüm modüller için tanımladığınız kişisel varsayılan geçerli.', en: 'Your personal default for all modules is in effect.' } },
    roleTemplate: { tr: 'Rol şablonu', en: 'Role template', hint: { tr: 'Rolünüzden miras alınan şablon geçerli.', en: 'A template inherited from your role is in effect.' } },
    roleDefault: { tr: 'Rol şablonu', en: 'Role template', hint: { tr: 'Rolünüzün genel şablonu geçerli.', en: 'Your role’s general template is in effect.' } },
    /* v7.81: 'preset' ve 'group' katmanları KALDIRILDI (kullanıcı kararı).
       İkisi de kullanıcının görmediği katmanlardı ve bu ekranda ayarlanan
       ortak filtreyi sessizce eziyordu. Geriye kullanıcının kendi ayarı ve
       rolünün şablonu kaldı; ikisi de bu rozetten kaldırılabilir/görülebilir. */
  };

  function shortTime(value) {
    const text = String(value || '').trim();
    if (!text) return '—';
    const date = new Date(text);
    if (Number.isNaN(date.getTime())) return text;
    const pad = n => String(n).padStart(2, '0');
    const today = new Date();
    const sameDay = date.toDateString() === today.toDateString();
    const clock = `${pad(date.getHours())}:${pad(date.getMinutes())}`;
    return sameDay ? clock : `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()} ${clock}`;
  }

  /* ---------------------------------------------------------------- */

  // Uçuştaki yükleme paylaşılır: sekmeye geçiş ile "Yönet" odaklanması aynı
  // anda gelirse iki ayrı istek atılmamalı.
  let loadPromise = null;
  function load() {
    if (!loadPromise) loadPromise = runLoad().finally(() => { loadPromise = null; });
    return loadPromise;
  }

  async function readLoadPayload(url, optional = false) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
      const payload = await response.json();
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Veri Yönetimi özeti okunamadı.', 'Could not read the Data Management summary.'));
      return payload;
    } catch (error) {
      if (optional) return null;
      if (controller.signal.aborted) throw new Error(T('Sunucu zamanında yanıt vermedi. Yeniden deneyin.', 'The server did not respond in time. Try again.'));
      throw error;
    } finally { clearTimeout(timer); }
  }

  async function runLoad() {
    loading = true;
    loadError = '';
    render();
    try {
      const [payload, labPayload, merchPayload] = await Promise.all([
        readLoadPayload(`/api/data-management/overview?language=${en() ? 'en' : 'tr'}`),
        readLoadPayload(`/api/data-management/integration-lab?language=${en() ? 'en' : 'tr'}`, true),
        readLoadPayload('/api/merch-calendar', true),
      ]);
      model = payload;
      if (labPayload) {
        lab = labPayload;
        if (!selectedLabSourceId) selectedLabSourceId = lab.selectedInspector && lab.selectedInspector.sourceId || '';
        if (!selectedAutomationId) selectedAutomationId = lab.automations && lab.automations[0] && lab.automations[0].id || '';
      }
      if (merchPayload) {
        merchCalendar = merchPayload;
        window.BLMerchCalendarRuntime?.apply?.(merchPayload);
      }
    } catch (error) {
      loadError = String(error && error.message || error);
      model = null;
    } finally {
      loading = false;
      render();
    }
  }

  /* ---------------------------------------------------------------- */

  function connectorKindText(source) {
    const connector = source && source.connector || {};
    const kind = String(connector.kind || '').toLowerCase();
    if (kind === 'analysis-services') return 'Analysis Services / MSOLAP';
    if (kind === 'sqlserver') return 'SQL Server';
    if (kind === 'odbc') return String(connector.family || '').toLowerCase() === 'oracle' ? 'Oracle / ODBC' : 'ODBC';
    if (kind === 'oledb') return String(connector.family || '').toLowerCase() === 'oracle' ? 'Oracle / OLE DB' : 'OLE DB';
    return source && source.profileLabel || T('Database', 'Database');
  }

  function connectorAuthText(source) {
    const auth = source && source.connector && source.connector.auth || {};
    if (auth.type === 'windows') return T('Windows / Integrated', 'Windows / Integrated');
    if (auth.type === 'username-password') return T('Kullanıcı adı + parola', 'Username + password');
    if (auth.type === 'office-managed') return T('Ayrı kimlik doğrulama gerekebilir', 'Separate authentication may be required');
    return T('Belirlenemedi', 'Unknown');
  }

  function isCustomDatabase(source) {
    return Boolean(source && source.profileId === 'custom-database' && source.connector);
  }

  function sourceCard(source) {
    const status = STATUS_TEXT[source.status] || STATUS_TEXT.unconfigured;
    const expanded = expandedSourceId === source.id;
    const problem = source.lastRun && !source.lastRun.ok && source.lastRun.error;
    const customDb = isCustomDatabase(source);
    const connMeta = customDb
      ? `${connectorKindText(source)} · ${source.connection.server}${source.connection.catalog ? ` / ${source.connection.catalog}` : ''}`
      : `${source.connection.server} / ${source.connection.catalog}`;
    return `<button type="button" class="dmSourceCard${expanded ? ' isOpen' : ''}" data-source="${esc(source.id)}" aria-expanded="${expanded}">
      <span class="dmSourceTop">
        <span class="dmDot dmDot--${status.tone}" aria-hidden="true"></span>
        <span class="dmSourceName">${esc(source.name)}</span>
      </span>
      <span class="dmSourceMeta">${esc(status[en() ? 'en' : 'tr'])} · ${esc(customDb ? connectorKindText(source) : source.profileLabel)}</span>
      <span class="dmSourceMeta dmSourceMeta--quiet">${esc(connMeta)}</span>
      <span class="dmSourceFoot">
        <span>${customDb ? esc(T('Bağımsız database', 'Standalone database')) : `${source.moduleCount} ${esc(T('modül', 'modules'))}`}</span>
        <span>${esc(shortTime(source.lastRun && source.lastRun.at))}</span>
      </span>
      ${source.mapping && source.mapping.needsAttention ? `<span class="dmSourceNote${source.mapping.blocking ? ' isBad' : ''}">
        ${source.mapping.blocking ? '⛔' : '⚠'} ${esc(T(`${source.mapping.needsAttention} alan eşlemesi bakım istiyor`, `${source.mapping.needsAttention} field mappings need attention`))}
      </span>` : ''}
      ${problem ? `<span class="dmSourceError">${esc(source.lastRun.error)}</span>` : ''}
    </button>`;
  }

  const MAPPING_STATUS = {
    foreign: { tr: 'Beklenen adla örtüşmüyor', en: 'Does not match the expected name' },
    weak: { tr: 'Yalnız kısmi ad benzerliğiyle tuttu', en: 'Matched only by partial name similarity' },
    unmapped: { tr: 'Eşlenmemiş', en: 'Not mapped' },
  };

  /* Eşleme bölümü. Tam liste BURADA GÖSTERİLMEZ — zaten sunucudan da gelmez.
     Amaç kullanıcının 38 satır yerine 3 satıra bakması; tam listeyi görmek
     isteyen mevcut eşleme ekranını açar. */
  function mappingSection(source) {
    const health = source.mapping;
    const label = model.canManage && (source.capabilities || []).includes('field-mapping')
      ? `<button type="button" class="dmMappingLink" data-open-mapping="${esc(source.id)}"
          aria-label="${esc(T('Alan eşlemelerini aç ve düzenle', 'Open and edit field mappings'))}">${esc(T('Alan eşlemesi', 'Field mapping'))}</button>`
      : `<span class="dmLabel">${esc(T('Alan eşlemesi', 'Field mapping'))}</span>`;
    if (!health) return '';
    if (!health.needsAttention) {
      return `<div class="dmMapping dmMapping--ok">
        ${label}
        <span class="dmValue">${esc(T(`${health.ok} alan eşlendi, hepsi beklenen adla tutuyor.`, `${health.ok} fields mapped, all match their expected names.`))}</span>
      </div>`;
    }
    const rows = health.problems.map(problem => {
      const label = MAPPING_STATUS[problem.status] || MAPPING_STATUS.unmapped;
      const blocking = problem.status === 'unmapped' && problem.required;
      return `<li class="dmMapRow${blocking ? ' isBlocking' : ''}">
        <span class="dmMapMark" aria-hidden="true">${blocking ? '⛔' : '⚠'}</span>
        <span class="dmMapField">${esc(problem.header)}${problem.required ? `<span class="dmReq">${esc(T('zorunlu', 'required'))}</span>` : ''}</span>
        <span class="dmMapArrow" aria-hidden="true">→</span>
        <span class="dmMapCol">${problem.column ? esc(problem.column) : `<em>${esc(T('seçilmedi', 'not selected'))}</em>`}</span>
        <span class="dmMapWhy">${esc(label[en() ? 'en' : 'tr'])}${problem.identity ? ` · ${esc(T('sipariş eşleşmesi bu alanı birebir kullanır', 'order matching uses this field exactly'))}` : ''}</span>
      </li>`;
    }).join('');
    return `<div class="dmMapping">
      <div class="dmMappingHead">
        ${label}
        <span class="dmMappingSummary">
          <span class="isOk">✓ ${health.ok} ${esc(T('otomatik eşlendi', 'auto-mapped'))}</span>
          ${health.review ? `<span class="isWarn">⚠ ${health.review} ${esc(T('gözden geçirilmeli', 'need review'))}</span>` : ''}
          ${health.blocking ? `<span class="isBad">⛔ ${health.blocking} ${esc(T('zorunlu alan eksik', 'required missing'))}</span>` : ''}
        </span>
      </div>
      <ul class="dmMapList">${rows}</ul>
      ${health.blocking ? `<p class="dmMapNote">${esc(T('Zorunlu alan eşlenmeden bu kaynak yenilenemez.', 'This source cannot refresh until the required field is mapped.'))}</p>` : ''}
    </div>`;
  }

  /* CP SÜTUNLARI ÖZETİ (§7 — eski ekrandan taşınan yetenek).

     Yalnız bu yeteneğe sahip kaynaklarda çıkar: pivot raporunda (INTAKE)
     "CP sütunu" diye bir kavram yok ve boş bir bölüm göstermek kullanıcıya
     var olmayan bir ayar arattırırdı. */
  function cpColumnsSection(source) {
    if (!(source.capabilities || []).includes('extra-columns')) return '';
    if (cpColumnsSourceId === source.id) return '';
    const columns = source.cpColumns || [];
    return `<div class="dmDetailRow">
      <span class="dmLabel">${esc(T('CP sütunları', 'CP columns'))}</span>
      <span class="dmValue">
        ${columns.length
          ? esc(columns.map(column => column.label).join(' · '))
          : esc(T('yok', 'none'))}
        ${model.canManage ? `<button type="button" class="dmInlineLink" data-open-cpcolumns="${esc(source.id)}">
          ${esc(columns.length ? T('düzenle', 'edit') : T('ekle', 'add'))}</button>` : ''}
      </span>
    </div>`;
  }

  function sourceDetail(source) {
    const feeds = (model.modules || []).filter(module => module.feeds.some(feed => feed.sourceId === source.id));
    const canNotFeed = (model.modules || []).filter(module => !source.feedableModules.includes(module.id));
    const customDb = isCustomDatabase(source);
    const connector = source.connector || {};
    const discovery = source.discovery || {};
    const queryText = customDb
      ? (source.query && source.query.trim() ? T('Elle yazılmış / Excel’den keşfedilmiş', 'Hand-written / discovered from Excel') : T('Tanımlı değil', 'Not defined'))
      : (source.queryMode === 'manual' ? T('Elle yazılmış', 'Hand-written') : T('Otomatik üretilir', 'Generated'));
    const customMeta = customDb ? `<div class="dmDetailRow dmDatabaseMeta">
      <span class="dmLabel">${esc(T('Database metadata', 'Database metadata'))}</span>
      <span class="dmValue">${esc(connectorKindText(source))}${connector.driver ? ` · ${esc(connector.driver)}` : ''}${connector.provider ? ` · ${esc(connector.provider)}` : ''}${connector.dsn ? ` · DSN: ${esc(connector.dsn)}` : ''} · ${esc(connectorAuthText(source))}</span>
    </div>${discovery.origin === 'excel-workbook' ? `<div class="dmDetailRow dmDetailRow--quiet"><span class="dmLabel">${esc(T('Tanımlama kaynağı', 'Definition origin'))}</span><span class="dmValue">${esc(T('Excel bağlantısından', 'From Excel connection'))}${discovery.workbookName ? ` · ${esc(discovery.workbookName)}` : ''}${discovery.connectionName ? ` · ${esc(discovery.connectionName)}` : ''}</span></div>` : ''}` : '';
    return `<div class="dmDetail" role="region" aria-label="${esc(source.name)}">
      <div class="dmDetailGrid">
        <div><span class="dmLabel">${esc(T('Bağlantı', 'Connection'))}</span>
          <span class="dmValue">${esc(source.connection.server)} / ${esc(source.connection.catalog)}</span></div>
        <div><span class="dmLabel">${esc(T('Kaynak türü', 'Source type'))}</span>
          <span class="dmValue">${esc(customDb ? connectorKindText(source) : source.profileLabel)}</span></div>
        <div><span class="dmLabel">${esc(T('Sorgu', 'Query'))}</span>
          <span class="dmValue">${esc(queryText)}
            ${model.canManage && (source.capabilities || []).includes('manual-query')
              ? `<button type="button" class="dmInlineLink" data-open-query="${esc(source.id)}">${esc(source.query && source.query.trim() ? T('düzenle', 'edit') : T('ekle', 'add'))}</button>` : ''}
          </span></div>
        <div><span class="dmLabel">${esc(customDb ? T('Authentication', 'Authentication') : T('Eşlenmiş alan', 'Mapped fields'))}</span>
          <span class="dmValue">${customDb ? esc(connectorAuthText(source)) : source.mappedFieldCount}</span></div>
      </div>
      ${customMeta}
      ${mappingEditorSourceId === source.id ? '' : mappingSection(source)}
      <div class="dmMappingSlot" data-mapping-slot="${esc(source.id)}"></div>
      ${cpColumnsSection(source)}
      <div class="dmCpSlot" data-cpcolumns-slot="${esc(source.id)}"></div>
      <div class="dmQuerySlot" data-query-slot="${esc(source.id)}"></div>
      <div class="dmConnSlot" data-connection-slot="${esc(source.id)}"></div>
      ${customDb ? '' : `<div class="dmDetailRow">
        <span class="dmLabel">${esc(T('Beslediği modüller', 'Feeds'))}</span>
        <span class="dmValue">${feeds.length ? feeds.map(module => esc(module.label)).join(' · ') : esc(T('henüz yok', 'none yet'))}</span>
      </div>
      ${canNotFeed.length ? `<div class="dmDetailRow dmDetailRow--quiet">
        <span class="dmLabel">${esc(T('Besleyemez', 'Cannot feed'))}</span>
        <span class="dmValue">${canNotFeed.map(module => esc(module.label)).join(' · ')}</span>
      </div>` : ''}`}
      <div class="dmDetailActions">
        ${source.mapping && source.mapping.needsAttention ? `<button type="button" class="navActionBtn" data-open-mapping="${esc(source.id)}">
          ${esc(T(`${source.mapping.needsAttention} alanı gözden geçir`, `Review ${source.mapping.needsAttention} fields`))}
        </button>` : ''}
        ${model.canManage && customDb ? `<button type="button" class="tbtn" data-test-database="${esc(source.id)}">${esc(T('Bağlantıyı Test Et', 'Test Connection'))}</button>` : ''}
        ${model.canManage && !customDb ? `<button type="button" class="tbtn" data-open-connection="${esc(source.id)}">
          ${esc(T('Bağlantıyı düzenle', 'Edit connection'))}
        </button>` : ''}
        ${model.canManage ? `<span class="dmDetailSpacer"></span>
        <button type="button" class="tbtn danger" data-delete-source="${esc(source.id)}"
          title="${esc(T('Kaynağı ve ona bağlı bütün ayarları kalıcı olarak siler', 'Permanently deletes the source and every setting attached to it'))}">
          ${esc(T('Kaynağı sil', 'Delete source'))}
        </button>` : ''}
      </div>
    </div>`;
  }

  /* KAYNAĞI SİL.

     Silme geri alınamaz ve kapatmaktan farklıdır: bağlantı, alan eşlemesi,
     kapsam filtreleri ve park edilmiş bağlantılar birlikte gider. Bu yüzden
     onay kutusu NE KAYBEDİLECEĞİNİ sayar ve kullanıcıya kaynağın adını
     yazdırır — kart listesinde yanlış kartı silmek fazlasıyla kolaydı.
     "Emin misiniz?" diye sorup içeriği söylememek karar değil, kumar. */
  async function deleteSource(sourceId) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source || !model.canManage) return;

    const feeds = (model.modules || [])
      .filter(module => module.feeds.some(feed => feed.sourceId === source.id))
      .map(module => module.label);
    const losses = [
      feeds.length ? T(`${feeds.length} modül bağlantısı (${feeds.join(', ')})`, `${feeds.length} module bindings (${feeds.join(', ')})`) : '',
      source.mappedFieldCount ? T(`${source.mappedFieldCount} alan eşlemesi`, `${source.mappedFieldCount} field mappings`) : '',
      (source.parkedModules || []).length ? T(`${source.parkedModules.length} park edilmiş bağlantı`, `${source.parkedModules.length} parked bindings`) : '',
    ].filter(Boolean);

    /* UYGULAMA İÇİ metin girişi kullanılır, native prompt() DEĞİL.
       Bu bir üslup tercihi değil: prompt() bastırıldığında null döner ve
       "vazgeçildi"den ayırt edilemez — silme sessizce hiç çalışmazdı.
       openHorizonTextInput app-main.js'te tanımlı ve bu uygulamanın kendi
       metin giriş yüzeyi; ikinci bir kopya üretmek §9'a aykırı olurdu. */
    const question = T(
      `"${source.name}" kalıcı olarak silinecek. Birlikte gidecekler: ${losses.length ? losses.join(', ') : 'kayıtlı bir ayar yok'}. Onaylamak için kaynağın adını yazın.`,
      `"${source.name}" will be permanently deleted. This also removes: ${losses.length ? losses.join(', ') : 'no stored settings'}. Type the source name to confirm.`);
    if (typeof openHorizonTextInput !== 'function') {
      /* native prompt()'a DÜŞÜLMEZ. Bastırıldığında null döner ve "vazgeçildi"
         ile ayırt edilemez; geri alınamaz bir işlemi belirsiz bir onaya
         bağlamak kabul edilemez. Giriş yüzeyi yoksa silme yapılmaz. */
      if (typeof showToast === 'function') {
        showToast(T('Onay penceresi açılamadı; sayfayı yenileyip tekrar deneyin.',
          'The confirmation dialog could not open; reload the page and try again.'));
      }
      return;
    }
    const typed = await openHorizonTextInput({
      title: T('Kaynağı sil', 'Delete source'),
      label: question,
      confirmLabel: T('Sil', 'Delete'),
      maxLength: 80,
    });
    if (typed == null) return;

    try {
      const response = await fetch(`/api/data-management/source/${encodeURIComponent(sourceId)}`, {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expectedName: typed, expectedSourceRevision: source.revision }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Kaynak silinemedi.', 'Could not delete the source.'));
      if (typeof showToast === 'function') {
        const removed = payload.removed || {};
        showToast(T(`${removed.name || source.name} silindi.`, `${removed.name || source.name} deleted.`)
          + (payload.warnings && payload.warnings.length ? ` ${payload.warnings.join(' ')}` : ''));
      }
      if (expandedSourceId === sourceId) expandedSourceId = '';
      if (mappingEditorSourceId === sourceId) mappingEditorSourceId = '';
      await load();
    } catch (error) {
      if (typeof showToast === 'function') showToast(String(error && error.message || error));
    }
  }

  /* ---------------------------------------------------------------- */

  /* İKİ UFUK — HORIZON VE YENİLEME (v2026-10-30, kullanıcı kararı)

     "Veri kaynağı refresh horizonlarını sadece 2 basit horizon seçimine
     daraltacağım (INTAKE hariç). CP ayrı, diğer modüller ayrı çalışacak.
     Diğer modüller yenilendiğinde CP de yenilensin. Data Management'ta da
     bunları birleştirelim."

     Bu panel eski üç yapının yerini alır: bağlı grup paneli (modül ekle /
     ayır), modül başına ayrı filtre ("yalnız bunu ayır") ve adlandırılmış
     yenileme grupları. Her ufuk bir satırdır: hangi kaynağın hangi filtreyle
     beslediği, kendi Yenile düğmesi ve filtre düzenleyicisinin açılacağı yer.
     Grup tanımı sunucudan gelir (read-model › horizonGroups). INTAKE kendi
     ekranından ve kendi bağlantısıyla yenilenir. */
  const HORIZON_TEXT = {
    cp: {
      title: { tr: 'CP', en: 'CP' },
      hint: { tr: 'Yalnız CP Tracker’ı besler; tek başına yenilenebilir.', en: 'Feeds CP Tracker only; it can be refreshed on its own.' },
      refresh: { tr: 'CP’yi yenile', en: 'Refresh CP' },
    },
    linked: {
      title: { tr: 'Diğer modüller', en: 'Other modules' },
      hint: { tr: 'Tek ortak ufuk. Yenilenirken CP de yenilenir; LFL tek başına da yenilenebilir.', en: 'One shared horizon. CP is refreshed along with it; LFL can also be refreshed on its own.' },
      refresh: { tr: 'Diğer modülleri + CP’yi yenile', en: 'Refresh other modules + CP' },
    },
    intake: {
      title: { tr: 'INTAKE', en: 'INTAKE' },
      hint: { tr: 'Bağımsız kaynak ve filtre; kendi ekranından yenilenir.', en: 'Independent source and filter; refreshes from its own screen.' },
    },
  };
  const DEFAULT_HORIZON_GROUPS = [
    { id: 'cp', targets: ['cp'] },
    { id: 'linked', targets: ['orders', 'backlog', 'lfl', 'priceanalysis'] },
  ];
  const horizonGroupsOf = () => (Array.isArray(model && model.horizonGroups) && model.horizonGroups.length
    ? model.horizonGroups : DEFAULT_HORIZON_GROUPS);
  const textOf = entry => entry[en() ? 'en' : 'tr'];

  /* Bir ufkun kaynak beslemeleri: kaynak başına bir çip. Grubun üyeleri aynı
     kapsamı paylaştığı için, kaynağı besleyen ilk üyenin beslemesi grubun
     filtresidir; düzenleyici o üye üzerinden açılır (sunucu bütün üyelere yazar). */
  function horizonFeeds(group) {
    const seen = new Set();
    const out = [];
    for (const moduleId of group.targets) {
      const module = (model.modules || []).find(entry => entry.id === moduleId);
      for (const feed of module ? module.feeds : []) {
        if (seen.has(feed.sourceId)) continue;
        seen.add(feed.sourceId);
        out.push({ moduleId, feed });
      }
    }
    return out;
  }

  function horizonRow(group) {
    const text = HORIZON_TEXT[group.id] || HORIZON_TEXT.linked;
    const busy = Boolean(window.BL_REFRESH_BUSY);
    const members = group.targets.map(moduleLabel).join(' · ');
    const feeds = horizonFeeds(group).map(({ moduleId, feed }) => {
      const name = feed.filterName || (feed.filterBounded ? feed.filterText : T('Filtre yok', 'No filter'));
      const layer = LAYER[feed.layer];
      return `<span class="dmFeed${feed.enabled ? '' : ' isOff'}">
        <span class="dmFeedSource">${esc(feed.sourceName)}</span>
        <button type="button" class="dmFeedFilter${feed.filterBounded ? '' : ' isUnbounded'}"
          data-open-filter="${esc(moduleId)}:${esc(feed.sourceId)}" data-horizon-group="${esc(group.id)}"
          title="${esc(feed.filterText || T('Filtre tanımlı değil', 'No filter defined'))}">${esc(name)}</button>
        ${layer ? (feed.layerRemovable
          ? `<button type="button" class="dmLayer dmLayer--${esc(feed.layer)} isRemovable" data-clear-layer="${esc(moduleId)}:${esc(feed.sourceId)}"
              title="${esc(`${layer.hint[en() ? 'en' : 'tr']}\n${T('Kaldırmak için tıklayın — ortak filtre yeniden geçerli olur.', 'Click to remove — the shared filter takes effect again.')}`)}">${esc(layer[en() ? 'en' : 'tr'])} ×</button>`
          : `<span class="dmLayer dmLayer--${esc(feed.layer)}" title="${esc(layer.hint[en() ? 'en' : 'tr'])}">${esc(layer[en() ? 'en' : 'tr'])}</span>`) : ''}
      </span>`;
    }).join('');
    // Kaynak filtresi tek kez görünür; isteğe bağlı modül bağlantıları korunur.
    const connections = group.targets.map(moduleId => {
      const module = (model.modules || []).find(entry => entry.id === moduleId);
      if (!module) return '';
      return module.feeds.map(feed => model.canManage && !feed.locked ? `<button type="button" class="dmDisconnect" data-toggle="${esc(feed.sourceId)}:${esc(module.id)}" data-next="off"
          ${busyCell === `${feed.sourceId}:${module.id}` ? 'disabled' : ''}
          title="${esc(T(`${feed.sourceName} bağlantısını kapat — filtre ve eşleme korunur`, `Disconnect ${feed.sourceName} — filter and mapping are preserved`))}"
          aria-label="${esc(T(`${feed.sourceName} · ${module.label} bağlantısını kapat`, `Disconnect ${feed.sourceName} · ${module.label}`))}">${esc(feed.sourceName)} · ${esc(module.label)} ×</button>` : '').join('')
        + connectables(module, group.targets.length > 1);
    }).join('');
    const needsFilter = group.targets.some(moduleId => ((model.modules || []).find(entry => entry.id === moduleId) || {}).needsFilter);
    return `<div class="dmHorizonRow${needsFilter ? ' hasWarning' : ''}" data-horizon-row="${esc(group.id)}">
      <div class="dmHorizonHead">
        <span class="dmHorizonTitle">${esc(textOf(text.title))}</span>
        ${group.id === 'linked' ? `<span class="dmHorizonMembers">${esc(members)}</span>` : ''}
        <span class="dmHorizonHint">${esc(textOf(text.hint))}</span>
        <span class="dmSummarySpacer"></span>
        ${horizonFeeds(group).length ? `<button type="button" class="tbtn dmHorizonEdit" data-open-horizon="${esc(group.id)}"
          title="${esc(T('Bu ufkun ASAS / IAS filtresini çekmecede düzenle', 'Edit this horizon\'s ASAS / IAS filter in the drawer'))}">
          <svg class="ic"><use href="#i-filter"/></svg>${esc(T('Filtreyi düzenle', 'Edit filter'))}</button>` : ''}
        ${text.refresh ? `<button type="button" class="tbtn" data-refresh-horizon="${esc(group.id)}" ${busy ? 'disabled' : ''}
          title="${esc(busy ? T('Bir yenileme zaten sürüyor', 'A refresh is already running') : textOf(text.refresh))}">
          <svg class="ic"><use href="#i-refresh"/></svg>${esc(textOf(text.refresh))}</button>` : ''}
        ${group.targets.includes('lfl') && group.id !== 'cp' ? `<button type="button" class="tbtn" data-refresh-horizon="lfl" ${busy ? 'disabled' : ''}
          title="${esc(busy ? T('Bir yenileme zaten sürüyor', 'A refresh is already running') : T('Yalnız LFL\'i yenile — LFL IAS\'tan beslenmez; ortak ufukla çalışır', 'Refresh LFL only — LFL is not fed from IAS; it runs with the shared horizon'))}">
          <svg class="ic"><use href="#i-refresh"/></svg>${esc(T('Yalnız LFL', 'LFL only'))}</button>` : ''}
      </div>
      <div class="dmHorizonFeeds">${feeds || `<span class="dmModuleEmpty">${esc(T('Hiçbir kaynağa bağlı değil', 'Not connected to any source'))}</span>`}${connections}
        ${needsFilter ? `<span class="dmWarn" title="${esc(T('Sınırsız sorgu çalıştırılamaz; bu ufuk yenilenmeden önce bir filtre gerekir.', 'An unbounded query cannot run; this horizon needs a filter before it can refresh.'))}">${esc(T('filtre gerekli', 'filter required'))}</span>` : ''}
      </div>
    </div>`;
  }

  /* v2026-10-30 — İKİ UFKA GEÇİŞ NOTU (kullanıcı kararı: "uygun olanı yap").
     Geçişte kendi filtresiyle ayrı duran bir modül (ör. LFL, IAS Backlog)
     Diğer modüllerin ortak ufkuna katıldı; o modülün VERİ KAPSAMI değişmiş
     olabilir. Not hangi kaynakta hangi modülün etkilendiğini ve eski filtreyi
     açıkça söyler; kullanıcı "Anladım" deyince bu tarayıcıda gizlenir. Eski
     filtre silinmez (linkRestore). Listeye yeni bir kayıt eklenirse parmak
     izi değişir ve not yeniden görünür. */
  const MERGED_NOTE_KEY = 'bl.dataManagement.mergedFiltersSeen.v1';
  const mergedFingerprint = merged => merged.map(entry => `${entry.sourceId}:${entry.moduleId}:${entry.filterText || entry.filterName || ''}`).sort().join('|');
  function mergedNoteSeen(merged) {
    try { return (window.BLStorage || window.localStorage).getItem(MERGED_NOTE_KEY) === mergedFingerprint(merged); }
    catch (_) { return false; }
  }
  function dismissMergedNote() {
    const merged = Array.isArray(model && model.mergedFilters) ? model.mergedFilters : [];
    try { (window.BLStorage || window.localStorage).setItem(MERGED_NOTE_KEY, mergedFingerprint(merged)); } catch (_) {}
    render();
  }
  function mergedNote(merged) {
    if (!merged.length || mergedNoteSeen(merged)) return '';
    const items = merged.map(entry => `<li>${esc(entry.sourceName)} · ${esc(moduleLabel(entry.moduleId))} — ${esc(T('eski filtre', 'previous filter'))}: ${esc(entry.filterName || entry.filterText || '—')}</li>`).join('');
    return `<div class="dmGroupNote" data-merged-note>
      <p>${esc(T(
        'Bu modüller eskiden kendi filtreleriyle çalışıyordu ve artık Diğer modüllerin ortak ufkunu kullanıyor; bir sonraki yenilemede verileri bu ortak ufka göre gelir. Eski filtreler silinmedi, saklanıyor.',
        'These modules used to run with their own filters and now use the shared Other modules horizon; from the next refresh their data follows this shared horizon. The previous filters were not deleted; they are kept.'))}</p>
      <ul>${items}</ul>
      <button type="button" class="tbtn" data-dismiss-merged-note>${esc(T('Anladım', 'Got it'))}</button>
    </div>`;
  }

  function horizonPanel() {
    const merged = Array.isArray(model.mergedFilters) ? model.mergedFilters : [];
    // Panel anahtarı eski "Yenileme" paneliyle aynı kalır: katlanma tercihi korunur.
    return `<div class="dmPanel dmHorizon" data-dm-panel="refresh">
      <div class="dmPanelHead">
        <span class="dmPanelTitle">${esc(T('Horizon ve yenileme', 'Horizon and refresh'))}</span>
      </div>
      ${horizonGroupsOf().map(horizonRow).join('')}
      ${horizonRow({ id: 'intake', targets: ['intake'] })}
      ${mergedNote(merged)}
      ${refreshSettings()}
    </div>`;
  }

  function refreshHorizon(groupId) {
    // "Yalnız LFL": sunucu ve istemci LFL'i tek başına yeniler (LINKED_STANDALONE_TARGETS).
    const group = groupId === 'lfl' ? { id: 'lfl', targets: ['lfl'] } : horizonGroupsOf().find(entry => entry.id === groupId);
    if (!group) return;
    /* İKİNCİ BİR YENİLEME MOTORU YOK: mevcut akış (iş kuyruğu, aşama paneli,
       iptal, filtre-gerekli uyarısı) kullanılır. "Diğer modüller" isteğini
       istemci ve sunucu CP ile genişletir. */
    if (typeof window.loadFromServer !== 'function') {
      if (typeof showToast === 'function') showToast(T('Yenileme akışı henüz hazır değil.', 'The refresh flow is not ready yet.'));
      return;
    }
    if (window.BL_REFRESH_BUSY) { if (typeof showToast === 'function') showToast(T('Bir yenileme zaten sürüyor.', 'A refresh is already running.')); return; }
    void Promise.resolve(window.loadFromServer(true, group.targets.slice())).then(() => load());
  }

  /* Bu modülü besleyebilecek ama şu an bağlı OLMAYAN kaynaklar.
     Ortak ufukta düğme hangi modülün bağlantısını açacağını da söyler. */
  function connectables(module, showModule = false) {
    if (!model.canManage) return '';
    return (model.sources || []).map(source => {
      if (model.matrix.cells[`${source.id}:${module.id}`] !== 'off') return '';
      const parked = (source.parkedModules || []).find(entry => entry.moduleId === module.id);
      const busy = busyCell === `${source.id}:${module.id}`;
      /* Park edilmiş kaynak "eklenebilir bir seçenek" değil, KAPATILMIŞ BİR
         BESLEMEDİR. Düğme bunu kendi söyler: yoksa kullanıcı kısalmış satıra
         bakıp verinin neden gelmediğini bilemez ve boş sütunları arıza sanar.
         Durum ile eylemi iki ayrı öğeye bölmek satırı gereksiz kalabalıklaştırırdı
         (§48); tek düğme ikisini de taşır. */
      return `<button type="button" class="dmConnect${parked ? ' isParked' : ''}" data-toggle="${esc(source.id)}:${esc(module.id)}" data-next="on" ${busy ? 'disabled' : ''}
        title="${esc(parked
          ? T(`${source.name} verisi bu modüle çekilmiyor. Tekrar bağla — eski filtren geri gelir.`, `${source.name} data is not pulled for this module. Reconnect — your previous filter returns.`)
          : T(`${source.name} ile bağla — sonra bir filtre tanımlaman gerekir`, `Connect ${source.name} — you will need to define a filter`))}">
        ${parked
          ? `↻ ${esc(source.name)} <span class="dmParkedNote">${esc(T('çekilmiyor', 'not pulled'))}</span>`
          : `+ ${esc(source.name)}`}${showModule ? ` · ${esc(module.label)}` : ''}
      </button>`;
    }).join('');
  }

  const moduleLabel = moduleId => {
    const found = (model.modules || []).find(entry => entry.id === moduleId);
    return found ? found.label : moduleId.toUpperCase();
  };

  /* Yenileme grupları. §23: "Bundan daha karmaşık configuration istemiyorum."
     Ad + onay kutuları, o kadar. Zamanlama ve koşul BİLEREK yok — otomatik
     yenileme zaten ayrı bir ayar ve onu buraya kopyalamak aynı yapılandırmanın
     iki yerde yaşaması demek olurdu. */
  /* =================================================================
     KAYNAK MODU (§7 — "Kaynak Veri" şeridinden taşındı)

     "Bu sayfa ailesi Excel'den mi, Database'den mi besleniyor?" Bu soru
     aşağıdaki bağlantı kartlarından ÖNCE gelir: Excel seçiliyse o kartlardaki
     model bağlantısı hiç sorgulanmaz. Şeritte dururken kullanıcı bağlantıyı
     kurup neden çalışmadığını anlamıyordu; karar artık sonucunu göreceği
     yerde, kartların hemen üstünde.

     MARKUP BİREBİR TAŞINDI. Kimlikler (#asasSourceControl…) ve veri
     öznitelikleri (data-asas-source-mode…) korunuyor; app-main.js'teki
     renderAsasSourceControl / renderAntrepoSourceControl / renderLflSourceControl
     seçiciyle çalıştığı için değiştirilmeden çalışmaya devam ediyor. İkinci bir
     durum yönetimi yazmak, iki ayrı doğruluk kaynağı demek olurdu (§9).

     TIKLAMA BAĞLAMASI DEĞİŞTİ. Eskiden düğmelere açılışta TEK SEFER
     bağlanıyordu; bu ekran her çizimde DOM'u yeniden kurduğu için o bağlama
     kaybolurdu. Ekranın kendi olay delegasyonu kullanılıyor. */
  const SOURCE_MODES = [
    {
      id: 'asasSourceControl', attr: 'data-asas-source-mode', fileId: 'asasSourceFile',
      label: { tr: 'ASAS Kaynağı', en: 'ASAS Source' },
      hint: {
        tr: 'CP, Siparişler, Backlog ve LFL sipariş satırlarını nereden alır.',
        en: 'Where CP, Orders, Backlog and LFL read their order lines from.',
      },
      modes: [['excel', 'Excel'], ['database', 'Database']],
      set: mode => setAsasSourceMode(mode),
    },
    {
      id: 'antrepoSourceControl', attr: 'data-source-mode', fileId: 'antrepoSourceFile',
      label: { tr: 'Antrepo Kaynağı', en: 'Bonded Warehouse Source' },
      hint: {
        tr: 'Antrepo/parsiyel satırlarının geldiği yer.',
        en: 'Where bonded warehouse / partial shipment rows come from.',
      },
      modes: [['excel', 'Excel'], ['database', 'Database'], ['dashboard', 'Dashboard']],
      set: mode => setAntrepoSourceMode(mode),
    },
    {
      id: 'lflSourceControl', attr: 'data-lfl-source-mode', fileId: 'lflSourceFile',
      label: { tr: 'LFL Kaynağı', en: 'LFL Source' },
      hint: {
        tr: 'LFL karşılaştırma satırları; ASAS ile aynı kitaptan beslenir ama seçimi bağımsızdır.',
        en: 'LFL comparison rows; fed from the same workbook as ASAS but selected independently.',
      },
      modes: [['excel', 'Excel'], ['database', 'Database']],
      set: mode => setLflSourceMode(mode),
    },
  ];

  function sourceModePanel() {
    if (!model.canManage) return '';
    return `<div class="dmPanel dmModes" data-dm-panel="modes">
      <div class="dmPanelHead">
        <span class="dmPanelTitle">${esc(T('Kaynak modu', 'Source mode'))}</span>
        <span class="dmsHint">${esc(T(
          'Excel seçiliyse model bağlantısı hiç sorgulanmaz.',
          'When Excel is selected, the model connection is never queried.'))}</span>
      </div>
      ${SOURCE_MODES.map(group => `<div class="dmModeRow">
        <span class="dmModeText">
          <span class="dmToolName">${esc(group.label[en() ? 'en' : 'tr'])}</span>
          <span class="dmToolHint">${esc(group.hint[en() ? 'en' : 'tr'])}</span>
        </span>
        <span class="sourceModeGroup" id="${esc(group.id)}" aria-label="${esc(group.label[en() ? 'en' : 'tr'])}">
          ${group.modes.map(([value, text]) =>
            `<button type="button" class="sourceModeBtn" ${group.attr}="${esc(value)}">${esc(text)}</button>`).join('')}
          <span class="sourceModeFile" id="${esc(group.fileId)}">—</span>
        </span>
      </div>`).join('')}
    </div>`;
  }

  /* Ekran her çizimde DOM'u baştan kurduğu için aktif durum yeniden
     uygulanmalı. Durumun kendisi app-main.js'te yaşıyor; buradan yalnız
     "yeniden çiz" deniyor, ikinci bir kopya tutulmuyor. */
  function syncSourceModes() {
    for (const fn of ['renderAsasSourceControl', 'renderAntrepoSourceControl',
      'renderLflSourceControl', 'renderAutoRefreshState']) {
      try { if (typeof window[fn] === 'function') window[fn](); } catch (_) { /* ekranı düşürme */ }
    }
  }

  /* =================================================================
     ARAÇLAR (§7 — "Kaynak Veri" ayarlar menüsünden taşınanlar)

     Bu on üç iş eskiden kenar çubuğundaki Ayarlar açılır menüsünde, tek bir
     etiketsiz yığın hâlinde duruyordu: iş kuralları, referans veri, dosya
     yüklemeleri, sistem ayarları ve tanı araçları yan yana. Kullanıcı bir
     şeyi bulmak için hepsini okumak zorundaydı ve hiçbiri ne yaptığını
     söylemiyordu.

     BURADA ÜÇ SORUYA GÖRE AYRILIYORLAR:

       Hesaplama kuralları  → "uygulama bu sayıyı nasıl hesaplıyor?"
       Referans veri        → "bu liste nereden geliyor, nasıl güncellenir?"
       Depolama ve bakım    → "veri nerede duruyor, sağlıklı mı?"

     Her satır NE YAPTIĞINI yazar. Bir kurulum ekranında asıl maliyet tıklama
     değil, doğru aracı bulmak için açıp kapamaktır.

     DÜZENLEYİCİLER YENİDEN YAZILMADI. Her satır bugün çalışan editörü çağırır;
     ikinci bir kopya üretmek §9'a aykırı olurdu. Tembel yüklenen modüller
     (e-posta grupları, yedekleme) çağrılmadan önce beklenir. */
  const TOOL_GROUPS = [
    {
      id: 'rules',
      label: { tr: 'Hesaplama kuralları', en: 'Calculation rules' },
      hint: {
        tr: 'Ortak kurallar: değiştirmek herkesin gördüğü sayıyı değiştirir.',
        en: 'Shared rules: changing one changes the numbers everyone sees.',
      },
      tools: [
        { id: 'merch', icon: 'i-calculator', inline: true,
          label: { tr: 'Merch Calendar', en: 'Merch Calendar' },
          hint: { tr: 'LCW hafta, ay ve ay-hafta takvimini yükle ve yönet (53. hafta desteklenir).',
            en: 'Upload and manage LCW week, month and month-week calendar (supports week 53).' } },
        { id: 'transit', requires: 'manageBusinessRules', icon: 'i-ship',
          label: { tr: 'Yol Süreleri', en: 'Transfer Lead Times' },
          hint: { tr: 'Üretim ülkesi ve sevkiyat tipine göre transit gün sayısı; tahmini varış bundan hesaplanır. İthalat Yol Süresi Raporu Excel\'inden ülke/taşıt analizi ve kural önerisi.',
            en: 'Transit days by production country and shipment type; estimated arrival is derived from this. Country/vehicle analysis and rule suggestions from the import lead-time report Excel.' },
          run: () => openTransitRulesModal() },
        { id: 'importance', icon: 'i-tag',
          label: { tr: 'Sipariş Önem Etiketleri', en: 'Order Importance Tags' },
          hint: { tr: 'BTS, Transition, Bayram, Ekvator, New Year gibi özel sipariş etiketleri ve Line kuralları. Etiketsiz sipariş Regular sayılır; CP, Orders ve Backlog aynı listeyi kullanır.',
            en: 'Special-order tags such as BTS, Transition, Eid, Equator and New Year, plus Line rules. Untagged orders count as Regular; CP, Orders and Backlog share the same list.' },
          run: () => window.BLOrderImportanceUI?.openSettings?.() },
        { id: 'landed', requires: 'manageBusinessRules', icon: 'i-calculator',
          label: { tr: 'Landed Çarpanları', en: 'Landed Multipliers' },
          hint: { tr: 'Koleksiyon TR ve Overseas landed maliyet çarpanları.',
            en: 'Collection TR and Overseas landed cost multipliers.' },
          run: () => openLandedMultipliersModal() },
        { id: 'royalty', requires: 'manageBusinessRules', icon: 'i-calculator',
          label: { tr: 'Lisans Kartları', en: 'License Cards' },
          hint: { tr: 'OPD tarih aralığı, sezon, üretim ülkesi, Licensor ve License bazlı royalty ve hologram hesapları.',
            en: 'Royalty and hologram calculations by OPD date range, season, production country, Licensor and License.' },
          run: () => openSuppFobRulesModal() },

      ],
    },
    {
      id: 'reference',
      label: { tr: 'Referans veri ve yüklemeler', en: 'Reference data and uploads' },
      hint: {
        tr: 'Bağlantıdan değil, dosya ya da elle girişten gelen ortak veri.',
        en: 'Shared data that arrives from a file or manual entry rather than a connection.',
      },
      tools: [
        /* v7.0.229 — E-Mail Grupları "Üreticiler" olarak sol menüye taşındı;
           buradaki araç o sayfaya götürür (sayfa yoksa rehberi açar). */
        { id: 'emailgroups', icon: 'i-mail-send',
          label: { tr: 'Üreticiler (eski E-Mail Grupları)', en: 'Manufacturers (formerly E-Mail Groups)' },
          hint: { tr: 'Üretici kartları ve e-posta rehberi artık sol menüdeki Üreticiler sayfasında.',
            en: 'Manufacturer cards and the e-mail directory now live on the Manufacturers page in the left menu.' },
          run: async () => { if (typeof window.switchTab === 'function' && document.getElementById('view-manufacturers')) { window.switchTab('manufacturers'); return; } await feature('deferredUi'); window.BLEmailGroups?.open?.(); } },
        { id: 'fx', requires: 'manageBusinessRules', icon: 'i-coins',
          label: { tr: 'Kur Excel’i', en: 'FX Excel' },
          hint: { tr: 'Döviz kuru tablosunu Excel’den yükler.', en: 'Loads the exchange-rate table from Excel.' },
          run: () => document.getElementById('sourceFxFile')?.click() },
        { id: 'endeksmatik', requires: 'manageModelConnections', icon: 'i-file-import',
          label: { tr: 'Endeksmatik Güncelle', en: 'Update Endeksmatik' },
          hint: { tr: 'Yeni ENDEKSMATİK çalışma kitabını doğrular ve yükler.',
            en: 'Validates and loads a new ENDEKSMATIK workbook.' },
          run: () => triggerEndeksmatikUpload() },
        { id: 'endeksmatikSets', icon: 'i-calculator',
          label: { tr: 'Endeksmatik Setleri', en: 'Endeksmatik Sets' },
          hint: { tr: 'Yüklenen ülke/bölge Endeksmatik setlerini listeler; varsayılan seti seçer.',
            en: 'Lists uploaded country/region Endeksmatik sets; chooses the default set.' },
          run: () => openEndeksmatikSetManager() },
        { id: 'folder', icon: 'i-folder',
          label: { tr: 'Kaynak Klasör', en: 'Source Folder' },
          hint: { tr: 'Excel kaynaklarının okunduğu klasör; model erişilemezse kullanılan yol.',
            en: 'The folder Excel sources are read from; the fallback path when the model is unreachable.' },
          /* SEÇİLİ YOL GÖSTERİLİR. Eski düğme onu kendi etiketinde taşıyordu;
             araç satırına taşınırken düşürülseydi kullanıcı hangi klasörün
             bağlı olduğunu hiçbir yerde göremezdi. */
          value: () => (model.environment || {}).sourceFolder || '',
          run: () => chooseSourceFolder() },
      ],
    },
    {
      id: 'storage',
      label: { tr: 'Depolama ve bakım', en: 'Storage and maintenance' },
      hint: {
        tr: 'Verinin nerede durduğu ve sağlığı. Analiz salt okunurdur.',
        en: 'Where the data lives and how healthy it is. Analysis is read-only.',
      },
      tools: [
        { id: 'maintenance', icon: 'i-database-import', inline: true,
          label: { tr: 'Data Maintenance', en: 'Data Maintenance' },
          hint: { tr: 'Yerel veri, PLM, cache ve Shared Sync sağlığını analiz eder; iş verisi silinmez.',
            en: 'Analyzes local data, PLM, cache and Shared Sync health; business data is never deleted.' } },
        { id: 'cleanup', icon: 'i-eraser', inline: true,
          label: { tr: 'Data Temizliği', en: 'Data Cleanup' },
          hint: { tr: 'Kurulum klasöründeki gereksiz dosyaları (zip, eski sürüm, geçici dosya) tarar, özetler ve siler. Moderatör sync klasöründeki eski yedekleri de temizler.',
            en: 'Scans, summarises and deletes unnecessary files in the install folder (zips, old versions, temp files). The Moderator can also clean stale backups in the sync folder.' } },
        { id: 'sync', icon: 'i-folder',
          label: { tr: 'Sync & Local Data', en: 'Sync & Local Data' },
          hint: { tr: 'Yerel veritabanının yeri ve paylaşılan senkron klasörü.',
            en: 'Local database location and the shared sync folder.' },
          run: () => openSyncLocalDataModal() },
        { id: 'backup', requires: 'manageModelConnections', icon: 'i-database-import',
          label: { tr: 'Yedekleme', en: 'Backup' },
          hint: { tr: 'Yedek al, geri yükle, zamanlanmış yedeklemeyi ayarla.',
            en: 'Take a backup, restore one, schedule automatic backups.' },
          run: async () => { await feature('deferredUi'); window.buyerLogBackupModal?.(); } },
        { id: 'imagelimit', icon: 'i-photo-size',
          label: { tr: 'Görsel Boyut Limiti', en: 'Image Size Limit' },
          hint: { tr: 'Kaydedilen model görsellerinin üst dosya boyutu.',
            en: 'Maximum file size for stored model images.' },
          run: () => openModelImageLimitModal() },
        { id: 'browser', icon: 'i-globe',
          label: { tr: 'Browser ve Remote Debugging', en: 'Browser & Remote Debugging' },
          hint: { tr: 'Kurumsal sitelerde mevcut tarayıcı oturumunu kullanan bağlantı.',
            en: 'The connection that reuses your existing browser session on corporate sites.' },
          run: () => openBrowserDebugSettingsModal() },
      ],
    },
  ];

  /* Tembel modül bekleyicisi. BLPerf yoksa (test koşumu) sessizce geçer. */
  function feature(name) {
    return window.BLPerf && typeof window.BLPerf.ensureFeature === 'function'
      ? window.BLPerf.ensureFeature(name)
      : Promise.resolve();
  }

  /* Ortak ayar düzenleyicileri Moderatörün verdiği izinle açılır; cihaza özel
     araçlar (kaynak klasör, senkron, görsel limiti, tarayıcı, bakım) Kaynak
     Veri alanı olan herkese açıktır. E-posta grupları herkese görünür,
     düzenleme yetkisi modülün içinde denetlenir. */
  function toolAllowed(tool) {
    if (!tool || !tool.requires) return true;
    return typeof window.BLHasPermission === 'function' ? window.BLHasPermission(tool.requires) : Boolean(model.canManage);
  }
  function visibleToolGroups() {
    return TOOL_GROUPS.map(group => ({ ...group, tools: group.tools.filter(toolAllowed) })).filter(group => group.tools.length);
  }

  function toolsPanel() {
    const groups = visibleToolGroups();
    if (!groups.length) return '';
    return `<div class="dmPanel dmTools" data-dm-panel="tools">
      <div class="dmPanelHead"><span class="dmPanelTitle">${esc(T('Araçlar', 'Tools'))}</span></div>
      ${groups.map(group => `<div class="dmToolGroup">
        <div class="dmToolGroupHead">
          <span class="dmToolGroupTitle">${esc(group.label[en() ? 'en' : 'tr'])}</span>
          <span class="dmsHint">${esc(group.hint[en() ? 'en' : 'tr'])}</span>
        </div>
        <ul class="dmToolList">
          ${group.tools.map(tool => `<li class="dmToolRow${openTool === tool.id ? ' isOpen' : ''}">
            <button type="button" class="dmTool" data-tool="${esc(tool.id)}">
              <svg class="ic" aria-hidden="true"><use href="#${esc(tool.icon)}"/></svg>
              <span class="dmToolText">
                <span class="dmToolName">${esc(tool.label[en() ? 'en' : 'tr'])}</span>
                <span class="dmToolHint">${esc(tool.hint[en() ? 'en' : 'tr'])}</span>
                ${typeof tool.value === 'function' && tool.value()
                  ? `<span class="dmToolValue" title="${esc(tool.value())}">${esc(tool.value())}</span>` : ''}
              </span>
            </button>
            ${tool.id === 'fx' ? '<div data-fx-folder-sync class="dmsHint" hidden></div>' : ''}
            ${tool.inline ? `<div class="dmToolSlot" data-tool-slot="${esc(tool.id)}">${openTool === 'merch' && tool.id === 'merch' ? merchCalendarPanel() : ''}</div>` : ''}
          </li>`).join('')}
        </ul>
      </div>`).join('')}
    </div>`;
  }

  function findTool(id) {
    for (const group of TOOL_GROUPS) {
      const found = group.tools.find(tool => tool.id === id);
      if (found) return found;
    }
    return null;
  }

  async function runTool(id) {
    const tool = findTool(id);
    if (!tool || !toolAllowed(tool)) return;

    if (tool.inline) {
      /* Satır içi araç ikinci tıklamada KAPANIR. Diğer düzenleyicilerle aynı
         davranış; açık bir paneli kapatmak için başka bir yol aramak gerekmez. */
      if (openTool === tool.id) { closeInlineTool(); return; }
      openTool = tool.id;
      render();
      const slot = root.querySelector(`[data-tool-slot="${CSS.escape(tool.id)}"]`);
      if (!slot) { openTool = ''; return; }
      slot.__onDataMaintClosed = () => { openTool = ''; render(); };
      if (tool.id === 'merch') return;
      if (tool.id === 'maintenance' && typeof openDataMaintenanceModal === 'function') {
        void openDataMaintenanceModal(slot);
      }
      if (tool.id === 'cleanup' && window.BLDataCleanup) {
        window.BLDataCleanup.open(slot, { onClose: slot.__onDataMaintClosed });
      }
      return;
    }

    try { await tool.run(); }
    catch (error) { if (typeof showToast === 'function') showToast(String(error && error.message || error)); }
  }

  function closeInlineTool() {
    const slot = root && root.querySelector('[data-tool-slot]');
    if (slot) slot.innerHTML = '';
    openTool = '';
    render();
  }

  /* Yenileme ayarları "Horizon ve yenileme" panelinin parçasıdır. Zamanlama
     ve koşul BİLEREK yok — değer ve zamanlayıcı app-main.js'te yaşar. */
  function refreshSettings() {
    return `${model.canManage ? `<div class="dmModeRow dmAutoRefresh">
        <span class="dmModeText">
          <span class="dmToolName">${esc(T('Otomatik yenileme', 'Auto refresh'))}</span>
          <span class="dmToolHint" id="autoRefreshNote"></span>
        </span>
        <select id="autoRefreshSelect" class="dmAutoSelect" aria-label="${esc(T('Otomatik yenileme', 'Auto refresh'))}">
          <option value="0">${esc(T('Kapalı', 'Off'))}</option>
          <option value="15">${esc(T('15 dk', '15 min'))}</option>
          <option value="30">${esc(T('30 dk', '30 min'))}</option>
          <option value="60">${esc(T('60 dk', '60 min'))}</option>
          <option value="120">${esc(T('2 sa', '2 h'))}</option>
          <option value="240">${esc(T('4 sa', '4 h'))}</option>
        </select>
      </div>` : ''}

      <div class="dmModeRow dmSourceWatch">
        <span class="dmModeText">
          <span class="dmToolName">${esc(T('Kaynak değişince otomatik güncelle', 'Update automatically when the source changes'))}</span>
          <span class="dmToolHint" id="sourceWatchNote"></span>
        </span>
        <label class="dmCheck">
          <input type="checkbox" id="sourceWatchToggle" aria-label="${esc(T('Kaynak değişince otomatik güncelle', 'Update automatically when the source changes'))}">
          <span>${esc(T('Açık', 'On'))}</span>
        </label>
      </div>

      <div class="dmModeRow dmRefreshTiming">
        <span class="dmModeText">
          <span class="dmToolName">${esc(T('Son yenileme süresi', 'Last refresh duration'))}</span>
          <span class="dmToolHint">${esc(T(
            'Tüm sayfalar için en son çalışan yenilemenin süresi.',
            'Duration of the most recent refresh across all pages.'))}</span>
        </span>
        <span class="sourceRefreshTimer" data-source-timer="all"
          aria-label="${esc(T('Yenileme süresi', 'Refresh duration'))}">—</span>
      </div>`;
  }

  const LAB_STATUS = {
    healthy: { tr: 'Sağlıklı', en: 'Healthy', tone: 'ok' },
    configured: { tr: 'Hazır', en: 'Configured', tone: 'ok' },
    warning: { tr: 'Uyarı', en: 'Warning', tone: 'warn' },
    failed: { tr: 'Başarısız', en: 'Failed', tone: 'bad' },
    unavailable: { tr: 'Kullanılamıyor', en: 'Unavailable', tone: 'muted' },
  };

  function labTabs() {
    const tabs = [['integrations', T('Entegrasyonlar', 'Integrations')]];
    if (model.canManage) tabs.push(
      ['inspector', T('Veri Denetçisi', 'Data Inspector')],
      ['automation', T('Browser Otomasyon Laboratuvarı', 'Browser Automation Lab')]);
    return `<div class="dmLabTabs" data-bl-tabs="line" role="tablist" aria-label="${esc(T('Entegrasyon laboratuvarı bölümleri', 'Integration lab sections'))}">${tabs.map(([id, label]) =>
      `<button type="button" id="dmLabTab-${id}" class="dmLabTab${labTab === id ? ' isActive' : ''}" data-lab-tab="${id}" role="tab" aria-controls="dmLabPanel" aria-selected="${labTab === id}" tabindex="${labTab === id ? '0' : '-1'}">${esc(label)}</button>`).join('')}</div>`;
  }

  function labInventory() {
    if (!lab || !(lab.inventory || []).length) return `<p class="dmLabEmpty">${esc(T('Kayıtlı entegrasyon bulunamadı.', 'No registered integrations found.'))}</p>`;
    return `<div class="dmLabTableWrap"><table class="dmLabTable">
      <thead><tr><th>${esc(T('Ad', 'Name'))}</th><th>${esc(T('Tür', 'Type'))}</th><th>${esc(T('Veri durumu', 'Data status'))}</th><th>${esc(T('Son kontrol', 'Last check'))}</th><th>${esc(T('Durum', 'Status'))}</th><th>${esc(T('Not', 'Note'))}</th><th></th></tr></thead>
      <tbody>${lab.inventory.map(item => {
        const status = LAB_STATUS[item.status] || { tr: item.status, en: item.status, tone: 'muted' };
        const database = item.kind === 'database';
        return `<tr>
          <td><strong>${esc(item.name)}</strong></td>
          <td>${esc(database ? T('Veritabanı', 'Database') : T('Web uygulaması', 'Web app'))}</td>
          <td>${item.rowCount == null ? '—' : `${Number(item.rowCount).toLocaleString(en() ? 'en-US' : 'tr-TR')} ${esc(T('satır', 'rows'))}`}</td>
          <td>${esc(shortTime(item.lastCheckedAt))}</td>
          <td><span class="dmLabStatus dmLabStatus--${status.tone}"><span class="dmDot dmDot--${status.tone}"></span>${esc(status[en() ? 'en' : 'tr'])}</span></td>
          <td>${esc(item.note || '—')}</td>
          <td>${model.canManage ? (database ? `<button type="button" class="tbtn" data-lab-inspect="${esc(item.id)}">${esc(T('İncele', 'Inspect'))}</button>` : `<button type="button" class="tbtn" data-lab-automation="${esc(String(item.id).replace(/^automation:/, ''))}">${esc(T('Dry run', 'Dry run'))}</button>`) : ''}</td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  }

  function currentInspector() {
    if (!lab) return null;
    return (lab.inspectors || []).find(item => item.sourceId === selectedLabSourceId) || lab.selectedInspector || null;
  }

  function labInspector() {
    const inspector = currentInspector();
    if (!inspector) return `<p class="dmLabEmpty">${esc(T('İncelenecek veritabanı bulunamadı.', 'No database is available to inspect.'))}</p>`;
    const options = (lab.inventory || []).filter(item => item.kind === 'database');
    return `<div class="dmLabInspector">
      <div class="dmLabTools">
        <label class="dmLabField"><span>${esc(T('Kaynak', 'Source'))}</span><select data-lab-source>${options.map(item => `<option value="${esc(item.id)}"${item.id === inspector.sourceId ? ' selected' : ''}>${esc(item.name)}</option>`).join('')}</select></label>
        <label class="dmLabField dmLabTrace"><span>${esc(T('Bir siparişi/kaydı izle', 'Trace one order/record'))}</span><input data-lab-trace type="text" autocomplete="off" placeholder="450123"></label>
        <button type="button" class="navActionBtn" data-lab-run-inspector ${labBusy ? 'disabled' : ''}>${esc(labBusy === 'inspect' ? T('Sınanıyor…', 'Testing…') : T('Canlı bağlantıyı sına', 'Test live connection'))}</button>
      </div>
      <div class="dmLabPipeline">${(inspector.pipeline || []).map((item, index) => `<div class="dmLabStage dmLabStage--${esc(item.status)}">
        <span class="dmLabStageNo">${index + 1}</span><strong>${esc(item.label)}</strong>
        <span>${item.count == null ? '' : Number(item.count).toLocaleString(en() ? 'en-US' : 'tr-TR')}</span>
        <small>${esc(item.note)}</small>
      </div>`).join('')}</div>
      <div class="dmLabMetrics">
        <span><strong>${Number(inspector.metrics && inspector.metrics.rawRows || 0).toLocaleString(en() ? 'en-US' : 'tr-TR')}</strong>${esc(T('Ham satır', 'Raw rows'))}</span>
        <span><strong>${Number(inspector.metrics && inspector.metrics.duplicateRows || 0).toLocaleString(en() ? 'en-US' : 'tr-TR')}</strong>${esc(T('Yinelenen', 'Duplicates'))}</span>
        <span><strong>${Number(inspector.metrics && inspector.metrics.missingOrderKeys || 0).toLocaleString(en() ? 'en-US' : 'tr-TR')}</strong>${esc(T('Sipariş anahtarı eksik', 'Missing order key'))}</span>
        <span><strong>${Number(inspector.metrics && inspector.metrics.rowLoss || 0).toLocaleString(en() ? 'en-US' : 'tr-TR')}</strong>${esc(inspector.metrics && inspector.metrics.joinInputRows != null ? T('ASAS–IAS eşleşmeyen', 'Unmatched ASAS–IAS') : T('Ölçülen satır kaybı', 'Measured row loss'))}</span>
      </div>
      ${inspector.join ? `<details class="dmLabJoin" open>
        <summary>${esc(T('ASAS–IAS eşleştirme kanıtı', 'ASAS–IAS matching evidence'))}</summary>
        <p><strong>${esc(inspector.join.ruleLabel || inspector.join.rule || '—')}</strong></p>
        <div class="dmLabJoinConditions">${(inspector.join.conditions || []).map(condition => `<span>${esc(condition.asasLabel)} = ${esc(condition.iasLabel)}</span>`).join('')}</div>
        ${(inspector.join.samples || []).length ? `<ul>${inspector.join.samples.map(sample => `<li><strong>${esc(sample.anchor)}</strong>: ${esc((sample.mismatch || []).join(', ') || T('eşleşmedi', 'not matched'))}</li>`).join('')}</ul>` : `<p>${esc(T('Örnek ayrışma yok.', 'No mismatch sample.'))}</p>`}
      </details>` : ''}
      ${inspector.trace && inspector.trace.value ? `<div class="dmLabTraceResult"><strong>${esc(inspector.trace.value)}</strong>${Object.entries(inspector.trace.stages || {}).map(([name, value]) => `<span>${esc(name)}: ${Number(value.matches) || 0}</span>`).join('')}</div>` : ''}
    </div>`;
  }

  function labAutomation() {
    const recipes = lab && lab.automations || [];
    if (!recipes.length) return `<p class="dmLabEmpty">${esc(T('Browser otomasyonu tanımlı değil.', 'No browser automation is configured.'))}</p>`;
    const recipe = recipes.find(item => item.id === selectedAutomationId) || recipes[0];
    return `<div class="dmLabAutomation">
      <div class="dmLabTools">
        <label class="dmLabField"><span>${esc(T('Otomasyon', 'Automation'))}</span><select data-lab-recipe>${recipes.map(item => `<option value="${esc(item.id)}"${item.id === recipe.id ? ' selected' : ''}>${esc(item.name)}</option>`).join('')}</select></label>
        <span class="dmLabSafety">${esc(T('Yalnız dry run — son işlem çalıştırılmaz.', 'Dry run only — the final action is never executed.'))}</span>
        <button type="button" class="navActionBtn" data-lab-dry-run="${esc(recipe.id)}" ${labBusy ? 'disabled' : ''}>${esc(labBusy === 'automation' ? T('Çalışıyor…', 'Running…') : T('Dry run çalıştır', 'Run dry run'))}</button>
      </div>
      <ol class="dmLabStepList">${(recipe.steps || []).map(step => `<li><span>${step.index}</span><strong>${esc(step.action || step.description)}</strong><small>${esc(step.description || step.target || '')}</small></li>`).join('')}</ol>
      ${automationPreview ? `<pre class="dmLabPreview">${esc(JSON.stringify(automationPreview, null, 2))}</pre>` : ''}
    </div>`;
  }

  function labPanel() {
    if (!lab) return `<div class="dmNotice">${esc(T('Entegrasyon tanısı yüklenemedi; bağlantı yönetimi kullanılmaya devam edebilir.', 'Integration diagnostics could not load; connection management remains available.'))}</div>`;
    const environment = lab.environment || {};
    const body = labTab === 'inspector' ? labInspector() : labTab === 'automation' ? labAutomation() : labInventory();
    return `<div class="dmLabPanel">
      <div class="dmLabOverview">
        <span class="dmLabEnvironment ${environment.mode === 'CORPORATE_LIVE' ? 'isLive' : 'isLocal'}">${esc(environment.mode === 'CORPORATE_LIVE' ? T('Kurumsal canlı', 'Corporate live') : T('Yerel simülasyon', 'Local simulation'))}</span>
        ${environment.validationRequired ? `<span class="dmLabValidation">${esc(T('Kurumsal doğrulama gerekli', 'Corporate validation required'))}</span>` : ''}
        <span>${Number(lab.summary && lab.summary.integrationCount || 0)} ${esc(T('entegrasyon', 'integrations'))}</span>
        <span>${Number(lab.summary && lab.summary.attentionCount || 0)} ${esc(T('dikkat isteyen', 'need attention'))}</span>
        <span class="dmSummarySpacer"></span>
        ${model.canManage ? `<button type="button" class="tbtn" data-lab-ai-export="json">${esc(T('AI tanısını JSON indir', 'Download AI diagnostic JSON'))}</button>
        <button type="button" class="tbtn" data-lab-ai-export="text">${esc(T('AI tanısını metin indir', 'Download AI diagnostic text'))}</button>` : ''}
      </div>
      ${labTabs()}
      <div id="dmLabPanel" class="dmLabBody" role="tabpanel" aria-labelledby="dmLabTab-${labTab}" tabindex="0">${body}</div>
      ${labMessage ? `<p class="dmfMessage ${/başarısız|failed|error/i.test(labMessage) ? 'is-bad' : 'is-info'}">${esc(labMessage)}</p>` : ''}
    </div>`;
  }

  /* Bağlantı düzenleyicisi (§7 — eski ekrandan taşınan yetenek).

     Ad, sunucu, model ve "yenilemede kullan" anahtarı. Eskiden bu tıklama
     1.619 satırlık eski modalı açıyordu; artık kaynağın kendi ayrıntısında,
     satır içinde düzenlenir. */
  async function testDatabaseSource(sourceId) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source || !isCustomDatabase(source) || !model.canManage) return;
    try {
      const response = await fetch(`/api/database-sources/${encodeURIComponent(sourceId)}/test`, { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Database bağlantısı başarısız.', 'Database connection failed.'));
      if (typeof showToast === 'function') {
        const ms = Number(payload.probe && payload.probe.elapsedMs) || 0;
        showToast(T(`Database bağlantısı başarılı${ms ? ` · ${ms} ms` : ''}.`, `Database connection successful${ms ? ` · ${ms} ms` : ''}.`));
      }
    } catch (error) {
      if (typeof showToast === 'function') showToast(String(error && error.message || error));
    }
  }

  function openConnectionEditor(sourceId) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source || !model.canManage) return;

    expandedSourceId = sourceId;
    render();
    const slot = root.querySelector(`[data-connection-slot="${CSS.escape(sourceId)}"]`);
    if (!slot) return;
    window.BLDataConnection?.open?.(slot, {
      sourceId: source.id,
      name: source.name,
      server: source.connection.server,
      catalog: source.connection.catalog,
      enabled: source.enabled !== false,
      revision: source.revision,
      moduleLabels: (model.modules || [])
        .filter(module => module.feeds.some(feed => feed.sourceId === source.id))
        .map(module => module.label),
      onSaved: async warnings => {
        /* Uyarılar YUTULMAZ: "sunucu değişti, eşlemeyi gözden geçirin" ya da
           "bu türde zaten aktif bir kaynak var" kaydın en önemli sonucudur. */
        if (warnings && warnings.length && typeof showToast === 'function') showToast(warnings.join(' '));
        await load();
      },
    });
  }

  /* Sorgu modu düzenleyicisi (§7 — eski ekrandan taşınan yetenek).
     Kaydettikten sonra ekran tazelenir ve sunucunun uyarıları gösterilir:
     "artık filtre yerine bu metin geçerli" bilgisi kaydın en önemli sonucudur
     ve yutulursa kullanıcı filtresini değiştirip hiçbir şeyin değişmediğini
     görür — eski ekranın tam olarak ürettiği şaşkınlık. */
  function openQueryEditor(sourceId) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source || !model.canManage) return;
    if (!(source.capabilities || []).includes('manual-query')) return;

    expandedSourceId = sourceId;
    render();
    const slot = root.querySelector(`[data-query-slot="${CSS.escape(sourceId)}"]`);
    if (!slot) return;
    window.BLDataQueryEditor?.open?.(slot, {
      sourceId: source.id,
      sourceName: source.name,
      server: source.connection.server,
      catalog: source.connection.catalog,
      engine: source.engine,
      revision: source.revision,
      mode: source.queryMode,
      query: source.query || '',
      moduleLabels: (model.modules || [])
        .filter(module => module.feeds.some(feed => feed.sourceId === source.id))
        .map(module => module.label),
      onSaved: async warnings => {
        if (warnings && warnings.length && typeof showToast === 'function') showToast(warnings.join(' '));
        await load();
      },
    });
  }

  /* VERİ EŞLEŞTİRME KURALLARI (§7 — v7.81 ASAS↔IAS satırının genellemesi).

     Kaynak kartının İÇİNDE değil, şeridin ALTINDA durur: bu kural tek bir
     kaynağın özelliği değil, kaynaklar ARASINDAKİ ilişkidir. Bir kartın
     altına koymak "o kaynağın ayarı" izlenimi verir ve kullanıcı diğer
     tarafı değiştirmek istediğinde yanlış kartta arar.

     GÖRÜNÜRLÜK KOŞULU KAYNAK ADIYLA YAZILMAZ. Satır, AYNI MODÜLÜ birden
     fazla kaynak beslediğinde görünür — eşleştirme sorusu tam olarak o zaman
     doğar. Eskiden koşul "asas-orders VE ias-warehouse bağlı mı" diye
     yazılıydı; üçüncü bir veritabanı bu satırı görünmez bırakırdı. */
  function matchRuleRow() {
    if (matchRuleOpen) return '';
    const shared = (model.modules || []).some(module => {
      const ids = new Set((module.feeds || []).map(feed => feed.sourceId).filter(Boolean));
      return ids.size >= 2;
    });
    if (!shared) return '';
    return `<div class="dmDetailRow dmMatchRow">
      <span class="dmLabel">${esc(T('Veri eşleştirme', 'Data matching'))}</span>
      <span class="dmValue">
        ${esc(T('Aynı modülü besleyen kaynakların satırlarını hangi alanların bağladığını belirler.',
          'Decides which fields link the rows of sources that feed the same module.'))}
        <button type="button" class="dmInlineLink" data-open-matchrule>${esc(T('kuralları aç', 'open rules'))}</button>
      </span>
    </div>`;
  }

  function openMatchRule() {
    matchRuleOpen = true;
    render();
    const slot = root.querySelector('[data-matchrule-slot]');
    if (!slot) { matchRuleOpen = false; return; }
    void window.BLDataMatchRule?.open?.(slot, {
      canManage: model.canManage,
      onClosed: () => { matchRuleOpen = false; render(); },
    });
  }

  function merchCalendarPanel() {
    const summary = merchCalendar && merchCalendar.summary;
    const configured = Boolean(merchCalendar && merchCalendar.configured && summary);
    const range = configured && summary.minDate && summary.maxDate ? `${summary.minDate} → ${summary.maxDate}` : '—';
    const years = configured && Array.isArray(summary.years) ? summary.years : [];
    const yearText = years.length
      ? years.map(item => `${item.year}: ${item.weeks} ${T('hafta','weeks')}`).join(' · ')
      : '';
    const warnings = configured && Array.isArray(summary.warnings) ? summary.warnings.length : 0;
    return `<div class="dmMerchPanel">
      <div class="dmPanelHead dmMerchHead">
        <div>
          <div class="dmPanelTitle">Merch Calendar</div>
          <div class="dmMerchIntro">${esc(T(
            'LCW iş haftası, iş ayı ve ay haftası için tek kaynak. Backlog, Koleksiyon ve bağlı analizler bu takvimi kullanır.',
            'Single source for LCW business week, business month and month-week. Backlog, Collection and linked analyses use this calendar.'
          ))}</div>
        </div>
        <span class="dmMerchState${configured ? ' isReady' : ''}">${esc(configured ? T('Aktif','Active') : T('Yüklenmedi','Not uploaded'))}</span>
      </div>
      <div class="dmMerchBody">
        <div class="dmMerchFacts">
          <div><span class="dmLabel">${esc(T('Kaynak dosya','Source file'))}</span><strong>${esc(configured ? summary.sourceName : '—')}</strong></div>
          <div><span class="dmLabel">${esc(T('Kapsam','Coverage'))}</span><strong>${esc(range)}</strong></div>
          <div><span class="dmLabel">${esc(T('LCW hafta kaydı','LCW week records'))}</span><strong>${configured ? Number(summary.weekCount || 0) : '—'}</strong></div>
          <div><span class="dmLabel">LCW / GLB</span><strong>${esc(T('Tarih seçicilerinde birlikte gösterilir','Shown together in date pickers'))}</strong></div>
        </div>
        ${yearText ? `<div class="dmMerchYears">${esc(yearText)}</div>` : ''}
        ${warnings ? `<div class="dmNotice dmNotice--warn">${esc(T(
          `${warnings} takvim boşluğu algılandı; kapsam dışındaki tarihler için LCW dönemi üretilmez.`,
          `${warnings} calendar gaps detected; no LCW period is generated for dates outside coverage.`
        ))}</div>` : ''}
        <div class="dmMerchRules">
          <span>${esc(T('LCW haftaları dosyadan okunur; Buyer Log kendi LCW haftasını tahmin etmez.','LCW weeks are read from the file; Buyer Log does not guess LCW weeks.'))}</span>
          <span>${esc(T('LCW hafta numaraları dosyadaki tanıma göre 1–53 olabilir.','LCW week numbers may be 1–53 according to the uploaded calendar.'))}</span>
        </div>
        ${merchMessage ? `<div class="dmMerchMessage">${esc(merchMessage)}</div>` : ''}
        <div class="dmMerchActions">
          ${model.canManage ? `<label class="tbtn dmMerchUpload${merchBusy ? ' isBusy' : ''}">
            <input type="file" data-merch-file accept=".xls,.xlsx,.html,.htm" ${merchBusy ? 'disabled' : ''}>
            ${esc(merchBusy ? T('İşleniyor…','Processing…') : (configured ? T('Takvimi Değiştir','Replace Calendar') : T('Merch Calendar Yükle','Upload Merch Calendar')))}
          </label>
          ${configured ? `<button type="button" class="tbtn danger" data-merch-delete ${merchBusy ? 'disabled' : ''}>${esc(T('Takvimi Kaldır','Remove Calendar'))}</button>` : ''}` : `<span class="dmReadOnly">${esc(T('Takvimi değiştirmek için Veri Yönetimi yetkisi gerekir.','Data Management permission is required to change the calendar.'))}</span>`}
        </div>
      </div>
    </div>`;
  }

  function readFileBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(reader.error || new Error(T('Dosya okunamadı.','Could not read the file.')));
      reader.onload = () => {
        const raw = String(reader.result || '');
        resolve(raw.includes(',') ? raw.slice(raw.indexOf(',') + 1) : raw);
      };
      reader.readAsDataURL(file);
    });
  }

  async function uploadMerchCalendar(file) {
    if (!file || merchBusy) return;
    merchBusy = true;
    merchMessage = '';
    render();
    try {
      if (Number(file.size || 0) > 12 * 1024 * 1024) throw new Error(T('Merch Calendar dosyası 12 MB sınırını aşıyor.','The Merch Calendar file exceeds the 12 MB limit.'));
      const contentBase64 = await readFileBase64(file);
      const response = await fetch('/api/merch-calendar', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body:JSON.stringify({ name:file.name, contentBase64,expectedFingerprint:merchCalendar?.fingerprint }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Merch Calendar yüklenemedi.','Could not upload Merch Calendar.'));
      merchCalendar = payload;
      window.BLMerchCalendarRuntime?.apply?.(payload);
      merchMessage = T('Merch Calendar doğrulandı ve Buyer Log tarih motoruna uygulandı.','Merch Calendar was validated and applied to the Buyer Log date engine.');
      if (typeof showToast === 'function') showToast(merchMessage);
    } catch (error) {
      merchMessage = String(error && error.message || error);
      if (typeof showToast === 'function') showToast(merchMessage);
    } finally {
      merchBusy = false;
      render();
    }
  }

  async function deleteMerchCalendar() {
    if (merchBusy) return;
    const ok = typeof confirm !== 'function' || confirm(T(
      'Merch Calendar kaldırılsın mı? LCW hafta/ay kırılımları takvim yeniden yüklenene kadar kullanılamaz.',
      'Remove Merch Calendar? LCW week/month breakdowns will be unavailable until a calendar is uploaded again.'
    ));
    if (!ok) return;
    merchBusy = true;
    merchMessage = '';
    render();
    try {
      const response = await fetch('/api/merch-calendar', { method:'DELETE',headers:merchCalendar?.fingerprint?{'If-Match':merchCalendar.fingerprint}:{} });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Merch Calendar kaldırılamadı.','Could not remove Merch Calendar.'));
      merchCalendar = payload;
      window.BLMerchCalendarRuntime?.apply?.(payload);
      merchMessage = T('Merch Calendar kaldırıldı.','Merch Calendar removed.');
      if (typeof showToast === 'function') showToast(merchMessage);
    } catch (error) {
      merchMessage = String(error && error.message || error);
      if (typeof showToast === 'function') showToast(merchMessage);
    } finally {
      merchBusy = false;
      render();
    }
  }

  function render() {
    if (!root) return;

    if (loading && !model) {
      root.innerHTML = `<div class="empty">${esc(T('Veri Yönetimi yükleniyor…', 'Loading Data Management…'))}</div>`;
      return;
    }
    if (loadError) {
      root.innerHTML = `<div class="dmError">
        <p>${esc(loadError)}</p>
        <button type="button" class="tbtn" data-retry>${esc(T('Yeniden dene', 'Retry'))}</button>
      </div>`;
      return;
    }
    if (!model) return;

    const summary = model.summary;
    const unsupported = model.support && model.support.supported === false;

    root.innerHTML = `
      <div class="dmPanel dmConnections" data-dm-panel="connections">
        <div class="dmPanelHead">
          <span class="dmPanelTitle">${esc(T('Bağlantı ve yapılandırma', 'Connections and configuration'))}</span>
        </div>
        <div class="dmConnectionBody">
      <div class="dmHead">
        <div>
          <h2 class="dmTitle">${esc(T('Kurumsal Entegrasyon Laboratuvarı', 'Corporate Integration Lab'))}</h2>
          <p class="dmSub">${esc(T('Tüm entegrasyonları tek platformda, gerçek kanıtlarla tanıla ve yönet.', 'Diagnose and manage every integration on one platform with real evidence.'))}</p>
        </div>
        <div class="dmHeadActions">
          <button type="button" class="tbtn" data-reload><svg class="ic"><use href="#i-refresh"/></svg>${esc(T('Tazele', 'Reload'))}</button>
          ${model.canManage ? `<button type="button" class="navActionBtn" data-add-source>+ ${esc(T('Database Ekle', 'Add Database'))}</button>` : ''}
        </div>
      </div>
      <div class="dmWizardSlot" data-wizard-slot></div>

      ${labPanel()}

      ${unsupported ? `<div class="dmNotice">${esc(T('Veri modeli sorguları yalnız Windows üzerinde çalışır; bu makinede bağlantı sınanamaz.', 'Data-model queries run on Windows only; connections cannot be tested on this machine.'))}</div>` : ''}
      ${(model.warnings || []).map(text => `<div class="dmNotice dmNotice--warn">${esc(text)}</div>`).join('')}

      <div class="dmSources">${model.sources.map(sourceCard).join('')}</div>
      ${expandedSourceId && model.sources.some(source => source.id === expandedSourceId)
        ? sourceDetail(model.sources.find(source => source.id === expandedSourceId)) : ''}

      ${matchRuleRow()}
      <div class="dmMatchSlot" data-matchrule-slot></div>
        </div>
      </div>

      ${sourceModePanel()}

      ${horizonPanel()}

      ${toolsPanel()}

      <div class="dmSummary">
        <span><strong>${summary.sourceCount}</strong> ${esc(T('kaynak', 'sources'))}</span>
        <span><strong>${summary.fedModuleCount}/${summary.totalFedModules}</strong> ${esc(T('beslenen modül', 'modules fed'))}</span>
        ${summary.problemCount ? `<span class="isWarn"><strong>${summary.problemCount}</strong> ${esc(T('sorunlu kaynak', 'sources need attention'))}</span>` : ''}
        <span class="dmSummarySpacer"></span>
        <span>${esc(T('Son yenileme', 'Last refresh'))}: <strong>${esc(shortTime(summary.lastRefreshAt))}</strong></span>
      </div>

      ${model.canManage ? '' : `<p class="dmReadOnly">${esc(T('Bu ekranı görüntüleyebilirsiniz; yapılandırmayı değiştirmek için Kaynak Veri yönetim yetkisi gerekir.', 'You can view this screen; changing the configuration requires Source Data management permission.'))}</p>`}
    `;

    /* DOM baştan kuruldu: kaynak modu ve otomatik yenileme durumunu yeniden
       uygula. Bu çağrı olmadan düğmeler doğru yerde ama HEPSİ pasif görünürdü —
       kullanıcı hangi modun seçili olduğunu göremezdi. */
    void feature('fx').then(()=>window.BLFX.load(true)).then(()=>window.BLFX.renderFolderSync(root.querySelector('[data-fx-folder-sync]'))).catch(()=>{});
    // Açık Horizon çekmecesinin sekme/kaynak başlığı yeni modelle güncellenir (içerik korunur).
    if (horizonDrawer) renderDrawerHead();
    decorateCollapsiblePanels();
    syncSourceModes();
  }

  /* Paneller başlıktan açılıp kapanır; seçim bu tarayıcıda kullanıcı başına
     hatırlanır. İçerik DOM'da kalır, yalnız gizlenir: durum ve olaylar bozulmaz. */
  // Yeni bölüm düzeni ilk kullanımda kapalıdır; eski açık tercihler taşınmaz.
  const COLLAPSED_PANELS_KEY = 'bl.dataManagement.collapsedPanels.v2';
  const DEFAULT_COLLAPSED_PANELS = ['connections', 'modes', 'refresh', 'tools'];
  let collapsedPanels = null;
  function readCollapsedPanels() {
    if (collapsedPanels) return new Set(collapsedPanels);
    try {
      const store = window.BLStorage || window.localStorage;
      const value = JSON.parse(store.getItem(COLLAPSED_PANELS_KEY) || 'null');
      collapsedPanels = new Set(Array.isArray(value) ? value.filter(key => DEFAULT_COLLAPSED_PANELS.includes(key)) : DEFAULT_COLLAPSED_PANELS);
    } catch (_) { collapsedPanels = new Set(DEFAULT_COLLAPSED_PANELS); }
    return new Set(collapsedPanels);
  }
  function writeCollapsedPanels(keys) {
    // Depolama kapalı olsa da oturum içindeki açma/kapatma çalışır.
    collapsedPanels = new Set(keys);
    try { (window.BLStorage || window.localStorage).setItem(COLLAPSED_PANELS_KEY, JSON.stringify([...keys])); } catch (_) {}
  }
  function expandPanel(key) {
    const collapsed = readCollapsedPanels();
    if (!collapsed.delete(key)) return;
    writeCollapsedPanels(collapsed);
    decorateCollapsiblePanels(key);
  }
  function decorateCollapsiblePanels(animateKey) {
    const collapsed = readCollapsedPanels();
    root.querySelectorAll('.dmPanel[data-dm-panel]').forEach(panel => {
      const head = panel.querySelector(':scope > .dmPanelHead');
      if (!head) return;
      let body = panel.querySelector(':scope > .dmPanelBody');
      if (!body) {
        body = document.createElement('div');
        body.className = 'dmPanelBody';
        Array.from(panel.children).filter(child => child !== head).forEach(child => body.appendChild(child));
        panel.appendChild(body);
      }
      const key = panel.dataset.dmPanel;
      const isCollapsed = collapsed.has(key);
      panel.classList.toggle('isCollapsed', isCollapsed);
      let toggle = head.querySelector(':scope > [data-dm-panel-toggle]');
      if (!toggle) {
        toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'dmPanelToggle';
        toggle.dataset.dmPanelToggle = key;
        toggle.innerHTML = '<svg class="ic" aria-hidden="true"><use href="#i-chevron-down"/></svg>';
        head.insertBefore(toggle, head.firstChild);
      }
      const label = isCollapsed ? T('Bölümü aç', 'Expand section') : T('Bölümü daralt', 'Collapse section');
      toggle.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
      toggle.setAttribute('aria-label', label);
      toggle.title = label;
      body.id = 'dm-panel-body-' + key;
      toggle.setAttribute('aria-controls', body.id);
      if (window.BLMotionPlus?.disclosure) window.BLMotionPlus.disclosure(body, !isCollapsed, { trigger: toggle, initial: key !== animateKey });
      else body.hidden = isCollapsed;
    });
  }
  function togglePanel(key) {
    const collapsed = readCollapsedPanels();
    if (collapsed.has(key)) collapsed.delete(key); else collapsed.add(key);
    writeCollapsedPanels(collapsed);
    decorateCollapsiblePanels(key);
  }

  /* ---------------------------------------------------------------- */

  /* Bağlantıyı aç/kapat. İyimser güncelleme YOK: sunucu kilitli bir hedefi
     reddedebilir ve ekranın bir an için yalan söylemesi, geri sıçrayan bir
     anahtardan farksız olurdu. İstek biter, sonra tazelenir. */
  async function toggleBinding(sourceId, moduleId, enabled) {
    const cell = `${sourceId}:${moduleId}`;
    if (busyCell) return;
    busyCell = cell;
    writeError = '';
    render();
    try {
      /* Eşzamanlılık kontrolü KAYNAK BAŞINADIR: bütün deponun revizyonu değil,
         yalnız dokunduğumuz kaynağın yapılandırma parmak izi gönderilir. Aksi
         hâlde başka bir kaynağı düzenleyen ikinci bir yönetici bizi engellerdi. */
      const source = (model.sources || []).find(entry => entry.id === sourceId);
      const response = await fetch('/api/data-management/binding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceId, moduleId, enabled,
          expectedSourceRevision: source ? source.revision : '',
        }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) {
        throw new Error(payload.error || T('Modül bağlantısı güncellenemedi.', 'Could not update the module connection.'));
      }
    } catch (error) {
      writeError = String(error && error.message || error);
    } finally {
      busyCell = '';
      await load();
      if (writeError && typeof showToast === 'function') showToast(writeError);
    }
  }

  /* Bağlı gruba ekle / gruptan ayır. toggleBinding ile aynı sözleşme: iyimser
     güncelleme yok, kaynak başına sürüm gönderilir, bitince tazelenir. */
  async function runLabInspector(sourceId, traceValue = '') {
    if (!sourceId || labBusy) return;
    labBusy = 'inspect';
    labMessage = '';
    render();
    try {
      const response = await fetch('/api/data-management/integration-lab/inspect', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceId, traceValue, liveProbe: true, language: en() ? 'en' : 'tr' }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Tanı tamamlanamadı.', 'Diagnostic could not complete.'));
      selectedLabSourceId = sourceId;
      lab.environment = payload.environment || lab.environment;
      lab.inspectors = (lab.inspectors || []).filter(item => item.sourceId !== sourceId).concat(payload.inspector);
      lab.selectedInspector = payload.inspector;
      labMessage = payload.probe && payload.probe.ok
        ? T('Canlı bağlantı doğrulandı.', 'Live connection verified.')
        : T(`Canlı bağlantı doğrulanamadı: ${payload.probe && payload.probe.error || 'bilinmeyen hata'}`, `Live connection could not be verified: ${payload.probe && payload.probe.error || 'unknown error'}`);
    } catch (error) {
      labMessage = String(error && error.message || error);
    } finally {
      labBusy = '';
      render();
    }
  }

  async function runAutomationDryRun(recipeId) {
    if (!recipeId || labBusy) return;
    labBusy = 'automation';
    labMessage = '';
    automationPreview = null;
    render();
    try {
      // Corporate Integration Lab deliberately calls PREVIEW only. The /run
      // endpoint is not reachable from this screen.
      const response = await fetch(`/api/automations/recipes/${encodeURIComponent(recipeId)}/preview`, { method: 'POST' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Dry run tamamlanamadı.', 'Dry run could not complete.'));
      automationPreview = payload.preview || {};
      labMessage = T('Dry run tamamlandı; son işlem uygulanmadı.', 'Dry run completed; no final action was applied.');
    } catch (error) {
      labMessage = String(error && error.message || error);
    } finally {
      labBusy = '';
      render();
    }
  }

  async function exportAiDiagnostic(format) {
    try {
      const kind = format === 'text' ? 'text' : 'json';
      const response = await fetch(`/api/data-management/integration-lab/diagnostic?format=${kind}`, { cache: 'no-store' });
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.error || T('Tanı paketi oluşturulamadı.', 'Diagnostic package could not be created.'));
      }
      const blob = await response.blob();
      const href = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = href;
      anchor.download = `buyer-log-integration-diagnostic.${kind === 'text' ? 'txt' : 'json'}`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(href);
      labMessage = T('Gizli bilgiler maskelenmiş AI tanı paketi indirildi.', 'Redacted AI diagnostic package downloaded.');
    } catch (error) {
      labMessage = String(error && error.message || error);
    }
    render();
  }

  function onClick(event) {
    const panelToggle = event.target.closest('[data-dm-panel-toggle]');
    if (panelToggle) { togglePanel(panelToggle.dataset.dmPanelToggle); return; }

    const labTabButton = event.target.closest('[data-lab-tab]');
    if (labTabButton) { labTab = labTabButton.dataset.labTab; labMessage = ''; render(); return; }

    const inspect = event.target.closest('[data-lab-inspect]');
    if (inspect) { selectedLabSourceId = inspect.dataset.labInspect; labTab = 'inspector'; render(); return; }

    const automation = event.target.closest('[data-lab-automation]');
    if (automation) { selectedAutomationId = automation.dataset.labAutomation; labTab = 'automation'; render(); return; }

    const runInspector = event.target.closest('[data-lab-run-inspector]');
    if (runInspector) {
      const trace = root.querySelector('[data-lab-trace]');
      void runLabInspector(selectedLabSourceId, trace ? trace.value : '');
      return;
    }

    const dryRun = event.target.closest('[data-lab-dry-run]');
    if (dryRun) { void runAutomationDryRun(dryRun.dataset.labDryRun); return; }

    const diagnostic = event.target.closest('[data-lab-ai-export]');
    if (diagnostic) { void exportAiDiagnostic(diagnostic.dataset.labAiExport); return; }

    const addSource = event.target.closest('[data-add-source]');
    if (addSource) {
      const slot = root.querySelector('[data-wizard-slot]');
      if (!slot) return;
      const labels = {};
      for (const module of model.modules || []) labels[module.id] = module.label;
      void window.BLDataSourceWizard?.open?.(slot, {
        moduleLabels: labels,
        onDone: warnings => {
          if (warnings && warnings.length && typeof showToast === 'function') showToast(warnings.join(' '));
          void load();
        },
      });
      return;
    }

    if (event.target.closest('[data-dismiss-merged-note]')) { dismissMergedNote(); return; }

    const refreshBtn = event.target.closest('[data-refresh-horizon]');
    if (refreshBtn) { refreshHorizon(refreshBtn.dataset.refreshHorizon); return; }

    const toggle = event.target.closest('[data-toggle]');
    if (toggle) {
      const [sourceId, moduleId] = String(toggle.dataset.toggle).split(':');
      void toggleBinding(sourceId, moduleId, toggle.dataset.next === 'on');
      return;
    }

    const merchDelete = event.target.closest('[data-merch-delete]');
    if (merchDelete) { void deleteMerchCalendar(); return; }

    const retry = event.target.closest('[data-retry], [data-reload]');
    if (retry) { void load(); return; }

    /* Silme, kart açma/kapamadan ÖNCE yakalanır. Düğme ayrıntı panelinde
       (kartın kardeşi) duruyor, ama sıra tersine dönerse silme tıklaması
       sessizce kartı katlamaya dönüşürdü. */
    const deleteSourceBtn = event.target.closest('[data-delete-source]');
    if (deleteSourceBtn) { void deleteSource(deleteSourceBtn.dataset.deleteSource); return; }

    const card = event.target.closest('[data-source]');
    if (card) {
      expandedSourceId = expandedSourceId === card.dataset.source ? '' : card.dataset.source;
      render();
      return;
    }

    /* Düzenleme henüz bu ekranda değil. Kullanıcıyı boş bir forma değil,
       BUGÜN ÇALIŞAN editöre götürüyoruz. P3'te bu çağrılar yerel editörle
       değiştirilecek; kullanıcı akışı o güne kadar kırılmaz. */
    const dbTestBtn = event.target.closest('[data-test-database]');
    if (dbTestBtn) { void testDatabaseSource(dbTestBtn.dataset.testDatabase); return; }

    const connBtn = event.target.closest('[data-open-connection]');
    if (connBtn) { openConnectionEditor(connBtn.dataset.openConnection); return; }

    /* Kaynak modu düğmeleri. Setter'lar app-main.js'te; burada yalnız hangi
       grubun tıklandığı çözülüp o gruba ait setter çağrılıyor. */
    for (const group of SOURCE_MODES) {
      const btn = event.target.closest(`#${group.id} [${group.attr}]`);
      if (!btn) continue;
      if (!model.canManage || btn.disabled) return;
      try { void group.set(btn.getAttribute(group.attr)); }
      catch (error) { if (typeof showToast === 'function') showToast(String(error && error.message || error)); }
      return;
    }

    const toolBtn = event.target.closest('[data-tool]');
    if (toolBtn) { void runTool(toolBtn.dataset.tool); return; }

    const queryBtn = event.target.closest('[data-open-query]');
    if (queryBtn) { openQueryEditor(queryBtn.dataset.openQuery); return; }

    if (event.target.closest('[data-open-matchrule]')) { openMatchRule(); return; }

    const cpCols = event.target.closest('[data-open-cpcolumns]');
    if (cpCols) { openCpColumnsEditor(cpCols.dataset.openCpcolumns); return; }

    const mapping = event.target.closest('[data-open-mapping]');
    if (mapping) { openMappingEditor(mapping.dataset.openMapping); return; }

    const legacy = event.target.closest('[data-open-legacy]');
    if (legacy) {
      window.openDataSourceAndFilters?.({ connectionId: legacy.dataset.openLegacy });
      return;
    }
    const clearLayer = event.target.closest('[data-clear-layer]');
    if (clearLayer) {
      const [moduleId, sourceId] = String(clearLayer.dataset.clearLayer).split(':');
      void clearPersonalLayer(moduleId, sourceId);
      return;
    }
    const filter = event.target.closest('[data-open-filter]');
    if (filter) {
      const [moduleId, sourceId] = String(filter.dataset.openFilter).split(':');
      // v2026-11-04 — Düzenleyici satır içinde değil, Horizon çekmecesinde açılır.
      openHorizonDrawer(filter.dataset.horizonGroup || moduleId, moduleId, sourceId);
      return;
    }
    const horizonEdit = event.target.closest('[data-open-horizon]');
    if (horizonEdit) openHorizonDrawer(horizonEdit.dataset.openHorizon);
  }

  /* KİŞİSEL KATMANI KALDIR.

     'Kişisel' rozeti iki farklı kaydı temsil edebilir: yalnız bu modül için
     tanımlanmış bir ufuk ya da TÜM modüller için tanımlanmış kişisel
     varsayılan. İkincisi başka ekranları da değiştireceği için ayrıca sorulur;
     kullanıcı sadece bir satırı düzeltmek isterken bütün ayarını kaybetmemeli. */
  /* Kişisel Horizon kaydının TARAYICIDAKİ kopyasını da unutur.

     Sunucudaki kayıt silinir ama localStorage aynası kalırsa, açılıştaki
     birleştirme onu "sunucuda eksik" sanıp geri gönderir ve kaldırılan katman
     dirilir. Sunucu artık silmeyi zaman damgasıyla kaydettiği için bir sonraki
     açılış zaten temizlerdi; burada AYNI OTURUM için hemen temizlenir. */
  function forgetLocalHorizonMirror(moduleName) {
    try {
      const storage = window.BLStorage;
      if (!storage || typeof storage.actualKey !== 'function' || !storage.native) return;
      const module = String(moduleName || 'default').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 40) || 'default';
      storage.native.removeItem(storage.actualKey(`buyerlog.workspace.horizon.${module}.v1`));
    } catch (_) { /* depolama kapalı olabilir; sunucu kaydı zaten kesindir */ }
  }

  async function clearPersonalLayer(moduleId, sourceId) {
    const module = (model.modules || []).find(entry => entry.id === moduleId);
    const feed = module && module.feeds.find(entry => entry.sourceId === sourceId);
    if (!feed || !feed.layerRemovable) return;

    if (feed.layerKey === 'personalDefault') {
      const ok = typeof confirm === 'function' && confirm(T(
        'Bu ayar tek bir modülün değil, TÜM modüllerin kişisel varsayılanı. Kaldırılırsa hepsi ortak filtreye döner. Devam edilsin mi?',
        'This is your personal default for ALL modules, not just this one. Removing it returns them all to the shared filter. Continue?'));
      if (!ok) return;
    }

    try {
      const response = await fetch('/api/data-management/layer', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ moduleId, layerKey: feed.layerKey }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) throw new Error(payload.error || T('Kişisel katman kaldırılamadı.', 'Could not remove the personal layer.'));
      forgetLocalHorizonMirror(feed.layerKey === 'personalDefault' ? 'default' : moduleId);
      if (typeof showToast === 'function') {
        showToast(T('Kişisel ayar kaldırıldı; ortak filtre yeniden geçerli.', 'Personal setting removed; the shared filter is in effect again.'));
      }
      await load();
    } catch (error) {
      if (typeof showToast === 'function') showToast(String(error && error.message || error));
    }
  }

  /* Eşleme düzenleyicisi. Kaydetmeden sonra ekran baştan çizildiği için
     düzenleyici YENİDEN AÇILIR — aynı işlev, taze yuva ve taze veriyle.
     Şema önbellekli olduğundan bu ikinci bir sorgu üretmez. */
  function openMappingEditor(sourceId, mappingRepair = null) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source) return;
    const baseProblems = (source.mapping && source.mapping.problems) || [];
    const repair = mappingRepair
      && mappingRepair.kind === 'field-mapping'
      && String(mappingRepair.sourceId || '') === String(sourceId)
      && String(mappingRepair.header || '').trim()
      ? mappingRepair : null;
    /* Canlı DAX hatası şema değişikliğini kanıtlar. mappingHealth yalnız
       saklanmış eşlemeye baktığı için bu alan normalde "sorunsuz" görünebilir;
       onarım akışında hatalı alanı zorla listenin başına ekliyoruz. */
    const repairProblem = repair ? {
      header: String(repair.header),
      status: 'unmapped',
      required: true,
      identity: false,
      column: String(repair.column || ''),
      table: String(repair.table || ''),
      expected: Array.isArray(repair.expected) ? repair.expected : [String(repair.header)],
    } : null;
    const problems = repairProblem
      ? [repairProblem, ...baseProblems.filter(problem => String(problem && problem.header || '') !== repairProblem.header)]
      : baseProblems;
    /* Düzenleyici KAYNAĞIN KENDİ ayrıntısında açılır — ekranın tepesinde değil.
       Düzenlenen şey o kaynağa ait; uzakta bir panelde açmak, kullanıcının
       hangi kaynağı düzenlediğini takip etmesini zorlaştırırdı. */
    expandedSourceId = sourceId;
    mappingEditorSourceId = sourceId;
    render();
    const slot = root.querySelector(`[data-mapping-slot="${CSS.escape(sourceId)}"]`);
    if (!slot) { mappingEditorSourceId = ''; return; }
    void window.BLDataMappingEditor?.open?.(slot, {
      sourceId: source.id,
      sourceName: source.name,
      server: source.connection.server,
      catalog: source.connection.catalog,
      revision: source.revision,
      role: source.mappingRole || 'asas',
      mappingEntries: source.mappingEntries || {},
      problems,
      repair,
      onSaved: async (warnings, saved) => {
        await load();
        const repairedTarget = repair && saved && String(saved.header || '') === String(repair.header || '');
        if (repairedTarget) {
          mappingEditorSourceId = '';
          render();
          if (warnings && warnings.length && typeof showToast === 'function') showToast(warnings.join(' '));
          if (typeof showToast === 'function') {
            showToast(T('Eşleme kaydedildi; yenileme yeniden deneniyor.', 'Mapping saved; retrying the refresh.'));
          }
          if (typeof window.BLRetryRefreshAfterFieldMapping === 'function') {
            void window.BLRetryRefreshAfterFieldMapping(repair);
          }
          return;
        }
        openMappingEditor(sourceId, repair);
      },
      onClosed: () => { mappingEditorSourceId = ''; render(); },
    });
  }

  /* CP sütunları düzenleyicisi — eşleme düzenleyicisiyle aynı sözleşme:
     kaynağın kendi ayrıntısında açılır, kaydettikten sonra ekran tazelenip
     düzenleyici TAZE YUVAYA yeniden açılır (öksüz düğüme yazmamak için). */
  function openCpColumnsEditor(sourceId) {
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!source || !model.canManage) return;
    if (!(source.capabilities || []).includes('extra-columns')) return;

    expandedSourceId = sourceId;
    cpColumnsSourceId = sourceId;
    render();
    const slot = root.querySelector(`[data-cpcolumns-slot="${CSS.escape(sourceId)}"]`);
    if (!slot) { cpColumnsSourceId = ''; return; }
    void window.BLDataCpColumns?.open?.(slot, {
      sourceId: source.id,
      sourceName: source.name,
      server: source.connection.server,
      catalog: source.connection.catalog,
      revision: source.revision,
      columns: source.cpColumns || [],
      onSaved: async () => { await load(); openCpColumnsEditor(sourceId); },
      onClosed: () => { cpColumnsSourceId = ''; render(); },
    });
  }

  /* Filtre düzenleyici satırın ALTINDA açılır. Eskiden buradaki tıklama
     1.619 satırlık eski modalı açıyordu; artık ortak filtre bu ekranda
     düzenlenir. Kişisel Horizon hâlâ sayfa rozetinden yönetilir. */
  /* v2026-10-30 — YAN YANA ASAS ⇄ IAS. Horizon panelinden açılan ufuk hem
     ASAS'tan hem IAS'tan besleniyorsa düzenleyici iki sütunlu açılır: solda
     ASAS, sağda IAS. Hangi çipe tıklanırsa tıklansın sol taraf ASAS'tır
     (kullanıcının okuma yönü: "Asas x — x Ias"). İki kaynağın da beslediği
     ortak bir modül gerekir: kayıt iki kaynağa aynı modül üzerinden yazılır. */
  /* Eş TIKLANAN kaynağa bağlanır: birden çok ASAS ya da IAS kaynağı varsa
     tıklanan kaynak düzenlenir (ASAS ise solda, IAS ise sağda) ve yalnız
     karşı rolün kaynağı eş seçilir. Eş yoksa tek kaynakla düzenlenir. */
  function horizonPairFor(moduleId, sourceId) {
    const group = horizonGroupsOf().find(entry => entry.targets.includes(moduleId));
    if (!group) return null;
    const ordered = [moduleId, ...group.targets.filter(id => id !== moduleId)];
    for (const id of ordered) {
      const module = (model.modules || []).find(entry => entry.id === id);
      const feeds = module ? module.feeds.filter(feed => feed.enabled !== false) : [];
      const clicked = feeds.find(feed => feed.sourceId === sourceId);
      if (!clicked || !['asas', 'antrepo'].includes(clicked.sourceRole)) continue;
      const other = feeds.find(feed => feed.sourceRole === (clicked.sourceRole === 'asas' ? 'antrepo' : 'asas'));
      if (!other) return null;
      return clicked.sourceRole === 'asas'
        ? { moduleId: id, primary: clicked, pair: other }
        : { moduleId: id, primary: other, pair: clicked };
    }
    return null;
  }

  /* =================================================================
     HORIZON ÇEKMECESİ (v2026-11-04, kullanıcı kararı)

     "CP ve geri kalanların filtre horizonunu daha şık, daha pratik bir yerde
     yapmak istiyorum." Kararlar: tek yer Veri Yönetimi; CP, Diğer modüller ve
     INTAKE ayrı sekmeler; yalnız Kaydet (yenileme ayrı kalır).

     Görünüm Backlog Analiz Filtreleri çekmecesinin ortak kabuğudur
     (.blvFilterRoot/.blvFilterDrawer); ikinci bir çekmece stili üretilmez.
     İçerik ortak filtre düzenleyicisidir (BLDataFilterEditor): eşleme,
     hatırlama ve kayıt aynı yoldan geçer. Çekmece body'ye eklenir: panel
     yeniden çizildiğinde açık düzenleyici kaybolmaz. */
  let horizonDrawer = null;   // {groupId, moduleId, sourceId, opener}
  const drawerGroups = () => [...horizonGroupsOf(), { id: 'intake', targets: ['intake'] }];
  const drawerGroup = groupId => drawerGroups().find(entry => entry.id === groupId)
    || drawerGroups().find(entry => entry.targets.includes(groupId)) || null;

  function ensureHorizonDrawer() {
    let element = document.getElementById('dmHorizonDrawer');
    if (element) return element;
    element = document.createElement('div');
    element.id = 'dmHorizonDrawer';
    element.className = 'blvFilterRoot dmHorizonDrawer';
    element.dataset.uiMigrated = 'dialog';
    element.hidden = true;
    element.innerHTML = `<div class="blvFilterScrim" data-dmh-close></div>
      <aside class="blvFilterDrawer dmHorizonAside" role="dialog" aria-modal="true" aria-labelledby="dmHorizonTitle">
        <div class="blvFilterMount"><header class="blvFilterHead dmHorizonHead" data-dmh-head></header>
          <div class="dmHorizonMount" data-dmh-mount></div></div>
      </aside>`;
    document.body.appendChild(element);
    element.addEventListener('click', onDrawerClick);
    element.addEventListener('keydown', onDrawerKeydown);
    // TR/EN: açılış ekranındaki dil seçimi bu olayı yayar; uygulama içi değişim refreshLanguage'i çağırır.
    document.addEventListener('bl:language-changed', refreshLanguage);
    return element;
  }

  function renderDrawerHead() {
    const element = document.getElementById('dmHorizonDrawer');
    const group = horizonDrawer && drawerGroup(horizonDrawer.groupId);
    if (!element || !group || !model) return;
    const text = HORIZON_TEXT[group.id] || HORIZON_TEXT.linked;
    const tabs = drawerGroups().map(entry => {
      const label = textOf((HORIZON_TEXT[entry.id] || HORIZON_TEXT.linked).title);
      const active = entry.id === group.id;
      return `<button type="button" id="dmHorizonTab-${esc(entry.id)}" class="dmLabTab${active ? ' isActive' : ''}" role="tab" aria-selected="${active}"
        aria-controls="dmHorizonPanel" tabindex="${active ? '0' : '-1'}" data-dmh-tab="${esc(entry.id)}">${esc(label)}</button>`;
    }).join('');
    /* Kaynak çipleri yalnız ufkun düzenleyicide görünenden FAZLA kaynağı
       varsa çıkar (ör. ikinci bir ASAS bağlantısı); yaygın ASAS+IAS
       durumunda iki kaynak zaten yan yana düzenlenir. */
    const feeds = horizonFeeds(group);
    const paired = horizonDrawer.moduleId ? horizonPairFor(horizonDrawer.moduleId, horizonDrawer.sourceId) : null;
    const shown = new Set(paired ? [paired.primary.sourceId, paired.pair.sourceId] : [horizonDrawer.sourceId]);
    const sources = feeds.length > shown.size ? `<div class="dmViewToggle dmHorizonSources" role="group" aria-label="${esc(T('Düzenlenen kaynak', 'Edited source'))}">${feeds.map(({ moduleId, feed }) =>
      `<button type="button" class="${shown.has(feed.sourceId) ? 'is-active' : ''}" aria-pressed="${shown.has(feed.sourceId)}"
        data-dmh-source="${esc(moduleId)}:${esc(feed.sourceId)}">${esc(feed.sourceName)}</button>`).join('')}</div>` : '';
    const members = group.id === 'linked' ? group.targets.map(moduleLabel).join(' · ') : '';
    element.querySelector('[data-dmh-head]').innerHTML = `<div class="dmHorizonHeadTop">
        <div><span class="blvFilterKicker">${esc(T('VERİ KAYNAĞI HORIZON', 'DATA SOURCE HORIZON'))}</span>
          <h3 id="dmHorizonTitle">${esc(T('Horizon filtreleri', 'Horizon filters'))}</h3>
          <p>${esc(textOf(text.hint))}${members ? ` ${esc(T('Üyeler', 'Members'))}: ${esc(members)}.` : ''} ${esc(T('Kaydetmek veriyi yenilemez; yenilemeyi Horizon panelinden başlatın.', 'Saving does not refresh data; start the refresh from the Horizon panel.'))}</p></div>
        <div class="blvFilterHeadActions"><button type="button" data-dmh-close title="${esc(T('Kapat', 'Close'))}" aria-label="${esc(T('Kapat', 'Close'))}"><svg class="ic"><use href="#i-x"/></svg></button></div>
      </div>
      <div class="dmLabTabs dmHorizonTabs" data-bl-tabs="line" role="tablist" aria-label="${esc(T('Horizon seçimi', 'Horizon selection'))}">${tabs}</div>
      ${sources}`;
  }

  function openHorizonDrawer(groupId, moduleId = '', sourceId = '') {
    const group = drawerGroup(groupId);
    if (!group || !model) return;
    if (!moduleId || !sourceId) {
      const feeds = horizonFeeds(group);
      const live = feeds.filter(({ feed }) => feed.enabled !== false);
      const pick = live.find(({ feed }) => feed.sourceRole === 'asas') || live[0] || feeds[0];
      moduleId = pick ? pick.moduleId : '';
      sourceId = pick ? pick.feed.sourceId : '';
    }
    const element = ensureHorizonDrawer();
    const wasOpen = !element.hidden && Boolean(horizonDrawer);
    const opener = wasOpen ? horizonDrawer.opener : document.activeElement;
    horizonDrawer = { groupId: group.id, moduleId, sourceId, opener };
    element.hidden = false;
    if (!wasOpen) {
      window.BLMotionPlus?.play?.('overlay', element.querySelector('.dmHorizonAside'));
      requestAnimationFrame(() => element.classList.add('is-open'));
    }
    renderDrawerHead();
    const mountEl = element.querySelector('[data-dmh-mount]');
    mountEl.id = 'dmHorizonPanel';
    mountEl.setAttribute('role', 'tabpanel');
    mountEl.setAttribute('aria-labelledby', `dmHorizonTab-${group.id}`);
    if (!moduleId) {
      window.BLDataFilterEditor?.close?.({ silent: true });
      mountEl.innerHTML = `<div class="blvFilterEditorEmpty"><svg class="ic"><use href="#i-filter"/></svg>
        <b>${esc(T('Bu ufuk hiçbir kaynağa bağlı değil', 'This horizon is not connected to any source'))}</b>
        <span>${esc(T('Önce Horizon panelinden bir kaynak bağlayın.', 'Connect a source from the Horizon panel first.'))}</span></div>`;
    } else {
      openFilterEditor(moduleId, sourceId, mountEl);
    }
    if (!wasOpen) requestAnimationFrame(() => element.querySelector('[data-dmh-tab].isActive')?.focus({ preventScroll: true }));
  }

  // fromEditor: düzenleyici kendisi kapandı (iptal/kayıt); sorulacak bir şey kalmadı.
  function closeHorizonDrawer(fromEditor = false) {
    const element = document.getElementById('dmHorizonDrawer');
    if (!element || element.hidden || !horizonDrawer) return true;
    if (!fromEditor) {
      // Kayıt sürerken çekmece kapanmaz: sonuç ve eşleme hafızası yarım kalmasın.
      if (window.BLDataFilterEditor?.isBusy?.()) return false;
      if (window.BLDataFilterEditor?.isDirty?.() && !window.confirm(T('Kaydedilmemiş filtre değişiklikleri kaybolacak. Kapatılsın mı?', 'Unsaved filter changes will be lost. Close anyway?'))) return false;
      window.BLDataFilterEditor?.close?.({ silent: true });
    }
    const { opener, groupId } = horizonDrawer;
    horizonDrawer = null;
    window.BLDataPicker?.close?.();
    element.classList.remove('is-open');
    setTimeout(() => { if (!horizonDrawer) element.hidden = true; }, 180);
    // Tetikleyiciye odak dönüşü; panel yeniden çizildiyse aynı ufkun düğmesine.
    const target = opener && opener.isConnected ? opener : root && root.querySelector(`[data-open-horizon="${CSS.escape(groupId)}"]`);
    target?.focus?.({ preventScroll: true });
    return true;
  }

  function switchHorizon(groupId, moduleId = '', sourceId = '') {
    if (window.BLDataFilterEditor?.isBusy?.()) return;
    if (window.BLDataFilterEditor?.isDirty?.() && !window.confirm(T('Kaydedilmemiş filtre değişiklikleri kaybolacak. Devam edilsin mi?', 'Unsaved filter changes will be lost. Continue?'))) return;
    openHorizonDrawer(groupId, moduleId, sourceId);
  }

  function onDrawerClick(event) {
    if (event.target.closest('[data-dmh-close]')) { closeHorizonDrawer(); return; }
    const tab = event.target.closest('[data-dmh-tab]');
    if (tab) { if (!horizonDrawer || tab.dataset.dmhTab !== horizonDrawer.groupId) switchHorizon(tab.dataset.dmhTab); return; }
    const source = event.target.closest('[data-dmh-source]');
    if (source && horizonDrawer) {
      const [moduleId, sourceId] = String(source.dataset.dmhSource).split(':');
      switchHorizon(horizonDrawer.groupId, moduleId, sourceId);
    }
  }

  function onDrawerKeydown(event) {
    const element = document.getElementById('dmHorizonDrawer');
    if (!element || element.hidden) return;
    if (event.key === 'Escape') {
      // Açık seçici varsa yalnız üst katman (seçici) kapanır.
      if (document.getElementById('_dmPicker')) { window.BLDataPicker?.close?.(); return; }
      event.preventDefault();
      closeHorizonDrawer();
      return;
    }
    // Ok/Home/End sekme odağını ortak tab-system.js taşır (role="tab").
    if (event.key !== 'Tab') return;
    // Odak çekmecenin içinde kalır (DESIGN_SYSTEM: Tab/Shift+Tab sınırı).
    const focusable = [...element.querySelectorAll('.dmHorizonAside :is(button, input, select, textarea, [tabindex]):not([disabled]):not([tabindex="-1"])')]
      .filter(node => node.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }

  function openFilterEditor(moduleId, sourceId, slotOverride = null) {
    const paired = slotOverride ? horizonPairFor(moduleId, sourceId) : null;
    if (paired) { moduleId = paired.moduleId; sourceId = paired.primary.sourceId; }
    const module = (model.modules || []).find(entry => entry.id === moduleId);
    const feed = module && module.feeds.find(entry => entry.sourceId === sourceId);
    const source = (model.sources || []).find(entry => entry.id === sourceId);
    if (!module || !feed || !source) return;

    /* v7.0.183 — Horizon KULLANICI BAZLI. Düzenleyici herkese açılır:
       varsayılan kaydetme kullanıcının KENDİ filtresini yazar. Ortak
       varsayılanı (herkesi etkiler) yalnız yönetim yetkisi olan görür
       (canShare: model.canManage). */
    /* EZEN KATMAN ARTIK ÇIKMAZ DEĞİL.

       Eskiden burada "önce onu kaldırın" denip düzenleyici hiç açılmıyordu.
       Uyarı doğruydu — kişisel/ön ayar katmanı varken ortak filtreyi
       değiştirmek kullanıcının gördüğünü değiştirmez — ama kaldırılacak yer
       BAŞKA BİR EKRANDI ve kullanıcı orada bırakılıyordu. Artık düzenleyici
       açılır, hangi katmanın kazandığını söyler ve kaldırılabiliyorsa
       kaldırma düğmesini yanında taşır. */
    const layerNote = feed.layer !== 'source' ? {
      layer: feed.layer,
      label: (LAYER[feed.layer] || {})[en() ? 'en' : 'tr'] || feed.layer,
      text: feed.filterText || '',
      removable: Boolean(feed.layerRemovable),
      onClear: feed.layerRemovable ? () => clearPersonalLayer(moduleId, sourceId) : null,
    } : null;

    // v2026-11-04 — Tek düzenleme yeri Horizon çekmecesidir (openHorizonDrawer).
    const slot = slotOverride;
    if (!slot) return;

    void window.BLDataFilterEditor?.open?.(slot, {
      sourceId, sourceName: feed.sourceName, sourceRole: feed.sourceRole || '',
      /* v7.81 — ASAS→IAS eşleme teklifi. Bu modülü besleyen BAŞKA bir
         rolde, KOŞUL İÇEREN bir kaynak varsa düzenleyici "oradan eşle"
         teklifi gösterebilir. Teklif yoksa düğme de çıkmaz — boş bir
         düğme, kullanıcıya olmayan bir yetenek vaat ederdi. */
      pair: paired ? {
        sourceId: paired.pair.sourceId, sourceName: paired.pair.sourceName, sourceRole: paired.pair.sourceRole,
        revision: ((model.sources || []).find(entry => entry.id === paired.pair.sourceId) || {}).revision || '',
        definition: paired.pair.effectiveDefinition || paired.pair.definition || {},
        // IAS tarafı kişisel katmandan başlıyorsa düzenleyici bunu açıkça söyler.
        layerNote: paired.pair.layer && paired.pair.layer !== 'source' ? ((LAYER[paired.pair.layer] || {})[en() ? 'en' : 'tr'] || '') : '',
      } : null,
      mapFrom: (() => {
        // Eşleme ucu yönetim yetkisi ister; yetkisiz kullanıcıya düğme gösterilmez.
        // Yan yana kipte eşleme zaten canlıdır; ayrı "eşle" düğmesi gösterilmez.
        if (!model.canManage || paired) return null;
        const mine = feed.sourceRole || '';
        const other = module.feeds.find(entry => entry
          && entry.sourceId !== sourceId
          && entry.sourceRole && entry.sourceRole !== mine
          && entry.conditionCount > 0);
        return other && mine ? { role: other.sourceRole, sourceId: other.sourceId, name: other.sourceName, toRole: mine } : null;
      })(),
      // Horizon panelinden açılan Diğer modüller düzenleyicisi grubun adını taşır.
      moduleId, moduleLabel: slotOverride && feed.linked === true ? T('Diğer modüller', 'Other modules') : module.label,
      revision: source.revision,
      /* Ezen katman varken ekrandaki ad/tanım o katmanın; DÜZENLENEN ise ortak
         katmandır. Bu yüzden düzenleyiciye ortak olanın adı ve tanımı verilir —
         yoksa kullanıcı kişisel ufkunu ortak filtrenin üstüne yazardı. */
      filterName: layerNote ? (feed.sharedFilterName || '') : feed.filterName,
      /* Düzenleyici kullanıcının GÖRDÜĞÜ (çalışan) filtreden başlar: varsayılan
         kaydetme onun kişisel filtresidir (v7.0.183). */
      definition: feed.effectiveDefinition || feed.definition || {},
      canShare: Boolean(model.canManage),
      sharedWith: (feed.sharedModuleIds || []),
      /* v2026-10-30 — İki sabit ufuk: "Diğer modüller"in bir üyesi ayrı
         filtreye ayrılamaz (sunucu da LINK_FIXED ile reddeder); düzenleyicide
         "ayır" seçeneği yoktur. */
      layerNote,
      // İptal, kayıt ya da katman kaldırma düzenleyiciyi kapatır; çekmece de onunla kapanır.
      onClosed: () => closeHorizonDrawer(true),
      labelOf: id => {
        const found = (model.modules || []).find(entry => entry.id === id);
        return found ? found.label : id;
      },
      onSaved: (warnings, result) => {
        /* Kişisel kayıttan sonra tarayıcıdaki eski kişisel ufuk aynası
           unutulur; açılıştaki birleştirme onu sunucuya geri yazmasın. */
        if (result && result.personal) (result.modules || [moduleId]).forEach(forgetLocalHorizonMirror);
        if (warnings && warnings.length && typeof showToast === 'function') showToast(warnings.join(' '));
        else if (result && result.personal && typeof showToast === 'function') {
          showToast(T('Filtreniz yalnız sizin için kaydedildi; diğer kullanıcılar etkilenmez.',
            'Your filter was saved for you only; other users are not affected.'));
        }
        void load();
      },
    });
  }

  /* ---------------------------------------------------------------- */

  /* Onay kutuları render'ı tetiklemez: her tıkta yeniden çizmek yazılmakta olan
     ad alanının imlecini kaybettiriyordu. Taslak sessizce güncellenir. */
  function onChange(event) {
    const merchFile = event.target && event.target.closest ? event.target.closest('[data-merch-file]') : null;
    if (merchFile) {
      const file = merchFile.files && merchFile.files[0];
      merchFile.value = '';
      if (file) void uploadMerchCalendar(file);
      return;
    }
    /* Otomatik yenileme. Değer ve zamanlayıcı app-main.js'te yaşıyor;
       burada yalnız seçim iletiliyor — ikinci bir zamanlayıcı yazmak iki ayrı
       yenileme turu demek olurdu (§9). */
    /* v20260930 — Kaynak değişince otomatik güncelleme kişisel tercihtir (her
       kullanıcı kendi verisini yeniler); izleyici app-main.js'te yaşar. */
    if (event.target && event.target.id === 'sourceWatchToggle') {
      if (typeof setSourceWatchEnabled !== 'function') return;
      const on = setSourceWatchEnabled(event.target.checked);
      if (typeof showToast === 'function') {
        showToast(on
          ? T('ASAS modeli güncellendiğinde ekranlar arka planda kendiliğinden yenilenecek.', 'Screens will refresh in the background when the ASAS model is updated.')
          : T('Kaynak değişince otomatik güncelleme kapatıldı.', 'Automatic update on source change turned off.'));
      }
      syncSourceModes();
      return;
    }
    if (event.target && event.target.id === 'autoRefreshSelect') {
      if (!model.canManage || typeof setAutoRefreshMinutes !== 'function') return;
      const value = setAutoRefreshMinutes(event.target.value);
      if (typeof showToast === 'function') {
        showToast(value
          ? T(`Otomatik yenileme ${value} dakikada bir olarak ayarlandı.`, `Auto refresh set to every ${value} minutes.`)
          : T('Otomatik yenileme kapatıldı.', 'Auto refresh turned off.'));
      }
      syncSourceModes();
      return;
    }
    const source = event.target.closest('[data-lab-source]');
    if (source) { selectedLabSourceId = source.value; labMessage = ''; render(); return; }
    const recipe = event.target.closest('[data-lab-recipe]');
    if (recipe) { selectedAutomationId = recipe.value; automationPreview = null; labMessage = ''; render(); return; }
  }

  function mount(host) {
    if (!host) return;
    if (root !== host) {
      root = host;
      root.addEventListener('click', onClick);
      root.addEventListener('change', onChange);
      /* Ufuk Yenile düğmeleri yenileme sürerken pasiftir; yenileme bitince
         (başka ekrandan başlatılmış olsa da) yeniden etkinleşmeli. */
      // Tam yeniden çizim yapılmaz: açık bir filtre düzenleyicisi kaybolmasın.
      window.addEventListener('bl-refresh-finished', () => {
        if (!root || window.BL_REFRESH_BUSY) return;
        root.querySelectorAll('[data-refresh-horizon]').forEach(button => {
          const group = HORIZON_TEXT[button.dataset.refreshHorizon] || HORIZON_TEXT.linked;
          button.disabled = false;
          button.title = textOf(group.refresh);
        });
      });
    }
    // Sekmeye her dönüşte tazelenir: başka bir ekrandan yapılan bir bağlantı
    // değişikliği burada bayat görünmemeli.
    void load();
  }

  /* Dış çağrıdaki modülü artık ait olduğu ufuk satırında göster. */
  function focusModule(moduleId) {
    const wanted = String(moduleId || '').trim();
    if (!wanted || !root) return;
    const apply = () => {
      if (!model) return;
      const groupId = horizonGroupsOf().find(entry => entry.targets.includes(wanted))?.id || wanted;
      const row = root.querySelector(`[data-horizon-row="${CSS.escape(groupId)}"]`);
      if (!row) return;
      const collapsed = readCollapsedPanels();
      if (collapsed.delete('refresh')) {
        writeCollapsedPanels(collapsed);
        decorateCollapsiblePanels();
      }
      row.classList.add('isFocused');
      row.scrollIntoView({ block: 'center', behavior: 'smooth' });
      window.BLMotionPlus?.play?.('card', row);
      // Vurgu kalıcı değil: satır bulunduktan sonra ekran normale döner.
      setTimeout(() => row.classList.remove('isFocused'), 2600);
    };
    // Yükleme sürüyorsa ONA katıl; ikinci bir istek başlatma.
    if (model && !loadPromise) apply();
    else void load().then(apply);
  }

  /* Bir KAYNAK kartına odaklan. "Şu bağlantıyı düzenle" / "şu kaynağın
     eşlemesini düzelt" diyen dış çağrılar buraya gelir; kullanıcı doğru kartı
     kart şeridinde aramak zorunda kalmamalı. */
  function focusSource(sourceId, options = {}) {
    const wanted = String(sourceId || '').trim();
    if (!wanted || !root) return;
    const apply = () => {
      if (!model || !model.sources.some(entry => entry.id === wanted)) return;
      expandPanel('connections');
      expandedSourceId = wanted;
      render();
      if (options.openMapping) { openMappingEditor(wanted, options.mappingRepair || null); return; }
      const card = root.querySelector(`[data-source="${CSS.escape(wanted)}"]`);
      if (card) card.scrollIntoView({ block: 'center', behavior: 'smooth' });
    };
    if (model && !loadPromise) apply();
    else void load().then(apply);
  }

  /* Dışarıdan bir aracı açar (ör. Data Temizliği hatırlatması). Araç zaten
     açıksa ikinci çağrı onu KAPATMAZ; yalnız görünür alana kaydırır. */
  function openToolById(toolId) {
    const wanted = String(toolId || '').trim();
    if (!wanted || !root) return;
    const reveal = () => root.querySelector(`[data-tool-slot="${CSS.escape(wanted)}"]`)
      ?.closest('.dmToolRow')?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    const apply = () => {
      if (!model) return;
      expandPanel('tools');
      if (openTool === wanted) { reveal(); return; }
      void runTool(wanted).then(reveal);
    };
    if (model && !loadPromise) apply();
    else void load().then(apply);
  }

  /* TR/EN: dil değişince açık Horizon çekmecesi (başlık + düzenleyici) aktif dille
     yeniden çizilir. Sayfanın tamamı yeniden kurulmaz: açık sihirbaz/eşleme durumu korunur. */
  function refreshLanguage() {
    if (!horizonDrawer) return;
    renderDrawerHead();
    window.BLDataFilterEditor?.refreshLanguage?.();
  }

  window.BLDataManagement = { mount, reload: load, focusModule, focusSource, openTool: openToolById, refreshLanguage };
})();
