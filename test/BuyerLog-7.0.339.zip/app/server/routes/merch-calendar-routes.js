'use strict';

const merchCalendarStore = require('../lib/merch-calendar-store');

module.exports = function registerMerchCalendarRoutes(app, deps) {
  deps = deps || {};
  const { express, userAccess } = deps;
  if (!app || !express || !userAccess) throw new Error('Merch Calendar route dependencies are incomplete.');
  const assertWrite=req=>{
    const current=userAccess.sessionProfile?userAccess.sessionProfile(req):userAccess.profileById?userAccess.profileById(req.currentUser.id):req.currentUser;
    if(!current||current.enabled===false||!userAccess.hasPermission(current,'manageModelConnections')||userAccess.hasArea&&!userAccess.hasArea(current,'source'))throw Object.assign(new Error('Güncel Veri Yönetimi yetkisi gerekli. / Current Data Management permission is required.'),{code:'OFFICE_TOOL_FORBIDDEN',status:403});
  };

  const read = (_req, res) => {
    try {
      res.set('Cache-Control', 'no-store').json({ ok:true, ...merchCalendarStore.publicProjection() });
    } catch (error) {
      res.status(500).json({ ok:false, error:'Merch Calendar okunamadı.', code:error.code || 'MERCH_READ_FAILED' });
    }
  };

app.get('/api/merch-calendar', read);

app.post(
    '/api/merch-calendar',
    userAccess.requireArea('source'),
    userAccess.requirePermission('manageModelConnections'),
    express.json({ limit:'18mb' }),
    async (req, res) => {
      try {
        const body = req.body || {};
        const sourceName = String(body.name || '').trim();
        const encoded = String(body.contentBase64 || '').trim();
        if (!sourceName) return res.status(400).json({ ok:false, error:'Dosya adı gerekli.', code:'MERCH_NAME_REQUIRED' });
        if (!encoded) return res.status(400).json({ ok:false, error:'Merch Calendar dosyası gerekli.', code:'MERCH_FILE_REQUIRED' });
        const ext = sourceName.toLocaleLowerCase('en').match(/\.(xlsx?|html?)$/);
        if (!ext) return res.status(400).json({ ok:false, error:'Yalnız .xls, .xlsx, .html veya .htm Merch Calendar dosyaları kabul edilir.', code:'MERCH_FILE_TYPE' });
        let buffer;
        try { buffer = Buffer.from(encoded, 'base64'); }
        catch (_) { return res.status(400).json({ ok:false, error:'Merch Calendar dosyası okunamadı.', code:'MERCH_BASE64_INVALID' }); }
        if (!buffer.length) return res.status(400).json({ ok:false, error:'Merch Calendar dosyası boş.', code:'MERCH_EMPTY' });
        assertWrite(req);
        const expectedFingerprint=body.expectedFingerprint??merchCalendarStore.fingerprint();
        const parsed=await require('../lib/parser-process-client').run('merch-calendar',{buffer,name:sourceName});
        assertWrite(req);
        const saved = merchCalendarStore.restoreSnapshotWithReceipt(parsed,{expectedFingerprint,assertAuthority:()=>assertWrite(req)}).value;
        if (typeof userAccess.appendAudit === 'function') {
          userAccess.appendAudit(req.currentUser, 'MERCH_CALENDAR_UPLOAD', sourceName, {
            yearFrom:saved.meta && saved.meta.yearFrom,
            yearTo:saved.meta && saved.meta.yearTo,
            weekCount:saved.meta && saved.meta.weekCount,
          });
        }
        return res.json({ ok:true, ...merchCalendarStore.publicProjection(saved) });
      } catch (error) {
        return res.status(Number(error.status||error.statusCode) || 400).json({
          ok:false,
          error:String(error && error.message || 'Merch Calendar yüklenemedi.'),
          code:error && error.code || 'MERCH_UPLOAD_FAILED',
          details:error && error.details || null,
        });
      }
    },
  );

app.delete(
    '/api/merch-calendar',
    userAccess.requireArea('source'),
    userAccess.requirePermission('manageModelConnections'),
    (req, res) => {
      try {
        merchCalendarStore.remove({expectedFingerprint:req.get?.('If-Match')?.replace(/^"|"$/g,''),assertAuthority:()=>assertWrite(req)});
        if (typeof userAccess.appendAudit === 'function') userAccess.appendAudit(req.currentUser, 'MERCH_CALENDAR_DELETE', 'Merch Calendar');
        return res.json({ ok:true, ...merchCalendarStore.publicProjection() });
      } catch (error) {
        return res.status(Number(error.status)||500).json({ ok:false, error:'Merch Calendar kaldırılamadı. / Merch Calendar could not be removed.', code:error.code || 'MERCH_DELETE_FAILED' });
      }
    },
  );
};
