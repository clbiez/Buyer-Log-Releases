'use strict';

/*
 * Buyer Log — MASAÜSTÜ BARINDIRICI (Electron ana süreci)
 *
 * ÖNCE:  START.cmd → node-portable → backend → localhost → harici Edge/Chrome → arayüz
 * SONRA: BuyerLog.exe → (aynı) backend → localhost → gömülü Chromium → (aynı) arayüz
 *
 * Bu dosya bir BARINDIRICIDIR. Buyer Log'un iş mantığından, veri modelinden,
 * sync semantiğinden veya arayüzünden hiçbir şey bilmez ve hiçbirini yeniden
 * uygulamaz. Yaptığı iş: yolları çözmek, veriyi taşımak, backend'i başlatıp
 * hazır olmasını beklemek, bir pencere açmak ve kapanışta arkasında süreç
 * bırakmamak.
 *
 * TASARIM KARARLARI:
 *
 * 1) BACKEND HTTP KALDI. Arayüz ile sunucu arasındaki iletişim IPC'ye
 *    çevrilmedi. ~27.500 satırlık istemci ve ~585 KB'lık sunucu aynı origin
 *    üzerinden konuşmaya devam ediyor; taşıma bir BARINDIRMA değişikliğidir,
 *    protokol değişikliği değil.
 *
 * 2) MENÜ YOK. Electron varsayılan menüsü Ctrl+Z/Ctrl+Y'yi menü hızlandırıcısı
 *    olarak yakalar ve sayfaya ulaşmadan tüketir. Collection'ın kendi
 *    geri al/yinele ve çok hücreli kopyala/yapıştır mantığı tam olarak bu
 *    tuşlara bağlı. Edge --app kipinde de menü yoktu; davranışı birebir
 *    korumanın yolu menüyü hiç kurmamak.
 *
 * 3) HARİCİ BAĞLANTILAR NORMALDE SİSTEM TARAYICISINA GİDER. PLM ve
 *    Harici kurumsal akışlar kullanıcının gerçek kurumsal profiline bağlıdır.
 *    CoreNectum PLM bunun bilinçli istisnasıdır: yalnız Bearer'ı otomatik
 *    edinmek için ayrı, sandbox'lı ve kalıcı bir Electron SSO partition'ı
 *    kullanılır. Ana Buyer Log renderer'ı bu tokenı hiçbir zaman görmez.
 *
 * 4) PENCERE, BACKEND GERÇEKTEN HAZIR OLMADAN AÇILMAZ. Aksi hâlde kullanıcı
 *    beyaz bir pencereye bakar. Başarısızlıkta beyaz pencere değil, ne
 *    yapacağını söyleyen bir hata ekranı gösterilir.
 *
 * 5) GÜVENLİ VARSAYILANLAR. nodeIntegration kapalı, contextIsolation açık,
 *    sandbox açık. Renderer'a yalnız adı sabit, sayısı sınırlı birkaç IPC
 *    kanalı açılır; keyfi çalıştırma yolu yoktur.
 */

const { app, BrowserWindow, WebContentsView, Menu, dialog, shell, ipcMain, screen, session, nativeTheme } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const { redactSecrets } = require('../shared/secret-redaction');

const { resolvePortableRoot, desktopPaths, resolveAppUrl, readJsonFile, pruneCompileCaches } = require('./portable-paths');
const { BackendProcess, probeOrigin, ensureConfig, ensureDataTree } = require('./backend');
const { runFirstRunMigration, healPortableSettings, readMigrationState } = require('./first-run-migration');
const { inspectPortOwner, closePortOwner } = require('./port-owner');
const { BuyerLogUpdater } = require('./update/updater');
const { createLauncherHost } = require('./update/launcher-host');
const { verifyPackagedCoreAsync } = require('./update/core-verify-async');
const { runInstallRepair, readRepairReport } = require('./install-repair');
// Onarım raporu için ikinci çekirdek taraması, sunucunun soğuk açılışıyla
// disk/CPU yarışına girmesin diye ilk ekran açıldıktan sonra başlar.
const INSTALL_REPAIR_INTEGRITY_DELAY_MS = 20000;
const { createOabAuthLifecycle } = require('./oab-auth-lifecycle');
const { createWorkspaceManager } = require('./workspace-manager');
const { syncShortcutIcons, ensureStableIcon, refreshShellIcons } = require('./shortcut-icon');
const { runExeIconPatch } = require('./exe-icon');

const APP_CORE_ROOT = path.resolve(__dirname, '..');
const DEFAULT_BOUNDS = { width: 1600, height: 1000 };

let paths = null;
let backend = null;
let mainWindow = null;
let workspace = null;
let errorWindow = null;
let splashWindow = null;
let logStream = null;
let quitting = false;
let startupFailure = null;
let restarting = false;
let lastStartedAt = 0;
let updater = null;
let updateStartupTimer = null;
let updateSignInTimer = null;
let updatePeriodicTimer = null;
let updateRelaunchRequested = false;
// Longer than the bounded backend stop (graceful wait + taskkill) so the tree is never orphaned.
const SHUTDOWN_DEADLINE_MS = 20000;

function activeBuyerLogWindow(contents) {
  return (workspace && contents && workspace.windowForContents(contents))
    || (workspace && workspace.focusedWindow())
    || (mainWindow && !mainWindow.isDestroyed() ? mainWindow : null);
}

function activeBuyerLogContents() {
  return (workspace && workspace.activeContents())
    || (mainWindow && !mainWindow.isDestroyed() ? mainWindow.webContents : null);
}

/* CoreNectum automatic auth — dedicated Electron corporate session.
 * No raw Bearer reaches the renderer and no user has to copy it from DevTools.
 * A random per-process bridge secret moves the captured token to the local
 * backend over loopback only. */
const CORENECTUM_AUTH_PARTITION = 'persist:buyerlog-corenectum-auth';
const CORENECTUM_HOME = 'https://corenectum.lcwaikiki.com/models-options/style-list';
const CORENECTUM_API_HOST = 'mym-api.lcwaikiki.com';
const CORENECTUM_STYLE_LIST_API = 'https://mym-api.lcwaikiki.com/lcw/live/corenectum/service/api/StyleList/GetStyleList';
const desktopBridgeSecret = crypto.randomBytes(32).toString('hex');
let coreNectumAuthWindow = null;
let coreNectumAuthInFlight = null;
/* LCW AI arka plan oturumu: CoreNectum ile aynı desen, ayrı kalıcı bölüm. */
const LCWAI_AUTH_PARTITION = 'persist:buyerlog-lcwai-auth';
const LCWAI_HOME = 'https://lcwai.lcwaikiki.com/';
const LCWAI_STORAGE_PROBE = "(() => { try { return localStorage.getItem('access_token') || ''; } catch (_) { return ''; } })()";
let lcwAiAuthWindow = null;
let lcwAiAuthInFlight = null;
let coreNectumStyleListTemplate = null;

/* OAB automatic auth — intentionally independent from CoreNectum and from the
 * user's normal Edge profile. Browser session state lives in this dedicated
 * persistent partition; raw Authorization still exists only in process/backend
 * memory and is captured only from the exact trusted PASS API host. The
 * captured Bearer is still accepted only after the loopback backend validates
 * it against the real OAB report endpoint. */
const OAB_AUTH_PARTITION = 'persist:oab';
const OAB_VIEWER_URL = 'https://pass.lcwaikiki.com/v3/report/viewer?key=OrderBudget_List_Report';
const OAB_HOME_URL = 'https://pass.lcwaikiki.com/';
const OAB_UI_HOST = 'pass.lcwaikiki.com';
const OAB_API_HOST = 'pass.prod.lcwaikiki.com';
const OAB_AUTH_CAPTURE_FILTER = { urls: [`https://${OAB_API_HOST}/pass/*`] };
const OAB_SILENT_PROBE_MS = 15000;
/* After the user closes the sign-in window, keep the (now hidden) PASS page
 * alive briefly so a login that already completed can still be picked up. */
const OAB_CLOSE_GRACE_MS = 15000;
/* The same rejected stored token is not re-validated more often than this. */
const OAB_STORED_TOKEN_RETRY_MS = 10000;
/* PASS (pass.lcwaikiki.com) keeps its OAuth access token in its own web
 * storage. This is the same reader the proven Edge/CDP path uses
 * (agent-browser-connector PASS_STORED_TOKEN_READER), plus oidc-client style
 * "oidc.user:*" entries. Detecting sign-in from storage does not depend on PASS
 * issuing a report request in the hidden window. */
const OAB_STORED_TOKENS_READER = `const readStoredOabTokens = () => {
  const extract = value => {
    let text = String(value == null ? '' : value).trim();
    if (!text) return '';
    if (text[0] === '"' || text[0] === '{') {
      try {
        const parsed = JSON.parse(text);
        text = typeof parsed === 'string' ? parsed : String(parsed && (parsed.access_token || parsed.accessToken) || '');
      } catch (_) { return ''; }
    }
    text = text.trim().replace(/^bearer\\s+/i, '');
    return text.length >= 20 && !/\\s/.test(text) ? 'Bearer ' + text : '';
  };
  const stores = [];
  try { if (typeof localStorage !== 'undefined' && localStorage) stores.push(localStorage); } catch (_) {}
  try { if (typeof sessionStorage !== 'undefined' && sessionStorage) stores.push(sessionStorage); } catch (_) {}
  const found = [];
  const add = value => { if (value && !found.includes(value)) found.push(value); };
  for (const store of stores) {
    for (const key of ['access_token', 'accessToken']) {
      try { add(extract(store.getItem(key))); } catch (_) {}
    }
  }
  for (const store of stores) {
    try {
      for (let index = 0; index < store.length; index += 1) {
        const key = String(store.key(index) || '');
        if (/^oidc\\.user:/i.test(key)) add(extract(store.getItem(key)));
      }
    } catch (_) {}
  }
  return found.slice(0, 6);
};`;
const OAB_STORAGE_PROBE = `(() => { ${OAB_STORED_TOKENS_READER} return readStoredOabTokens(); })()`;
/* PASS API calls run INSIDE the signed-in PASS page, exactly like the proven
 * Edge/CDP model (agent-browser-connector passRequestExpression): same origin,
 * Chromium network stack (corporate proxy + Windows certificate store),
 * credentials:'omit' + Authorization. Validating or fetching from the Node
 * backend instead used to reject every captured token, so a completed sign-in
 * was never accepted. */
const OAB_PASS_API_ROOT = 'https://pass.prod.lcwaikiki.com/pass/common/report/api/v2.0';
const OAB_RELAY_ENDPOINTS = new Set(['Report/GetReportData', 'Report/GetReportVariablesWithData', 'Report/GetVariableWithData']);
/* Field log (7.0.262): PASS answers Report/GetReportVariablesWithData with
 * HTTP 405 for every captured token, so that endpoint cannot prove a session.
 * Validation uses Report/GetReportData — the one call the proven Edge/CDP path
 * makes — first with empty filters (cheap; ASP.NET authorizes before model
 * validation, so 2xx/400/422 means the Bearer was accepted), then, only if the
 * server cannot answer that, with the user's selected Season/MAG/Buyer Group. */
function oabReportDataBody(selection = {}) {
  return {
    reportRef:'OrderBudget_List_Report',
    languageRef:2,
    parameters:{
      SeasonRef:selection.seasonRef || '',
      MerchSubGroupRef:selection.merchSubGroupRef || '',
      BuyerGroupRefs:selection.buyerGroupRef || '',
      CategoryGroupRefs:'',
      CategoryRef:'',
    },
  };
}
function oabSessionAccepted(result, { allowClientError = false } = {}) {
  const status = Number(result && result.status) || 0;
  if (status >= 200 && status < 300) return true;
  return allowClientError && (status === 400 || status === 422);
}
function oabSelectionFromViewerUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return {
      seasonRef:url.searchParams.get('SeasonRef') || '',
      merchSubGroupRef:url.searchParams.get('MerchSubGroupRef') || '',
      buyerGroupRef:url.searchParams.get('BuyerGroupRefs') || '',
    };
  } catch (_) { return {}; }
}
/* Speed (field report: 180 s vs 30-40 s on Edge). An empty-filter
 * GetReportData makes PASS compute the whole report, so it ran into the
 * 120 s page timeout before the real request even started. Now:
 *  - with a Season/MAG/Buyer Group selection, the validation request IS the
 *    user's report request and its rows are handed to the backend's first
 *    identical request (one PASS report call, like the Edge path);
 *  - without a selection (user-menu sign-in) the empty-filter probe is cut
 *    after a few seconds: PASS rejects a bad Bearer immediately with 401/403,
 *    so a request still running at that point was authorized. */
const OAB_PROBE_PENDING_MS = 8000;
const OAB_VALIDATED_REPORT_TTL_MS = 120000;
let oabValidatedReport = null;
function oabReportCacheKey(body) {
  const params = body && body.parameters || {};
  return [params.SeasonRef, params.MerchSubGroupRef, params.BuyerGroupRefs].map(value => String(value == null ? '' : value)).join('\u0000');
}
function takeOabValidatedReport(endpoint, body) {
  const cached = oabValidatedReport;
  if (!cached || endpoint !== 'Report/GetReportData') return null;
  if (Date.now() - cached.at > OAB_VALIDATED_REPORT_TTL_MS) { oabValidatedReport = null; return null; }
  if (cached.key !== oabReportCacheKey(body)) return null;
  oabValidatedReport = null;
  return cached.result;
}
async function validateOabSessionInPage(page, authorization, selection) {
  const hasSelection = Boolean(selection && selection.seasonRef && selection.merchSubGroupRef && selection.buyerGroupRef);
  if (hasSelection) {
    const body = oabReportDataBody(selection);
    const result = await runOabPageRequest(page, 'Report/GetReportData', body, authorization);
    if (!oabSessionAccepted(result)) return result;
    oabValidatedReport = { key:oabReportCacheKey(body), result, at:Date.now() };
    return { ok:true, status:result.status };
  }
  const probe = await runOabPageRequest(page, 'Report/GetReportData', oabReportDataBody(), authorization, { pendingAfterMs:OAB_PROBE_PENDING_MS });
  if (probe && probe.code === 'OAB_PENDING') return { ok:true, status:0, pending:true };
  return oabSessionAccepted(probe, { allowClientError:true }) ? { ok:true, status:probe.status } : probe;
}
const OAB_PAGE_REQUEST_TIMEOUT_MS = 120000;
function oabPassRequestExpression(url, body, fallbackAuthorization, options = {}) {
  const config = JSON.stringify({ url, body: body == null ? {} : body, fallback: String(fallbackAuthorization || ''), pendingAfterMs: Math.max(0, Number(options.pendingAfterMs) || 0), timeoutMs:120000 });
  return `(async () => {
    const cfg = ${config};
    ${OAB_STORED_TOKENS_READER}
    const candidates = [...readStoredOabTokens()];
    if (cfg.fallback && !candidates.includes(cfg.fallback)) candidates.push(cfg.fallback);
    if (!candidates.length) return { ok:false, status:0, code:'OAB_AUTH_REQUIRED' };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), cfg.pendingAfterMs || cfg.timeoutMs);
    const startedAt = Date.now();
    let last = null;
    try {
      for (const authorization of candidates) {
        const response = await fetch(cfg.url, {
          method:'POST', credentials:'omit', cache:'no-store', signal:controller.signal,
          redirect:'error',
          headers:{ Accept:'application/json', 'Content-Type':'application/json', Authorization:authorization },
          body:JSON.stringify(cfg.body),
        });
        const headersAt = Date.now();
        const text = await response.text();
        let json = null; try { json = text ? JSON.parse(text) : null; } catch (_) {}
        last = { ok:response.ok, status:response.status, json,
          timings:{ headersMs:headersAt-startedAt, bodyMs:Date.now()-headersAt, totalMs:Date.now()-startedAt } };
        if (response.status !== 401 && response.status !== 403) return last;
      }
      return last;
    } catch (error) {
      if (controller.signal.aborted) return { ok:false, status:0, code:cfg.pendingAfterMs ? 'OAB_PENDING' : 'OAB_TIMEOUT' };
      throw error;
    } finally {
      clearTimeout(timer);
    }
  })()`;
}
function oabWindowOnPass(win) {
  if (!win || win.isDestroyed()) return false;
  try { return new URL(win.webContents.getURL()).hostname.toLowerCase() === OAB_UI_HOST; } catch (_) { return false; }
}
async function runOabPageRequest(win, endpoint, body, fallbackAuthorization, options = {}) {
  if (!OAB_RELAY_ENDPOINTS.has(endpoint)) return { ok:false, status:0, code:'OAB_ENDPOINT_BLOCKED' };
  if (!oabWindowOnPass(win)) return { ok:false, status:0, code:'OAB_AUTH_REQUIRED' };
  let timer = null;
  const timeout = new Promise(resolve => {
    timer = setTimeout(() => resolve({ ok:false, status:0, code:'OAB_TIMEOUT' }), OAB_PAGE_REQUEST_TIMEOUT_MS);
  });
  try {
    const result = await Promise.race([
      win.webContents.executeJavaScript(oabPassRequestExpression(`${OAB_PASS_API_ROOT}/${endpoint}`, body, fallbackAuthorization, options), true),
      timeout,
    ]);
    if (result && result.timings) log('OAB PASS HTTP ' + result.status + ': headers=' + result.timings.headersMs + 'ms, body=' + result.timings.bodyMs + 'ms, total=' + result.timings.totalMs + 'ms');
    return result && typeof result === 'object' ? result : { ok:false, status:0, code:'OAB_NO_RESPONSE' };
  } catch (_) {
    return { ok:false, status:0, code:'OAB_PAGE_REQUEST_FAILED' };
  } finally {
    if (timer) clearTimeout(timer);
  }
}
/* The signed-in PASS page is kept alive, hidden, after sign-in and serves the
 * backend's OAB requests through the loopback relay below. */
let oabSessionWindow = null;
let oabSessionAuthorization = '';
let oabSessionOrphanWatch = false;
function oabSessionReady() { return oabWindowOnPass(oabSessionWindow); }
function closeOrphanOabSessionWindow() {
  setImmediate(() => {
    if (!oabSessionWindow || oabSessionWindow.isDestroyed()) return;
    const visible = BrowserWindow.getAllWindows().filter(win => win !== oabSessionWindow && !win.isDestroyed() && win.isVisible());
    // A hidden session window must never keep Buyer Log running after its last
    // visible window closed (window-all-closed would never fire).
    if (!visible.length) { try { oabSessionWindow.destroy(); } catch (_) {} }
  });
}
function adoptOabSessionWindow(win, authorization, parent) {
  const previous = oabSessionWindow;
  oabSessionWindow = win;
  oabSessionAuthorization = String(authorization || '');
  try { win.hide(); } catch (_) {}
  try { win.setParentWindow(parent && !parent.isDestroyed() ? parent : null); } catch (_) {}
  win.once('closed', () => {
    if (oabSessionWindow === win) { oabSessionWindow = null; oabSessionAuthorization = ''; }
  });
  if (!oabSessionOrphanWatch) {
    oabSessionOrphanWatch = true;
    for (const existing of BrowserWindow.getAllWindows()) existing.on('closed', closeOrphanOabSessionWindow);
    app.on('browser-window-created', (_event, created) => created.on('closed', closeOrphanOabSessionWindow));
  }
  if (previous && previous !== win && !previous.isDestroyed()) { try { previous.destroy(); } catch (_) {} }
}
function destroyOabSessionWindow() {
  const win = oabSessionWindow;
  oabValidatedReport = null;
  oabSessionWindow = null;
  oabSessionAuthorization = '';
  if (win && !win.isDestroyed()) { try { win.destroy(); } catch (_) {} }
}
/* Loopback relay: whitelisted PASS calls and the shared LCW AI session.
 * Same per-process bridge secret as the other desktop bridges;
 * only 127.0.0.1, small JSON bodies. */
let oabRelayServer = null;
let oabRelayUrl = '';
function oabRelaySecretValid(supplied) {
  const value = String(supplied || '');
  if (!value) return false;
  const a = crypto.createHash('sha256').update(value).digest();
  const b = crypto.createHash('sha256').update(desktopBridgeSecret).digest();
  return crypto.timingSafeEqual(a, b);
}
async function handleOabRelayRequest(req, res) {
  const send = (status, payload) => {
    if (res.headersSent) return;
    res.writeHead(status, { 'Content-Type':'application/json', 'Cache-Control':'no-store' });
    res.end(JSON.stringify(payload));
  };
  try {
    if (req.method !== 'POST') return send(405, { ok:false, code:'METHOD_NOT_ALLOWED' });
    if (!oabRelaySecretValid(req.headers['x-buyerlog-desktop-bridge'])) return send(403, { ok:false, code:'DESKTOP_BRIDGE_FORBIDDEN' });
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 65536) return send(413, { ok:false, code:'PAYLOAD_TOO_LARGE' });
      chunks.push(chunk);
    }
    let body = {};
    try { body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch (_) { return send(400, { ok:false, code:'INVALID_JSON' }); }
    const route = String(req.url || '').split('?')[0];
    if (route === '/lcwai/auth') {
      const result = await acquireLcwAiToken({ interactive: body && body.interactive === true, avoidFingerprint: String(body && body.avoidFingerprint || '') });
      return send(200, result && result.ok ? { ok:true } : { ok:false, code:result && result.code || 'LCWAI_AUTH_FAILED' });
    }
    if (route === '/oab/status') return send(200, { ok:true, ready:oabSessionReady() });
    if (route === '/oab/pass-request') {
      const endpoint = String(body && body.endpoint || '');
      if (!OAB_RELAY_ENDPOINTS.has(endpoint)) return send(400, { ok:false, code:'OAB_ENDPOINT_BLOCKED' });
      const requestBody = body && body.body || {};
      // The sign-in validation already fetched exactly this report: reuse it.
      const result = takeOabValidatedReport(endpoint, requestBody) || await runOabPageRequest(oabSessionWindow, endpoint, requestBody, oabSessionAuthorization);
      if (result && (result.status === 401 || result.status === 403)) log('OAB oturum sayfası isteği reddetti (HTTP ' + result.status + ').');
      return send(200, { ok:true, result });
    }
    return send(404, { ok:false, code:'NOT_FOUND' });
  } catch (_) {
    send(500, { ok:false, code:'OAB_RELAY_FAILED' });
  }
}
function startOabRelay() {
  if (oabRelayServer) return Promise.resolve(oabRelayUrl);
  return new Promise(resolve => {
    const server = http.createServer((req, res) => { void handleOabRelayRequest(req, res); });
    server.on('error', error => {
      log('OAB masaüstü köprüsü başlatılamadı: ' + String(error && error.code || 'unknown'));
      resolve('');
    });
    server.listen(0, '127.0.0.1', () => {
      oabRelayServer = server;
      oabRelayUrl = 'http://127.0.0.1:' + server.address().port;
      resolve(oabRelayUrl);
    });
  });
}
let oabAuthWindow = null;
let oabAuthInFlight = null;
let oabAuthFlowState = null;

/*
 * Tamamlanan indirmelerin token → gerçek yol eşlemesi. "Dosya hazır" bildirim
 * kartındaki Aç/Klasörde Göster aksiyonları renderer'dan HİÇBİR ZAMAN ham bir
 * yol almaz (bkz. preload.js §keyfi yol yok) — yalnız burada üretilen opak bir
 * token alır ve gerçek yolu ana süreç kendi belleğinden çözer. Sınırsız
 * büyümemesi için en eski girdi, sınır aşılınca atılır.
 */
const downloadRegistry = new Map();
const DOWNLOAD_REGISTRY_LIMIT = 50;
function registerDownload(filePath) {
  const token = crypto.randomBytes(8).toString('hex');
  downloadRegistry.set(token, { path: filePath });
  if (downloadRegistry.size > DOWNLOAD_REGISTRY_LIMIT) {
    downloadRegistry.delete(downloadRegistry.keys().next().value);
  }
  return token;
}

/* LCW AI çıktıları masaüstü kipinde doğrudan gerçek İndirilenler klasörüne
 * yazılır. Renderer yalnız dosya ADINI geri verir; ham/keyfi bir yol kabul
 * edilmez. Böylece Aç / Klasörde Göster güvenli biçimde Electron shell
 * üzerinden çalışır ve backend'in PowerShell/explorer başlatmasına bağlı kalmaz. */
function generatedDownloadPath(fileName) {
  const name = String(fileName || '').trim();
  if (!name || path.basename(name) !== name || /[\\/]/.test(name)) return '';
  try {
    const downloads = path.resolve(app.getPath('downloads'));
    const full = path.resolve(downloads, name);
    if (path.dirname(full) !== downloads || !fs.existsSync(full)) return '';
    return full;
  } catch (_) { return ''; }
}

/* ------------------------------------------------------------------ log */

function timestamp() { return new Date().toISOString(); }

function log(message) {
  const line = '[' + timestamp() + '] ' + redactSecrets(message);
  /*
   * KONSOL YOKKEN stdout'a YAZMA.
   *
   * BuyerLog.exe GUI alt sisteminde derlenmistir ve cift tiklamayla
   * acildiginda bagli bir konsolu yoktur. Boyle bir surecte
   * process.stdout.write, okuyucusu olmayan bir handle'a yazip BLOKE
   * OLABILIR. Bloke olan ana surec, calistirdigi cocugun stdout borusunu
   * bosaltmayi da birakir; boru dolunca cocuk de kilitlenir.
   *
   * Canlida ilk acilis tasimasi tam olarak boyle asildi: cocuk ~10 MB
   * kopyaladi (bir boru tamponu kadar), sonra ikisi de sonsuza kadar
   * bekledi. Ekranda pencere bile acilmadi.
   *
   * Gunluk zaten dosyaya yaziliyor; konsol yalniz gelistirme kolayligi.
   */
  if (process.stdout && process.stdout.isTTY) {
    try { process.stdout.write(line + '\r\n'); } catch (_) {}
  }
  try {
    if (!logStream && paths) {
      fs.mkdirSync(paths.logsRoot, { recursive: true });
      try {
        const stat = fs.statSync(paths.desktopLogPath);
        if (stat.size > 4 * 1024 * 1024) fs.renameSync(paths.desktopLogPath, paths.desktopLogPath + '.1');
      } catch (_) { /* ilk çalıştırmada dosya yok */ }
      logStream = fs.createWriteStream(paths.desktopLogPath, { flags: 'a' });
    }
    if (logStream) logStream.write(line + '\r\n');
  } catch (_) { /* log yazılamaması uygulamayı durdurmaz */ }
}

const readJson = readJsonFile;

function appVersion() {
  const pkg = readJson(path.join(APP_CORE_ROOT, 'package.json'), {});
  return String(pkg.version || 'bilinmiyor');
}

/* Yeni sürüm deneme (trial) açılışında launcher'a sağlık onayı verilir. İlk sekme
 * yüklendiği an yerel DB veya backend henüz hazır değilse launcher onayı reddeder;
 * tek atışlık bildirimde bu durum 60 sn sonra sessiz geri almaya dönüşüyor ve
 * kullanıcı yeni sürümün özellikleri olmadan eski sürümde kalıyordu. Onay, launcher
 * zaman aşımının içinde kalacak şekilde sınırlı sayıda yeniden denenir. */
const HEALTH_CONFIRM_RETRY_MS = 2000;
const HEALTH_CONFIRM_MAX_ATTEMPTS = 20;
let launcherHealthConfirmed = false;
function confirmLauncherHealth(attempt = 0) {
  if (launcherHealthConfirmed) return;
  if (!process.env.BUYER_LOG_UPDATE_HEALTH_TOKEN || typeof global.__buyerLogLauncherHealthReady !== 'function') return;
  let ok = false;
  try {
    ok = global.__buyerLogLauncherHealthReady({
      version: appVersion(),
      backendReady: Boolean(backend && backend.running),
      localDbPath: paths && paths.localDbPath || '',
      localDbReady: Boolean(paths && paths.localDbPath && fs.existsSync(paths.localDbPath)),
      rendererReady: true,
    }) === true;
  } catch (error) { log('Updater health ready bildirimi başarısız: ' + error.message); }
  if (ok) { launcherHealthConfirmed = true; log('Updater health onaylandı: ' + appVersion()); scheduleLauncherInfrastructureSync(); return; }
  if (attempt < HEALTH_CONFIRM_MAX_ATTEMPTS) {
    const timer = setTimeout(() => confirmLauncherHealth(attempt + 1), HEALTH_CONFIRM_RETRY_MS);
    if (timer && timer.unref) timer.unref();
    return;
  }
  log('Updater health onaylanamadı (backend/DB hazır değil): ' + appVersion());
}

/* Güncelleme altyapısı (launcher) yalnız sağlığı kanıtlanmış ve bütünlüğü
 * doğrulanmış çekirdekten, deneme (trial) bittikten sonra eşitlenir. Eski 1.0/1.1
 * kurulumlar burada bir kez stage-0 host'a geçer; sonraki açılışta yeni
 * launcher etkinleşir. Başarısızlık açılışı etkilemez, güncelleme panelinde görünür.
 *
 * Her sürüm yeni bir launcher kimliği taşıdığı için (bootstrap.json kaynak commit'i)
 * bu eşitleme güncellemeden sonraki İLK açılışta her seferinde çalışır. Ön kontrol
 * kurulum + etkin çekirdeğin tam SHA-256 taramasıdır (~165 MB × 2). Eskiden sağlık
 * onayından 5 sn sonra ana süreçte senkron yapılıyor ve tam giriş ekranı açılırken
 * pencereyi donduruyordu. Tarama artık işçi iş parçacığında yürür ve sunucunun soğuk
 * açılışıyla disk yarışına girmemek için açılış yükü bittikten sonra başlar. */
const LAUNCHER_SYNC_AFTER_HEALTH_MS = 45000;
let launcherHost = null;
let launcherSyncTimer = null;
let launcherSyncRunning = false;
function scheduleLauncherInfrastructureSync(delayMs = LAUNCHER_SYNC_AFTER_HEALTH_MS) {
  if (!launcherHost || !app.isPackaged || launcherSyncTimer || launcherSyncRunning) return;
  launcherSyncTimer = setTimeout(() => {
    launcherSyncTimer = null;
    try { if (updater && updater.state().activation) return; } catch (_) { return; }
    launcherSyncRunning = true;
    const started = Date.now();
    void launcherHost.installAsync({ sourceCore: APP_CORE_ROOT, sourceVersion: appVersion() }, { verifyCore: verifyPackagedCoreAsync })
      .then(result => {
        if (!result.changed) return;
        log('Güncelleme altyapısı hazırlandı: launcher ' + result.version + ' (sonraki açılışta etkin) · ' + (Date.now() - started) + ' ms.');
        updateStatusFor('').then(emitUpdateStatus).catch(() => {});
      })
      .catch(error => {
        log('Güncelleme altyapısı yükseltilemedi: ' + (error.code || '') + ' ' + error.message);
        updateStatusFor('').then(emitUpdateStatus).catch(() => {});
      })
      .finally(() => { launcherSyncRunning = false; });
  }, delayMs);
  if (launcherSyncTimer.unref) launcherSyncTimer.unref();
}

function updaterBaseConfig() {
  const config = paths ? readJson(paths.configPath, {}) : {};
  return config && typeof config.updates === 'object' && config.updates ? config.updates : {};
}

async function verifyUpdateModerator(userId, contents=activeBuyerLogContents()) {
  const id=String(userId||'').trim();
  if(!id||!backend||!backend.running||!backend.origin)return false;
  try{
    if(!contents||contents.isDestroyed?.()||!contents.session?.cookies)return false;
    const cookie=(await contents.session.cookies.get({url:backend.origin})).find(item=>item.name==='bl_user_session');
    if(!cookie)return false;
    const response=await fetch(backend.origin+'/api/internal/desktop/update-authority',{
      method:'POST',cache:'no-store',redirect:'error',
      headers:{'Content-Type':'application/json','X-BuyerLog-Desktop-Bridge':desktopBridgeSecret,'Cookie':'bl_user_session='+cookie.value},
      body:JSON.stringify({userId:id}),
    });
    const data=await response.json().catch(()=>({}));
    return Boolean(response.ok&&data.ok&&data.moderator);
  }catch(_){return false;}
}

async function currentRendererUserId() {
  const contents=activeBuyerLogContents();
  if(!contents||contents.isDestroyed())return '';
  try{return String(await contents.executeJavaScript("String((window.BL_USER_CONTEXT&&window.BL_USER_CONTEXT.id)||'')",true)||'').trim();}
  catch(_){return '';}
}

async function effectiveUpdateChannel(userId='') {
  if(!updater)return 'stable';
  const cfg=updater.config(updaterBaseConfig());
  if(cfg.channel!=='test')return 'stable';
  return await verifyUpdateModerator(userId)?'test':'stable';
}

function emitUpdateStatus(payload) {
  if(workspace){workspace.broadcast('buyerlog:update-status-changed',payload);return;}
  if(mainWindow&&!mainWindow.isDestroyed())try{mainWindow.webContents.send('buyerlog:update-status-changed',payload);}catch(_){}
}

function repairSummary() {
  try {
    const report = paths ? readRepairReport(paths.localDataRoot) : null;
    if (!report || report.version !== appVersion()) return null;
    const integrity = report.steps && report.steps.integrity || null;
    const state = report.steps && report.steps.updaterState || null;
    return {
      version: report.version,
      finishedAt: report.finishedAt || null,
      cacheCleared: Boolean(report.steps && report.steps.rendererCache && report.steps.rendererCache.ok),
      stateFixes: state && Array.isArray(state.actions) ? state.actions.length : 0,
      integrity: integrity ? integrity.status : 'pending',
      damagedFiles: integrity ? (integrity.missingCount || 0) + (integrity.changedCount || 0) : 0,
      restaged: Boolean(integrity && integrity.restage && integrity.restage.restaged),
    };
  } catch (_) { return null; }
}

async function updateStatusFor(userId='') {
  if(!updater)return {enabled:false,state:'IDLE',currentVersion:appVersion(),channel:'stable',moderator:false};
  const moderator=await verifyUpdateModerator(userId);
  const configured=updater.config(updaterBaseConfig());
  const channel=(configured.channel==='test'&&moderator)?'test':'stable';
  return {...updater.status(updaterBaseConfig(),channel),moderator,manualPatchSupported:typeof global.__buyerLogPrepareSignedPatch==='function',configuredChannel:configured.channel,repair:repairSummary()};
}

async function runUpdateCheck(options={}) {
  if(!updater)return {ok:false,disabled:true,reason:'updater-unavailable'};
  const userId=String(options.userId||await currentRendererUserId()||'');
  const channel=await effectiveUpdateChannel(userId);
  try{
    const result=await updater.checkAndStage({baseConfig:updaterBaseConfig(),channel,manual:options.manual===true,retryFailed:options.retryFailed===true,retryVersion:options.retryVersion,retrySha256:options.retrySha256,retryChannel:options.retryChannel,assertCheckAuthority:channel==='test'||options.retryFailed===true?async()=>{if(!(await verifyUpdateModerator(userId)))throw Object.assign(new Error('UPDATE_ADMIN_REQUIRED'),{code:'UPDATE_ADMIN_REQUIRED'});if(await effectiveUpdateChannel(userId)!==channel||options.retryFailed===true&&channel!==options.retryChannel)throw Object.assign(new Error('UPDATE_RETRY_TARGET_CHANGED'),{code:'UPDATE_RETRY_TARGET_CHANGED'});}:undefined});
    emitUpdateStatus(await updateStatusFor(userId));
    return result;
  }catch(error){emitUpdateStatus(await updateStatusFor(userId));throw error;}
}

function scheduleUpdateChecks() {
  if(!updater||!app.isPackaged)return;
  if(updateStartupTimer){clearTimeout(updateStartupTimer);updateStartupTimer=null;}
  if(updatePeriodicTimer)clearInterval(updatePeriodicTimer);
  const cfg=updater.config(updaterBaseConfig());
  // Açılış kontrolü login/renderer beklemez: uygulama ayağa kalkarken hemen
  // başlar. Ağ veya release kaynağı yavaşsa Buyer Log yine bloklanmadan açılır.
  void runUpdateCheck({manual:false}).catch(()=>{});
  watchSignedInTestChannel();
  updatePeriodicTimer=setInterval(()=>{void runUpdateCheck({manual:false}).catch(()=>{});},cfg.checkIntervalHours*60*60*1000);
  if(updatePeriodicTimer.unref)updatePeriodicTimer.unref();
}

// Açılış kontrolü girişten önce çalışır; kullanıcı kimliği yokken moderator
// doğrulanamaz ve TEST kanalı STABLE'a düşer. TEST yapılandırılmışsa giriş yapan
// her yeni kullanıcı için kanal bir kez yeniden kontrol edilir; aksi hâlde TEST
// sürümü ancak 6 saatlik periyodik kontrolde veya elle görülürdü.
function watchSignedInTestChannel() {
  if(updateSignInTimer){clearInterval(updateSignInTimer);updateSignInTimer=null;}
  const cfg=updater.config(updaterBaseConfig());
  if(cfg.channel!=='test')return;
  let checkedUserId='',busy=false;
  updateSignInTimer=setInterval(async()=>{
    if(busy)return;
    busy=true;
    try{
      const userId=await currentRendererUserId();
      if(userId&&userId!==checkedUserId){
        checkedUserId=userId;
        await runUpdateCheck({manual:false,userId}).catch(()=>{});
      }
    }finally{busy=false;}
  },5000);
  if(updateSignInTimer.unref)updateSignInTimer.unref();
}

/* --------------------------------------------------------- pencere durumu */

/*
 * Pencere geometrisi KULLANICI TERCİHİDİR, paylaşılan iş verisi değildir:
 * cihaza özel yerel dosyada durur, sync'e girmez.
 *
 * Ekran düzeni değişince (dizüstü dock'tan ayrılınca) eski konum artık var
 * olmayan bir monitörü gösterebilir; pencere görünmez bir yerde açılırdı.
 * Bu yüzden kayıtlı dikdörtgen, mevcut ekranlarla KESİŞMİYORSA yok sayılır.
 */
function loadWindowState() {
  const saved = readJson(paths.windowStatePath, null);
  const fallback = { ...DEFAULT_BOUNDS, maximized: false };
  if (!saved || typeof saved !== 'object') return fallback;
  const width = Math.max(800, Number(saved.width) || DEFAULT_BOUNDS.width);
  const height = Math.max(600, Number(saved.height) || DEFAULT_BOUNDS.height);
  const state = { width, height, maximized: saved.maximized === true };
  if (Number.isInteger(saved.x) && Number.isInteger(saved.y)) {
    const visible = screen.getAllDisplays().some(display => {
      const area = display.workArea;
      return saved.x < area.x + area.width && saved.x + width > area.x
        && saved.y < area.y + area.height && saved.y + height > area.y;
    });
    if (visible) { state.x = saved.x; state.y = saved.y; }
  }
  return state;
}

function saveWindowState(targetWindow = activeBuyerLogWindow()) {
  if (!targetWindow || targetWindow.isDestroyed()) return;
  try {
    const maximized = targetWindow.isMaximized();
    const bounds = maximized ? targetWindow.getNormalBounds() : targetWindow.getBounds();
    fs.mkdirSync(path.dirname(paths.windowStatePath), { recursive: true });
    fs.writeFileSync(paths.windowStatePath, JSON.stringify({
      x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height, maximized,
    }, null, 2) + '\n', 'utf8');
  } catch (_) { /* tercih kaydedilemezse uygulama yine çalışır */ }
}

/* ------------------------------------------------------- gezinme politikası */

function isExternalScheme(target) {
  return /^(https?|mailto|tel|msteams):/i.test(String(target || ''));
}

function openExternal(target) {
  if (!isExternalScheme(target)) return;
  shell.openExternal(target).catch(error => log('Harici bağlantı açılamadı: ' + error.message));
}

/*
 * Uygulama origin'i dışına çıkan her gezinme sistem tarayıcısına yönlenir (§3).
 * Buyer Log arayüzü kendi origin'inde kalır; keyfi bir sayfa Electron
 * penceresini ele geçiremez.
 */
/*
 * Gerçek URL.origin eşitliği. Önek karşılaştırması (url.startsWith(origin))
 * "http://127.0.0.1:6194@evil.example/" (userinfo) ve "http://127.0.0.1:61940/"
 * gibi adresleri aynı origin sanıp yabancı sayfayı preload köprülü pencereye
 * yüklüyordu.
 */
function sameOrigin(url, origin) {
  try { return new URL(String(url)).origin === new URL(String(origin)).origin; }
  catch (_) { return false; }
}
function applyNavigationPolicy(contents, origin) {
  contents.setWindowOpenHandler(({ url }) => {
    openExternal(url);
    return { action: 'deny' };
  });
  const guard = (event, url) => {
    if (sameOrigin(url, origin)) return;
    event.preventDefault();
    openExternal(url);
  };
  contents.on('will-navigate', guard);
  contents.on('will-redirect', guard);
  contents.on('will-attach-webview', event => event.preventDefault());
}

/*
 * Çakışmayan hedef ad: "Rapor.xlsx" → "Rapor (2).xlsx". Tarayıcıların yaptığı
 * budur; var olan bir dışa aktarımın üstüne yazmak veri kaybıdır.
 */
function uniqueDownloadPath(directory, fileName) {
  const extension = path.extname(fileName);
  const base = path.basename(fileName, extension) || 'indirme';
  let candidate = path.join(directory, base + extension);
  for (let index = 2; fs.existsSync(candidate) && index < 1000; index += 1) {
    candidate = path.join(directory, base + ' (' + index + ')' + extension);
  }
  return candidate;
}

/*
 * İNDİRMELER — mevcut davranış korunur.
 *
 * Edge --app kipinde Excel/PDF/Download PO çıktıları kullanıcıya sorulmadan
 * İndirilenler klasörüne düşüyordu. Electron, kaydetme yolu verilmezse bir
 * kaydetme penceresi açar; toplu dışa aktarımda bu, her dosya için kullanıcıyı
 * bekleyen bir kutu demektir — çalışan bir özelliğin sessizce ağırlaşması.
 * Bu yüzden hedef açıkça verilir: GERÇEK İndirilenler klasörü.
 *
 * Paketin resources klasörüne ASLA yazılmaz: app.getPath('downloads') gerçek
 * Windows kabuk klasörünü döndürür ve ana süreçte AppData yönlendirmesi
 * yapılmadığı için (bkz. portable-paths.js §2) bu yol doğrudur.
 */
function applyDownloadPolicy(targetSession) {
  targetSession.on('will-download', (_event, item, initiatingContents) => {
    let target = '';
    try {
      const downloads = app.getPath('downloads');
      fs.mkdirSync(downloads, { recursive: true });
      target = uniqueDownloadPath(downloads, item.getFilename());
      item.setSavePath(target);
    } catch (error) {
      // Yol belirlenemezse Electron'un kendi kaydetme penceresine düşülür:
      // indirmenin sessizce kaybolmasındansa kullanıcıya sorulsun.
      log('İndirme hedefi belirlenemedi (' + error.message + '); kaydetme penceresi açılacak.');
    }
    item.once('done', (_doneEvent, state) => {
      log('İndirme (' + state + '): ' + item.getFilename() + (target ? ' → ' + target : ''));
      /*
       * Buyer Log'un tüm istemci-taraflı dışa aktarımları (CP/Orders Excel vb.)
       * Blob URL + <a download> ile bu indirme yöneticisinden geçer; bu yüzden
       * BURASI, o dosyaların GERÇEK çakışma-güvenli son yolunu bilen TEK yerdir.
       * Yalnız başarıyla tamamlanan indirme renderer'a bildirilir — iptal/hata
       * durumunda "başarı" kartı ASLA üretilmez.
       */
      if (state === 'completed' && target) {
        const token = registerDownload(target);
        const payload = {
          token, filename: path.basename(target), path: target, success: true,
        };
        if (workspace) workspace.sendToDownloadOwner(initiatingContents, 'buyerlog:download-complete', payload);
        else if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('buyerlog:download-complete', payload);
      }
    });
  });

  /*
   * İzinler açıkça yönetilir. Collection'ın çok hücreli kopyala/yapıştır
   * mantığı asenkron pano API'sini kullanıyor (navigator.clipboard.write +
   * ClipboardItem); bu izin verilmezse Excel/Word/e-posta istemcisine yapıştırma
   * sessizce bozulur. Kamera, mikrofon, konum vb. Buyer Log'un işi değildir.
   */
  const ALLOWED = new Set(['clipboard-read', 'clipboard-sanitized-write', 'clipboard-write', 'fullscreen']);
  targetSession.setPermissionRequestHandler((_contents, permission, callback) => {
    callback(ALLOWED.has(permission));
  });
  targetSession.setPermissionCheckHandler((_contents, permission) => ALLOWED.has(permission));
}


/* ---------------------------------------------------- CoreNectum auto auth */

function normalizeBearer(value) {
  let text = String(value == null ? '' : value).replace(/[\u0000\r\n]/g, '').trim();
  if (/^bearer\s+/i.test(text)) text = text.replace(/^bearer\s+/i, '').trim();
  return text;
}

function jwtExpiryMs(token) {
  const raw = normalizeBearer(token);
  const parts = raw.split('.');
  if (parts.length !== 3) return 0;
  try {
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    return Number.isFinite(Number(payload.exp)) ? Number(payload.exp) * 1000 : 0;
  } catch (_) { return 0; }
}

function usableCoreNectumToken(value) {
  const token = normalizeBearer(value);
  if (token.length < 20) return '';
  const exp = jwtExpiryMs(token);
  if (exp && exp <= Date.now() + 30000) return '';
  return token;
}

function authorizationTokenFromHeaders(headers) {
  if (!headers || typeof headers !== 'object') return '';
  for (const [name, value] of Object.entries(headers)) {
    if (String(name).toLowerCase() !== 'authorization') continue;
    const token = usableCoreNectumToken(Array.isArray(value) ? value[0] : value);
    if (token) return token;
  }
  return '';
}

function coreNectumStyleTemplateFromRequest(details) {
  try {
    if (!details || String(details.method || '').toUpperCase() !== 'POST') return null;
    const url = new URL(String(details.url || ''));
    const expected = new URL(CORENECTUM_STYLE_LIST_API);
    if (url.origin !== expected.origin || url.pathname !== expected.pathname) return null;
    const chunks = [];
    for (const part of Array.from(details.uploadData || [])) {
      if (!part || !part.bytes) continue;
      const chunk = Buffer.from(part.bytes);
      if (chunk.length) chunks.push(chunk);
    }
    if (!chunks.length) return null;
    const body = Buffer.concat(chunks);
    if (!body.length || body.length > 256 * 1024) return null;
    const parsed = JSON.parse(body.toString('utf8'));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch (_) { return null; }
}

async function pushCoreNectumStyleTemplateToBackend(template) {
  if (!template || !backend || !backend.running || !backend.origin) return false;
  const response = await fetch(backend.origin + '/api/internal/desktop/corenectum-style-template', {
    method:'POST', cache:'no-store',
    headers:{
      'Content-Type':'application/json',
      'X-BuyerLog-Desktop-Bridge':desktopBridgeSecret,
    },
    body:JSON.stringify({ template }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.error || 'CoreNectum Style List istek şablonu backend’e aktarılamadı.');
  return true;
}

async function waitForCoreNectumStyleTemplate(timeoutMs = 2500) {
  const deadline = Date.now() + Math.max(0, Number(timeoutMs) || 0);
  while (!coreNectumStyleListTemplate && Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  return coreNectumStyleListTemplate;
}

const CORENECTUM_STORAGE_PROBE = `(()=>{try{
  const extract=value=>{const text=String(value==null?'':value).trim();if(!text)return '';
    if(/^bearer\\s+/i.test(text))return text.replace(/^bearer\\s+/i,'').trim();
    if(text[0]==='{'){try{const parsed=JSON.parse(text),candidate=parsed&&((parsed.access_token)||(parsed.accessToken));if(typeof candidate==='string'&&candidate.trim())return candidate.trim();}catch(_){}}
    return text;};
  const read=storage=>{if(!storage)return '';for(const key of ['access_token','accessToken']){try{const value=extract(storage.getItem(key));if(value)return value;}catch(_){}}
    try{for(let i=0;i<storage.length;i+=1){const key=String(storage.key(i)||'');if(!/^oidc\\.user:/i.test(key)&&!/(?:^|[._:-])access[_-]?token(?:$|[._:-])/i.test(key))continue;const raw=String(storage.getItem(key)||'').trim();if(!raw)continue;try{const parsed=JSON.parse(raw),candidate=parsed&&((parsed.access_token)||(parsed.accessToken));if(typeof candidate==='string'&&candidate.trim())return candidate.trim();}catch(_){if(!/^oidc\\.user:/i.test(key)){const value=extract(raw);if(value)return value;}}}}catch(_){}return '';};
  return read(typeof localStorage==='undefined'?null:localStorage)||read(typeof sessionStorage==='undefined'?null:sessionStorage)||'';
}catch(_){return '';}})()`;

async function validateCoreNectumToken(token) {
  const usable = usableCoreNectumToken(token);
  if (!usable) return { ok: false, status: 0 };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(CORENECTUM_STYLE_LIST_API, {
      method: 'POST', signal: controller.signal, cache: 'no-store', redirect: 'follow',
      headers: {
        Accept: 'application/json, text/plain, */*',
        Authorization: 'Bearer ' + usable,
        Origin: 'https://corenectum.lcwaikiki.com',
        Referer: 'https://corenectum.lcwaikiki.com/',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        pageNumber: 1,
        pageSize: 120,
        filterCriterias: [{ filterColumnName: 'plmCode', filterOperator: 10, filterValue: '999999999999999' }],
        searchCriteria: { columnNames: [], searchText: '' },
        favoriteGroupId: null,
      }),
    });
    return { ok: response.ok, status: response.status };
  } catch (_) {
    return { ok: false, status: 0 };
  } finally { clearTimeout(timer); }
}

async function pushCoreNectumTokenToBackend(token) {
  if (!backend || !backend.running || !backend.origin) throw new Error('Buyer Log backend hazır değil.');
  const response = await fetch(backend.origin + '/api/internal/desktop/corenectum-token', {
    method: 'POST', cache: 'no-store',
    headers: {
      'Content-Type': 'application/json',
      'X-BuyerLog-Desktop-Bridge': desktopBridgeSecret,
    },
    body: JSON.stringify({ token: usableCoreNectumToken(token) }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.error || 'CoreNectum oturumu backend\'e aktarılamadı.');
  return data;
}

async function clearCoreNectumBackendToken() {
  if (!backend || !backend.running || !backend.origin) return;
  try {
    await fetch(backend.origin + '/api/internal/desktop/corenectum-token', {
      method: 'DELETE', cache: 'no-store',
      headers: { 'X-BuyerLog-Desktop-Bridge': desktopBridgeSecret },
    });
  } catch (_) {}
}

function coreNectumAuthSession() {
  return session.fromPartition(CORENECTUM_AUTH_PARTITION, { cache: true });
}

function isAllowedCoreNectumAuthUrl(value) {
  try {
    const url = new URL(String(value || ''));
    if (url.protocol !== 'https:') return false;
    const host = url.hostname.toLowerCase();
    return host === 'corenectum.lcwaikiki.com'
      || host === CORENECTUM_API_HOST
      || host.endsWith('.lcwaikiki.com')
      || host === 'login.microsoftonline.com'
      || host.endsWith('.microsoftonline.com')
      || host.endsWith('.windows.net')
      || host.endsWith('.windowsazure.com')
      || host.endsWith('.msauth.net')
      || host.endsWith('.msftauth.net')
      || host === 'login.live.com'
      || host.endsWith('.microsoft.com');
  } catch (_) { return false; }
}

function coreNectumNavigationErrno(error) {
  const code = Number(error && error.errno);
  if (Number.isFinite(code) && code < 0) return code;
  const match = /\((-\d+)\)/.exec(String(error && error.message || ''));
  if (match) return Number(match[1]);
  const text = String(error && (error.code || error.message) || '');
  if (/ERR_ABORTED/i.test(text)) return -3;
  if (/ERR_FAILED/i.test(text)) return -2;
  return 0;
}

/* SSO oturumuna (çerez/localStorage) dokunmadan yalnız gezinmeyi bozabilen
 * service worker kayıtlarını, Cache Storage'ı ve HTTP önbelleğini temizler. */
async function resetCoreNectumNavigationCache(authSession) {
  try { await authSession.clearStorageData({ storages: ['serviceworkers', 'cachestorage'] }); } catch (_) {}
  try { await authSession.clearCache(); } catch (_) {}
}

async function acquireCoreNectumToken(options = {}) {
  if (coreNectumAuthInFlight) return coreNectumAuthInFlight;
  const interactive = options.interactive !== false;
  const request = (async () => {
    const authSession = coreNectumAuthSession();
    let authWindow = null;
    let settled = false;
    let storageTimer = null;
    let timeoutTimer = null;
    let silentTimer = null;
    let candidateBusy = false;

    const cleanup = () => {
      if (storageTimer) clearInterval(storageTimer);
      if (timeoutTimer) clearTimeout(timeoutTimer);
      if (silentTimer) clearTimeout(silentTimer);
      try { authSession.webRequest.onBeforeRequest({ urls: [CORENECTUM_STYLE_LIST_API] }, null); } catch (_) {}
      try { authSession.webRequest.onBeforeSendHeaders({ urls: ['https://mym-api.lcwaikiki.com/*'] }, null); } catch (_) {}
      if (authWindow && !authWindow.isDestroyed()) { try { authWindow.close(); } catch (_) {} }
      if (coreNectumAuthWindow === authWindow) coreNectumAuthWindow = null;
    };

    const finishWithToken = async (token, source) => {
      if (settled || candidateBusy) return null;
      const usable = usableCoreNectumToken(token);
      if (!usable) return null;
      candidateBusy = true;
      try {
        const valid = await validateCoreNectumToken(usable);
        if (!valid.ok) {
          if (valid.status === 401 || valid.status === 403) return null;
          // Network unavailable: keep the token; the real PLM request will
          // report the network condition accurately later.
        }
        await pushCoreNectumTokenToBackend(usable);
        const template = coreNectumStyleListTemplate || await waitForCoreNectumStyleTemplate(2500);
        if (template) {
          try { await pushCoreNectumStyleTemplateToBackend(template); }
          catch (error) { log('CoreNectum Style List şablonu aktarılamadı: ' + String(error && error.message || error)); }
        }
        settled = true;
        log('CoreNectum otomatik oturumu hazır (' + source + (template ? ', Style List şablonu hazır' : '') + ').');
        cleanup();
        return { ok: true, source: 'desktop-sso', capture: source };
      } finally { candidateBusy = false; }
    };

    return await new Promise((resolve) => {
      const resolveOnce = value => { if (settled && !(value && value.ok)) return; cleanup(); resolve(value); };

      authWindow = new BrowserWindow({
        width: 1120, height: 820, show: false, title: 'Buyer Log · CoreNectum Oturumu',
        parent: activeBuyerLogWindow(options.requestingContents) || undefined,
        autoHideMenuBar: true, backgroundColor: '#ffffff',
        webPreferences: {
          partition: CORENECTUM_AUTH_PARTITION,
          nodeIntegration: false, contextIsolation: true, sandbox: true,
          spellcheck: false,
        },
      });
      coreNectumAuthWindow = authWindow;

      authWindow.webContents.setWindowOpenHandler(({ url }) => {
        if (isAllowedCoreNectumAuthUrl(url)) {
          setImmediate(() => { if (authWindow && !authWindow.isDestroyed()) authWindow.loadURL(url).catch(() => {}); });
        }
        return { action: 'deny' };
      });
      authWindow.webContents.on('will-navigate', (event, url) => {
        if (isAllowedCoreNectumAuthUrl(url)) return;
        event.preventDefault();
      });
      authWindow.webContents.on('did-navigate', (_event, url) => {
        if (!interactive || settled || authWindow.isVisible()) return;
        try {
          const host = new URL(url).hostname.toLowerCase();
          if (host !== 'corenectum.lcwaikiki.com') { authWindow.show(); authWindow.focus(); }
        } catch (_) {}
      });
      authWindow.on('closed', () => {
        coreNectumAuthWindow = null;
        if (!settled) {
          settled = true;
          resolve({ ok: false, code: 'CORENECTUM_AUTH_CANCELLED', error: 'CoreNectum oturum açma işlemi kapatıldı.' });
        }
      });

      authSession.webRequest.onBeforeRequest({ urls: [CORENECTUM_STYLE_LIST_API] }, (details, callback) => {
        const template = coreNectumStyleTemplateFromRequest(details);
        if (template) coreNectumStyleListTemplate = template;
        callback({});
      });

      authSession.webRequest.onBeforeSendHeaders({ urls: ['https://mym-api.lcwaikiki.com/*'] }, (details, callback) => {
        const token = authorizationTokenFromHeaders(details.requestHeaders);
        callback({ requestHeaders: details.requestHeaders });
        if (!token || settled) return;
        void finishWithToken(token, 'network-header').then(result => { if (result && result.ok) resolve(result); });
      });

      const probeStorage = async () => {
        if (settled || candidateBusy || !authWindow || authWindow.isDestroyed()) return;
        let url = '';
        try { url = authWindow.webContents.getURL(); } catch (_) {}
        if (!/^https:\/\/corenectum\.lcwaikiki\.com\//i.test(url)) return;
        try {
          const token = await authWindow.webContents.executeJavaScript(CORENECTUM_STORAGE_PROBE, true);
          const result = await finishWithToken(token, 'session-storage');
          if (result && result.ok) resolve(result);
        } catch (_) {}
      };
      authWindow.webContents.on('did-finish-load', () => { void probeStorage(); });
      storageTimer = setInterval(() => { void probeStorage(); }, 900);

      silentTimer = setTimeout(() => {
        if (settled || !interactive || !authWindow || authWindow.isDestroyed()) return;
        authWindow.show(); authWindow.focus();
      }, 4500);
      timeoutTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        const value = { ok: false, code: interactive ? 'CORENECTUM_AUTH_TIMEOUT' : 'CORENECTUM_SIGNIN_REQUIRED', error: interactive ? 'CoreNectum oturumu zamanında doğrulanamadı.' : 'CoreNectum oturumu gerekli.' };
        cleanup();
        resolve(value);
      }, interactive ? 180000 : 9000);

      const failNavigation = error => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve({ ok: false, code: 'CORENECTUM_AUTH_NAVIGATION_FAILED', error: error && error.message ? error.message : 'CoreNectum açılamadı.' });
      };
      const loadHome = async (attempt) => {
        if (settled || !authWindow || authWindow.isDestroyed()) return;
        try {
          await authWindow.loadURL(CORENECTUM_HOME);
        } catch (error) {
          if (settled || !authWindow || authWindow.isDestroyed()) return;
          const errno = coreNectumNavigationErrno(error);
          // SSO yönlendirmesi devam ederken ilk yükleme ERR_ABORTED ile biter;
          // pencere gezinmeye devam eder, zaman aşımı/probe akışı sonucu belirler.
          if (errno === -3) { log('CoreNectum SSO yönlendirmesi devam ediyor (ERR_ABORTED göz ardı edildi).'); return; }
          // ERR_FAILED: kalıcı bölümdeki eski service worker/önbellek (Chromium ya
          // da CoreNectum güncellemesi sonrası) gezinmeyi düşürür. Oturum
          // çerezleri/localStorage korunur; yalnız SW + önbellek temizlenip bir
          // kez yeniden denenir.
          if (errno === -2 && attempt === 0) {
            log('CoreNectum ERR_FAILED; service worker/önbellek temizlenip yeniden deneniyor.');
            await resetCoreNectumNavigationCache(authSession);
            return loadHome(1);
          }
          log('CoreNectum açılamadı (' + errno + ').');
          failNavigation(error);
        }
      };
      void loadHome(0);
    });
  })();
  coreNectumAuthInFlight = request;
  try { return await request; }
  finally { if (coreNectumAuthInFlight === request) coreNectumAuthInFlight = null; }
}

async function clearCoreNectumAuthSession() {
  coreNectumStyleListTemplate = null;
  await clearCoreNectumBackendToken();
  try {
    const authSession = coreNectumAuthSession();
    await authSession.clearStorageData({ storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage'] });
    await authSession.clearCache();
  } catch (_) {}
  if (coreNectumAuthWindow && !coreNectumAuthWindow.isDestroyed()) coreNectumAuthWindow.close();
  coreNectumAuthWindow = null;
  return { ok: true };
}

/* ---------------------------------------------------- LCW AI arka plan oturumu
 * Kullanıcı tarayıcı görmeden: LCW AI gizli pencerede, kalıcı ayrılmış
 * bölümde açılır; kurumsal SSO çerezleri orada kaldığı için token sessizce
 * yenilenir. Pencere yalnız etkileşimli kipte ve gerçekten giriş sayfasına
 * gidildiğinde (ya da 4,5 sn içinde token yoksa) görünür. Token yalnız
 * localStorage'dan okunur, masaüstü köprüsüyle sunucu belleğine verilir;
 * renderer'a/IPC yanıtına/log'a girmez. Parola alanları okunmaz/doldurulmaz. */
function lcwAiAuthSession() {
  return session.fromPartition(LCWAI_AUTH_PARTITION, { cache: true });
}

async function pushLcwAiTokenToBackend(token) {
  if (!backend || !backend.running || !backend.origin) throw new Error('Buyer Log backend hazır değil.');
  const response = await fetch(backend.origin + '/api/internal/desktop/lcwai-token', {
    method: 'POST', cache: 'no-store',
    headers: { 'Content-Type': 'application/json', 'X-BuyerLog-Desktop-Bridge': desktopBridgeSecret },
    body: JSON.stringify({ token: String(token || '') }),
  });
  const data = await response.json().catch(() => ({}));
  return Boolean(response.ok && data.ok);
}

async function acquireLcwAiToken(options = {}) {
  if (lcwAiAuthInFlight) return lcwAiAuthInFlight;
  const interactive = options.interactive !== false;
  const request = new Promise(resolve => {
    let settled = false;
    let busy = false;
    let probeTimer = null, showTimer = null, timeoutTimer = null;
    const win = new BrowserWindow({
      width: 1120, height: 820, show: false, title: 'Buyer Log · LCW AI Oturumu',
      parent: activeBuyerLogWindow(options.requestingContents) || undefined,
      autoHideMenuBar: true, backgroundColor: '#ffffff',
      webPreferences: { partition: LCWAI_AUTH_PARTITION, nodeIntegration: false, contextIsolation: true, sandbox: true, spellcheck: false },
    });
    lcwAiAuthWindow = win;
    const finish = value => {
      if (settled) return;
      settled = true;
      if (probeTimer) clearInterval(probeTimer);
      if (showTimer) clearTimeout(showTimer);
      if (timeoutTimer) clearTimeout(timeoutTimer);
      if (!win.isDestroyed()) { try { win.close(); } catch (_) {} }
      if (lcwAiAuthWindow === win) lcwAiAuthWindow = null;
      resolve(value);
    };
    win.webContents.setWindowOpenHandler(({ url }) => {
      if (isAllowedCoreNectumAuthUrl(url)) setImmediate(() => { if (!win.isDestroyed()) win.loadURL(url).catch(() => {}); });
      return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (event, url) => { if (!isAllowedCoreNectumAuthUrl(url)) event.preventDefault(); });
    win.webContents.on('did-navigate', (_event, url) => {
      if (!interactive || settled || win.isVisible()) return;
      try { if (new URL(url).hostname.toLowerCase() !== 'lcwai.lcwaikiki.com') { win.show(); win.focus(); } } catch (_) {}
    });
    win.on('closed', () => finish({ ok: false, code: 'LCWAI_AUTH_CANCELLED' }));
    const probe = async () => {
      if (settled || busy || win.isDestroyed()) return;
      let url = '';
      try { url = win.webContents.getURL(); } catch (_) {}
      if (!/^https:\/\/lcwai\.lcwaikiki\.com\//i.test(url)) return;
      busy = true;
      try {
        const token = await win.webContents.executeJavaScript(LCWAI_STORAGE_PROBE, true);
        if (token && options.avoidFingerprint && crypto.createHash('sha256').update(String(token)).digest('hex').slice(0, 12) === options.avoidFingerprint) return;
        // Sunucu iss/azp/exp doğrular; geçersiz token kabul edilmez, beklenir.
        if (token && await pushLcwAiTokenToBackend(token)) { log('LCW AI arka plan oturumu hazır.'); finish({ ok: true, source: 'desktop-sso' }); }
      } catch (_) {} finally { busy = false; }
    };
    win.webContents.on('did-finish-load', () => { void probe(); });
    probeTimer = setInterval(() => { void probe(); }, 900);
    if (interactive) showTimer = setTimeout(() => { if (!settled && !win.isDestroyed()) { win.show(); win.focus(); } }, 4500);
    timeoutTimer = setTimeout(() => finish({ ok: false, code: interactive ? 'LCWAI_LOGIN_TIMEOUT' : 'LCWAI_SIGNIN_REQUIRED' }), interactive ? 300000 : 12000);
    win.loadURL(LCWAI_HOME).catch(() => finish({ ok: false, code: 'LCWAI_NETWORK' }));
  });
  lcwAiAuthInFlight = request;
  try { return await request; }
  finally { if (lcwAiAuthInFlight === request) lcwAiAuthInFlight = null; }
}

async function clearLcwAiAuthSession() {
  if (backend && backend.running && backend.origin) {
    try { await fetch(backend.origin + '/api/internal/desktop/lcwai-token', { method: 'DELETE', cache: 'no-store', headers: { 'X-BuyerLog-Desktop-Bridge': desktopBridgeSecret } }); } catch (_) {}
  }
  try {
    const authSession = lcwAiAuthSession();
    await authSession.clearStorageData({ storages: ['cookies', 'localstorage', 'indexdb', 'serviceworkers', 'cachestorage'] });
    await authSession.clearCache();
  } catch (_) {}
  if (lcwAiAuthWindow && !lcwAiAuthWindow.isDestroyed()) lcwAiAuthWindow.close();
  lcwAiAuthWindow = null;
  return { ok: true };
}

/* ---------------------------------------------------------- OAB auto auth */

function oabAuthSession() {
  return session.fromPartition(OAB_AUTH_PARTITION, { cache: true });
}

function isAllowedOabLoginUrl(value) {
  try {
    const url = new URL(String(value || ''));
    if (url.protocol !== 'https:') return false;
    const host = url.hostname.toLowerCase();
    return host === OAB_UI_HOST
      || host === OAB_API_HOST
      || host.endsWith('.lcwaikiki.com')
      || host === 'login.microsoftonline.com'
      || host.endsWith('.microsoftonline.com')
      || host.endsWith('.windows.net')
      || host.endsWith('.windowsazure.com')
      || host.endsWith('.msauth.net')
      || host.endsWith('.msftauth.net')
      || host === 'login.live.com'
      || host.endsWith('.microsoft.com');
  } catch (_) { return false; }
}

function isLikelyOabSignInUrl(value) {
  try {
    const url = new URL(String(value || ''));
    const host = url.hostname.toLowerCase();
    const pathText = `${url.pathname}${url.search}`.toLowerCase();
    if (host === OAB_UI_HOST) return /\/(?:login|signin|auth)(?:\/|$)/i.test(url.pathname);
    const identityHost = /(^|[.-])(keycloak|login|signin|auth|sso|identity|idp|adfs)([.-]|$)/i.test(host);
    if (identityHost) return true;
    return /login|signin|auth|identity|sso|adfs|microsoftonline|oauth|authorize|openid-connect/i.test(`${host}${pathText}`);
  } catch (_) { return false; }
}

async function oabWindowLooksLikeSignIn(authWindow) {
  if (!authWindow || authWindow.isDestroyed()) return true;
  const currentUrl = authWindow.webContents.getURL();
  if (isLikelyOabSignInUrl(currentUrl)) return true;
  try {
    return Boolean(await authWindow.webContents.executeJavaScript(
      `Boolean(document.querySelector('input[type="password"],input[name*="password" i],input[id*="password" i],form[action*="login" i],form[action*="signin" i]'))`,
      true,
    ));
  } catch (_) { return false; }
}

/* Electron loadURL() may reject with ERR_ABORTED (-3) while an SSO redirect is
 * actually continuing successfully. PASS performs exactly this kind of redirect.
 * Treating -3 as a hard failure used to close the OAB window before the user ever
 * saw the corporate sign-in page. Real main-frame navigation failures still fail. */
function isBenignOabNavigationAbort(error) {
  const code = Number(error && (error.errno ?? error.code));
  const text = String(error && (error.code || error.message) || '');
  return code === -3 || /ERR_ABORTED/i.test(text);
}

async function clearOabBackendAuthorization() {
  if (!backend || !backend.running || !backend.origin) return;
  try {
    await fetch(backend.origin + '/api/internal/desktop/oab-authorization', {
      method: 'DELETE', cache: 'no-store', redirect: 'error',
      headers: { 'X-BuyerLog-Desktop-Bridge': desktopBridgeSecret },
      // A busy backend must not hold the whole desktop shutdown open.
      signal: AbortSignal.timeout(1500),
    });
  } catch (_) {}
}

function oabAuthSelectionValue(value) {
  return String(value == null ? '' : value).replace(/[\u0000\r\n]/g, '').trim().slice(0, 200);
}

function oabViewerUrl(options = {}) {
  const url = new URL(OAB_VIEWER_URL);
  const seasonRef = oabAuthSelectionValue(options.seasonRef);
  const merchSubGroupRef = oabAuthSelectionValue(options.merchSubGroupRef);
  const buyerGroupRef = oabAuthSelectionValue(options.buyerGroupRef);
  if (seasonRef) url.searchParams.set('SeasonRef', seasonRef);
  if (merchSubGroupRef) url.searchParams.set('MerchSubGroupRef', merchSubGroupRef);
  if (buyerGroupRef) url.searchParams.set('BuyerGroupRefs', buyerGroupRef);
  return url.toString();
}

async function acquireOabAuthorization(options = {}) {
  const requestedInteractive = options.interactive !== false;
  const forceFresh = options.forceFresh === true;
  const requestedViewerUrl = oabViewerUrl(options);

  if (oabAuthInFlight) {
    if (requestedInteractive) {
      if (oabAuthFlowState) {
        oabAuthFlowState.interactive = true;
        oabAuthFlowState.viewerUrl = requestedViewerUrl;
        try { oabAuthFlowState.promoteInteractive?.({ immediate:true, reason:'interactive-join' }); } catch (_) {}
      } else if (oabAuthWindow && !oabAuthWindow.isDestroyed()) {
        try { oabAuthWindow.show(); oabAuthWindow.focus(); } catch (_) {}
      }
    }
    return oabAuthInFlight;
  }

  const flowState = {
    interactive: requestedInteractive,
    viewerUrl: requestedViewerUrl,
    promoteInteractive: null,
  };
  oabAuthFlowState = flowState;

  const request = (async () => {
    let authWindow = null;
    let settled = false;
    let timeoutTimer = null;
    let silentProbeTimer = null;
    let lifecycleTimer = null;
    let lifecycle = null;
    let resolvePromise = null;
    let fallbackTried = false;
    let navigationBusy = false;
    let freshReloadPending = false;
    let loginRequiredKnown = false;
    let networkCaptureInstalled = false;
    let authWebRequest = null;
    let networkReady = null;
    let closeRequested = false;
    let closeGraceTimer = null;
    let keptWindow = null;
    const popupWindows = new Set();

    const targetViewerUrl = () => flowState.viewerUrl || OAB_VIEWER_URL;

    const clearSilentProbe = () => {
      if (silentProbeTimer) { clearTimeout(silentProbeTimer); silentProbeTimer = null; }
    };
    const cleanupCapture = () => {
      if (lifecycleTimer) { clearInterval(lifecycleTimer); lifecycleTimer = null; }
      if (lifecycle) lifecycle.stop();
      if (authWebRequest && networkCaptureInstalled) {
        try { authWebRequest.onBeforeSendHeaders(null); } catch (_) {}
      }
      networkCaptureInstalled = false;
      authWebRequest = null;
    };
    const cleanup = () => {
      if (timeoutTimer) { clearTimeout(timeoutTimer); timeoutTimer = null; }
      if (closeGraceTimer) { clearTimeout(closeGraceTimer); closeGraceTimer = null; }
      clearSilentProbe();
      cleanupCapture();
      for (const popup of popupWindows) {
        if (popup && popup !== keptWindow && !popup.isDestroyed()) { try { popup.close(); } catch (_) {} }
      }
      popupWindows.clear();
      if (authWindow && authWindow !== keptWindow && !authWindow.isDestroyed()) { try { authWindow.close(); } catch (_) {} }
      if (oabAuthWindow === authWindow) oabAuthWindow = null;
    };
    let authorizationBusy = false;
    const finishAuthorizationNow = async (authorization, source, target) => {
      if (settled || !authorization) return false;
      const page = oabWindowOnPass(target) ? target : authWindow;
      // Validate in the signed-in PASS page itself (browser network stack).
      let result;
      authorizationBusy = true;
      try { result = await validateOabSessionInPage(page, authorization, oabSelectionFromViewerUrl(targetViewerUrl())); }
      finally { authorizationBusy = false; }
      if (!result || !result.ok) {
        log('OAB oturum adayı doğrulanamadı: ' + (result && (result.code || ('HTTP ' + result.status)) || 'OAB_AUTH_FAILED'));
        return false;
      }
      if (settled) return true;
      settled = true;
      log('OAB otomatik oturumu hazır (' + source + ', PASS sayfası içinde doğrulandı).');
      let parent = null;
      try { parent = authWindow.getParentWindow(); } catch (_) {}
      keptWindow = page;
      adoptOabSessionWindow(page, authorization, parent);
      cleanup();
      if (resolvePromise) resolvePromise({ ok:true, authenticated:true, source:'desktop-oab-sso' });
      return true;
    };
    /* Network capture and the storage probe can find candidates at the same
     * time. The backend holds a single RAM token, so candidates are validated
     * strictly one after another; a later rejected candidate can therefore
     * never wipe an already accepted one. */
    let authorizationChain = Promise.resolve(false);
    const finishAuthorization = (authorization, source = 'network', target = null) => {
      const run = authorizationChain.then(() => finishAuthorizationNow(authorization, source, target));
      authorizationChain = run.catch(() => false);
      return run;
    };
    const clearBackendAuthorizationInChain = () => {
      const run = authorizationChain.then(async () => { if (!settled) await clearOabBackendAuthorization(); return false; });
      authorizationChain = run.catch(() => false);
      return run;
    };
    const storedTokenAttempts = new Map();
    let storageProbeBusy = false;
    const probeStoredAuthorization = async () => {
      if (settled || storageProbeBusy) return false;
      const targets = [authWindow, ...popupWindows].filter(target => target && !target.isDestroyed());
      storageProbeBusy = true;
      try {
        for (const target of targets) {
          let host = '';
          try { host = new URL(target.webContents.getURL()).hostname.toLowerCase(); } catch (_) { continue; }
          if (host !== OAB_UI_HOST) continue;
          let candidates = [];
          try { candidates = await target.webContents.executeJavaScript(OAB_STORAGE_PROBE, true); }
          catch (_) { continue; }
          // Every distinct stored token is tried, so a stale plain key cannot
          // hide a fresh oidc.user entry.
          for (const candidate of Array.isArray(candidates) ? candidates : []) {
            const authorization = String(candidate || '');
            if (!authorization || settled) continue;
            const lastTriedAt = storedTokenAttempts.get(authorization) || 0;
            if (lastTriedAt && Date.now() - lastTriedAt < OAB_STORED_TOKEN_RETRY_MS) continue;
            storedTokenAttempts.set(authorization, Date.now());
            if (await finishAuthorization(authorization, 'PASS storage', target)) return true;
          }
        }
        return false;
      } finally {
        storageProbeBusy = false;
      }
    };

    return await new Promise(resolve => {
      resolvePromise = resolve;

      const finishFailure = (code, error) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve({ ok:false, authenticated:false, code, error });
      };
      const showWindow = target => {
        if (!flowState.interactive || settled || closeRequested || !target || target.isDestroyed()) return false;
        try {
          target.show();
          target.focus();
          return true;
        } catch (_) {
          return false;
        }
      };
      const showInteractiveWindow = () => showWindow(authWindow);
      const resetOabBrowserAuthState = async reason => {
        await clearOabBackendAuthorization();
        try {
          const authSession = oabAuthSession();
          await authSession.clearStorageData({ storages:['cookies','localstorage','indexdb','serviceworkers','cachestorage'] });
          await authSession.clearCache();
        } catch (_) {}
        lifecycle?.resetForFreshViewer?.();
        log('OAB tarayıcı oturumu yeni kullanıcı girişi için sıfırlandı (' + String(reason || 'interactive') + ').');
      };
      const armHardTimeout = () => {
        if (timeoutTimer) clearTimeout(timeoutTimer);
        const interactiveNow = flowState.interactive;
        timeoutTimer = setTimeout(() => {
          if (settled) return;
          finishFailure(
            interactiveNow ? 'OAB_AUTH_TIMEOUT' : 'OAB_AUTH_REQUIRED',
            interactiveNow ? 'OAB oturum açma işlemi zamanında tamamlanmadı.' : 'OAB oturumu gerekli.',
          );
        }, interactiveNow ? 180000 : 12000);
        timeoutTimer.unref?.();
      };
      const promoteInteractive = ({ immediate = true } = {}) => {
        flowState.interactive = true;
        if (closeRequested) {
          // A new interactive request after the user closed the window: the
          // window becomes usable again instead of silently cancelling.
          closeRequested = false;
          if (closeGraceTimer) { clearTimeout(closeGraceTimer); closeGraceTimer = null; }
          immediate = true;
        }
        clearSilentProbe();
        armHardTimeout();
        if (immediate || loginRequiredKnown) showInteractiveWindow();
      };
      flowState.promoteInteractive = promoteInteractive;
      // Programmatic clear (clearOabAuthSession) ends the flow without the
      // close grace period.
      flowState.abort = () => finishFailure('OAB_AUTH_CANCELLED', 'OAB kullanıcı girişi iptal edildi.');

      const loadLoginTarget = async (url, allowFallback = true) => {
        if (settled || authorizationBusy || navigationBusy || !authWindow || authWindow.isDestroyed()) return false;
        navigationBusy = true;
        try {
          await authWindow.loadURL(url);
          return true;
        } catch (error) {
          if (isBenignOabNavigationAbort(error)) {
            log('OAB SSO yönlendirmesi devam ediyor (ERR_ABORTED göz ardı edildi).');
            return true;
          }
          if (allowFallback && !fallbackTried) {
            fallbackTried = true;
            log('OAB viewer doğrudan açılamadı; PASS ana sayfası deneniyor.');
            try {
              await authWindow.loadURL(OAB_HOME_URL);
              return true;
            } catch (fallbackError) {
              if (isBenignOabNavigationAbort(fallbackError)) {
                log('OAB PASS SSO yönlendirmesi devam ediyor (fallback ERR_ABORTED göz ardı edildi).');
                return true;
              }
            }
          }
          if (closeRequested) finishFailure('OAB_AUTH_CANCELLED', 'OAB kullanıcı girişi iptal edildi.');
          else finishFailure('OAB_AUTH_NAVIGATION_FAILED', 'OAB giriş ekranı açılamadı.');
          return false;
        } finally {
          navigationBusy = false;
          if (freshReloadPending && !settled) {
            freshReloadPending = false;
            setImmediate(() => { if (!settled) void loadLoginTarget(targetViewerUrl(), false); });
          }
        }
      };
      const markLoginRequired = (url, target = authWindow) => {
        if (!isLikelyOabSignInUrl(url)) return false;
        // After the user closed the window an SSO hop may still pass through a
        // sign-in URL silently; never reveal it again, let the grace timer decide.
        if (closeRequested) return true;
        loginRequiredKnown = true;
        clearSilentProbe();
        if (lifecycle) void lifecycle.observe({ url, signIn:true });
        showWindow(target);
        return true;
      };
      const pulseLifecycle = async () => {
        if (settled || authorizationBusy || !lifecycle || !authWindow || authWindow.isDestroyed()) return;
        // A token already present in PASS storage wins over every heuristic
        // below: a signed-in session must never be sent back to the login page.
        if (await probeStoredAuthorization()) return;
        if (settled || authorizationBusy || authWindow.isDestroyed()) return;
        let url = '';
        try { url = authWindow.webContents.getURL(); } catch (_) { return; }
        const signIn = await oabWindowLooksLikeSignIn(authWindow);
        if (signIn) {
          markLoginRequired(url, authWindow);
          return;
        }
        await lifecycle.observe({ url, signIn:false });
      };
      const recoverStaleSilentProbe = async () => {
        if (settled || !flowState.interactive || forceFresh || loginRequiredKnown || closeRequested) return;
        if (await probeStoredAuthorization()) return;
        const state = lifecycle && lifecycle.snapshot();
        if (authorizationBusy || state && state.candidateBusy) {
          silentProbeTimer = setTimeout(() => { void recoverStaleSilentProbe(); }, 1000);
          silentProbeTimer.unref?.();
          return;
        }

        // A slow PASS viewer must never be interpreted as a reason to delete the
        // persistent corporate session. Keep persist:oab intact, discard only a
        // stale backend RAM token, reveal the current page and let the bounded
        // viewer lifecycle retry once if authenticated API traffic is still absent.
        log('OAB sessiz oturum kontrolü sonuçlanmadı; mevcut kalıcı OAB oturumu korunarak görünür akışa geçiliyor.');
        // Serialized with candidate validation: a DELETE must never abort a
        // candidate that the backend is still validating.
        await clearBackendAuthorizationInChain();
        lifecycle?.resetForFreshViewer?.();
        showInteractiveWindow();

        let currentUrl = '';
        try { currentUrl = authWindow.webContents.getURL(); } catch (_) {}
        if (currentUrl && isAllowedOabLoginUrl(currentUrl) && !isLikelyOabSignInUrl(currentUrl)) {
          schedulePulse(80);
          return;
        }
        if (navigationBusy) {
          freshReloadPending = true;
          try { authWindow.webContents.stop(); } catch (_) {}
          return;
        }
        await loadLoginTarget(targetViewerUrl(), false);
      };
      const armSilentProbe = () => {
        if (!flowState.interactive || forceFresh || settled || loginRequiredKnown || silentProbeTimer) return;
        silentProbeTimer = setTimeout(() => {
          silentProbeTimer = null;
          void recoverStaleSilentProbe();
        }, OAB_SILENT_PROBE_MS);
        silentProbeTimer.unref?.();
      };

      authWindow = new BrowserWindow({
        width: 1120, height: 820, show: false,
        title: 'OAB Kullanıcı Girişi',
        parent: activeBuyerLogWindow(options.requestingContents) || undefined,
        autoHideMenuBar: true, backgroundColor: '#ffffff',
        webPreferences: {
          partition: OAB_AUTH_PARTITION,
          backgroundThrottling: false,
          nodeIntegration: false,
          contextIsolation: true,
          sandbox: true,
          spellcheck: false,
        },
      });
      oabAuthWindow = authWindow;

      lifecycle = createOabAuthLifecycle({
        apiHost: OAB_API_HOST,
        uiHost: OAB_UI_HOST,
        maxViewerKicks: 2,
        viewerKickIntervalMs: 6000,
        viewerSettleMs: 12000,
        onViewerKick: async ({ attempt, reason }) => {
          if (settled || navigationBusy || !authWindow || authWindow.isDestroyed()) return false;
          log('OAB viewer report isteği yeniden tetikleniyor (' + reason + ', ' + attempt + '/2).');
          return loadLoginTarget(targetViewerUrl(), false);
        },
        onAuthorization: authorization => finishAuthorization(authorization, 'network', authWindow),
        onPhase: phase => {
          if (phase !== 'waiting-report-request') log('OAB auth aşaması: ' + phase);
          if (phase === 'login-required') {
            loginRequiredKnown = true;
            clearSilentProbe();
            showInteractiveWindow();
          }
        },
      });

      /*
       * Authorization is observed only inside the dedicated persist:oab
       * Electron session. webRequest is installed before the first viewer
       * navigation, so no external browser, debugging port or DevTools
       * protocol connection is involved.
       */
      try {
        authWebRequest = oabAuthSession().webRequest;
        authWebRequest.onBeforeSendHeaders(OAB_AUTH_CAPTURE_FILTER, (details, callback) => {
          if (!settled && lifecycle) void lifecycle.onNetworkRequest(details);
          callback({ requestHeaders: details.requestHeaders });
        });
        networkCaptureInstalled = true;
        networkReady = Promise.resolve(true);
      } catch (error) {
        finishFailure('OAB_AUTH_CAPTURE_UNAVAILABLE', 'OAB ağ isteği yakalama başlatılamadı.');
        return;
      }

      authWindow.once('ready-to-show', () => {
        // Do not reveal the PASS viewer shell merely because the user selected
        // "OAB Kullanıcı Girişi". The actual sign-in surface can be a child
        // SSO window; showing this parent early is what produced the blank page.
        if (loginRequiredKnown) showInteractiveWindow();
      });

      const schedulePulse = delay => {
        const timer = setTimeout(() => { void pulseLifecycle(); }, Math.max(0, Number(delay) || 0));
        timer.unref?.();
      };
      const handleAllowedMainFrameNavigation = url => {
        if (!isAllowedOabLoginUrl(url)) return;
        if (markLoginRequired(url, authWindow)) return;
        schedulePulse(80);
      };

      authWindow.webContents.on('did-start-navigation', (_event, url, _inPlace, isMainFrame) => {
        if (!isMainFrame) return;
        handleAllowedMainFrameNavigation(url);
      });
      authWindow.webContents.on('will-redirect', (_event, url, _inPlace, isMainFrame) => {
        if (!isMainFrame) return;
        handleAllowedMainFrameNavigation(url);
      });
      authWindow.webContents.on('did-navigate', (_event, url) => handleAllowedMainFrameNavigation(url));
      authWindow.webContents.on('did-finish-load', () => schedulePulse(60));
      authWindow.webContents.on('did-navigate-in-page', (_event, url, isMainFrame) => {
        if (isMainFrame === false) return;
        handleAllowedMainFrameNavigation(url);
      });
      authWindow.webContents.on('did-fail-load', (_event, errorCode, _description, _validatedURL, isMainFrame) => {
        if (!isMainFrame || settled || Number(errorCode) === -3) return;
        log('OAB giriş sayfası main-frame yükleme hatası: ' + Number(errorCode));
        if (closeRequested) finishFailure('OAB_AUTH_CANCELLED', 'OAB kullanıcı girişi iptal edildi.');
        else finishFailure('OAB_AUTH_NAVIGATION_FAILED', 'OAB giriş ekranı yüklenemedi.');
      });
      authWindow.webContents.on('render-process-gone', (_event, details) => {
        if (settled) return;
        log('OAB giriş renderer süreci kapandı: ' + String(details && details.reason || 'unknown'));
        finishFailure('OAB_AUTH_RENDERER_FAILED', 'OAB giriş ekranı çalıştırılamadı.');
      });
      authWindow.webContents.on('page-title-updated', event => {
        event.preventDefault();
        if (!authWindow.isDestroyed()) authWindow.setTitle('OAB Kullanıcı Girişi');
      });
      authWindow.webContents.setWindowOpenHandler(({ url }) => {
        if (url !== 'about:blank' && !isAllowedOabLoginUrl(url)) return { action:'deny' };
        if (url !== 'about:blank' && isLikelyOabSignInUrl(url)) {
          loginRequiredKnown = true;
          clearSilentProbe();
          if (lifecycle) void lifecycle.observe({ url, signIn:true });
          // The popup itself is revealed in did-create-window. Showing the
          // parent here exposes an empty PASS shell before Electron gives us
          // the child BrowserWindow.
        }
        return {
          action:'allow',
          overrideBrowserWindowOptions: {
            show:false,
            parent:authWindow,
            autoHideMenuBar:true,
            backgroundColor:'#ffffff',
            webPreferences: {
              partition: OAB_AUTH_PARTITION,
              backgroundThrottling:false,
              nodeIntegration:false,
              contextIsolation:true,
              sandbox:true,
              spellcheck:false,
            },
          },
        };
      });
      authWindow.webContents.on('did-create-window', popup => {
        popupWindows.add(popup);
        try { popup.setMenu(null); } catch (_) {}

        const handlePopupNavigation = url => {
          if (!isAllowedOabLoginUrl(url)) return;
          if (markLoginRequired(url, popup)) return;
          if (loginRequiredKnown) showWindow(popup);
        };

        popup.webContents.on('will-navigate', (event, url) => {
          if (url === 'about:blank' || isAllowedOabLoginUrl(url)) {
            if (url !== 'about:blank') handlePopupNavigation(url);
            return;
          }
          event.preventDefault();
          try { popup.close(); } catch (_) {}
        });
        popup.webContents.on('did-start-navigation', (_event, url, _inPlace, isMainFrame) => {
          if (!isMainFrame) return;
          handlePopupNavigation(url);
        });
        popup.webContents.on('will-redirect', (_event, url, _inPlace, isMainFrame) => {
          if (!isMainFrame) return;
          handlePopupNavigation(url);
        });
        popup.webContents.on('did-navigate', (_event, url) => handlePopupNavigation(url));
        popup.once('ready-to-show', () => {
          let url = '';
          try { url = popup.webContents.getURL(); } catch (_) {}
          // Microsoft/Keycloak can create an about:blank child and populate or
          // redirect it afterwards. For a user-triggered interactive auth flow,
          // the child is the usable sign-in surface and must never stay hidden.
          if (flowState.interactive || loginRequiredKnown || isLikelyOabSignInUrl(url)) showWindow(popup);
        });
        popup.webContents.on('did-finish-load', () => {
          if (flowState.interactive && !settled) showWindow(popup);
        });
        popup.webContents.on('did-fail-load', (_event, errorCode, _description, _validatedURL, isMainFrame) => {
          if (!isMainFrame || settled || Number(errorCode) === -3) return;
          log('OAB SSO penceresi yükleme hatası: ' + Number(errorCode));
          finishFailure('OAB_AUTH_NAVIGATION_FAILED', 'OAB kurumsal giriş ekranı yüklenemedi.');
        });
        popup.on('closed', () => {
          popupWindows.delete(popup);
          if (!settled) setImmediate(() => { void loadLoginTarget(targetViewerUrl(), false); });
        });

        let currentPopupUrl = '';
        try { currentPopupUrl = popup.webContents.getURL(); } catch (_) {}
        if (currentPopupUrl && currentPopupUrl !== 'about:blank') handlePopupNavigation(currentPopupUrl);
      });
      authWindow.webContents.on('will-navigate', (event, url) => {
        if (isAllowedOabLoginUrl(url)) {
          markLoginRequired(url, authWindow);
          return;
        }
        event.preventDefault();
      });
      /* Closing the sign-in window used to end the flow as "cancelled" even when
       * the user had just signed in and PASS had not issued a report request
       * yet. Now the window is only hidden: the PASS page keeps running for a
       * short grace period, storage/network detection continues, and only if
       * no session appears (or PASS asks for sign-in again) is it cancelled. */
      authWindow.on('close', event => {
        if (settled || closeRequested) return;
        event.preventDefault();
        closeRequested = true;
        clearSilentProbe();
        log('OAB giriş penceresi kapatıldı; tamamlanmış oturum arka planda kontrol ediliyor.');
        for (const target of [authWindow, ...popupWindows]) {
          if (target && !target.isDestroyed()) { try { target.hide(); } catch (_) {} }
        }
        closeGraceTimer = setTimeout(() => {
          closeGraceTimer = null;
          finishFailure('OAB_AUTH_CANCELLED', 'OAB kullanıcı girişi iptal edildi.');
        }, OAB_CLOSE_GRACE_MS);
        closeGraceTimer.unref?.();
        void (async () => {
          if (await probeStoredAuthorization()) return;
          if (settled) return;
          // Let PASS finish its SSO callback with the cookies the login just set.
          let currentUrl = '';
          try { currentUrl = authWindow.webContents.getURL(); } catch (_) {}
          if (!currentUrl || !isAllowedOabLoginUrl(currentUrl) || isLikelyOabSignInUrl(currentUrl)) {
            await loadLoginTarget(targetViewerUrl(), false);
          }
        })();
      });
      authWindow.on('closed', () => {
        oabAuthWindow = null;
        clearSilentProbe();
        cleanupCapture();
        for (const popup of popupWindows) {
          if (popup && !popup.isDestroyed()) { try { popup.close(); } catch (_) {} }
        }
        popupWindows.clear();
        if (!settled) {
          settled = true;
          if (timeoutTimer) clearTimeout(timeoutTimer);
          resolve({ ok:false, authenticated:false, code:'OAB_AUTH_CANCELLED', error:'OAB kullanıcı girişi iptal edildi.' });
        }
      });

      lifecycleTimer = setInterval(() => { void pulseLifecycle(); }, 500);
      lifecycleTimer.unref?.();
      armHardTimeout();

      void Promise.resolve(networkReady)
        .then(async () => {
          if (settled) return false;
          // Normal interactive authentication always reuses persist:oab.
          // A destructive browser-session reset is reserved for an explicit
          // forceFresh request; the ordinary user-menu action and Get OAB must
          // see exactly the same corporate session.
          if (forceFresh) await resetOabBrowserAuthState('force-fresh-login');
          if (settled) return false;
          armSilentProbe();
          return loadLoginTarget(targetViewerUrl(), true);
        })
        .catch(() => {
          if (!settled) finishFailure('OAB_AUTH_CAPTURE_UNAVAILABLE', 'OAB ağ isteği yakalama başlatılamadı.');
        });
    });
  })();

  oabAuthInFlight = request;
  try {
    return await request;
  } finally {
    if (oabAuthInFlight === request) oabAuthInFlight = null;
    if (oabAuthFlowState === flowState) oabAuthFlowState = null;
  }
}

async function clearOabAuthSession() {
  const pending = oabAuthInFlight;
  try { oabAuthFlowState?.abort?.(); } catch (_) {}
  destroyOabSessionWindow();
  if (oabAuthWindow && !oabAuthWindow.isDestroyed()) {
    try { oabAuthWindow.close(); } catch (_) {}
  }
  if (pending) {
    await Promise.race([
      Promise.resolve(pending).catch(() => {}),
      new Promise(resolve => setTimeout(resolve, 250)),
    ]);
  }

  await clearOabBackendAuthorization();
  try {
    const authSession = oabAuthSession();
    await authSession.clearStorageData({ storages:['cookies','localstorage','indexdb','serviceworkers','cachestorage'] });
    await authSession.clearCache();
  } catch (_) {}
  oabAuthWindow = null;
  return { ok:true, authenticated:false };
}

/* ------------------------------------------------------------- pencereler */

function createMainWindow(origin) {
  workspace = createWorkspaceManager({
    BrowserWindow,
    WebContentsView,
    dialog,
    screen,
    path,
    crypto,
    origin,
    nativeTheme,
    shellFile: path.join(__dirname, 'workspace.html'),
    shellPreload: path.join(__dirname, 'workspace-preload.js'),
    contentPreload: path.join(__dirname, 'preload.js'),
    iconPath: APP_ICON_SOURCE,
    appDetails: taskbarAppDetails(),
    loadWindowState,
    saveWindowState,
    applyNavigationPolicy,
    log,
    onFirstRendererReady: () => {
      confirmLauncherHealth();
      watchUiLanguage();
    },
  });
  log('Çoklu sekme çalışma alanı yükleniyor: ' + origin);
  const state = workspace.createWindow({ module: 'overview' });
  mainWindow = state.window; // eski hata/teşhis yolları için ilk pencere başvurusu
  // Açılış ekranı, ana pencere gerçekten görünür olduğunda kapanır (boşluk kalmaz).
  mainWindow.once('show', closeSplash);
  mainWindow.once('closed', closeSplash);
  // GPU durumu pencere çizmeye başladıktan sonra yeniden ölçülür (bkz. logGpuDiagnostics).
  mainWindow.once('show', () => {
    const timer = setTimeout(() => logGpuDiagnostics('window-shown'), GPU_DIAGNOSTIC_DELAY_MS);
    if (timer.unref) timer.unref();
  });
  return mainWindow;
}

/*
 * AÇILIŞ EKRANI. Kurulum onarımı, veri taşıma ve sunucunun hazır olmasını
 * beklemek birkaç saniye sürebiliyor; bu sürede ekranda hiçbir şey olmadığı
 * için kullanıcılar programın açılmadığını sanıp BuyerLog.exe'yi tekrar
 * çalıştırıyordu. Ekranın ortasında küçük bir "başlatılıyor" penceresi ana
 * pencere görünene ya da hata ekranı açılana kadar kalır.
 *
 * Güncellemenin ilk açılışı (launcher denemesi ya da bu sürümün ilk kurulum
 * onarımı) dakikalar sürebiliyor ve ekran normal bir açılış gibi görünüyordu.
 * Pencere artık hangi adımda olunduğunu, geçen süreyi ve güncelleme kipinde
 * "kapatmayın" uyarısını gösterir. Adım metinleri splash.html'dedir; buradan
 * yalnız doğrulanmış adım kimliği gönderilir.
 */
const SPLASH_STEPS = ['update', 'repair', 'data', 'server', 'database', 'finish', 'screens'];
let splashState = null;

function uiLanguageFile() {
  return path.join(paths.localDataRoot, 'desktop-ui-language.json');
}

// Açılış ekranı arayüz yüklenmeden önce görünür; son kullanılan dil kapanışta
// saklanır, ilk açılışta işletim sistemi dili kullanılır.
function startupLanguage() {
  const saved = paths ? readJson(uiLanguageFile(), null) : null;
  if (saved && (saved.language === 'tr' || saved.language === 'en')) return saved.language;
  let locale = '';
  try { locale = String((app.getPreferredSystemLanguages()[0]) || app.getLocale() || ''); } catch (_) { locale = ''; }
  return !locale || /^tr\b/i.test(locale) ? 'tr' : 'en';
}

let rememberedUiLanguage = '';
let uiLanguageTimer = null;
// Son pencere kapatılırken sekmeler window-all-closed'dan ÖNCE yok edilir;
// kapanışta okumak yetmez. Dil, çalışma sırasında hafifçe izlenir.
function watchUiLanguage() {
  if (uiLanguageTimer) return;
  void rememberUiLanguage();
  uiLanguageTimer = setInterval(() => { void rememberUiLanguage(); }, 30000);
  if (uiLanguageTimer.unref) uiLanguageTimer.unref();
}

async function rememberUiLanguage() {
  const contents = activeBuyerLogContents();
  if (!paths || !contents || contents.isDestroyed()) return;
  let timer = null;
  try {
    const language = await Promise.race([
      contents.executeJavaScript('document.documentElement.lang', false),
      new Promise(resolve => { timer = setTimeout(() => resolve(''), 400); }),
    ]);
    if ((language !== 'tr' && language !== 'en') || language === rememberedUiLanguage) return;
    rememberedUiLanguage = language;
    fs.mkdirSync(path.dirname(uiLanguageFile()), { recursive: true });
    fs.writeFileSync(uiLanguageFile(), JSON.stringify({ language }) + '\n', 'utf8');
  } catch (_) { /* dil hatırlanamazsa açılış ekranı sistem dilini kullanır */ }
  finally { clearTimeout(timer); }
}

/* Güncelleme kipi: launcher bu açılışta yeni sürümü denemeye aldıysa ya da
 * önceki bir sürümün onarım kaydı varken bu sürüm/çekirdek için kurulum onarımı
 * henüz tamamlanmadıysa. Kaydı hiç olmayan ilk kurulum normal açılıştır. */
function startupIsUpdate() {
  if (process.env.BUYER_LOG_UPDATE_HEALTH_TOKEN) return true;
  if (!app.isPackaged || !paths) return false;
  try {
    const report = readRepairReport(paths.localDataRoot);
    return Boolean(report) && !(report.version === appVersion() && report.appCoreRoot === path.resolve(APP_CORE_ROOT) && report.finishedAt);
  } catch (_) { return false; }
}

function pushSplashState() {
  const window = splashWindow;
  if (!splashState || !window || window.isDestroyed() || window.webContents.isLoading()) return;
  const script = 'window.BLSplash&&window.BLSplash.update(' + JSON.stringify(splashState) + ')';
  window.webContents.executeJavaScript(script, false).catch(() => {});
}

// Adımlar yalnız ileri gider; geç gelen bir sunucu işareti ekranı geri sardırmaz.
function setSplashStep(step) {
  if (!splashState || SPLASH_STEPS.indexOf(step) <= SPLASH_STEPS.indexOf(splashState.step)) return;
  splashState = { ...splashState, step };
  log('Açılış adımı: ' + step);
  pushSplashState();
}

function showSplash() {
  if (splashWindow && !splashWindow.isDestroyed()) return;
  const launchNotice = global.__buyerLogLaunchNotice;
  delete global.__buyerLogLaunchNotice;
  const update = startupIsUpdate();
  const firstSplash = !splashState;
  splashState = {
    mode: update ? 'update' : 'start',
    lang: startupLanguage(),
    version: appVersion(),
    step: update ? 'repair' : 'data',
    // İlk açılışta süre BuyerLog.exe başlangıcından (launcher doğrulaması dahil) sayılır.
    startedAt: firstSplash ? Math.round(Date.now() - process.uptime() * 1000) : Date.now(),
  };
  try {
    const splash = new BrowserWindow({
      width: 460, height: 320, center: true, show: false, frame: false,
      resizable: false, minimizable: false, maximizable: false, fullscreenable: false,
      backgroundColor: '#f8f8f9', title: 'Buyer Log başlatılıyor / Starting Buyer Log',
      icon: APP_ICON_SOURCE,
      webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true },
    });
    splashWindow = splash;
    // Launcher'ın erken bildirimi, adımlı ekran gerçekten görününce kapanır (boşluk kalmaz).
    splash.once('ready-to-show', () => {
      if (splash.isDestroyed()) return;
      splash.show();
      if (launchNotice && !launchNotice.isDestroyed()) launchNotice.destroy();
    });
    splash.webContents.on('did-finish-load', pushSplashState);
    splash.on('closed', () => {
      if (splashWindow === splash) splashWindow = null;
      if (launchNotice && !launchNotice.isDestroyed()) launchNotice.destroy();
    });
    splash.loadFile(path.join(__dirname, 'splash.html'), {
      query: {
        v: splashState.version, mode: splashState.mode, lang: splashState.lang,
        step: splashState.step, t0: String(splashState.startedAt),
      },
    });
  } catch (error) {
    log('Açılış ekranı gösterilemedi: ' + error.message);
    splashWindow = launchNotice && !launchNotice.isDestroyed() ? launchNotice : null;
    if (splashWindow) splashWindow.on('closed', () => { if (splashWindow === launchNotice) splashWindow = null; });
  }
}

function closeSplash() {
  const window = splashWindow;
  splashWindow = null;
  if (window && !window.isDestroyed()) window.destroy();
}

/*
 * BAŞLATMA HATASI EKRANI (§4). CMD penceresi artık yok; yığın izi göstermek
 * yerine kullanıcının yapabileceği üç şey sunulur: Tekrar Dene, Teşhis, Çıkış.
 */
function showStartupError(detail) {
  startupFailure = detail;
  log('BAŞLATMA HATASI: ' + detail.message);
  if (errorWindow && !errorWindow.isDestroyed()) { errorWindow.focus(); return; }
  errorWindow = new BrowserWindow({
    width: 720, height: 560, show: false, title: 'Buyer Log', resizable: true,
    icon: path.join(APP_CORE_ROOT, 'buyerlog.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false, contextIsolation: true, sandbox: true,
    },
  });
  errorWindow.webContents.setWindowOpenHandler(({ url }) => { openExternal(url); return { action: 'deny' }; });
  // Preload'lu hata ekranı yerel dosyadan başka bir yere gezinemez.
  errorWindow.webContents.on('will-navigate', (event, url) => { event.preventDefault(); if (/^https?:/i.test(String(url))) openExternal(url); });
  errorWindow.webContents.on('will-attach-webview', event => event.preventDefault());
  errorWindow.once('ready-to-show', () => { closeSplash(); errorWindow.show(); });
  errorWindow.on('closed', () => { errorWindow = null; });
  errorWindow.loadFile(path.join(__dirname, 'startup-error.html'));
}

function closeErrorWindow() {
  if (errorWindow && !errorWindow.isDestroyed()) errorWindow.close();
  errorWindow = null;
  startupFailure = null;
}

/*
 * Backend AÇILDIKTAN SONRA öldüyse. Gözetmen normal çökmeleri kendi
 * toparlıyor (server/watchdog.js); buraya düşmek, gözetmenin de pes ettiği
 * anlamına gelir. O noktada pencere hâlâ açıktır ama arkasında sunucu yoktur:
 * kullanıcı tıklar, hiçbir şey olmaz. Sessiz kalmak yerine ne olduğu söylenir.
 */
function handleBackendLoss() {
  const parent = activeBuyerLogWindow();
  if (quitting || !parent || parent.isDestroyed()) return;
  dialog.showMessageBox(parent, {
    type: 'error',
    title: 'Buyer Log',
    message: 'Buyer Log sunucusu durdu.',
    detail: 'Sunucu beklenmedik şekilde kapandı ve kendiliğinden toparlanamadı. '
      + 'Kaydedilmemiş ekran değişiklikleri gönderilemeyebilir.\n\nGünlük: '
      + path.join(paths.logsRoot, 'backend.log'),
    buttons: ['Yeniden Başlat', 'Kapat'],
    defaultId: 0,
    cancelId: 1,
    noLink: true,
  }).then(async result => {
    if (result.response !== 0) return;
    restarting = true;
    try {
      if (backend) { try { await backend.stop(); } catch (_) {} backend = null; }
      if (workspace) { workspace.destroyAllWindows(); workspace = null; }
      else if (mainWindow && !mainWindow.isDestroyed()) mainWindow.destroy();
      mainWindow = null;
      await startBuyerLog();
    } finally { restarting = false; }
  }).catch(error => log('Sunucu kaybı iletişim kutusu gösterilemedi: ' + error.message));
}

/* ------------------------------------------------------------ başlatma akışı */

async function startBuyerLog(options = {}) {
  lastStartedAt = Date.now();
  showSplash();
  setSplashStep('data');
  try {
    ensureDataTree(paths);
  } catch (error) {
    showStartupError({
      message: 'Veri klasörü oluşturulamadı.',
      detail: paths.dataRoot + '\n' + error.message,
      hint: 'Buyer Log klasörünü YAZILABİLİR bir yere taşıyın (örn. C:\\BuyerLog). Program Files ve salt okunur ağ klasörleri çalışmaz.',
    });
    return false;
  }

  const migration = await runFirstRunMigration({ paths, appCoreRoot: APP_CORE_ROOT, log });
  if (migration.state === 'failed') {
    showStartupError({
      message: 'Eski Buyer Log verisi taşınamadı.',
      detail: (migration.detail && migration.detail.reason) || 'Bilinmeyen taşıma hatası.',
      hint: 'ESKİ KURULUMUNUZA DOKUNULMADI; olduğu gibi çalışmaya devam ediyor. '
        + 'Yarım kalan kopya data\\.staging klasöründe bekletiliyor ve silinmedi. '
        + 'Tekrar Dene ile yeniden deneyebilir, Teşhis ile ayrıntıyı görebilirsiniz.',
      migration: migration.detail,
    });
    return false;
  }

  /*
   * Taşıma yalnız bir kez çalışır; klasör `data/` ile kopyalanırsa atlanır ve
   * eski bilgisayara ait mutlak localDbPath geride kalır. Bu, her açılışta
   * çalışan emniyet ağıdır — yalnız dış yol MEVCUT DEĞİLKEN düzeltir, yani
   * hiçbir koşulda var olan veriden uzaklaşmaz.
   */
  try { healPortableSettings(paths, log); }
  catch (error) { log('UYARI: ayar onarımı atlandı: ' + error.message); }

  /*
   * Portu başkası tutuyorsa SESSİZCE ONA BAĞLANMA (bkz. backend.js →
   * probeOrigin). Bu kontrol sunucu başlatılmadan önce yapılır.
   */
  const address = resolveAppUrl(readJson(paths.configPath, {}));
  const probe = await probeOrigin(address.origin);
  if (probe.occupied) {
    showStartupError({
      message: 'Bu bilgisayarda Buyer Log zaten çalışıyor.',
      detail: address.origin + ' adresini başka bir Buyer Log kopyası kullanıyor (HTTP ' + probe.status + ').',
      hint: 'Masaüstü sürümü, kendi verisi yerine o kopyanın verisini göstermemek için açılmadı. '
        + 'Çalışan kopyayı buradan kapatabilirsiniz; kapanınca Buyer Log kendiliğinden açılır.',
      kind: 'port-occupied',
      origin: address.origin,
      port: address.port,
    });
    return false;
  }

  const desktopOabRelayUrl = await startOabRelay();
  backend = new BackendProcess({
    paths,
    appCoreRoot: APP_CORE_ROOT,
    desktopBridgeSecret,
    desktopOabRelayUrl,
    desktopAuthRelayUrl: desktopOabRelayUrl,
    downloadsRoot: app.getPath('downloads'),
    log,
    // A busy first-start sync can delay HTTP responses beyond the immutable
    // launcher's 60s trial window even after the server and local DB are ready.
    // The child process itself reports both milestones via stdout; confirm the
    // same existing health token immediately, while retaining HTTP/renderer
    // completion as fallbacks and launcher rollback for genuine failures.
    onStartupReady: () => {
      log('Backend server and local DB ready (startup milestones).');
      confirmLauncherHealth();
      setSplashStep('finish');
    },
    onStartupProgress: marker => {
      if (marker === 'LOCAL_DB_CONFIG_PATH') setSplashStep('database');
    },
    onUnexpectedExit: info => {
      if (quitting) return;
      log('Backend beklenmedik şekilde kapandı: ' + JSON.stringify(info));
      handleBackendLoss();
    },
  });

  let bound;
  setSplashStep('server');
  try {
    bound = backend.start();
  } catch (error) {
    showStartupError({
      message: 'Buyer Log sunucusu başlatılamadı.',
      detail: error.message,
      hint: error && error.code === 'BACKEND_DEPENDENCIES_MISSING'
        ? 'Bu klasör GitHub kaynak kodundan (Code → Download ZIP) oluşturulmuş görünüyor; kaynak kod çalıştırılabilir paket değildir. '
          + 'GitHub Releases sayfasındaki BuyerLog-Kurulum-<sürüm>.zip dosyasını indirip boş bir klasöre çıkarın ve oradaki BuyerLog.exe\'yi çalıştırın. '
          + 'Başka bir kullanıcının Buyer Log klasörünü kopyalamayın.'
        : 'Paket eksik kopyalanmış olabilir. Klasörün tamamını yeniden çıkarın.',
    });
    return false;
  }

  log('Sunucunun hazır olması bekleniyor: ' + bound.origin);
  const ready = await backend.waitUntilReady();
  if (!ready.ready) {
    const exit = backend.lastExit;
    showStartupError({
      message: 'Buyer Log sunucusu yanıt vermedi.',
      detail: 'Adres: ' + bound.origin
        + (exit ? '\nSunucu çıkış kodu: ' + exit.code + (exit.signal ? ' / ' + exit.signal : '') : '\nZaman aşımı.'),
      hint: 'Ayrıntılı sunucu günlüğü: ' + path.join(paths.logsRoot, 'backend.log')
        + '\nBaşka bir Buyer Log kopyası ' + address.port + ' portunu kullanıyor olabilir.',
    });
    await backend.stop();
    backend = null;
    return false;
  }

  log('Sunucu hazır (HTTP ' + ready.status + '). Pencere açılıyor.');
  /* The bootstrap launcher rolls a trial version back after a fixed 60 s.
   * On the first launch of a freshly extracted version the backend alone can
   * take ~45 s (field log 7.0.259: ready at +56 s, first tab at +61 s → rolled
   * back). The new core is already proven here — main.js loaded and its own
   * backend answers HTTP — so health is confirmed now instead of after the
   * first tab finishes loading. The renderer hook below stays as a fallback. */
  confirmLauncherHealth();
  // Kurulum onarımı sunucuyla paralel yürüdü; pencere onun bitmesini bekler
  // (yeni sürümde eski service worker'ın sayfayı karşılamaması için).
  if (options.beforeWindow) { try { await options.beforeWindow; } catch (_) {} }
  closeErrorWindow();
  setSplashStep('screens');
  createMainWindow(bound.origin);
  return true;
}

/* --------------------------------------------------------------- kapanış */

async function shutdown() {
  log('Buyer Log kapatılıyor.');
  if (updateStartupTimer) { clearTimeout(updateStartupTimer); updateStartupTimer = null; }
  if (updateSignInTimer) { clearInterval(updateSignInTimer); updateSignInTimer = null; }
  if (updatePeriodicTimer) { clearInterval(updatePeriodicTimer); updatePeriodicTimer = null; }
  if (uiLanguageTimer) { clearInterval(uiLanguageTimer); uiLanguageTimer = null; }
  try { saveWindowState(); } catch (_) {}
  await rememberUiLanguage();
  // Backend Authorization is process memory and may be cleared. The dedicated
  // OAB browser partition is deliberately preserved across normal restarts.
  try { await clearOabBackendAuthorization(); } catch (_) {}
  if (backend) {
    try { await backend.stop(); } catch (error) { log('Backend durdurulurken hata: ' + error.message); }
    backend = null;
  }
  log('Kapanış tamamlandı.');
  await new Promise(resolve => {
    if (!logStream) { resolve(); return; }
    logStream.end(resolve);
    logStream = null;
  });
}

/* ------------------------------------------------------------------- IPC */

function diagnostics() {
  const address = resolveAppUrl(readJson(paths.configPath, {}));
  const migration = readMigrationState(paths);
  let dbBytes = 0;
  try { dbBytes = fs.statSync(paths.localDbPath).size; } catch (_) { dbBytes = 0; }
  let electronProcesses = [];
  try {
    electronProcesses = app.getAppMetrics().map(metric => ({
      pid: Number(metric && metric.pid) || 0,
      type: String(metric && metric.type || 'Unknown'),
      cpuPercent: Number(metric && metric.cpu && metric.cpu.percentCPUUsage) || 0,
      idleWakeupsPerSecond: Number(metric && metric.cpu && metric.cpu.idleWakeupsPerSecond) || 0,
      memoryWorkingSetKb: Number(metric && metric.memory && metric.memory.workingSetSize) || 0,
      memoryPeakWorkingSetKb: Number(metric && metric.memory && metric.memory.peakWorkingSetSize) || 0,
      memoryPrivateKb: Number(metric && metric.memory && metric.memory.privateBytes) || 0,
    }));
  } catch (_) {
    electronProcesses = [];
  }
  return {
    /* Kimlik bilgisi, oturum anahtarı veya token BURAYA KOYULMAZ. */
    buyerLogVersion: appVersion(),
    electron: process.versions.electron,
    chromium: process.versions.chrome,
    node: process.versions.node,
    platform: process.platform + ' ' + process.arch,
    portableRoot: paths.portableRoot,
    dataRoot: paths.dataRoot,
    appCoreRoot: APP_CORE_ROOT,
    configPath: paths.configPath,
    backendRunning: Boolean(backend && backend.running),
    backendPid: backend ? backend.pid : 0,
    backendOrigin: backend && backend.origin ? backend.origin : address.origin,
    backendPort: backend && backend.port ? backend.port : address.port,
    localDbPath: paths.localDbPath,
    localDbBytes: dbBytes,
    logsRoot: paths.logsRoot,
    desktopLog: paths.desktopLogPath,
    backendLog: path.join(paths.logsRoot, 'backend.log'),
    migrationVersion: migration ? migration.schemaVersion : null,
    migrationState: migration ? migration.state : 'not-run',
    migrationReason: migration ? (migration.reason || '') : '',
    startupFailure: startupFailure ? {
      message: startupFailure.message, detail: startupFailure.detail, hint: startupFailure.hint,
      kind: startupFailure.kind || '',
    } : null,
    uptimeSeconds: lastStartedAt ? Math.round((Date.now() - lastStartedAt) / 1000) : 0,
    electronProcesses,
    workspace: workspace && typeof workspace.diagnosticsSnapshot === 'function'
      ? workspace.diagnosticsSnapshot()
      : null,
    updater: updater ? updater.status(updaterBaseConfig()) : null,
    activeAppCoreRoot: APP_CORE_ROOT,
    bootstrapAppCoreRoot: String(process.env.BUYER_LOG_BOOTSTRAP_APP_CORE || ''),
  };
}

// Küçük belge data: URL ile açılır (Chromium ~2 MB sınırı); model görselleri
// gömülü büyük belge geçici dosyadan açılır. Her iki yolda da ağ kapalıdır.
const AI_PDF_DATA_URL_MAX_BYTES = 1400 * 1024;
const AI_PDF_HTML_MAX_BYTES = 60 * 1024 * 1024;
let aiPdfAllowedFileUrl = '';
function withDeadline(promise, ms, label) {
  let timer = null;
  return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label}-timeout`)), ms); })]).finally(() => clearTimeout(timer));
}
// Tek, kalıcı olmayan (bellek içi) oturum: her basımda yeni oturum açıp
// sızdırmak yerine aynı kilitli oturum yeniden kullanılır.
const AI_PDF_PARTITION = 'buyerlog-ai-pdf';
let aiPdfSessionReady = false;
let aiPdfQueue = Promise.resolve();
function aiPdfSession() {
  const pdfSession = session.fromPartition(AI_PDF_PARTITION, { cache: false });
  if (!aiPdfSessionReady) {
    // Yalnız data:/about: ve o anki basımın kendi geçici dosyası; başka hiçbir
    // dosya veya ağ isteği yüklenmez.
    pdfSession.webRequest.onBeforeRequest((details, callback) => {
      const url = String(details.url || '');
      callback({ cancel: !(/^(data|about):/i.test(url) || (aiPdfAllowedFileUrl && url === aiPdfAllowedFileUrl)) });
    });
    pdfSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    aiPdfSessionReady = true;
  }
  return pdfSession;
}
// Basımlar sıraya alınır: aynı anda en fazla bir gizli PDF penceresi.
function renderAiPdf(html, options) {
  const run = aiPdfQueue.then(() => renderAiPdfNow(html, options));
  aiPdfQueue = run.catch(() => {});
  return run;
}
async function renderAiPdfNow(html, { landscape = false, footer = true } = {}) {
  aiPdfSession();
  let tempFile = '';
  const partition = AI_PDF_PARTITION;
  const win = new BrowserWindow({
    show: false, width: 1123, height: 794,
    webPreferences: { javascript: false, sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true, partition, spellcheck: false, navigateOnDragDrop: false, devTools: false },
  });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', navigation => navigation.preventDefault());
  try {
    const bytes = Buffer.from(html, 'utf8');
    if (bytes.length <= AI_PDF_DATA_URL_MAX_BYTES) {
      await withDeadline(win.loadURL(`data:text/html;charset=utf-8;base64,${bytes.toString('base64')}`), 30000, 'load');
    } else {
      tempFile = path.join(app.getPath('temp'), `buyerlog-ai-pdf-${crypto.randomBytes(8).toString('hex')}.html`);
      fs.writeFileSync(tempFile, bytes, { mode: 0o600 });
      aiPdfAllowedFileUrl = require('url').pathToFileURL(tempFile).href;
      await withDeadline(win.loadURL(aiPdfAllowedFileUrl), 60000, 'load');
    }
    return await withDeadline(win.webContents.printToPDF({
      printBackground: true, preferCSSPageSize: true, landscape,
      // Smart Layout Studio pages carry their own footer and page number; a second one would overlap it.
      displayHeaderFooter: footer,
      headerTemplate: '<span></span>',
      footerTemplate: '<div style="font-size:8px;width:100%;padding:0 12mm;color:#7a7a7d;display:flex;justify-content:space-between;font-family:Segoe UI,Arial,sans-serif"><span>Buyer Log · LCW AI</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>',
    }), 60000, 'print');
  } finally {
    if (!win.isDestroyed()) win.destroy();
    aiPdfAllowedFileUrl = '';
    if (tempFile) { try { fs.unlinkSync(tempFile); } catch (_) {} }
  }
}

function trustedBuyerLogIpcSender(event) {
  if (!event || !event.sender || event.sender.isDestroyed()) return false;
  if (workspace && !workspace.tabForContents(event.sender)) return false;
  if (!workspace && (!mainWindow || mainWindow.isDestroyed() || event.sender !== mainWindow.webContents)) return false;
  try {
    const source = new URL(String(event.senderFrame && event.senderFrame.url || event.sender.getURL() || ''));
    const expected = new URL(String(backend && backend.origin || resolveAppUrl(readJson(paths.configPath, {})).origin));
    return source.origin === expected.origin;
  } catch (_) { return false; }
}

/*
 * Başlatma hatası ekranı (file://startup-error.html) uygulama origin'inde değildir
 * ama teşhis/yeniden dene/çıkış uçlarını kullanır. Bu uçlar yalnız o pencereden
 * ya da güvenilen Buyer Log renderer'ından çağrılabilir; başka bir webContents
 * (SSO pencereleri, dış sayfalar) bu kanallara erişemez.
 */
function trustedDesktopShellSender(event) {
  if (trustedBuyerLogIpcSender(event)) return true;
  if (!event || !event.sender || event.sender.isDestroyed()) return false;
  if (!errorWindow || errorWindow.isDestroyed() || event.sender !== errorWindow.webContents) return false;
  try {
    const source = new URL(String(event.senderFrame && event.senderFrame.url || event.sender.getURL() || ''));
    return source.protocol === 'file:' && path.basename(decodeURIComponent(source.pathname)) === 'startup-error.html';
  } catch (_) { return false; }
}

/* GPU durumu. VDI/RDP ve bazı kurumsal sürücülerde Chromium yazılım çizimine
 * düşer; o zaman bulanık arka plan ve hücre dalgası işlemciye yük olur. Durum
 * teşhis için günlüğe yazılır ve arayüze yalnız "yazılım çizimi mi" bilgisi verilir. */
function softwareCompositing() {
  try { return !String((app.getGPUFeatureStatus() || {}).gpu_compositing || '').startsWith('enabled'); }
  catch (_) { return false; }
}
function logGpuStatus(reason) {
  try { log('GPU durumu (' + reason + '): ' + JSON.stringify(app.getGPUFeatureStatus())); }
  catch (error) { log('GPU durumu okunamadı: ' + error.message); }
}
/* 7.0.323 teşhisi. "ready" anındaki durum GPU süreci başlamadan okunabildiği için
 * yazılım çiziminin GERÇEK nedenini göstermez. Electron 44 ANGLE'ı electron.exe
 * içine statik bağlar; libEGL.dll/libGLESv2.dll resmi pakette yoktur ve eksikliği
 * neden değildir. Neden (sürücü kara listesi, RDP/VDI, GPU süreci çökmesi) ilk
 * pencere göründükten sonra ölçülen durum + GPU kimlik özeti ile ayrılır.
 * Yalnız donanım/sürücü kimliği yazılır; kullanıcı veya makine adı yazılmaz. */
function gpuInfoSummary(info) {
  const source = info && typeof info === 'object' ? info : {};
  const devices = Array.isArray(source.gpuDevice) ? source.gpuDevice : [];
  const aux = source.auxAttributes && typeof source.auxAttributes === 'object' ? source.auxAttributes : {};
  const pick = (object, keys) => {
    const out = {};
    for (const key of keys) if (object && object[key] != null && typeof object[key] !== 'object') out[key] = object[key];
    return out;
  };
  return {
    devices: devices.slice(0, 4).map(device => pick(device, ['active', 'vendorId', 'deviceId', 'driverVendor', 'driverVersion'])),
    aux: pick(aux, ['glImplementationParts', 'displayType', 'inProcessGpu', 'sandboxed', 'canSupportThreadedTextureMailbox', 'passthroughCmdDecoder']),
  };
}
function logGpuDiagnostics(reason) {
  logGpuStatus(reason);
  try {
    Promise.resolve(app.getGPUInfo('basic'))
      .then(info => log('GPU bilgisi (' + reason + '): ' + JSON.stringify(gpuInfoSummary(info))))
      .catch(error => log('GPU bilgisi okunamadı: ' + (error && error.message)));
  } catch (error) { log('GPU bilgisi okunamadı: ' + error.message); }
}
const GPU_DIAGNOSTIC_DELAY_MS = 5000;
let gpuInfoUpdateLogged = false;

function registerIpc() {
  // Argümansız, salt okunur: arayüz yalnız yazılım çizimi bilgisini alır.
  ipcMain.handle('buyerlog:render-profile', event => {
    if (!trustedBuyerLogIpcSender(event)) return null;
    return { softwareCompositing: softwareCompositing() };
  });
  /*
   * Motion+ tema geçişi: renderer kendi görünür sayfasının tek karelik
   * görüntüsünü ister (toz/üçgen efektleri eski temayı parçalara ayırır).
   * Yalnız çağıranın KENDİ webContents'i yakalanır ve CSS piksel boyutuna
   * küçültülmüş ham BGRA baytları yalnız ona döner; diske, log'a veya başka
   * bir sürece yazılmaz. Renderer'ın zaten gördüğü içerikten fazlası açılmaz.
   */
  ipcMain.handle('buyerlog:capture-view', async (event, payload = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return null;
    const width = Math.round(Number(payload && payload.width) || 0), height = Math.round(Number(payload && payload.height) || 0);
    if (!(width > 0 && height > 0 && width <= 8192 && height <= 8192)) return null;
    try {
      let image = await event.sender.capturePage();
      if (image.isEmpty()) return null;
      const size = image.getSize();
      if (size.width !== width || size.height !== height) image = image.resize({ width, height, quality:'good' });
      const out = image.getSize();
      return { width: out.width, height: out.height, bgra: image.toBitmap() };
    } catch (_) { return null; }
  });
  const startupTransition=require('./startup-transition').createStartupTransition();
  ipcMain.handle('buyerlog:startup-transition', (event,payload={}) => {
    if (!trustedBuyerLogIpcSender(event)) return null;
    if(payload.action==='take')return startupTransition.take(event.sender);
    // Only the sign-in document may stage a frame for the next document.
    if(payload.action!=='prepare'||softwareCompositing())return false;
    let pathname='';try{pathname=new URL(event.sender.getURL()).pathname;}catch(_){}
    if(pathname!=='/select-user.html')return false;
    return startupTransition.prepare(event.sender,Math.round(Number(payload.width)||0),Math.round(Number(payload.height)||0));
  });
  ipcMain.handle('buyerlog:workspace-snapshot', event => {
    if (!workspace || !workspace.windowForShellContents(event.sender)) return null;
    return workspace.shellSnapshot(event);
  });
  ipcMain.handle('buyerlog:workspace-show-module-menu', event => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    if (!state) return false;
    const openModules = new Set(workspace.snapshot(state).tabs.map(tab => tab.module));
    const template = Object.entries(workspace.MODULES).map(([moduleId, labels]) => ({
      label: labels.tr,
      type: 'checkbox',
      checked: openModules.has(moduleId),
      click: () => workspace.openModule(state.window.id, moduleId),
    }));
    Menu.buildFromTemplate(template).popup({ window:state.window });
    return true;
  });
  ipcMain.handle('buyerlog:workspace-activate', (event, tabId) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    return Boolean(state && workspace.activateTab(state.window.id, tabId));
  });
  ipcMain.handle('buyerlog:workspace-open-module', (event, moduleId) => {
    if (!workspace || !trustedBuyerLogIpcSender(event)) return null;
    const shellState = workspace.windowForShellContents(event.sender);
    const contentWindow = workspace.windowForContents(event.sender);
    const targetState = shellState || (contentWindow ? workspace.stateForWindow(contentWindow.id) : null);
    if (!targetState || !targetState.window || targetState.window.isDestroyed()) return null;
    const tab = workspace.openModule(targetState.window.id, moduleId, { forceNew:true });
    return tab ? { ok:true, tabId:tab.id, module:tab.module } : null;
  });
  ipcMain.handle('buyerlog:workspace-show-module-context-menu', (event, payload = {}) => {
    if (!workspace || !trustedBuyerLogIpcSender(event)) return false;
    const contentWindow = workspace.windowForContents(event.sender);
    const targetState = contentWindow ? workspace.stateForWindow(contentWindow.id) : null;
    if (!targetState || !targetState.window || targetState.window.isDestroyed()) return false;
    const moduleId = String(payload.moduleId || '');
    const language = String(payload.language || '').toLowerCase() === 'en' ? 'en' : 'tr';
    const template = [{
      label: language === 'en' ? 'Open in new tab' : 'Yeni sekmede aç',
      click: () => workspace.openModule(targetState.window.id, moduleId, { forceNew:true }),
    }];
    Menu.buildFromTemplate(template).popup({ window:targetState.window });
    return true;
  });
  ipcMain.handle('buyerlog:workspace-set-module', (event, moduleId) => {
    if (!workspace || !trustedBuyerLogIpcSender(event)) return false;
    return workspace.updateTabModule(event.sender, moduleId);
  });
  ipcMain.handle('buyerlog:workspace-theme', (event, theme) => {
    if (!workspace || !trustedBuyerLogIpcSender(event)) return false;
    return workspace.setTheme(theme);
  });
  ipcMain.handle('buyerlog:workspace-move-tab', (event, payload = {}) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    return Boolean(state && workspace.moveTab(payload.tabId, state.window.id, payload.index));
  });
  ipcMain.handle('buyerlog:workspace-receive-tab', (event, payload = {}) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    return Boolean(state && workspace.moveTab(payload.tabId, state.window.id, payload.index));
  });
  ipcMain.handle('buyerlog:workspace-detach-tab', (event, payload = {}) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    if (!state || state.window.id !== Number(payload.sourceWindowId)) return false;
    return workspace.detachTab(payload.tabId, state.window.id, payload.point || {});
  });
  ipcMain.handle('buyerlog:workspace-finish-tab-drag', (event, payload = {}) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    if (!state || state.window.id !== Number(payload.sourceWindowId)) return false;
    return workspace.finishTabDrag(payload.tabId, state.window.id, payload.point || {});
  });
  ipcMain.handle('buyerlog:workspace-reattach-tab', (event, payload = {}) => {
    const state = workspace && workspace.windowForShellContents(event.sender);
    if (!state || state.window.id !== Number(payload.sourceWindowId)) return false;
    return workspace.reattachTab(payload.tabId, state.window.id);
  });
  ipcMain.handle('buyerlog:workspace-close-tab', async (event, tabId) => {
    const activeWorkspace = workspace;
    const state = activeWorkspace && activeWorkspace.windowForShellContents(event.sender);
    const requested = state && state.tabs.includes(String(tabId || ''));
    return Boolean(requested && await activeWorkspace.closeTab(tabId));
  });

  ipcMain.handle('buyerlog:diagnostics', event => trustedDesktopShellSender(event) ? diagnostics() : { ok:false, code:'IPC_FORBIDDEN' });
  ipcMain.handle('buyerlog:startup-failure', event => trustedDesktopShellSender(event) ? startupFailure : null);
  ipcMain.handle('buyerlog:open-logs', event => {
    if (!trustedDesktopShellSender(event)) return false;
    shell.openPath(paths.logsRoot);
    return true;
  });
  /*
   * "Çalışan Kopyayı Kapat" — hata ekranındaki düğme.
   *
   * Doğrulama ve sonlandırma electron/port-owner.js'te; oradaki kural şudur:
   * yalnız portu GERÇEKTEN tutan, görüntü adı bilinen ve Buyer Log gibi cevap
   * veren süreç kapatılır. Doğrulanamayan hiçbir şeye dokunulmaz.
   *
   * Kapanma başarılıysa açılış kendiliğinden yeniden denenir: kullanıcıdan
   * ikinci bir tıklama beklemek, çözülmüş bir sorunu çözülmemiş göstermek olur.
   */
  ipcMain.handle('buyerlog:inspect-port', async event => {
    if (!trustedDesktopShellSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const address = resolveAppUrl(readJson(paths.configPath, {}));
    return inspectPortOwner(address.origin, address.port);
  });

  ipcMain.handle('buyerlog:close-other', async event => {
    if (!trustedDesktopShellSender(event)) return { ok:false, code:'IPC_FORBIDDEN', started:false };
    const address = resolveAppUrl(readJson(paths.configPath, {}));
    const result = await closePortOwner(address.origin, address.port, log);
    if (!result.ok) return { ...result, started: false };
    restarting = true;
    try {
      closeErrorWindow();
      const started = await startBuyerLog();
      return { ...result, started };
    } finally { restarting = false; }
  });

  ipcMain.handle('buyerlog:retry', async event => {
    if (!trustedDesktopShellSender(event)) return false;
    restarting = true;
    try {
      if (backend) { try { await backend.stop(); } catch (_) {} backend = null; }
      closeErrorWindow();
      return await startBuyerLog();
    } finally { restarting = false; }
  });
  ipcMain.handle('buyerlog:quit', event => { if (!trustedDesktopShellSender(event)) return false; app.quit(); return true; });

  ipcMain.handle('buyerlog:update-status', async (event, payload = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    return { ok:true, ...(await updateStatusFor(String(payload.userId || ''))) };
  });
  ipcMain.handle('buyerlog:update-check', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    try {
      return await runUpdateCheck({ manual:true, userId:String(options.userId || '') });
    } catch (error) {
      return { ok:false, code:error && error.code || 'UPDATE_CHECK_FAILED', error:'Güncelleme kaynağına şu anda ulaşılamıyor. Buyer Log mevcut sürümle çalışmaya devam edecek.', detail:String(error && error.message || '').slice(0,300), ...(await updateStatusFor(String(options.userId || ''))) };
    }
  });
  ipcMain.handle('buyerlog:update-configure', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const userId=String(options.userId || '');
    if (!(await verifyUpdateModerator(userId))) return { ok:false, code:'UPDATE_ADMIN_REQUIRED', error:'Bu ayar yalnız moderator tarafından değiştirilebilir.' };
    try {
      const patch={};
      if(Object.prototype.hasOwnProperty.call(options,'enabled'))patch.enabled=options.enabled!==false;
      if(Object.prototype.hasOwnProperty.call(options,'releaseSource'))patch.releaseSource=String(options.releaseSource || '');
      if(Object.prototype.hasOwnProperty.call(options,'channel'))patch.channel=String(options.channel || 'stable');
      const config=updater.configure(patch,updaterBaseConfig());
      scheduleUpdateChecks();
      emitUpdateStatus(await updateStatusFor(userId));
      return {ok:true,config,...(await updateStatusFor(userId))};
    } catch (error) { return {ok:false,code:error && error.code || 'UPDATE_CONFIG_FAILED',error:String(error && error.message || error)}; }
  });
  ipcMain.handle('buyerlog:update-choose-source', async (event, payload = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const userId=String(payload.userId || '');
    if (!(await verifyUpdateModerator(userId))) return { ok:false, code:'UPDATE_ADMIN_REQUIRED' };
    const result=await dialog.showOpenDialog(activeBuyerLogWindow(event.sender),{title:'Buyer Log release klasörünü seçin',properties:['openDirectory']});
    if(result.canceled||!Array.isArray(result.filePaths)||!result.filePaths[0])return {ok:false,cancelled:true};
    return {ok:true,path:path.resolve(String(result.filePaths[0]))};
  });
  ipcMain.handle('buyerlog:update-retry', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const userId=String(options.userId || '');
    if (!(await verifyUpdateModerator(userId))) return {ok:false,code:'UPDATE_ADMIN_REQUIRED'};
    try {
      const state=updater?.state(),version=String(options.version || state?.latestVersion || ''),failed=state?.failedVersions?.[version];
      if(!version||!failed||!/^[a-f0-9]{64}$/.test(String(failed.sha256||'')))return {ok:false,code:'UPDATE_RETRY_TARGET_CHANGED'};
      const channel=await effectiveUpdateChannel(userId);
      if(options.channel&&options.channel!==channel)return {ok:false,code:'UPDATE_RETRY_TARGET_CHANGED'};
      return await runUpdateCheck({manual:true,retryFailed:true,retryVersion:version,retrySha256:failed.sha256,retryChannel:channel,userId});
    } catch(error){return {ok:false,code:error && error.code || 'UPDATE_RETRY_FAILED',error:String(error && error.message || error)};}
  });
  ipcMain.handle('buyerlog:update-restart', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    if(!updater||!updater.state().pending||!updater.state().pending.ready)return {ok:false,code:'UPDATE_NOT_READY'};
    updateRelaunchRequested=true;
    /* BrowserWindow.close() deliberately uses the existing beforeunload/dirty-state
       protection. If renderer vetoes the close, the flag is cleared below. */
    if(workspace&&workspace.hasWindows())workspace.closeAllWindows();
    else if(mainWindow&&!mainWindow.isDestroyed())mainWindow.close();
    else app.quit();
    setTimeout(()=>{if(workspace&&workspace.hasWindows())updateRelaunchRequested=false;},1500).unref?.();
    return {ok:true};
  });

  ipcMain.handle('buyerlog:update-signed-patch', async (event,options={})=>{
    if(!trustedBuyerLogIpcSender(event))return {ok:false,code:'IPC_FORBIDDEN'};
    const userId=String(options.userId||''),authorize=()=>verifyUpdateModerator(userId,event.sender);
    if(!await authorize())return {ok:false,code:'UPDATE_ADMIN_REQUIRED'};
    if(!updater||typeof global.__buyerLogPrepareSignedPatch!=='function')return {ok:false,code:'PATCH_BOOTSTRAP_REQUIRED',error:'Güncel imzalı tam kurulum gerekli. / A current signed full installation is required.'};
    try{
      const result=await updater.prepareSignedPatch(()=>global.__buyerLogPrepareSignedPatch({window:activeBuyerLogWindow(event.sender),language:options.language==='en'?'en':'tr',authorize}));
      const status=await updateStatusFor(userId);emitUpdateStatus(status);return {...result,...status};
    }catch(error){return {ok:false,code:error.code||'PATCH_FAILED',error:String(error.message||error)};}
  });

  ipcMain.handle('buyerlog:choose-shared-hub-folder', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const result = await dialog.showOpenDialog(activeBuyerLogWindow(event.sender), {
      title: 'Buyer Log Shared Hub klasörünü seçin',
      properties: ['openDirectory', 'createDirectory'],
    });
    if (result.canceled || !Array.isArray(result.filePaths) || !result.filePaths[0]) return { ok:false, cancelled:true };
    return { ok:true, path:String(result.filePaths[0]) };
  });
  ipcMain.handle('buyerlog:choose-database-workbook', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'IPC_FORBIDDEN' };
    const result = await dialog.showOpenDialog(activeBuyerLogWindow(event.sender), {
      title: 'Database bağlantı bilgisini içeren Excel dosyasını seçin',
      properties: ['openFile'],
      filters: [{ name: 'Excel Workbooks', extensions: ['xlsx', 'xlsm'] }],
    });
    if (result.canceled || !Array.isArray(result.filePaths) || !result.filePaths[0]) return { ok:false, cancelled:true };
    const selectedPath = path.resolve(String(result.filePaths[0]));
    const proofPayload = selectedPath.toLowerCase();
    const proof = crypto.createHmac('sha256', desktopBridgeSecret).update(proofPayload, 'utf8').digest('hex');
    return { ok:true, path:selectedPath, name:path.basename(selectedPath), proof };
  });

  /* CoreNectum automatic SSO. The raw Bearer never crosses IPC: Electron main
     captures it and writes it straight to the local backend through the
     per-process loopback bridge. Renderer receives only success/error state. */
  ipcMain.handle('buyerlog:corenectum-auth', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'CORENECTUM_IPC_FORBIDDEN', error:'CoreNectum yetkilendirme isteği reddedildi.' };
    try { return await acquireCoreNectumToken({ interactive: options && options.interactive !== false, requestingContents:event.sender }); }
    catch (error) { return { ok:false, code:error && error.code || 'CORENECTUM_AUTH_FAILED', error:error && error.message || String(error) }; }
  });
  ipcMain.handle('buyerlog:corenectum-auth-clear', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'CORENECTUM_IPC_FORBIDDEN' };
    try { return await clearCoreNectumAuthSession(); }
    catch (error) { return { ok:false, code:'CORENECTUM_AUTH_CLEAR_FAILED', error:error && error.message || String(error) }; }
  });

  /* LCW AI arka plan oturumu: yanıt yalnız durum kodudur, token dönmez. */
  ipcMain.handle('buyerlog:lcwai-auth', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'LCWAI_IPC_FORBIDDEN' };
    try { return await acquireLcwAiToken({ interactive: options && options.interactive !== false, requestingContents:event.sender }); }
    catch (_) { return { ok:false, code:'LCWAI_AUTH_FAILED' }; }
  });
  ipcMain.handle('buyerlog:lcwai-auth-clear', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'LCWAI_IPC_FORBIDDEN' };
    try { return await clearLcwAiAuthSession(); }
    catch (_) { return { ok:false, code:'LCWAI_AUTH_CLEAR_FAILED' }; }
  });

  /* OAB SSO is independent from CoreNectum. Only the trusted Buyer Log renderer
     may request the flow; the external OAB/Microsoft pages have no preload and
     therefore cannot invoke these channels. Raw Authorization never crosses IPC. */
  ipcMain.handle('buyerlog:oab-auth', async (event, options = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, authenticated:false, code:'OAB_IPC_FORBIDDEN', error:'OAB yetkilendirme isteği reddedildi.' };
    try {
      return await acquireOabAuthorization({
        interactive:options && options.interactive !== false,
        forceFresh:options && options.forceFresh === true,
        seasonRef:options && options.seasonRef,
        merchSubGroupRef:options && options.merchSubGroupRef,
        buyerGroupRef:options && options.buyerGroupRef,
        requestingContents:event.sender,
      });
    }
    catch (error) { return { ok:false, authenticated:false, code:error && error.code || 'OAB_AUTH_FAILED', error:'OAB yetkilendirmesi başarısız oldu.' }; }
  });
  ipcMain.handle('buyerlog:oab-auth-clear', async event => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, code:'OAB_IPC_FORBIDDEN' };
    try { return await clearOabAuthSession(); }
    catch (_) { return { ok:false, code:'OAB_AUTH_CLEAR_FAILED', error:'OAB oturumu temizlenemedi.' }; }
  });

  /*
   * "Dosya hazır" bildirim kartının Aç/Klasörde Göster aksiyonları. Argüman
   * yalnız registerDownload'ın ürettiği opak bir token'dır — renderer'dan asla
   * ham bir dosya yolu alınmaz/çalıştırılmaz. Token bilinmiyorsa (uygulama
   * yeniden başladı, kayıt sınırdan düştü) ya da dosya o andan beri
   * silinmiş/taşınmışsa çökmeden kontrollü bir hata döner.
   */
  ipcMain.handle('buyerlog:open-download', (event, token) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, error:'forbidden' };
    const entry = downloadRegistry.get(String(token || ''));
    if (!entry || !fs.existsSync(entry.path)) return { ok: false, error: 'not-found' };
    const error = shell.openPath(entry.path);
    return error ? { ok: false, error } : { ok: true };
  });
  ipcMain.handle('buyerlog:reveal-download', (event, token) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, error:'forbidden' };
    const entry = downloadRegistry.get(String(token || ''));
    if (!entry || !fs.existsSync(entry.path)) return { ok: false, error: 'not-found' };
    shell.showItemInFolder(entry.path);
    return { ok: true };
  });
  ipcMain.handle('buyerlog:open-generated-download', async (event, fileName) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, error:'forbidden' };
    const full = generatedDownloadPath(fileName);
    if (!full) return { ok:false, error:'not-found' };
    const error = await shell.openPath(full);
    return error ? { ok:false, error } : { ok:true };
  });
  ipcMain.handle('buyerlog:reveal-generated-download', (event, fileName) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, error:'forbidden' };
    const full = generatedDownloadPath(fileName);
    if (!full) return { ok:false, error:'not-found' };
    shell.showItemInFolder(full);
    return { ok:true };
  });
  /*
   * LCW AI Export Engine → PDF. Renderer, sunucunun temizleyip katı CSP ile
   * sardığı rapor HTML'ini verir; burada JavaScript'i KAPALI, ağı ENGELLİ
   * (yalnız data:/about:), izinleri reddedilen, kalıcı olmayan bir oturumdaki
   * GİZLİ pencerede açılır ve Chromium printToPDF ile basılır. Dönen yalnız
   * PDF baytlarıdır: dosya sistemi yetkisi verilmez, kaydı Buyer Log
   * sunucusu (AI Outputs) yapar. AI HTML'i ana Buyer Log DOM'una girmez.
   */
  ipcMain.handle('buyerlog:render-pdf', async (event, payload = {}) => {
    if (!trustedBuyerLogIpcSender(event)) return { ok:false, error:'forbidden' };
    const html = payload && typeof payload.html === 'string' ? payload.html : '';
    if (!html || Buffer.byteLength(html, 'utf8') > AI_PDF_HTML_MAX_BYTES) return { ok:false, error:'invalid' };
    try { return { ok:true, data: await renderAiPdf(html, { landscape: payload.landscape === true, footer: payload.footer !== false }) }; }
    catch (error) { return { ok:false, error: String(error && error.message || 'render-failed').slice(0, 80) }; }
  });
}

/*
 * Uygulama simgesi Windows'ta (bkz. shortcut-icon.js, exe-icon.js): BuyerLog.exe'nin
 * gömülü simgesi app-core güncellemesiyle değişmez. Pencereler görev çubuğu
 * kimliği/simgesiyle açılır; mevcut kısayollar buyerlog.ico'ya yönlendirilir ve
 * exe'nin simgesi ayrı bir süreçte güncellenir. Açılışı geciktirmemesi için
 * kısayol/exe işleri arka planda çalışır.
 */
const APP_USER_MODEL_ID = 'com.lcw.buyerlog';
const APP_ICON_SOURCE = path.join(APP_CORE_ROOT, 'buyerlog.ico');

function brandingDir() {
  return path.join(paths.localDataRoot, 'branding');
}

function taskbarAppDetails() {
  if (process.platform !== 'win32' || !app.isPackaged) return null;
  try {
    // appIconPath bilerek verilmez: pencere başına RelaunchIconResource
    // Windows'ta çözülemediğinde görev çubuğu düğmesi genel "dosya" simgesine
    // düşüyordu. Düğme simgesi BrowserWindow `icon` (buyerlog.ico) değerinden,
    // sabitlenmiş kısayolun simgesi syncShortcutIcons'tan gelir.
    ensureStableIcon({ sourceIcon: APP_ICON_SOURCE, iconDir: brandingDir() });
    return {
      appId: APP_USER_MODEL_ID,
      relaunchCommand: '"' + process.execPath + '"',
      relaunchDisplayName: 'Buyer Log',
    };
  } catch (error) {
    log('Görev çubuğu simgesi hazırlanamadı: ' + error.message);
    return null;
  }
}

function scheduleShortcutIconSync() {
  if (process.platform !== 'win32' || !app.isPackaged) return;

  // Görev çubuğu gruplaması BrowserWindow açılırken çözülür. Kısayolun
  // AppUserModelID'si eksik/eski ise 15 sn sonraki düzeltme o ilk gruplamayı
  // kaçırır ve Windows genel "dosya" simgesine düşebilir. Bu yüzden yalnız
  // hafif kısayol kimliği/simge eşitlemesi ilk pencere açılmadan önce yapılır.
  try {
    const result = syncShortcutIcons({
      shell,
      getPath: name => app.getPath(name),
      exePath: process.execPath,
      sourceIcon: APP_ICON_SOURCE,
      iconDir: brandingDir(),
      appUserModelId: APP_USER_MODEL_ID,
      log,
    });
    if (result.updated.length) {
      log('Kısayol simgesi/AppUserModelID güncellendi: ' + result.updated.length + ' kısayol');
      refreshShellIcons();
    }
  } catch (error) {
    log('Kısayol simgesi/AppUserModelID eşitlenemedi: ' + error.message);
  }

  // EXE kaynak yaması daha ağırdır; açılışı geciktirmemek için arka planda kalır.
  const timer = setTimeout(() => {
    runExeIconPatch({
      exePath: process.execPath,
      sourceIcon: APP_ICON_SOURCE,
      stateFile: path.join(brandingDir(), 'exe-icon.json'),
      log,
      onApplied: () => refreshShellIcons(),
    }).catch(error => log('BuyerLog.exe simgesi güncellenemedi: ' + error.message));
  }, 15000);
  if (timer.unref) timer.unref();
}

/* ------------------------------------------------------------ uygulama */

function bootstrap() {
  app.setName('Buyer Log');
  app.setAppUserModelId(APP_USER_MODEL_ID);

  paths = desktopPaths(resolvePortableRoot({
    packaged: app.isPackaged,
    execPath: process.execPath,
    appPath: APP_CORE_ROOT,
  }));

  try {
    launcherHost = app.isPackaged ? createLauncherHost({
      bootstrapCore: String(process.env.BUYER_LOG_BOOTSTRAP_APP_CORE || APP_CORE_ROOT),
      portableRoot: paths.portableRoot,
    }) : null;
  } catch (error) {
    launcherHost = null;
    log('Güncelleme altyapısı yöneticisi hazırlanamadı: ' + error.message);
  }
  try {
    updater = new BuyerLogUpdater({
      launcherHost,
      currentVersion: appVersion(),
      updaterVersion: String(process.env.BUYER_LOG_UPDATER_VERSION || '1.0.0'),
      appCoreRoot: APP_CORE_ROOT,
      portableRoot: paths.portableRoot,
      localDataRoot: paths.localDataRoot,
      packaged: app.isPackaged,
      log,
    });
  } catch (error) {
    updater = null;
    if (process.stdout && process.stdout.isTTY) process.stdout.write('Updater hazırlanamadı: ' + error.message + '\r\n');
  }

  /*
   * Electron'un KENDİ profili açıkça data\electron-profile'a alınır.
   * app.asar/resources içine yazma yapılmaz ve kurumsal Edge/Chrome profili
   * ile hiçbir şekilde karışmaz (bkz. portable-paths.js §2, §3).
   */
  try {
    fs.mkdirSync(paths.electronProfileRoot, { recursive: true });
    app.setPath('userData', paths.electronProfileRoot);
    app.setPath('sessionData', paths.electronProfileRoot);
  } catch (error) {
    // Yol ayarlanamazsa uygulama yine açılmalı; hata başlatma akışında raporlanır.
    // Konsol yokken stdout bloke olabilir (bkz. log()).
    if (process.stdout && process.stdout.isTTY) process.stdout.write('Electron profil klasörü ayarlanamadı: ' + error.message + '\r\n');
  }

  /*
   * TEK KOPYA. İki kopya iki veritabanı yazıcısı, iki sync motoru ve port
   * çakışması demektir. İkinci çalıştırma var olan pencereyi öne getirir.
   */
  if (!app.requestSingleInstanceLock()) {
    app.exit(0);
    return;
  }
  app.on('second-instance', () => {
    const window = activeBuyerLogWindow() || errorWindow || splashWindow;
    if (!window || window.isDestroyed()) return;
    if (window.isMinimized()) window.restore();
    window.show();
    window.focus();
  });

  /* Son pencere kapanınca uygulama kapanır — AMA yeniden başlatma sırasında
     değil. Yeniden başlatma eski pencereyi yıkıp yenisini kuruyor; aradaki
     pencerede bu olay tetiklenirse uygulama tam da toparlanırken kapanırdı. */
  app.on('window-all-closed', () => {
    if (restarting) return;
    if (updateRelaunchRequested) { try { app.relaunch(); } catch (_) {} }
    app.quit();
  });

  app.on('before-quit', event => {
    if (quitting) return;
    quitting = true;
    closeSplash();
    event.preventDefault();
    /* Shutdown steps are individually bounded; this hard deadline guarantees the
       process exits (and an update relaunch runs) even if one of them stalls. */
    let deadlineTimer = null;
    const deadline = new Promise(resolve => { deadlineTimer = setTimeout(() => { log('Kapanış süre sınırı aşıldı; çıkılıyor.'); resolve(); }, SHUTDOWN_DEADLINE_MS); });
    Promise.race([shutdown(), deadline]).catch(() => {}).finally(() => { clearTimeout(deadlineTimer); app.exit(0); });
  });

  app.whenReady().then(async () => {
    log('Buyer Log masaüstü ' + appVersion() + ' · Electron ' + process.versions.electron
      + ' · Chromium ' + process.versions.chrome + ' · Node ' + process.versions.node);
    log('Portable kök: ' + paths.portableRoot);
    log('Veri kökü   : ' + paths.dataRoot);

    Menu.setApplicationMenu(null); // §2
    showSplash(); // kurulum onarımı/sunucu beklemesi sırasında kullanıcı boş ekran görmesin
    applyDownloadPolicy(session.defaultSession);
    registerIpc();
    logGpuStatus('ready');
    app.on('gpu-info-update', () => { if (!gpuInfoUpdateLogged) { gpuInfoUpdateLogged = true; logGpuStatus('gpu-info-update'); } });
    app.on('child-process-gone', (_event, details) => {
      if (details && details.type === 'GPU') { log('GPU süreci sonlandı: ' + JSON.stringify(details)); logGpuDiagnostics('gpu-gone'); }
    });

    try {
      ensureConfig(paths, APP_CORE_ROOT);
    } catch (error) {
      log('config.json hazırlanamadı: ' + error.message);
    }

    // Tek seferlik kurulum onarımı: yeni sürümün ilk açılışında service worker
    // kalıntıları ve güncellemeyi engelleyen durum kayıtları pencere açılmadan
    // temizlenir. Sunucunun soğuk açılışı bu adımı BEKLEMEZ (7.0.323): onarım
    // Chromium oturumu ve updater durumuyla ilgilidir, backend'e dokunmaz.
    // Yalnız ana pencere açılmadan önce tamamlanması beklenir (beforeWindow).
    const installRepairDone = (async () => {
      try {
        const repair = await runInstallRepair({
          localDataRoot: paths.localDataRoot,
          appCoreRoot: APP_CORE_ROOT,
          currentVersion: appVersion(),
          updater,
          session,
          packaged: app.isPackaged,
          integrityDelayMs: INSTALL_REPAIR_INTEGRITY_DELAY_MS,
          log,
        });
        if (!repair.skipped) {
          log('Kurulum onarımı çalıştı: ' + appVersion());
          repair.integrity.then(() => updateStatusFor('').then(emitUpdateStatus)).catch(() => {});
        }
      } catch (error) {
        log('Kurulum onarımı atlandı: ' + error.message);
      }
    })();

    // Güncelleme kontrolü backend/login akışından bağımsızdır. Böylece kullanıcı
    // giriş ekranını görmeden önce bile STABLE manifest kontrolü başlamış olur.
    // Onarımın updater durum temizliğinden sonra başlar (eski sıra korunur).
    void installRepairDone.then(() => {
      scheduleUpdateChecks();
      scheduleShortcutIconSync();
      // Etkin deneme varken eşitleme atlanır ve sağlık onayından sonra yeniden planlanır.
      scheduleLauncherInfrastructureSync();
    });

    const started = await startBuyerLog({ beforeWindow: installRepairDone });
    if (!started) log('Başlatma tamamlanamadı; hata ekranı gösteriliyor.');
    // Eski sürümlerin backend derleme önbelleği açılış yükü bittikten sonra silinir.
    const pruneTimer = setTimeout(() => {
      try { const removed = pruneCompileCaches(paths, appVersion()); if (removed) log('Eski derleme önbelleği silindi: ' + removed); }
      catch (error) { log('Derleme önbelleği temizlenemedi: ' + error.message); }
    }, 90000);
    if (pruneTimer.unref) pruneTimer.unref();
  });

  process.on('uncaughtException', error => {
    log('Yakalanmamış hata: ' + (error && error.stack ? error.stack : error));
    if ((!workspace || !workspace.hasWindows()) && !mainWindow && !errorWindow) {
      try {
        dialog.showErrorBox('Buyer Log', 'Beklenmeyen bir hata oluştu:\n\n' + (error && error.message));
      } catch (_) {}
    }
  });
  process.on('unhandledRejection', reason => {
    log('Yakalanmamış promise hatası: ' + (reason && reason.stack ? reason.stack : reason));
  });
}

bootstrap();
