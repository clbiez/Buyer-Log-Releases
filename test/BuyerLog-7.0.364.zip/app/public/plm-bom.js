/* Buyer Log — PLM BOM / Baskı Detayı
 *
 * PLM Sync sırasında sunucunun kaydettiği normalize BOM analizini model adına
 * sağ tık menüsünden gösterir. Bu istemci CoreNectum'a doğrudan bağlanmaz;
 * token/çerez görmez ve LCW AI çağrısı yapmaz.
 */
(function () {
  'use strict';
  if (window.BLPlmBom) return;

  const isEn = () => typeof appLang !== 'undefined' && appLang === 'en';
  const L = (tr, en) => (isEn() ? en : tr);
  const esc = value => (typeof escapeHtml === 'function' ? escapeHtml(String(value == null ? '' : value))
    : String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])));
  function numericId(value) {
    let text = String(value == null ? '' : value).trim().replace(/^_+/, '');
    if (/^\d+\.0+$/.test(text)) text = text.slice(0, text.indexOf('.'));
    text = text.replace(/^0+(?=\d)/, '');
    return /^\d+$/.test(text) && Number(text) > 0 ? text : '';
  }
  function plmIdOfRow(row, moduleId) {
    if (!row) return '';
    const canonical = window.BLCanonicalFields;
    let value = '';
    try { value = canonical && canonical.normalizedValue ? canonical.normalizedValue(row, moduleId || 'collection', 'plmId') : ''; } catch (_) { value = ''; }
    return numericId(value || row['PLM ID'] || row.plmId || row._plmId);
  }
  function dateTime(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString(isEn() ? 'en-GB' : 'tr-TR');
  }
  async function entryForPlm(plmId) {
    const id = numericId(plmId);
    if (!id) return null;
    const response = await fetch('/api/plm-sync/bom/' + encodeURIComponent(id), { cache: 'no-store' });
    const payload = await response.json().catch(() => ({}));
    if (response.status === 404) return null;
    if (!response.ok || !payload.ok) throw new Error(payload.error || L('BOM bilgisi okunamadı.', 'BOM data could not be read.'));
    return payload.entry || null;
  }
  function aiText(ai) {
    const status = ai && ai.status || 'not-needed';
    if (status === 'resolved') return L('LCW AI belirsiz yerleşimi çözdü', 'LCW AI resolved the ambiguous placement');
    if (status === 'partial') return L('LCW AI kısmen çözümledi · kontrol gerekli', 'LCW AI partially resolved it · review required');
    if (status === 'failed') return L('LCW AI kullanılamadı · kural sonucu korundu', 'LCW AI unavailable · rule result preserved');
    if (status === 'deferred') return L('LCW AI analizi bu senkron için ertelendi', 'LCW AI analysis deferred for this sync');
    return L('BOM net · LCW AI gerekmedi', 'BOM clear · LCW AI not needed');
  }
  function toneForAi(ai) {
    const status = ai && ai.status || 'not-needed';
    return status === 'resolved' || status === 'not-needed' ? 'ok' : status === 'failed' ? 'bad' : 'wait';
  }

  /* Tüm BOM kalemleri: PLM SYNC'in sakladığı tam liste, kategori yoluna göre
     gruplu. Her kalemin yanında CP BOM Kontrol'deki kişisel işaret (Ortak /
     Model bazlı) salt okunur etiket olarak görünür. Sapma burada hesaplanmaz:
     sapma bir karşılaştırma grubuna bağlıdır ve BOM Kontrol ekranındadır. */
  const BOM_CONTROL_PREF_KEY = 'lcw.cp.bomControl.v1';
  function bomControlPrefs() {
    try {
      const storage = window.BLStorage || window.localStorage;
      const raw = JSON.parse(storage && storage.getItem(BOM_CONTROL_PREF_KEY) || 'null');
      return raw && typeof raw === 'object' ? raw : {};
    } catch (_) { return {}; }
  }
  async function bomControlEngine() {
    if (window.BLBomControlEngine) return window.BLBomControlEngine;
    try {
      // perf-runtime 'bomControl' özelliğiyle aynı dize: dosya tek kez yüklenir.
      await window.BLPerf?._loadScript?.('bom-control-engine.js?rev=1');
    } catch (_) { /* işaretsiz liste gösterilir */ }
    return window.BLBomControlEngine || null;
  }
  async function renderFullBom(body, entry) {
    const full = Array.isArray(entry && entry.fullComponents) ? entry.fullComponents : [];
    const section = document.createElement('section');
    section.className = 'plmBomFull';
    section.dataset.bomFull = '';
    if (!full.length && entry && entry.fullCoverage === 'all-normalized') {
      section.innerHTML = `<p class="cpaEmpty">${esc(L('PLM\'deki BOM boş: bu modelde hiç BOM kalemi yok.', 'The BOM in PLM is empty: this style has no BOM items.'))}</p>`;
      body.appendChild(section);
      return;
    }
    if (!full.length) {
      section.innerHTML = `<p class="cpaEmpty">${esc(L('Bu modelin kayıtlı BOM\'u eski: yalnız baskı kalemleri var. Tüm BOM kalemleri için CP\'de PLM SYNC → Artwork/Fabric ile yenileyin.', 'This style\'s stored BOM is outdated and only contains print items. Refresh it in CP with PLM SYNC → Artwork/Fabric to see all BOM items.'))}</p>`;
      body.appendChild(section);
      return;
    }
    /* Liste motoru beklemeden hemen çizilir (kategori gruplu, işaretsiz); motor
       ilk kez yükleniyorsa geldiğinde aynı bölüm işaret sütunuyla yenilenir. */
    body.appendChild(section);
    drawFullBom(section, full, window.BLBomControlEngine || null);
    if (!window.BLBomControlEngine) {
      const engine = await bomControlEngine();
      if (engine && section.isConnected) drawFullBom(section, full, engine);
    }
  }
  function drawFullBom(section, full, engine) {
    const prefs = bomControlPrefs();
    const level = engine && engine.SLOT_LEVELS.includes(prefs.slotLevel) ? prefs.slotLevel : 'category';
    const marks = engine ? engine.normalizeMarks(prefs.marks) : {};
    const groups = new Map();
    for (const component of full) {
      const slot = engine
        ? engine.slotOf(component, level)
        : { key: [component.setPart, component.mainCategoryName, component.categoryGroupName, component.categoryName].join('|'), markKey: '', part: component.setPart || '', label: [component.mainCategoryName, component.categoryGroupName, component.categoryName].filter(Boolean).join(' › ') || '—' };
      if (!groups.has(slot.key)) groups.set(slot.key, { slot, items: [] });
      groups.get(slot.key).items.push(component);
    }
    const markTag = markKey => {
      const mark = marks[markKey];
      if (mark === 'common') return `<span class="cpaPlm tone-ok">${esc(L('Ortak', 'Common'))}</span>`;
      if (mark === 'model') return `<span class="cpaPlm tone-off">${esc(L('Model bazlı', 'Model-specific'))}</span>`;
      return `<span class="cpaPlm tone-off">${esc(L('İşaretsiz', 'Unmarked'))}</span>`;
    };
    const rows = [...groups.values()].map(({ slot, items }) => items.map((item, index) => `<tr>
        ${index === 0 ? `<td rowspan="${items.length}"><b>${esc(slot.label)}</b>${slot.part ? ` <span class="cpaPlm">${esc(L('Parça', 'Part'))} ${esc(slot.part)}</span>` : ''}</td>` : ''}
        <td>${esc(item.componentCode || '—')}</td>
        <td>${esc(item.componentName || '—')}${item.description ? `<small>${esc(item.description)}</small>` : ''}</td>
        <td class="num">${item.quantity == null ? '—' : esc(item.quantity)}</td>
        ${index === 0 && engine ? `<td rowspan="${items.length}">${markTag(slot.markKey)}</td>` : ''}
      </tr>`).join('')).join('');
    section.innerHTML = `<b class="plmBomFullTitle">${esc(L(`Tüm BOM kalemleri (${full.length})`, `All BOM items (${full.length})`))}</b>
      <div class="cpaScroll"><table class="cpaTable"><thead><tr>
        <th>${esc(L('Kalem', 'Item'))}</th><th>${esc(L('Kod', 'Code'))}</th><th>${esc(L('Ad / Açıklama', 'Name / Description'))}</th><th class="num">${esc(L('Miktar', 'Qty'))}</th>${engine ? `<th>${esc(L('BOM Kontrol işareti', 'BOM Check mark'))}</th>` : ''}
      </tr></thead><tbody>${rows}</tbody></table></div>
      <p class="cpaEmpty">${esc(L('İşaretler CP → Araçlar → BOM Kontrol\'de verilir; sapmalar orada, seçilen grupla karşılaştırılarak gösterilir.', 'Marks are set in CP → Tools → BOM Check, where deviations are shown against the selected group.'))}</p>`;
  }

  function openForPlm(plmId, title, context = {}) {
    const id = numericId(plmId);
    // Yerel BOM okuması, dialogun odak/layout hazırlığını beklemez.
    const entryPromise = id ? entryForPlm(id) : Promise.resolve(null);
    // İşaret motoru BOM okumasıyla paralel yüklenir; ilk açılış iki bekleme sırası yaşamaz.
    if (id) void bomControlEngine();
    const modal = document.createElement('div');
    modal.className = 'cpaModalOverlay';
    let releaseKeyboard = () => {};
    const close = () => { releaseKeyboard(); modal.remove(); };
    modal.innerHTML = `<div class="cpaModal" role="dialog" aria-modal="true" aria-label="${esc(L('PLM BOM · Baskı Detayı', 'PLM BOM · Print Details'))}"><header>
      <div><b>${esc(L('PLM BOM · Baskı Detayı', 'PLM BOM · Print Details'))}</b><small>${esc([id && 'PLM ' + id, title].filter(Boolean).join(' · '))}</small></div>
      <button type="button" data-bom-close aria-label="${esc(L('Kapat', 'Close'))}">×</button></header>
      <div class="cpaModalBody"><p class="cpaEmpty">${esc(L('BOM bilgisi yükleniyor…', 'Loading BOM data…'))}</p></div>
      <footer><button type="button" class="cpaBtn ghost" data-bom-close>${esc(L('Kapat', 'Close'))}</button></footer></div>`;
    modal.querySelectorAll('[data-bom-close]').forEach(el => { el.onclick = close; });
    modal.addEventListener('click', event => { if (event.target === modal) close(); });
    modal.addEventListener('keydown', event => { if (event.key === 'Escape') close(); });
    document.body.appendChild(modal);
    releaseKeyboard = window.BLUI?.bindDialogKeyboard?.(modal, { onEscape: close }) || (() => {});
    if (window.BLMotionPlus?.enabled?.()) window.BLMotionPlus.play('overlay', modal.querySelector('.cpaModal'));

    const body = modal.querySelector('.cpaModalBody');
    (async () => {
      if (!id) {
        body.innerHTML = `<p class="cpaEmpty">${esc(L('Bu satırda PLM ID yok.', 'This row has no PLM ID.'))}</p>`;
        return;
      }
      try {
        const entry = await entryPromise;
        if (!modal.isConnected) return;
        if (!entry) {
          body.innerHTML = `<p class="cpaEmpty">${esc(L('Bu model için henüz BOM kaydı yok. PLM SYNC çalıştırıldığında BOM da otomatik okunur.', 'No BOM record exists for this style yet. BOM is read automatically during PLM SYNC.'))}</p>`;
          return;
        }
        const placements = Array.isArray(entry.placements) ? entry.placements : [];
        const setComponents = Array.isArray(entry.setComponents) ? entry.setComponents : [];
        const isSet = entry.isSetStyle === true || setComponents.length > 0;
        const rows = placements.map(item => `<tr>
          ${isSet ? `<td><b>${esc(item.setPart || '—')}</b></td>` : ''}
          <td>${esc(isEn() ? (item.placementEn || item.placement) : (item.placementTr || item.placement))}${item.aiResolved ? ` <span class="cpaPlm tone-ok">AI</span>` : ''}</td>
          <td>${esc(item.printType || item.categoryName || 'Print')}</td>
          <td>${esc(item.componentCode || '—')}</td>
          <td>${esc(item.description || '—')}</td>
          <td>${esc(item.count || 1)}</td>
          <td>${item.quantity == null ? '—' : esc(item.quantity)}</td>
          <td>${esc(item.graphicApprovalStatusName || '—')}</td>
        </tr>`).join('');
        const ai = entry.ai || {};
        const artwork = context.moduleId === 'collection' ? window.BLCollectionArtworkDetail : null;
        const summary = artwork ? artwork.summaryFor(entry) : isSet ? (entry.artworkSummary || entry.summary || L('Baskı yok', 'No print')) : (entry.hasPrint ? entry.summary : L('Baskı yok', 'No print'));
        const setRows = setComponents.map(item => `<tr>
          <td><b>${esc(item.label || '—')}</b></td>
          <td>${esc(item.childPlmId || '—')}</td>
          <td>${esc(item.childStyleName || '—')}</td>
          <td>${esc(item.specialCode || '—')}</td>
          <td>${esc(item.fabric || '—')}</td>
          <td>${esc(item.bomSummary || L('Baskı yok', 'No print'))}</td>
        </tr>`).join('');
        body.innerHTML = `
          <div class="cpaChips">
            <div class="cpaChip is-static"><span class="l">${esc(L('Baskı', 'Print'))}</span><b>${esc(summary)}</b></div>
            ${isSet && entry.fabricSummary ? `<div class="cpaChip is-static"><span class="l">${esc(L('Kumaş', 'Fabric'))}</span><span class="q">${esc(entry.fabricSummary)}</span></div>` : ''}
            <div class="cpaChip is-static"><span class="l">${esc(L('Kaynak', 'Source'))}</span><span class="q">CoreNectum BOM · ${esc(dateTime(entry.fetchedAt))}</span></div>
            <div class="cpaChip is-static"><span class="l">AI</span><span class="cpaPlm tone-${toneForAi(ai)}">${esc(aiText(ai))}</span>${ai.model ? `<span class="q">${esc(ai.model)}${ai.confidence ? ' · ' + esc(ai.confidence) : ''}</span>` : ''}</div>
          </div>
          ${setRows ? `<div class="cpaScroll"><table class="cpaTable"><thead><tr>
            <th>${esc(L('Parça', 'Part'))}</th><th>PLM</th><th>${esc(L('Model', 'Model'))}</th><th>Special Code</th>
            <th>${esc(L('Kumaş', 'Fabric'))}</th><th>Artwork / BOM</th>
          </tr></thead><tbody>${setRows}</tbody></table></div>` : ''}
          ${rows ? `<div class="cpaScroll"><table class="cpaTable"><thead><tr>
            ${isSet ? `<th>${esc(L('Parça', 'Part'))}</th>` : ''}<th>${esc(L('Yerleşim', 'Placement'))}</th><th>${esc(L('Teknik', 'Technique'))}</th><th>Component</th>
            <th>${esc(L('PLM Açıklaması', 'PLM Description'))}</th><th>${esc(L('Baskı Adedi', 'Print Count'))}</th>
            <th>${esc(L('BOM Miktarı', 'BOM Quantity'))}</th><th>${esc(L('Grafik Onayı', 'Graphic Approval'))}</th>
          </tr></thead><tbody>${rows}</tbody></table></div>`
            : `<p class="cpaEmpty">${esc(L('BOM içinde Print kategorisinde bileşen yok.', 'No component is classified as Print in the BOM.'))}</p>`}
          ${entry.needsAi ? `<p class="cpaEmpty">${esc(L('Bazı baskı yerleşimleri hâlâ belirsiz. Manuel kontrol önerilir.', 'Some print placements remain ambiguous. Manual review is recommended.'))}</p>` : ''}
          ${ai.error ? `<p class="cpaEmpty">${esc(ai.error)}</p>` : ''}
        `;
        void renderFullBom(body, entry);
        if (artwork && context.row) {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = 'cpaBtn';
          button.dataset.bomApply = '';
          const applyLabel = L('BOM değerini Artwork Detayına uygula', 'Apply BOM value to Artwork Detail');
          button.textContent = applyLabel;
          button.disabled = !artwork.canApplyBom(context.row, entry);
          button.onclick = async () => {
            button.disabled = true;
            button.textContent = L('BOM değeri uygulanıyor…', 'Applying BOM value…');
            // Ortak hücre kaydı tabloyu çizebilir; önce gerçek geri bildirimi boya.
            await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
            if (!modal.isConnected) return;
            try {
              const result = artwork.applyBom(context.row, entry);
              if (!result?.ok) throw new Error('BOM_APPLY_FAILED');
              close();
              window.showToast?.(result.changed ? L('BOM değeri Artwork Detayına uygulandı. Geri Al ile eski değere dönebilirsiniz.', 'BOM value applied to Artwork Detail. Use Undo to restore the previous value.') : L('Artwork Detayı zaten BOM değeriyle aynı.', 'Artwork Detail already matches the BOM value.'));
            } catch (_) {
              let status = body.querySelector('[data-bom-status]');
              if (!status) { status = document.createElement('p'); status.className = 'cpaEmpty'; status.dataset.bomStatus = ''; status.setAttribute('role', 'status'); body.appendChild(status); }
              status.textContent = L('BOM değeri uygulanamadı. Düzenleme iznini ve satırı kontrol edip BOM penceresini yeniden açın.', 'BOM value could not be applied. Check edit permission and the row, then reopen the BOM window.');
              button.textContent = applyLabel;
              button.disabled = !artwork.canApplyBom(context.row, entry);
            }
          };
          const footer = modal.querySelector('footer');
          footer.insertBefore(button, footer.firstChild);
        }
      } catch (error) {
        if (modal.isConnected) body.innerHTML = `<p class="cpaEmpty">${esc(L('BOM bilgisi okunamadı: ', 'BOM data could not be read: ') + String(error && error.message || error))}</p>`;
      }
    })();
  }

  function openForRow(row, moduleId) {
    const title = String((row && (row['Model Name'] || row.modelName || row.model || row.modelKod)) || '').trim();
    openForPlm(plmIdOfRow(row, moduleId), title, { row, moduleId: moduleId || 'collection' });
  }

  window.BLPlmBom = { numericId, plmIdOfRow, entryForPlm, openForPlm, openForRow };
})();
