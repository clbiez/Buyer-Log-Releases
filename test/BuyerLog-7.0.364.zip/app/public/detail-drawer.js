/* Buyer Log — ortak sağ detay çekmecesi.
 * Detay tabloları tek davranışta toplar: görsel, sütun seçimi, PLM görsel senkronu
 * ve görünen sütunları Excel'e aktarma. İş kuralları bu katmanda tutulmaz.
 */
(function(root,factory){
  const api=factory(root);
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root&&root.document)root.BLDetailDrawer=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root){
'use strict';

const PREF_PREFIX='buyerlog.detailDrawer.report.columns.v1.';
const WIDTH_PREFIX='buyerlog.detailDrawer.report.width.v1.';
const COL_WIDTH_PREFIX='buyerlog.detailDrawer.report.colWidths.v1.';
const PRESET_PREFIX='buyerlog.detailDrawer.report.preset.v1.';
// Sütun genişliği sınırları: uzun başlık sarılır, sütunu genişletmez.
const COL_MIN=56,COL_MAX=640,COL_FIT_MAX=360,COL_DEFAULT_MAX=240;
// Büyük detay kümelerinde tablo parça parça çizilir; Excel ve arama bütün satırlarla çalışır.
const RENDER_CHUNK=300;
const clean=value=>String(value==null?'':value).replace(/\s+/g,' ').trim();
const safeFilePart=value=>clean(value).replace(/[\\/:*?"<>|]+/g,' ').replace(/\s+/g,' ').trim().slice(0,90)||'BuyerLog_Detail';
const escapeHtml=value=>clean(value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function inferColumns(rows){
  const seen=new Set(),out=[];
  (rows||[]).slice(0,40).forEach(row=>Object.keys(row||{}).forEach(key=>{
    if(!key||key.startsWith('_')||seen.has(key))return;
    seen.add(key);out.push({key,label:key});
  }));
  return out;
}
function normalizeColumns(columns,rows){
  const source=Array.isArray(columns)&&columns.length?columns:inferColumns(rows);
  const seen=new Set();
  return source.map((col,index)=>{
    if(typeof col==='string')col={key:col,label:col};
    const key=clean(col&&col.key)||('column_'+index);
    if(seen.has(key))return null;seen.add(key);
    return {...col,key,label:clean(col&&col.label)||key};
  }).filter(Boolean);
}

function hasValue(value){return value!==undefined&&value!==null&&!(typeof value==='string'&&clean(value)==='');}
function rowSources(row){
  const sources=[],seen=new Set(),pending=[row];
  for(let i=0;i<pending.length;i++){
    const source=pending[i];
    if(!source||typeof source!=='object'||Array.isArray(source)||seen.has(source))continue;
    seen.add(source);sources.push(source);
    pending.push(source.row,source.raw,source.source,source.data,source._source,source.sourceRow,source._detailSource);
  }
  return sources;
}
/* Detail reports are often supplied a curated column catalog while their ASAS
   rows still contain MAG. Add that source field only when data exists; never
   infer a value, duplicate an alias, or alter flat OAB/pivot column catalogs. */
function includeMagColumn(rows,columns,moduleId,canonical){
  if(!Array.isArray(rows)||!rows.length||columns.some(col=>col.canonicalId==='mag'||col.key==='MAG'||canonical?.canonicalId?.(moduleId,col.key)==='mag'))return columns;
  const sourceKeys=['MAG','mag','Merch Alt Grup Kod','Merch Alt Grup','merch'];
  const sample=rows.length<=160?rows:rows.slice(0,120).concat(rows.slice(-40));
  for(const row of sample){
    for(const source of rowSources(row)){
      if(hasValue(canonical?.canonicalValue?.(source,moduleId,'mag'))||
         sourceKeys.some(key=>hasValue(source[key]))){
        return [...columns,{key:'MAG',label:'MAG',canonicalId:'mag',type:'text'}];
      }
    }
  }
  return columns;
}

if(!root||!root.document)return {inferColumns,normalizeColumns,safeFilePart,includeMagColumn};

const document=root.document;
const isEn=()=>String(document.documentElement.lang||'tr').toLowerCase().startsWith('en');
const L=(tr,en)=>isEn()?en:tr;
const store=()=>root.BLStorage||root.localStorage;
let active=null;

function storagePart(value){return clean(value||'generic').replace(/[^a-z0-9_.-]+/gi,'_');}
function pageScope(input){
  const explicit=clean(input&&input.pageScope);
  if(explicit)return explicit;
  return clean(document.body&&document.body.dataset&&document.body.dataset.activeTab)||'global';
}
function prefKey(scope,page){return PREF_PREFIX+storagePart(page)+'.'+storagePart(scope);}
function loadVisible(scope,page,columns,defaults){
  const allowed=new Set(columns.map(c=>c.key));
  try{
    const raw=JSON.parse(store().getItem(prefKey(scope,page))||'null');
    const selected=Array.isArray(raw)?raw.filter(key=>allowed.has(key)):[];
    if(selected.length)return selected;
  }catch(_){}
  const preferred=Array.isArray(defaults)?defaults.filter(key=>allowed.has(key)):[];
  return preferred.length?preferred:columns.map(c=>c.key);
}
function saveVisible(scope,page,keys){try{store().setItem(prefKey(scope,page),JSON.stringify(keys));}catch(_){}}
function colWidthKey(scope,page){return COL_WIDTH_PREFIX+storagePart(page)+'.'+storagePart(scope);}
function loadColWidths(scope,page){
  try{
    const raw=JSON.parse(store().getItem(colWidthKey(scope,page))||'null');
    return raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
  }catch(_){return {};}
}
function saveColWidths(){if(!active)return;try{store().setItem(colWidthKey(active.scope,active.pageScope),JSON.stringify(active.colWidths||{}));}catch(_){}}
function presetKey(scope,page){return PRESET_PREFIX+storagePart(page)+'.'+storagePart(scope);}
function loadPreset(scope,page){try{const v=clean(store().getItem(presetKey(scope,page))).toLowerCase();return ['focus','extended','all','custom'].includes(v)?v:'';}catch(_){return '';}}
function savePreset(){if(!active||active.tableSetup||!active.viewPresets)return;try{store().setItem(presetKey(active.scope,active.pageScope),active.preset);}catch(_){}}
// Bağlama özel (tableSetup olmayan) Odak/Genişletilmiş görünüm listeleri.
// Tümü her zaman bütün sütunlardır.
function normalizeViewPresets(input,columns){
  const raw=input&&input.viewPresets;
  if(!raw||typeof raw!=='object')return null;
  const allowed=new Set(columns.map(col=>col.key)),out={};
  ['focus','extended'].forEach(name=>{
    const keys=(Array.isArray(raw[name])?raw[name]:[]).map(clean).filter(key=>allowed.has(key));
    if(keys.length)out[name]=[...new Set(keys)];
  });
  if(!out.focus&&!out.extended)return null;
  if(!out.focus)out.focus=out.extended.slice();
  if(!out.extended)out.extended=out.focus.slice();
  return out;
}
function viewPresetVisible(preset){
  if(!active)return[];
  if(preset==='all')return active.columns.map(col=>col.key);
  if(active.tableSetup)return setupVisibleKeys(active.tableSetup,preset,active.contextKeys);
  return active.viewPresets&&active.viewPresets[preset]?active.viewPresets[preset].slice():[];
}

function tableSetupSnapshot(input){
  const tableKey=clean(input&&input.tableSetup);
  if(!tableKey||!root.BLTableViewSetup||typeof root.BLTableViewSetup.snapshot!=='function')return null;
  try{
    const snapshot=root.BLTableViewSetup.snapshot(tableKey);
    return snapshot&&Array.isArray(snapshot.columns)&&snapshot.columns.length?snapshot:null;
  }catch(err){console.warn('Detay çekmecesi tablo görünümü alınamadı:',err);return null;}
}
function setupPresetKeys(snapshot,preset){
  if(!snapshot||!snapshot.presets)return[];
  const keys=snapshot.presets[preset];
  return Array.isArray(keys)?keys.slice():[];
}
function setupInitialPreset(snapshot){
  const preset=clean(snapshot&&snapshot.activePreset).toLowerCase();
  return ['focus','extended','all'].includes(preset)?preset:'custom';
}
function widthKey(page){return WIDTH_PREFIX+storagePart(page);}
function loadWidth(page){
  try{
    const value=Number(store().getItem(widthKey(page)));
    return Number.isFinite(value)&&value>=420?value:null;
  }catch(_){return null;}
}
function saveWidth(page,width){try{store().setItem(widthKey(page),String(Math.round(width)));}catch(_){}}
function ensureHost(){
  let host=document.getElementById('blSharedDetailDrawer');
  if(host)return host;
  host=document.createElement('aside');
  host.id='blSharedDetailDrawer';
  host.className='blDetailDrawer';
  host.dataset.uiMigrated='detail-drawer';
  host.setAttribute('aria-hidden','true');
  document.body.appendChild(host);
  return host;
}
function fieldRefs(col){
  // Etiket çevirisi ve parantez içi açıklama veri anahtarı değildir.
  // Örn. Fabric (PLM), PLM ID değerine dönüşmemeli.
  return [...new Set([col&&col.key,col&&col.field].map(clean).filter(Boolean))];
}
function detailModule(){
  const known=['overview','cp','orders','backlog','collection','lfl','logistics','antrepo','openCosting'];
  const aliases={koleksiyon:'collection',collection:'collection',priceanalysis:'',shipping:'logistics'};
  const candidates=[active&&active.moduleId,active&&active.pageScope,active&&active.scope,active&&active.source].map(clean).filter(Boolean);
  for(const raw of candidates){
    const lower=raw.toLowerCase();
    if(Object.prototype.hasOwnProperty.call(aliases,lower)&&aliases[lower])return aliases[lower];
    for(const id of known){
      const canonical=String(id).toLowerCase();
      if(lower===canonical||lower.startsWith(canonical+'.')||lower.includes('.'+canonical+'.'))return id;
    }
  }
  return '';
}
function lookupValue(col,row){
  const plan=active?.backlogLookupPlans?.get(col),sources=rowSources(row);
  const refs=plan?plan.refs:fieldRefs(col);
  const canonical=root.BLCanonicalFields,moduleId=plan?plan.moduleId:detailModule();
  const ids=plan?plan.ids:[...new Set([col&&col.canonicalId,...refs.map(ref=>canonical?.canonicalId?.(moduleId,ref))].filter(Boolean))];
  const token=canonical&&canonical.token?canonical.token:(value=>String(value==null?'':value).toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim());
  const wanted=plan?plan.wanted:[...new Set(refs.map(token).filter(Boolean))];
  if(!plan)active?.backlogLookupPlans?.set(col,{refs,moduleId,ids,wanted});
  // Dış satırın kanonik değeri, içteki eski ham anahtardan önce gelir.
  for(const source of sources){
    for(const ref of refs){
      if(Object.prototype.hasOwnProperty.call(source,ref)&&hasValue(source[ref]))return source[ref];
    }
    if(canonical&&moduleId){
      for(const id of ids){
        const value=canonical.canonicalValue?.(source,moduleId,id);
        if(hasValue(value))return value;
      }
    }
    const keys=Object.keys(source);
    for(const key of keys){
      if(wanted.includes(token(key))&&hasValue(source[key]))return source[key];
    }
  }
  return undefined;
}
function rawValueOf(col,row){
  try{
    let value;
    if(typeof col.value==='function'){
      value=col.value(row);
      // undefined = bu erişimci alanı çözmedi. Boş/null ise gerçek sonuçtur;
      // parsiyelin boş Handover'ı sipariş tarihinden doldurulmamalı.
      if(value===undefined)value=lookupValue(col,row);
    }else value=lookupValue(col,row);
    return value;
  }catch(_){return undefined;}
}
const columnSchemaCache=new WeakMap();
function columnSchema(col,rows){
  const resolver=root.BLColumnSchema&&root.BLColumnSchema.resolveColumnSchema;
  if(typeof resolver!=='function'||!col)return null;
  const sourceRows=Array.isArray(rows)?rows:[];
  const cached=columnSchemaCache.get(col);
  if(cached&&cached.rows===sourceRows)return cached.schema;
  try{
    const schema=resolver({...col,field:col.field||col.key},sourceRows,col.sourceMetadata||col.metadata);
    columnSchemaCache.set(col,{rows:sourceRows,schema});
    return schema;
  }catch(_){return null;}
}
function fallbackDateText(value){
  if(!(value instanceof Date)||Number.isNaN(value.getTime()))return '';
  if(typeof root.fmtDate==='function')return root.fmtDate(value);
  const p=n=>String(n).padStart(2,'0');
  return p(value.getDate())+'.'+p(value.getMonth()+1)+'.'+String(value.getFullYear()).slice(-2);
}
function valueOf(col,row){
  try{
    const value=rawValueOf(col,row);
    if(typeof col.format==='function')return col.format(value,row);
    if(!hasValue(value))return '';
    const schema=columnSchema(col,active&&active.rows||[row]);
    if(value instanceof Date&&!Number.isNaN(value.getTime())&&(!schema||!['date','datetime'].includes(schema.dataType)))return fallbackDateText(value);
    if(schema&&['integer','quantity','decimal','currency'].includes(schema.dataType)){
      const number=schema.parse?.(value);
      if(typeof number==='number'&&Number.isFinite(number))return number.toLocaleString(isEn()?'en-GB':'tr-TR',{minimumFractionDigits:schema.dataType==='currency'?2:0,maximumFractionDigits:['integer','quantity'].includes(schema.dataType)?0:2});
    }
    if(schema&&typeof schema.format==='function')return schema.format(value,{row});
    if(value instanceof Date&&!Number.isNaN(value.getTime()))return fallbackDateText(value);
    if(typeof value==='object')return JSON.stringify(value);
    return value;
  }catch(_){return '';}
}
function excelValueOf(col,row){
  const raw=rawValueOf(col,row);
  if(!hasValue(raw))return '';
  const schema=columnSchema(col,active&&active.rows||[row]);
  if(raw instanceof Date&&!Number.isNaN(raw.getTime())&&(!schema||!['date','datetime'].includes(schema.dataType)))return raw;
  if(schema&&typeof schema.excelValue==='function')return schema.excelValue(raw,{row});
  if(typeof col.exportValue==='function')return col.exportValue(raw,row);
  if(col.type==='number'&&typeof raw==='number')return raw;
  if(typeof col.format==='function')return col.format(raw,row);
  if(schema&&typeof schema.exportValue==='function')return schema.exportValue(raw,{row});
  return typeof raw==='object'&&!(raw instanceof Date)?JSON.stringify(raw):raw;
}
function excelFormatOf(col,row){
  const raw=rawValueOf(col,row),schema=columnSchema(col,active&&active.rows||[row]);
  const format=schema&&typeof schema.excelNumberFormat==='function'?schema.excelNumberFormat(raw,{row}):'';
  if(format)return format;
  return raw instanceof Date&&!Number.isNaN(raw.getTime())?(root.BLExcelDates?.DATE_FORMAT||'dd.mm.yy'):'';
}
function textValue(col,row){const value=valueOf(col,row);return value==null?'':String(value);}
function modelIdentity(row){
  const nested=row&&typeof row==='object'?(row.row||row.raw||null):null;
  const get=(...keys)=>{
    for(const source of [row,nested]){
      if(!source)continue;
      for(const key of keys){const v=source[key];if(v!=null&&clean(v))return clean(v);}
    }
    return '';
  };
  const cached=active?.imageIdentities?.get(row);
  if(cached)return cached;
  const read=root.BLDetailImages?.identityFromRow,moduleId=detailModule()||'overview';
  const fromRow=read?.(row,moduleId),fromNested=nested&&read?.(nested,moduleId);
  const id={
    plmId:fromRow?.plmId||fromNested?.plmId||get('plmId','plm','_plmId','PLM ID','PLM Id','PLMID','Plm Kod','PLM Kod','PLM Code'),
    modelName:fromRow?.modelName||fromNested?.modelName||get('model','modelName','modelKod','Model Adı','Model Name','Style Name','Style','Option Adı','Option Name','_modelName'),
    colourCode:fromRow?.colourCode||fromNested?.colourCode||get('colourCode','ccode','_colourCode','colorCode','C.Code','Renk Kod','Renk Kodu','Colour Code','Color Code'),
    colour:fromRow?.colour||fromNested?.colour||get('colour','color','Colour','Color','Renk','Renk Tanım','Renk Adı'),
    orderCode:fromRow?.orderCode||fromNested?.orderCode||get('orderCode','ocode','orderKey','Sipariş Kod','Sipariş Kodu','Order Code','Order No'),
    specialCode:fromRow?.specialCode||fromNested?.specialCode,
    season:fromRow?.season||fromNested?.season,
    allowOptionPrefix:active?.source==='oab'
  };
  if(row&&typeof row==='object')active?.imageIdentities?.set(row,id);
  return id;
}
function imageUrl(row,index){
  return root.BLDetailImages?.urlFrom?.(index,modelIdentity(row))||'';
}
function imageCell(row,index){
  const helper=root.BLDetailImages;
  if(!helper?.thumbHtml)return '<span class="blDetailNoImage">—</span>';
  const id=helper.resolve(index,modelIdentity(row));
  return helper.thumbHtml(id.source,{...id,modelId:id.plmId||id.modelName},{
    title:L('Büyük önizleme için üzerine gelin','Hover for large preview'),allowEmpty:true
  });
}
function searchText(row,index){
  if(!active.searchIndex)active.searchIndex=new Array(active.rows.length);
  let text=active.searchIndex[index];
  if(text==null){const locale=isEn()?'en-GB':'tr-TR';text=active.columns.map(col=>textValue(col,row).toLocaleLowerCase(locale)).join('\u0001');active.searchIndex[index]=text;}
  return text;
}
/* Sütun filtresi CP başlık filtresiyle aynı değer kümesi mantığını kullanır:
   değerler ekranda görünen (biçimlendirilmiş) metindir, boş küme = filtre yok. */
function cellFilterValue(col,row){return clean(textValue(col,row));}
function columnByKey(key){return active&&(active.columns.find(col=>col.key===key)||reportColumns().find(col=>col.key===key))||null;}
function rowPassesFilters(row,skipKey){
  if(!active||!active.filters)return true;
  for(const [key,set] of active.filters){
    if(key===skipKey||!set||!set.size)continue;
    const col=columnByKey(key);if(!col)continue;
    if(!set.has(cellFilterValue(col,row)))return false;
  }
  return true;
}
function filteredRows(){
  if(!active)return[];
  const q=clean(active.search).toLocaleLowerCase(isEn()?'en-GB':'tr-TR');
  const sig=q+'\u0002'+(active.filterVersion||0);
  if(!q&&!(active.filters&&active.filters.size))return active.rows;
  if(active.filterCache&&active.filterCache.sig===sig)return active.filterCache.rows;
  const rows=active.rows.filter((row,index)=>(!q||searchText(row,index).includes(q))&&rowPassesFilters(row));
  active.filterCache={sig,rows};return rows;
}
function filterValueSort(a,b){
  if(a==='')return 1;if(b==='')return -1;
  return a.localeCompare(b,isEn()?'en-GB':'tr-TR',{numeric:true,sensitivity:'base'});
}
function openColumnFilter(key,anchor){
  const col=columnByKey(key),openPanel=root.openValueFilterPanel;
  if(!col||typeof openPanel!=='function')return;
  const values=new Set(),activeValues=new Set();
  active.rows.forEach(row=>{
    const value=cellFilterValue(col,row);values.add(value);
    if(rowPassesFilters(row,key))activeValues.add(value);
  });
  openPanel({
    anchorEl:anchor,title:col.label,values:[...values].sort(filterValueSort),activeValues,
    selected:new Set(active.filters.get(key)||[]),
    labelFor:value=>value===''?L('(boş)','(blank)'):value,
    onApply:selected=>setColumnFilter(key,selected),
    onRemove:()=>setColumnFilter(key,null)
  });
}
function setColumnFilter(key,selected){
  if(!active)return;
  if(selected&&selected.size)active.filters.set(key,new Set(selected));else active.filters.delete(key);
  active.filterVersion=(active.filterVersion||0)+1;active.limit=RENDER_CHUNK;
  renderTable();
}
function clearColumnFilters(){
  if(!active||!active.filters.size)return;
  active.filters.clear();active.filterVersion=(active.filterVersion||0)+1;active.limit=RENDER_CHUNK;renderTable();
}
function syncFilterTools(){
  const host=document.getElementById('blSharedDetailDrawer');if(!host||!active)return;
  const button=host.querySelector('[data-bl-detail-clear-filters]');if(!button)return;
  const count=active.filters.size;
  button.hidden=!count;
  button.textContent='✕ '+L('Filtreleri Temizle','Clear Filters')+(count?' ('+count+')':'');
}

/* ----- Sütun genişliği: sürükle, çift tıkla sığdır, Sütunları Sığdır ----- */
let measureCtx=null;
function measureText(text,font){
  try{
    if(!measureCtx)measureCtx=document.createElement('canvas').getContext('2d');
    if(measureCtx){measureCtx.font=font;return Math.ceil(measureCtx.measureText(String(text)).width);}
  }catch(_){}
  return Math.ceil(String(text).length*6.4);
}
function tableFonts(){
  const table=document.querySelector('#blSharedDetailDrawer [data-bl-detail-table]');
  let family='Arial, sans-serif',size='11px';
  try{if(table){const cs=root.getComputedStyle(table);family=cs.fontFamily||family;size=cs.fontSize||size;}}catch(_){}
  return {cell:'400 '+size+' '+family,head:'600 11px '+family};
}
// En dar okunabilir genişlik: hücre içeriği tek satır sığar, başlık ise
// kelime kelime sarılır (en uzun kelime + en fazla `lines` satır).
function fitWidthOf(col,maxPx,lines){
  const fonts=tableFonts(),visibleRows=filteredRows(),rows=visibleRows.length?visibleRows:active.rows;
  let data=0;
  if(col.fields)return Math.max(col.widthPx||120,...col.fields.map(field=>fitWidthOf(field,maxPx,lines)));
  const sample=rows.length>600?rows.slice(0,600):rows;
  sample.forEach(row=>{const text=textValue(col,row);if(text)data=Math.max(data,measureText(text,fonts.cell));});
  const label=clean(col.label),longestWord=label.split(' ').reduce((max,word)=>Math.max(max,measureText(word,fonts.head)),0);
  const header=Math.max(longestWord,Math.ceil(measureText(label,fonts.head)/(lines||3)))+22+18;
  return Math.max(COL_MIN,Math.min(maxPx||COL_FIT_MAX,Math.max(data+22,header)));
}
function columnWidth(col){
  const saved=Number(active.colWidths&&active.colWidths[col.key]);
  if(Number.isFinite(saved)&&saved>=COL_MIN)return Math.min(COL_MAX,Math.round(saved));
  if(!active.autoWidths)active.autoWidths={};
  if(active.autoWidths[col.key])return active.autoWidths[col.key];
  const inherited=Number(col.widthPx)||0;
  const px=inherited?Math.max(COL_MIN,Math.min(COL_MAX,Math.round(inherited))):fitWidthOf(col,COL_DEFAULT_MAX,2);
  active.autoWidths[col.key]=px;return px;
}
function applyTableWidth(table,columns,showImages){
  const total=columns.reduce((sum,col)=>sum+columnWidth(col),(showImages?74:0)+(active?.rowActions?.length?120:0));
  table.style.width=total+'px';
}
function fitAllColumns(){
  if(!active)return;
  if(!active.colWidths)active.colWidths={};
  reportColumns().forEach(col=>{active.colWidths[col.key]=fitWidthOf(col);});
  saveColWidths();renderTable();
  root.showToast?.(L('Sütunlar en dar okunabilir genişliğe getirildi.','Columns were fitted to their narrowest readable width.'));
}
function bindColumnResize(table){
  table.querySelectorAll('[data-bl-detail-col-resize]').forEach(grip=>{
    grip.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();});
    grip.addEventListener('dblclick',event=>{
      event.preventDefault();event.stopPropagation();
      const col=columnByKey(grip.dataset.blDetailColResize);if(!col)return;
      active.colWidths[col.key]=fitWidthOf(col);saveColWidths();renderTable();
    });
    grip.addEventListener('pointerdown',event=>{
      if(event.button!==0)return;
      event.preventDefault();event.stopPropagation();
      const key=grip.dataset.blDetailColResize,col=columnByKey(key),th=grip.closest('th');
      if(!col||!th)return;
      const index=[...th.parentElement.children].indexOf(th),colEl=table.querySelectorAll('colgroup col')[index];
      const startX=event.clientX,startPx=Math.round(th.getBoundingClientRect().width)||columnWidth(col);
      const showImages=Boolean(table.querySelector('.blDetailImageCol'));
      const move=ev=>{
        const next=Math.max(COL_MIN,Math.min(COL_MAX,Math.round(startPx+(ev.clientX-startX))));
        active.colWidths[key]=next;
        if(colEl)colEl.style.width=next+'px';
        applyTableWidth(table,reportColumns(),showImages);
      };
      const end=()=>{
        root.removeEventListener('pointermove',move);root.removeEventListener('pointerup',end);
        document.body.classList.remove('blColResizing');
        if(active)saveColWidths();
      };
      document.body.classList.add('blColResizing');
      root.addEventListener('pointermove',move);root.addEventListener('pointerup',end);
    });
  });
}
function currentColumns(){if(!active)return[];const set=new Set(active.visible);if(active.requiredVisible)active.requiredVisible.forEach(key=>set.add(key));return active.columns.filter(col=>set.has(col.key));}

function setupVisibleKeys(snapshot,preset,contextKeys){
  const base=preset==='custom'&&Array.isArray(snapshot&&snapshot.visible)?snapshot.visible:setupPresetKeys(snapshot,preset);
  return [...new Set([...(base||[]),...(contextKeys||[])])];
}
function applyViewPreset(preset){
  if(!active||!(active.tableSetup||active.viewPresets)||!['focus','extended','all'].includes(preset))return false;
  const allowed=new Set(active.columns.map(col=>col.key));
  const next=(active.tableSetup?setupVisibleKeys(active.tableSetup,preset,active.contextKeys):viewPresetVisible(preset)).filter(key=>allowed.has(key));
  if(!next.length)return false;
  active.preset=preset;active.visible=next;savePreset();
  return true;
}
function syncViewPresetButtons(){
  const host=document.getElementById('blSharedDetailDrawer');if(!host||!active)return;
  host.querySelectorAll('[data-bl-detail-view-preset]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.blDetailViewPreset===active.preset)));
}
function viewPresetHtml(){
  if(!active||!(active.tableSetup||active.viewPresets))return'';
  return '<div class="blDetailViewActions" role="group" aria-label="'+escapeHtml(L('Tablo görünümü','Table view'))+'">'+
    '<span class="blDetailViewLabel">'+escapeHtml(L('GÖRÜNÜM','VIEW'))+'</span>'+
    ['focus','extended','all'].map(preset=>{
      const label=preset==='focus'?L('Odak','Focus'):preset==='extended'?L('Genişletilmiş','Extended'):L('Tümü','All');
      return '<button type="button" class="blDetailViewPreset" data-bl-detail-view-preset="'+preset+'" aria-pressed="'+String(active.preset===preset)+'">'+escapeHtml(label)+'</button>';
    }).join('')+'</div>';
}
function groupHeaderHtml(columns,showImages){
  if(!columns.some(col=>clean(col.group)))return'';
  const cells=[];let last='',count=0;
  const flush=()=>{if(count)cells.push('<th colspan="'+count+'" data-group="'+escapeHtml(last)+'">'+escapeHtml(last||L('Detay','Detail'))+'</th>');};
  columns.forEach(col=>{const group=clean(col.group)||L('Detay','Detail');if(count&&group!==last){flush();count=0;}last=group;count++;});
  flush();
  return '<tr class="blDetailGroupRow">'+(showImages?'<th class="blDetailImageHead" aria-hidden="true"></th>':'')+cells.join('')+'</tr>';
}
function registerAssetScope(panel,rows,imageIndex){
  const helper=root.BLDetailImages;if(!helper?.registerScope)return;
  try{
    helper.registerScope(panel,{
      contextType:'shared-detail-drawer',label:active.title,imageIndex,
      identities:rows.map(row=>({...modelIdentity(row),rowId:rowKey(row)})),
      repaint:render
    });
  }catch(err){console.warn('Detay çekmecesi model varlık kapsamı kaydedilemedi:',err);}
}
function renderColumnsPanel(){
  const host=document.querySelector('#blSharedDetailDrawer [data-bl-detail-column-panel]');
  if(!host||!active)return;
  const selected=new Set(active.visible);if(active.requiredVisible)active.requiredVisible.forEach(key=>selected.add(key));
  host.innerHTML='<div class="blDetailColumnPanelHead"><b>'+escapeHtml(L('Görünen sütunlar','Visible columns'))+'</b><button type="button" data-bl-detail-column-all>'+escapeHtml(L('Tümü','All'))+'</button></div>'+
    '<div class="blDetailColumnList">'+active.columns.map(col=>{const required=Boolean(active.requiredVisible&&active.requiredVisible.has(col.key));return '<label><input type="checkbox" value="'+escapeHtml(col.key)+'"'+(selected.has(col.key)?' checked':'')+(required?' disabled title="'+escapeHtml(L('Bu sütun seçili alt detay metriğidir ve her zaman görünür.','This is the selected drill-down metric and is always visible.'))+'"':'')+'><span>'+escapeHtml(col.label)+'</span></label>';}).join('')+'</div>';
  host.querySelectorAll('input[type="checkbox"]').forEach(input=>input.addEventListener('change',()=>{
    const keys=[...host.querySelectorAll('input[type="checkbox"]:checked')].map(x=>x.value);
    if(!keys.length){input.checked=true;return;}
    active.visible=keys;active.preset='custom';saveVisible(active.scope,active.pageScope,keys);savePreset();renderTable();syncViewPresetButtons();
  }));
  host.querySelector('[data-bl-detail-column-all]')?.addEventListener('click',()=>{
    active.visible=active.columns.map(c=>c.key);active.preset=active.tableSetup||active.viewPresets?'all':'custom';saveVisible(active.scope,active.pageScope,active.visible);savePreset();renderTable();renderColumnsPanel();syncViewPresetButtons();
  });
}
function reportColumns(){
  if(!active)return[];
  const current=currentColumns();
  if(active.flatColumns)return current.map(col=>{const schema=columnSchema(col,active.rows);const numeric=col.type==='number'||Boolean(schema&&['integer','quantity','decimal','currency'].includes(schema.dataType));return {...col,fields:[col],reportRole:numeric?'number':'field'};});
  const labels={identity:L('Sipariş / Model','Order / Model'),buyer:L('Buyer / Grup','Buyer / Group'),supplier:L('Üretici / Sezon','Manufacturer / Season'),status:L('Durum / Portföy','Status / Portfolio'),context:L('Sevkiyat / Rota','Shipment / Route')};
  return root.BLDetailReportLayout.project(current,detailModule(),root.BLCanonicalFields,labels);
}
function reportCell(col,row){
  const parts=col.fields.map(field=>{
    const text=clean(textValue(field,row));if(!text||text==='—')return null;
    let html=escapeHtml(text);
    if(typeof field.html==='function'){try{html=field.html(row)||html;}catch(_){} }
    else{
      const linked=root.BLDetailLinks?.cellHtml?.({column:field.key,label:field.label,value:rawValueOf(field,row),displayValue:text,row,plmId:modelIdentity(row).plmId});
      if(linked!=null)html=linked;
    }
    return {field,text,html};
  }).filter(Boolean);
  if(!parts.length)return '—';
  const primary=parts[0],secondary=parts.slice(1);
  const span=part=>'<span title="'+escapeHtml(part.field.label+': '+part.text)+'">'+(col.reportRole==='buyer'&&root.BLDetailReportLayout?.fieldId(part.field,detailModule(),root.BLCanonicalFields)==='mag'?'MAG: ':'')+part.html+'</span>';
  return '<div class="blDetailReportPrimary">'+(col.reportRole==='status'?'<span class="blDetailReportBadge">'+primary.html+'</span>':span(primary))+'</div>'+
    (secondary.length?'<div class="blDetailReportSub">'+secondary.map(span).join(' · ')+'</div>':'');
}
function renderReportStats(rows){
  const stats=document.querySelector('#blSharedDetailDrawer [data-bl-detail-stats]');if(!stats||!active)return;
  const layout=root.BLDetailReportLayout,moduleId=detailModule(),canonical=root.BLCanonicalFields;
  const find=id=>active.columns.find(col=>layout.fieldId(col,moduleId,canonical)===id);
  const unique=col=>new Set(rows.map(row=>clean(rawValueOf(col,row))).filter(value=>value&&value!=='—')).size;
  const order=find('orderCode'),plm=find('plmId'),model=find('modelName');
  const quantity=(moduleId==='backlog'?find('shipmentQuantity'):null)||find('orderQuantity')||find('collectionQuantity');
  const cards=[{value:rows.length,label:L('satır','lines')}];
  if(order)cards.push({value:unique(order),label:L('sipariş','orders')});
  if(plm||model)cards.push({value:new Set(rows.map(row=>(plm&&clean(rawValueOf(plm,row)))||(model&&clean(rawValueOf(model,row)))).filter(value=>value&&value!=='—')).size,label:L('model','models')});
  if(quantity){
    const values=rows.map(row=>rawValueOf(quantity,row)).map(value=>root.BLColumnSchema?.parseNumber?root.BLColumnSchema.parseNumber(value):(typeof value==='number'?value:null)).filter(value=>typeof value==='number'&&Number.isFinite(value));
    if(values.length)cards.unshift({value:values.reduce((sum,value)=>sum+value,0),label:quantity.label});
  }
  stats.innerHTML=cards.map(card=>'<div><b>'+escapeHtml(card.value.toLocaleString(isEn()?'en-GB':'tr-TR',{maximumFractionDigits:2}))+'</b><span>'+escapeHtml(card.label)+'</span></div>').join('');
}
/* Hücre seçimi ve Ctrl+C: CP/Orders ile aynı ortak motor (BLGridClipboard).
   Satır kimliği render sırasından değil satır nesnesinden gelir; arama/filtre
   sonrasında seçim başka bir kayda kaymaz. Kopya metni ekrandaki rapor
   hücresinin düz metnidir (birleşik sütunlarda alanlar " · " ile ayrılır). */
const CLIPBOARD_TABLE_ID='blDetailTable';
let clipboardRegistered=false;
function rowKey(row){
  if(!active||!row||typeof row!=='object')return '';
  let id=active.rowIds.get(row);
  if(id==null){active.rowSeq+=1;id=String(active.rowSeq);active.rowIds.set(row,id);}
  return id;
}
function reportCellText(col,row){
  if(!col||!row)return '';
  return (col.fields||[col]).map(field=>clean(textValue(field,row))).filter(text=>text&&text!=='—').join(' · ');
}
async function writeClipboard(html,plain){
  if(typeof root.BLCopyRichToClipboard==='function')return root.BLCopyRichToClipboard(html,plain);
  try{await root.navigator.clipboard.writeText(plain);return true;}catch(_){return false;}
}
function registerClipboard(){
  const grid=root.BLGridClipboard;
  if(clipboardRegistered||!grid?.register||!root.BLTableExport)return;
  clipboardRegistered=true;
  grid.register(CLIPBOARD_TABLE_ID,{
    priority:10,
    label:()=>L('Detay raporu veri tablosu','Detail report data grid'),
    isActive:()=>Boolean(active&&document.getElementById(CLIPBOARD_TABLE_ID)),
    rows:()=>active&&active.renderedRows||[],
    columns:()=>active&&active.renderedColumns||[],
    rowId:row=>rowKey(row),
    ensureVisible:cell=>document.getElementById(CLIPBOARD_TABLE_ID)?._blEnsureVisible?.(cell),
    columnId:col=>col&&col.key,
    header:col=>col&&col.label||'',
    value:(row,col)=>reportCellText(col,row),
    exporter:root.BLTableExport,
    copy:async(matrix,range,_state,options={})=>{
      const payload=grid.serialize(matrix,root.BLTableExport,options),ok=await writeClipboard(payload.html,payload.plain),size=grid.selectionSize(range);
      grid.diagnostics?.record?.({module:'detail',operation:'copy',selection:size,includeHeaders:payload.includeHeaders,transport:'rich',ok});
      root.showToast?.(ok?(payload.includeHeaders?L(size.label+' hücre başlıklarıyla kopyalandı.',size.label+' cells copied with headers.'):L(size.label+' hücre kopyalandı.',size.label+' cells copied.')):L('Kopyalama başarısız.','Copy failed.'));
      return ok;
    },
  });
}
function releaseVirtualBody(table){
  const body=table?.tBodies?.[0];
  if(body){body._virtualState=null;if(typeof _pendingTableRenders!=='undefined')_pendingTableRenders.delete(body);}
  if(table){table._blFinishNative=null;table._blEnsureVisible=null;table._blAfterVirtualPaint=null;}
}
function renderTable(){
  const host=document.getElementById('blSharedDetailDrawer');if(!host||!active)return;
  const table=host.querySelector('[data-bl-detail-table]'),summary=host.querySelector('[data-bl-detail-summary]');if(!table)return;
  releaseVirtualBody(table);
  active.imageIdentities=new WeakMap();
  active.backlogLookupPlans=active.source==='backlog'?new WeakMap():null;
  const rows=filteredRows(),columns=reportColumns(),helper=root.BLDetailImages;
  const imageIndex=helper?.buildIndex?helper.buildIndex():null,showImages=active.images&&Boolean(helper);
  const shown=rows.slice(0,Math.max(RENDER_CHUNK,active.limit||RENDER_CHUNK)),rest=rows.length-shown.length,hasRowActions=active.rowActions.length>0,colspan=Math.max(1,columns.length+(showImages?1:0)+(hasRowActions?1:0));
  active.renderedRows=shown;active.renderedColumns=columns;
  table.querySelector('colgroup').innerHTML=(hasRowActions?'<col style="width:120px">':'')+(showImages?'<col class="blDetailImageCol" style="width:74px">':'')+columns.map(col=>'<col style="width:'+columnWidth(col)+'px">').join('');
  applyTableWidth(table,columns,showImages);
  table.querySelector('thead').innerHTML=(active.flatColumns&&!hasRowActions?groupHeaderHtml(columns,showImages):'')+'<tr class="blDetailColumnRow">'+(hasRowActions?'<th>'+escapeHtml(L('İşlem','Action'))+'</th>':'')+(showImages?'<th class="blDetailImageHead">'+escapeHtml(L('Görsel','Image'))+'</th>':'')+columns.map(col=>{
    const filtered=col.fields.some(field=>active.filters.has(field.key));
    return '<th data-key="'+escapeHtml(col.key)+'" class="'+(col.reportRole==='number'?'blDetailNumeric ':'')+(filtered?'columnFilterActive':'')+'"><div class="blDetailReportHeading"><span>'+escapeHtml(col.label)+'</span>'+
      '<details class="blDetailReportFilter"><summary aria-label="'+escapeHtml(L('Alanları filtrele','Filter fields')+': '+col.label)+'">▾</summary><div>'+col.fields.map(field=>'<button type="button" data-bl-detail-filter="'+escapeHtml(field.key)+'"'+(active.filters.has(field.key)?' class="filterActive"':'')+'>'+escapeHtml(field.label)+'</button>').join('')+'</div></details></div>'+
      '<span class="colResizer" data-bl-detail-col-resize="'+escapeHtml(col.key)+'" title="'+escapeHtml(L('Sürükleyerek genişliği ayarla · çift tıklayarak sığdır','Drag to resize · double-click to fit'))+'"></span></th>';
  }).join('')+'</tr>';
  bindColumnResize(table);
  const rowCells=(row,index)=>(hasRowActions?'<td class="blDetailRowActions">'+active.rowActions.map((action,actionIndex)=>'<button type="button" class="blDetailTool" data-bl-detail-row-action="'+actionIndex+'" data-bl-detail-row="'+index+'"'+(action.disabled?.(row)?' disabled':'')+'>'+escapeHtml(action.label)+'</button>').join('')+'</td>':'')+(showImages?'<td class="blDetailImageCell">'+imageCell(row,imageIndex)+'</td>':'')+columns.map((col,colIndex)=>'<td class="'+(col.reportRole==='number'?'blDetailNumeric':'')+'" data-key="'+escapeHtml(col.key)+'" data-r="'+index+'" data-c="'+colIndex+'">'+reportCell(col,row)+'</td>').join('');
  const rowHtml=(row,index)=>'<tr data-id="'+escapeHtml(rowKey(row))+'">'+rowCells(row,index)+'</tr>';
  const moreCells='<td class="blDetailMore" colspan="'+colspan+'"><button type="button" class="blDetailTool" data-bl-detail-more>'+escapeHtml(L('Daha fazla göster','Show more'))+' · '+rest.toLocaleString(isEn()?'en-GB':'tr-TR')+' '+escapeHtml(L('satır kaldı','rows left'))+'</button></td>';
  const more=rest>0?{}:null,viewRows=more?shown.concat(more):shown;
  const html=()=>shown.map(rowHtml).join('')+(more?'<tr data-bl-virtual-index="'+shown.length+'">'+moreCells+'</tr>':'');
  const tbody=table.querySelector('tbody');
  if(active.source==='backlog'&&rows.length>RENDER_CHUNK&&typeof root.setupVirtualizedBody==='function'&&root.BLGridClipboard?.withNativeSelection){
    const cache=new Map();
    root.setupVirtualizedBody(tbody,table,viewRows,(row,index)=>{
      if(cache.has(index))return cache.get(index);
      const tr=document.createElement('tr');tr.dataset.blVirtualIndex=String(index);
      if(row!==more)tr.dataset.id=rowKey(row);
      tr.innerHTML=row===more?moreCells:rowCells(row,index);cache.set(index,tr);return tr;
    },colspan);
    const virtual=tbody._virtualState,paint=virtual.paint,scrollHost=table.parentElement;
    const paintGrid=()=>{
      if(root.BLGridClipboard.state(CLIPBOARD_TABLE_ID)?.activeCell)root.BLGridClipboard.afterRender(CLIPBOARD_TABLE_ID);
      tbody.querySelectorAll('tr[data-id]').forEach(tr=>{
        const rowIndex=String(Number(tr.dataset.blVirtualIndex)+2);
        if(tr.getAttribute('aria-rowindex')!==rowIndex)tr.setAttribute('aria-rowindex',rowIndex);
        if(tr.getAttribute('role')!=='row')tr.setAttribute('role','row');
        tr.querySelectorAll('td[data-key]').forEach((td,index)=>{
          if(td.getAttribute('aria-rowindex')!==rowIndex)td.setAttribute('aria-rowindex',rowIndex);
          if(td.getAttribute('role')!=='gridcell'){td.setAttribute('role','gridcell');td.setAttribute('aria-colindex',String(index+1));td.setAttribute('aria-selected','false');}
        });
      });
    };
    table._blAfterVirtualPaint=paintGrid;
    const finish=()=>{
      if(tbody._virtualState!==virtual)return;
      tbody._virtualState=null;if(typeof _pendingTableRenders!=='undefined')_pendingTableRenders.delete(tbody);
      tbody.innerHTML=html();tbody.querySelectorAll('tr').forEach((tr,index)=>{tr.dataset.blVirtualIndex=String(index);});cache.clear();paintGrid();
    };
    table._blFinishNative=()=>tbody._virtualState===virtual&&root.BLGridClipboard.withNativeSelection(table,finish);
    if(typeof _pendingTableRenders!=='undefined')_pendingTableRenders.set(tbody,()=>{if(!table._blFinishNative?.())finish();});
    virtual.paint=(...args)=>{
      if(table._blFinishNative())return;
      paint(...args);paintGrid();
      for(const index of cache.keys())if(index<virtual.renderedStart-15||index>=virtual.renderedEnd+15)cache.delete(index);
    };
    table._blEnsureVisible=cell=>{
      if(tbody._virtualState!==virtual)return;
      const index=shown.findIndex(row=>rowKey(row)===cell.rowId);
      if(index<0)return;
      const row=tbody.querySelector('tr[data-id="'+cell.rowId+'"]'),hostRect=scrollHost.getBoundingClientRect(),rowRect=row?.getBoundingClientRect();
      if(rowRect&&rowRect.top>=hostRect.top+table.tHead.getBoundingClientRect().height&&rowRect.bottom<=hostRect.bottom)return;
      scrollHost.scrollTop=index*virtual.rowHeight;virtual.paint();
    };
  }else tbody.innerHTML=shown.length?html():'<tr><td class="blDetailEmpty" colspan="'+colspan+'">'+escapeHtml(L('Gösterilecek satır yok.','No rows to display.'))+'</td></tr>';
  if(summary)summary.textContent=(active.subtitle?active.subtitle+' · ':'')+rows.length.toLocaleString(isEn()?'en-GB':'tr-TR')+' '+L('satır','rows');
  renderReportStats(rows);syncFilterTools();registerAssetScope(host.querySelector('.blDetailDrawerPanel'),rows,imageIndex);
  registerClipboard();root.BLGridClipboard?.afterRender?.(CLIPBOARD_TABLE_ID);
  table._blAfterVirtualPaint?.();
}

function downloadBuffer(buffer,name,mime){
  const helper=root.BLDetailImages;
  if(helper?.downloadBuffer){helper.downloadBuffer(buffer,name,mime);return;}
  const blob=new Blob([buffer],{type:mime}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
async function exportExcelJsWithImages(columns,rows,fileName,operation){
  const helper=root.BLDetailImages;
  if(!active.images||!helper?.prepareForExcel||!helper?.addToExcel)return false;
  if(root.BLPerf?.ensureLibrary)await root.BLPerf.ensureLibrary('exceljs');
  operation.check();
  if(!root.ExcelJS)return false;
  const wb=new root.ExcelJS.Workbook(),ws=wb.addWorksheet(L('Detay','Detail')),imageIndex=helper.buildIndex?.();
  ws.columns=[{header:L('Görsel','Image'),key:'__image',width:12},...columns.map((col,index)=>({header:col.label,key:'c'+index,width:Math.max(11,Math.min(40,Number(col.exportWidth)||18))}))];
  const head=ws.getRow(1);head.height=22;head.font={bold:true};head.alignment={vertical:'middle',wrapText:true};
  for(let start=0;start<rows.length;start+=200){
    operation.check();rows.slice(start,start+200).forEach(row=>{const excelRow=ws.addRow(['',...columns.map(col=>excelValueOf(col,row))]);excelRow.height=48;columns.forEach((col,index)=>{const fmt=excelFormatOf(col,row);if(fmt)excelRow.getCell(index+2).numFmt=fmt;});});
    operation.checkpoint(Math.min(rows.length,start+200),L('Satırlar hazırlanıyor','Preparing rows'));await operation.yield();
  }
  for(let start=0;start<rows.length;start+=8){
    const slice=rows.slice(start,start+8);
    const prepared=await Promise.all(slice.map(async row=>{const url=imageUrl(row,imageIndex);if(!url)return null;try{return await helper.prepareForExcel(url);}catch(_){return null;}}));
    operation.check();
    prepared.forEach((image,offset)=>{if(image)helper.addToExcel(ws,wb,image,start+offset+2,1,null,{moveAndSizeWithCells:true});});
    operation.checkpoint(rows.length+Math.min(rows.length,start+8),L('Görseller hazırlanıyor','Preparing images'));await operation.yield();
  }
  ws.views=[{state:'frozen',ySplit:1}];
  if(rows.length)ws.autoFilter={from:{row:1,column:1},to:{row:rows.length+1,column:Math.max(1,columns.length+1)}};
  root.BLExcelDates?.normalizeExcelJsWorkbookDateColumns?.(wb);
  operation.checkpoint(rows.length*2,L('Excel paketleniyor · iptal indirmeyi durdurur','Packing Excel · cancel prevents download'),{indeterminate:true});
  const buffer=await wb.xlsx.writeBuffer();
  operation.check();
  downloadBuffer(buffer,fileName,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  return true;
}
function applyPanelWidth(panel){
  if(!panel||!active||root.innerWidth<=760)return;
  const max=Math.max(420,root.innerWidth-24),width=Math.min(max,Math.max(420,Number(active.width)||panel.getBoundingClientRect().width||980));
  panel.style.width=Math.round(width)+'px';
}
function bindResize(panel){
  const handle=panel&&panel.querySelector('[data-bl-detail-resize]');
  if(!handle||root.innerWidth<=760)return;
  handle.addEventListener('pointerdown',event=>{
    event.preventDefault();
    const startX=event.clientX,startWidth=panel.getBoundingClientRect().width;
    const move=ev=>{
      const max=Math.max(420,root.innerWidth-24);
      const next=Math.min(max,Math.max(420,startWidth+(startX-ev.clientX)));
      active.width=next;panel.style.width=Math.round(next)+'px';
    };
    const end=()=>{
      root.removeEventListener('pointermove',move);root.removeEventListener('pointerup',end);
      if(active&&active.width)saveWidth(active.pageScope,active.width);
      document.body.classList.remove('blDetailResizing');
    };
    document.body.classList.add('blDetailResizing');
    root.addEventListener('pointermove',move);root.addEventListener('pointerup',end,{once:true});
  });
}
function toggleExportMenu(){
  const menu=document.querySelector('#blSharedDetailDrawer [data-bl-detail-export-menu]');
  if(menu)menu.hidden=!menu.hidden;
}
async function exportExcel(mode='visible'){
  if(!active||active.exportOperation)return;
  const report=active;
  const button=document.querySelector('#blSharedDetailDrawer [data-bl-detail-excel]'),old=button&&button.textContent;
  const columns=mode==='all'?active.columns:currentColumns(),rows=filteredRows(),fileName=safeFilePart(active.fileName||active.title)+'.xlsx';
  const images=report.images&&root.BLDetailImages?.prepareForExcel&&root.BLDetailImages?.addToExcel;
  const operation=root.BLUI.createProgress({total:Math.max(1,rows.length*(images?2:1)),onProgress:value=>{
    if(active!==report)return;report.exportProgress=value;
    root.BLUI.renderProgress(document.querySelector('#blSharedDetailDrawer [data-bl-detail-progress]'),{...value,language:isEn()?'en':'tr',cancellable:!report.exporter||report.exporter.cancellable===true,onCancel:()=>operation.cancel()});
  }});
  report.exportOperation=operation;
  if(button){button.disabled=true;button.textContent=L('Hazırlanıyor…','Preparing…');}
  try{
    operation.checkpoint(0,L('Dışa aktarım hazırlanıyor','Preparing export'),{indeterminate:Boolean(report.exporter)});await operation.yield();
    if(typeof active.exporter==='function'){
      await active.exporter({rows,columns,includeImages:active.images,fileName,title:active.title,source:active.source,valueOf,signal:operation.signal,onProgress:value=>operation.checkpoint(value.completed,value.label,{indeterminate:value.indeterminate})});
    }else if(!(await exportExcelJsWithImages(columns,rows,fileName,operation))){
      if(!root.XLSX&&root.BLPerf?.ensureLibrary)await root.BLPerf.ensureLibrary('xlsx');
      operation.check();
      if(!root.XLSX)throw new Error(L('Excel kütüphanesi yüklenemedi.','Excel library could not be loaded.'));
      const data=[columns.map(c=>c.label)];
      for(let start=0;start<rows.length;start+=200){operation.check();rows.slice(start,start+200).forEach(row=>data.push(columns.map(col=>excelValueOf(col,row))));operation.checkpoint(Math.min(rows.length,start+200),L('Satırlar hazırlanıyor','Preparing rows'));await operation.yield();}
      const ws=root.XLSX.utils.aoa_to_sheet(data,{cellDates:true});
      rows.forEach((row,rowIndex)=>columns.forEach((col,colIndex)=>{const fmt=excelFormatOf(col,row);if(!fmt)return;const ref=root.XLSX.utils.encode_cell({r:rowIndex+1,c:colIndex}),cell=ws[ref];if(cell)cell.z=fmt;}));
      if(data.length&&columns.length)ws['!autofilter']={ref:root.XLSX.utils.encode_range({r:0,c:0},{r:Math.max(0,data.length-1),c:columns.length-1})};
      ws['!cols']=columns.map(col=>({wch:Math.max(11,Math.min(40,Number(col.exportWidth)||18))}));
      const wb=root.XLSX.utils.book_new();root.XLSX.utils.book_append_sheet(wb,ws,L('Detay','Detail'));
      operation.checkpoint(rows.length,L('Excel paketleniyor · iptal indirmeyi durdurur','Packing Excel · cancel prevents download'),{indeterminate:true});await operation.yield();
      const buffer=root.XLSX.write(wb,{type:'array',bookType:'xlsx'});operation.check();
      downloadBuffer(buffer,fileName,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }
    operation.check();
    root.showToast?.(mode==='all'?L('Detay satırları tüm sütunlarla Excel’e aktarıldı.','Detail rows were exported to Excel with all columns.'):L('Görünen detay satırları ve seçili sütunlar Excel’e aktarıldı.','Visible detail rows and selected columns were exported to Excel.'));
  }catch(err){if(active===report)root.BLUI.renderState(document.querySelector('#blSharedDetailDrawer [data-bl-detail-progress]'),{kind:err?.name==='AbortError'?'info':'error',title:err?.name==='AbortError'?L('Dışa aktarım iptal edildi. Dosya indirilmedi.','Export cancelled. No file was downloaded.'):String(err?.message||err)});}
  finally{report.exportOperation=null;if(active===report){const liveButton=document.querySelector('#blSharedDetailDrawer [data-bl-detail-excel]');if(liveButton){liveButton.disabled=false;liveButton.textContent=old||'⇩ Excel';}if(!operation.signal.aborted){const progress=document.querySelector('#blSharedDetailDrawer [data-bl-detail-progress]');if(progress&&!progress.querySelector('.uiState--error'))progress.hidden=true;}}}
}
function render(){
  const host=ensureHost();if(!active){host.classList.remove('is-open');host.setAttribute('aria-hidden','true');return;}
  root.BLLayerSystem?.closeDialog?.(host,{restoreFocus:false});
  releaseVirtualBody(host.querySelector('[data-bl-detail-table]'));
  host.innerHTML='<div class="blDetailDrawerBackdrop" data-bl-detail-close></div><section class="blDetailDrawerPanel" role="dialog" aria-modal="true" aria-labelledby="blDetailDrawerTitle">'+
    '<div class="blDetailResizeHandle" data-bl-detail-resize title="'+escapeHtml(L('Genişliği değiştirmek için sürükleyin','Drag to resize'))+'"></div>'+
    '<header class="blDetailDrawerHead"><div class="blDetailDrawerTitle"><b id="blDetailDrawerTitle">'+escapeHtml(active.title)+'</b><span data-bl-detail-summary></span></div>'+
    '<div class="blDetailDrawerActions"><button type="button" class="blDetailTool" data-bl-detail-images aria-pressed="'+(active.images?'true':'false')+'">▧ '+escapeHtml(L('Görseller','Images'))+'</button>'+
    '<span data-bl-detail-plm></span><button type="button" class="blDetailTool" data-bl-detail-columns>☷ '+escapeHtml(L('Sütunlar','Columns'))+'</button>'+
    '<button type="button" class="blDetailTool" data-bl-detail-excel>⇩ Excel</button>'+
    '<div class="blDetailExportMenu" data-bl-detail-export-menu hidden><button type="button" data-bl-export-mode="all">'+escapeHtml(L('Tüm Sütunlarla','All Columns'))+'</button><button type="button" data-bl-export-mode="visible">'+escapeHtml(L('Görünen Sütunlarla','Visible Columns'))+'</button></div>'+
    '<button type="button" class="blDetailClose" data-bl-detail-close aria-label="'+escapeHtml(L('Kapat','Close'))+'">×</button></div></header>'+
    '<div class="blDetailDrawerSubbar">'+viewPresetHtml()+'<input type="search" data-bl-detail-search value="'+escapeHtml(active.search)+'" placeholder="'+escapeHtml(L('Detaylarda ara…','Search details…'))+'">'+
    '<button type="button" class="blDetailTool" data-bl-detail-fit title="'+escapeHtml(L('Tüm sütunları en dar okunabilir genişliğe getir','Fit all columns to the narrowest readable width'))+'">⇔ '+escapeHtml(L('Sütunları Sığdır','Fit Column Width'))+'</button>'+
    '<button type="button" class="blDetailTool" data-bl-detail-clear-filters hidden></button>'+
    '<div class="blDetailExtraActions" data-bl-detail-extra></div><div class="blDetailColumnPanel" data-bl-detail-column-panel hidden></div></div>'+
    '<div class="blDetailReportStats" data-bl-detail-stats></div><div class="blDetailReportAccent"></div>'+
    (active.note?'<div class="blDetailDrawerNote">'+escapeHtml(active.note)+'</div>':'')+
    '<div class="uiProgressRegion" data-bl-detail-progress hidden></div><div class="blDetailTableWrap"><table class="blDetailTable" id="blDetailTable" data-bl-detail-table><colgroup></colgroup><thead></thead><tbody></tbody></table></div></section>';
  host.classList.add('is-open');host.setAttribute('aria-hidden','false');
  const panel=host.querySelector('.blDetailDrawerPanel');applyPanelWidth(panel);bindResize(panel);
  host.querySelectorAll('[data-bl-detail-close]').forEach(el=>el.addEventListener('click',close));
  host.querySelector('[data-bl-detail-search]')?.addEventListener('input',event=>{
    // Sorgu hemen state'e yazılır (Excel/yeniden çizim aynı sorguyu görür); yalnız tablo çizimi gecikir.
    if(!active)return;active.search=event.target.value;active.limit=RENDER_CHUNK;if(active.searchTimer)clearTimeout(active.searchTimer);
    active.searchTimer=setTimeout(()=>{if(!active)return;active.searchTimer=0;renderTable();},120);
  });
  host.querySelector('[data-bl-detail-table]')?.addEventListener('click',event=>{
    if(!active)return;
    const rowButton=event.target.closest('[data-bl-detail-row-action]');
    if(rowButton){
      event.preventDefault();event.stopPropagation();
      const report=active,row=report.renderedRows[Number(rowButton.dataset.blDetailRow)],action=report.rowActions[Number(rowButton.dataset.blDetailRowAction)];
      if(!row||!action||rowButton.disabled)return;
      rowButton.disabled=true;
      Promise.resolve().then(()=>action.run(row)).then(removed=>{
        if(active!==report)return;
        if(removed===true){report.rows=report.rows.filter(item=>item!==row);report.searchIndex=null;report.filterCache=null;report.autoWidths=null;}
        renderTable();
      }).catch(error=>{if(active===report){rowButton.disabled=false;root.showToast?.(error.message||L('Not silinemedi.','Could not delete the note.'));}});
      return;
    }
    const filterButton=event.target.closest('[data-bl-detail-filter]');
    if(filterButton){event.preventDefault();event.stopPropagation();const menu=filterButton.closest('details');if(menu)menu.open=false;openColumnFilter(filterButton.dataset.blDetailFilter,filterButton);return;}
    if(!event.target.closest('[data-bl-detail-more]'))return;active.limit=(active.limit||RENDER_CHUNK)+RENDER_CHUNK;renderTable();
  });
  host.querySelector('[data-bl-detail-fit]')?.addEventListener('click',fitAllColumns);
  host.querySelector('[data-bl-detail-clear-filters]')?.addEventListener('click',clearColumnFilters);
  host.querySelector('[data-bl-detail-images]')?.addEventListener('click',()=>{active.images=!active.images;render();});
  host.querySelector('[data-bl-detail-columns]')?.addEventListener('click',()=>{
    const panel=host.querySelector('[data-bl-detail-column-panel]');panel.hidden=!panel.hidden;if(!panel.hidden)renderColumnsPanel();
  });
  host.querySelectorAll('[data-bl-detail-view-preset]').forEach(button=>button.addEventListener('click',()=>{
    if(applyViewPreset(button.dataset.blDetailViewPreset)){render();syncViewPresetButtons();}
  }));
  host.querySelector('[data-bl-detail-excel]')?.addEventListener('click',toggleExportMenu);
  host.querySelectorAll('[data-bl-export-mode]').forEach(button=>button.addEventListener('click',()=>{
    const menu=host.querySelector('[data-bl-detail-export-menu]');if(menu)menu.hidden=true;
    void exportExcel(button.dataset.blExportMode==='all'?'all':'visible');
  }));
  const extra=host.querySelector('[data-bl-detail-extra]');
  (active.actions||[]).forEach(action=>{
    const button=document.createElement('button');button.type='button';button.className='blDetailTool';button.textContent=action.label||L('Aç','Open');
    button.addEventListener('click',()=>{try{action.run?.(filteredRows(),active);}catch(err){console.warn(err);}});extra.appendChild(button);
  });
  const plm=host.querySelector('[data-bl-detail-plm]');
  if(root.BLDetailImages?.modelImagesButtonHtml&&root.BLDetailImages?.bindModelImagesButton){
    const id='blSharedDetailModelImages';plm.innerHTML=root.BLDetailImages.modelImagesButtonHtml(id);root.BLDetailImages.bindModelImagesButton(id);
  }else if(plm)plm.hidden=true;
  renderTable();
  root.BLLayerSystem?.openDialog?.(host,{trigger:active.trigger,onClose:close,initialFocus:'[data-bl-detail-search]'});
  if(active.exportOperation){host.querySelector('[data-bl-detail-excel]').disabled=true;if(active.exportProgress)root.BLUI.renderProgress(host.querySelector('[data-bl-detail-progress]'),{...active.exportProgress,language:isEn()?'en':'tr',cancellable:!active.exporter||active.exporter.cancellable===true,onCancel:()=>active?.exportOperation?.cancel()});}
}
function open(options){
  const input=options&&typeof options==='object'?options:{};
  const trigger=input.trigger||active?.trigger||document.activeElement;
  if(active)close({restoreFocus:false});
  const rows=Array.isArray(input.rows)?input.rows.filter(Boolean):[];
  const setup=tableSetupSnapshot(input);
  const contextColumns=normalizeColumns(input.columns,rows);
  const setupColumns=setup?normalizeColumns(setup.columns,rows):[];
  const contextKeys=setup?contextColumns.map(col=>col.key).filter(key=>!setupColumns.some(col=>col.key===key)):[];
  const scope=input.storageKey||input.scope||input.source||'generic',page=pageScope(input);
  const suppliedColumns=setup?normalizeColumns([...setupColumns,...contextColumns.filter(col=>!setupColumns.some(base=>base.key===col.key))],rows):contextColumns;
  const columns=input.flatColumns===true?suppliedColumns:includeMagColumn(rows,suppliedColumns,input.moduleId||input.source||page,root.BLCanonicalFields);
  const canonical=root.BLCanonicalFields,moduleId=input.moduleId||input.source||page;
  const requestedDefaults=Array.isArray(input.defaultVisible||input.initialVisible)?(input.defaultVisible||input.initialVisible):[];
  const exactDefault=input.exactDefaultVisible===true?requestedDefaults.filter(key=>columns.some(col=>col.key===key)):[];
  const focus=[...new Set((exactDefault.length?exactDefault:root.BLDetailReportLayout.focusKeys(columns,moduleId,canonical,requestedDefaults)).concat(contextKeys))];
  const supplied=setup?{focus:setupPresetKeys(setup,'focus'),extended:setupPresetKeys(setup,'extended')}:normalizeViewPresets(input,columns);
  const extended=[...new Set(focus.concat(supplied?.extended||columns.slice(0,24).map(col=>col.key),contextKeys))];
  const viewPresets={focus,extended};
  let preset='focus';
  if(viewPresets){
    const saved=loadPreset(scope,page),fallback=['focus','extended','all'].includes(input.defaultPreset)?input.defaultPreset:'focus';
    preset=saved||fallback;
  }
  const initialVisible=viewPresets&&preset!=='custom'?(preset==='all'?columns.map(col=>col.key):viewPresets[preset])
    :loadVisible(scope,page,columns,input.defaultVisible||input.initialVisible);
  const allowed=new Set(columns.map(col=>col.key));
  const requiredVisible=[...new Set((Array.isArray(input.requiredVisible)?input.requiredVisible:[]).filter(key=>allowed.has(key)))];
  const visible=[...new Set(initialVisible.filter(key=>allowed.has(key)).concat(requiredVisible))];
  active={
    trigger,
    scope,pageScope:page,moduleId:input.moduleId||page,source:input.source||'shared-detail-drawer',
    title:clean(input.title)||L('Sipariş Detayları','Order Details'),
    subtitle:clean(input.subtitle),note:clean(input.note),fileName:input.fileName||input.title,
    rows,columns,visible,width:loadWidth(page)||Math.min(1600,root.innerWidth*0.96),
    tableSetup:null,viewPresets,contextKeys,preset,flatColumns:input.flatColumns===true,requiredVisible:new Set(requiredVisible),
    colWidths:loadColWidths(scope,page),autoWidths:null,filters:new Map(),filterVersion:0,
    rowIds:new WeakMap(),rowSeq:0,renderedColumns:[],
    images:input.images!==false,search:'',limit:RENDER_CHUNK,searchIndex:null,filterCache:null,searchTimer:0,actions:Array.isArray(input.actions)?input.actions:[],
    rowActions:Array.isArray(input.rowActions)?input.rowActions:[],
    exporter:typeof input.exporter==='function'?input.exporter:null
  };
  // Yeni rapor eski raporun hücre seçimini devralmaz (satır kimlikleri raporla sıfırlanır).
  root.BLGridClipboard?.clear?.(CLIPBOARD_TABLE_ID);
  render();
  requestAnimationFrame(()=>ensureHost().querySelector('[data-bl-detail-search]')?.focus());
}
function close(options={}){releaseVirtualBody(document.getElementById(CLIPBOARD_TABLE_ID));if(active&&active.searchTimer)clearTimeout(active.searchTimer);active?.exportOperation?.cancel();if(typeof root.closeHeaderFilter==='function')root.closeHeaderFilter();active=null;const host=document.getElementById('blSharedDetailDrawer');if(host){root.BLLayerSystem?.closeDialog?.(host,{restoreFocus:options.restoreFocus!==false});host.classList.remove('is-open');host.setAttribute('aria-hidden','true');}}
document.addEventListener('keydown',event=>{
  if(event.key!=='Escape'||!active)return;
  // Açık sütun filtresi paneli önce kapanır; çekmece ikinci Escape ile kapanır.
  if(document.querySelector('.colFilterPanel')){if(typeof root.closeHeaderFilter==='function')root.closeHeaderFilter();return;}
  close();
});
document.addEventListener('copy',event=>{
  if(!event.defaultPrevented&&!root.BLGridClipboard?.nativeEditingTarget(event.target))document.getElementById(CLIPBOARD_TABLE_ID)?._blFinishNative?.();
},true);
if(typeof root.MutationObserver==='function')new root.MutationObserver(()=>{if(active)render();}).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
return {open,close,inferColumns,normalizeColumns,safeFilePart,isOpen:()=>Boolean(active)};
});
